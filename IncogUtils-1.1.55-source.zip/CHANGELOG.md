## 1.1.55
- Updated the Claim Core Menu: magenta Claim Info, the claim owner's real player-head texture for Trusted Players, and an automatic close when Delete Claim is clicked.
- Updated the Market Main Menu: plain title, empty background, centered category controls, Nether Star All Items button at the top center, simplified Search compass, and a red Barrier Back to Main Menu button.
- Kept the claims expansion improvements from 1.1.53: free downgrades, permanent larger-size unlocks, automatic full-height protection at Large, and the Beacon full-height control.
- Added a project-local Maven repository configuration and fixed Paper API version so builds no longer depend on the machine-wide Maven cache.

## 1.1.52–1.1.54
- Added the six rank-based Daily Rewards tabs: Secret, Unknown, Ominous, Cryptic, Incog, and Incog+.
- Added the four-row Skills menu cleanup, centered bottom skills, diamond tool icons, real player-head support, and the simplified Skills back button.
- Added the four-row Player Settings menu with the PVP display preference shown periodically on the action bar.
- Updated Claims expansion navigation, persistent unlocked claim sizes, free resizing of unlocked tiers, and automatic full-height mode at Large.

## 1.1.51
- Changed the optional PVP action-bar status from a permanent display into a short periodic reminder.
- Added configurable PVP status display duration and reminder interval, defaulting to 5 seconds every 3 minutes.

## 1.1.50
- Centered all five Player Settings controls on one row, removed the comparator header, and moved the barrier Back button to the bottom-right slot.
- Changed the Player Settings PVP control into a display preference that shows or hides the player's current PVP state on the action bar without changing that state.
- The PVP Status control now uses a diamond sword while enabled and gray dye while disabled.

## 1.1.49
- Reduced the central `/menus` hub to four rows, removed its compass header, moved its controls upward, and centered Player Settings and UltraCosmetics.
- Removed artificial enchantment glints from central-menu and settings controls.
- Replaced the Skills, Claims, and PVP hub icons with an experience bottle, beacon, and diamond sword.
- Expanded Player Settings to four empty-background rows with a plain title, barrier Back button, and a saved PVP protection toggle.

## 1.1.48
- Simplified the `/menus` inventory title to the unformatted text `Main Menu`.
- Removed black stained-glass filler items from the central menu hub so unused slots remain empty.

## 1.1.47
- Fixed intermittent Peaceful/Aggressive markers in the player list by reconciling the displayed suffix every two seconds.
- Added direct optional integration with NEZNAMY TAB while preserving its existing rank suffix and avoiding duplicate playstyle markers.
- Added a Bukkit player-list fallback when TAB is absent or its tablist-formatting feature is disabled.
- Added `%incogutils_claims_playstyle_suffix%` for TAB-Bridge and other PlaceholderAPI consumers.

## 1.1.46
- Added `/settings` for per-player skill-progress, numeric-health, level-up, and achievement-notification preferences.
- Added `/adminsettings` for persistent global and per-feature player-access switches.
- Moved skill progress and numeric health back to one shared action bar.
- Standardized bundled module chat prefixes under the `IncogUtils • Feature` format while preserving custom prefixes.
- Added a `/menus` Back button to every root inventory menu.
- Made Peaceful/Aggressive LuckPerms suffixes self-repair after join and periodically while online.
- Corrected PvP protection so lava, fire, falls, drowning, suffocation, starvation, lightning, mobs, and other natural damage still apply.
- Expanded player-source detection to projectiles, tamed mobs, and player-placed TNT, including redstone-, fire-, and chain-primed TNT.

## 1.1.45
- Added configurable AFK-farm passive item-pickup throttling with lag-safe excess removal and an OP bypass permission.
- Added durable transaction logging to `logs/transactions.tsv`.
- Added `/shoplog <player|all> [page]` with buyer/seller player filtering.
- Logs server-market buys/sells, bulk sells, player-shop purchases, Auction House buy-now sales, and market-order fills.
- Added `incogshop.logs` (default: op).

# IncogUtils 1.1.42

- Added rarity-scaled market base pricing: common items such as cobblestone stay at 1x while progressively rarer items scale upward, with ultra-rare items reaching 231x (+23,000%).
- Added a one-time `market.yml` migration guarded by `meta.rarity-price-curve-1_1_42` so existing base prices are scaled exactly once.
- Added reversible-crafting anti-arbitrage caps using each player's effective rank-adjusted prices and transaction fees. This prevents loops such as buying Netherite Blocks, converting them into ingots, and selling the ingots for infinite profit.

# Changelog

## 1.1.40 - Multi-Reward Daily Rewards
- Added a dedicated per-day reward editor GUI.
- Each streak day can now contain up to 45 separate item-stack rewards.
- Added support for appending multiple console commands to one day without overwriting existing commands.
- Money, item stacks, and commands can all be combined on the same day.
- Added individual item removal, command clearing, and a full-day clear action.

## 1.1.39 - 30-Day Daily Rewards Editor

- `/daily admin` now exposes every reward day from Day 1 through Day 30 in the in-game editor.
- Added an in-game Streak Length control that accepts 1-30 days.
- Each active day can independently configure an item, money, and console-command reward.
- Existing seven-day configurations remain compatible and continue using the safe fallback pattern until later days are explicitly configured.

## 1.1.38 - Fall damage enforcement

- Restored normal player fall-damage events at high priority when an earlier
  plugin listener cancels them. This is enabled in every world by default.
- Kept the Acrobatics, pet, relic, and item fall-protection attributes, but
  clamp combined IncogUtils fall-damage reduction to a configurable positive
  minimum so it can never make a fall deal zero damage.

## 1.1.37 - Crossplay rank crown displays

- Added a configurable bridge for UltraCosmetics rank crowns. When one of the
  configured custom crown items is equipped, IncogUtils renders its matching
  resource-pack item display above the player's head.
- The bridge supports the included Java resource pack and Geyser custom-item
  mappings, removes displays on logout/reload, and recovers stale displays
  from an earlier plugin reload.

## 1.1.36 - Unified Creative Catalog

- Expanded `/itemforge catalog` to include every giveable custom item from the
  bundled modules: ItemForge, IncogRPG items/relics, configured custom-enchant
  books, Claims cores/Claim Breaker, Vault Regen Keys, and the Sell Wand.

## 1.1.35 - ItemForge creative catalog

- Added `/itemforge catalog`, a read-only, paged catalog that lets permitted
  creative builders take copies of every configured ItemForge custom item.
- Added `itemforge.catalog`; it does not grant ItemForge editor access.

## 1.1.34 - Monthly Daily Rewards

- Daily Rewards now supports a maximum 30-claim (one-month) streak cycle.
- Upgraded seven-day reward configurations repeat their existing weekly reward
  pattern until Days 8-30 are configured through `/daily admin`.

## 1.1.33 - PlaceholderAPI coverage

- Added the `%incogutils_...%` PlaceholderAPI expansion for player-facing claims,
  homes, economy, market events, daily rewards, XP vault, and Shopping District data.
- Kept all existing `%incogrpg_...%` placeholders unchanged.
- Added a full placeholder reference at `docs/PLACEHOLDERS.md`.

## 1.1.28

- Revised Shopping District connections to use one continuous paved surface
  across the hub and every allocated plot. Barriers now appear only on that
  surface's outer perimeter, never alongside internal paths.

## 1.1.27

- Connected every allocated Shopping District plot to the hub through
  lazy-materialized road corridors, while leaving all unused cells as void.
- Added configurable exposed-edge safety barriers. They form only around the
  outside of connected district terrain, never between plots and roads.

## 1.1.26

- Fixed Shopping District void protection pinning players to the hub platform.
  Players can now fly or teleport through the lazy-generated void between
  islands; only a fall below `generation.void-rescue-below-floor` returns them
  safely to the hub with fall distance cleared.

## 1.1.25

- Added ItemForge `max-durability` support in both the item editor and
  `itemforge/items.yml`. It uses Paper's native `MAX_DAMAGE` component so
  custom items begin at full durability and lose durability through normal
  Minecraft gameplay.
- Durable custom items now safely enforce a maximum stack size of one, as
  required by Minecraft. Existing `unbreakable` behavior remains available.

## 1.1.24

- Added `/regenkey <player> <normal|ominous> [amount]` with `/vaultregenkey`
  and `/vrkey` aliases. It gives the exact PDC-tagged Normal or Ominous Vault
  Regen Key that the vault listener recognizes, with online-player validation,
  tab completion, bounded quantities, and safe inventory-overflow drops.
- Added the `incogvaults.admin.keys` permission and made it a child of
  `incogvaults.admin`.
- Moved IncogVaults command wiring into the module-enable phase so both
  `/incogvaults` and the new key command are registered after the module exists.

## 1.1.23

- Converted Shopping District generation to lazy void islands: only the hub
  and allocated plots create terrain, with one expandable outer world border
  and a movement backstop for void between islands.
- Raised the paid plot system to a 40×40 starter, normal 50×50 cap, and
  configurable rank-gated purchase ceilings through 100×100. Rank access now
  unlocks a ceiling rather than granting a free expansion.
- Merged the uploaded branch's enchantment/table-loot updates with the latest
  market and Shopping District work instead of replacing either code path.
- Added Daily Market Flux: each Minecraft day, a configurable random number of
  market items independently roll Buy and Sell price multipliers from `0.80x`
  to `1.75x` by default. Selected items can receive either effect or both.
- Weekly Infinite Stock now recognizes configured LuckPerms group names as
  well as permission nodes, has safe tier fallbacks, and includes `/weeklystock`.
- Added safe Multiverse-Inventories integration for the Shopping District.
  IncogUtils discovers the existing Overworld group, adds the district world,
  and ensures the `inventory` share is enabled.
- Added a one-time migration that disables Shopping District PvP on existing
  configurations, backed by the world PvP flag and district damage listener.

## 1.1.15

- Added the fully configurable weekly rank-based Infinite Stock market event.
  The default schedule is Sunday 20:00 America/New_York, with a 90-minute
  (1.5-hour) duration and a suspense draw ten seconds before start.
- Added shared ranked access: Cryptic receives one selected material, Incog
  receives two, and Incog+ receives three by default; permissions, counts,
  schedule, duration, exclusions, and GUI display are configurable.
- Added private market/bazaar event cards that show a countdown before the draw
  and only the viewer's permitted selected materials once they are chosen.
- Added `/globalrestock` (`/marketrestock`, `/restockall`) to restore every
  market entry to `market.initial-stock` without altering price/demand tuning.
- Restored the Stick-based Sell Wand safeguards, legacy Blaze-Rod crafting
  block, and configurable PhoenixLobby/PDC namespace market-sale protection.

## Unreleased Shopping District refinements

- Added configurable, private `Your Shop` holograms above registered player
  shops in their owners' Shopping District plots. Labels are hidden from all
  non-owners and are removed on shop removal, plot sale, reload, and shutdown.
- Changed WorldEdit/FAWE schematic templates to paste one horizontal layer per
  tick by default, with a configurable `schematic-layers-per-tick` safety knob.
- Fixed Shopping District schematic pasting on WorldEdit 7.4.x by resolving
  `ClipboardHolder#createPaste` against the runtime `Extent` API while retaining
  compatibility with older WorldEdit builds.
- Added template, plot-sale, and schematic troubleshooting notes to the
  Shopping District documentation.
- Centered schematic templates using actual non-air content and grounded their
  lowest block at the plot floor, with per-template placement offsets and
  content-bound safeguards.
- Lowered every schematic paste position by one block without requiring an
  existing configuration edit (`y-offset: 0` now rests the lowest block at
  `floor-y`); use `y-offset: 1` to restore the old height for one template.
- Added safe plot-arrival scanning, so purchasing or visiting a plot cannot
  place a player inside a template wall, counter, or the public hub platform.
- Added persistent, unique player plot names; home, visit, info, expand, sell,
  and staff plot commands now accept a plot name or list number.
- Changed plot sales and staff force-sales to restore the entire plot column to
  default flat terrain by default, including hidden basements and non-player
  entities.

## 1.1.14

- Added the configurable Shopping District economy module.
- Added a procedurally generated flat market world with protected roads,
  allocated plots, owner-only building, container/hopper protection, disabled
  explosions/pistons/fluids/mob damage by default, and safe dropped-item rules.
- New players receive a starter plot automatically; players can expand plots up
  to the configured maximum or buy additional plots at escalating prices.
- Added `/shopdistrict` (`/sdistrict`, `/shoppingdistrict`, `/shopplot`) with
  home, spawn, visit, list, info, buy, expand, and staff subcommands.
- Integrated physical `/pshop` storefronts with district ownership checks and
  persisted plot data in `shopping-district.yml`.

## 1.4.0

- Added 51 new skill relics for 68 total milestone rewards, with a source-aware acquisition guard that prevents milestone-exclusive items from leaking through recipes, achievements, or random mob drops.
- Added a persistent, configurable three-slot accessory bag. Equipped relics contribute custom item, enchant, and reforge stat sources to `/stats` and survive restarts in SQLite.
- Added 170 skill-linked pets across all 17 skills, including persistent XP/levels, automatic skill-level unlocks, active-pet stat and XP bonuses, configurable safe visual followers, player/admin commands, and menus. Pets are disabled by default.
- Added natural reforge generation for crafted equipment, player-killed mob equipment, and generated chest loot, including ten source-exclusive reforges for 52 total outcomes.
- Split HUD output into a temporary skill-XP boss bar and independent numeric-health boss bar; real health remains unchanged while the vanilla display is visually limited to ten hearts.
- Added hoverable in-chat achievement names with descriptions, parents, live requirements, and how-to hints.
- Added `relics.yml`, `pets.yml`, complete relic/pet catalogs, expanded reforge acquisition documentation, and updated player/admin/config references.
- Extended transactional SQLite persistence with pet progress, active pets, and serialized accessory contents.
- Expanded default-resource tests for catalogs, references, exclusivity, natural sources, bag size, and the disabled-by-default pet switch.

## 1.3.3

- Rebuilt the reforge GUI input as loss-safe escrow: explicit input/cursor swaps, safe shift-click insertion/removal, and drag rejection inside the custom inventory.
- Rolls now modify a clone and replace the escrowed input only after a valid result and successful payment.
- Close, quit, and plugin-disable recovery now delivers the item before clearing the GUI slot and drops inventory overflow at the player.
- Reforge failures preserve the original input and emit only one concise diagnostic instead of allowing an event stack trace to disrupt recovery.
- Added exact held-item admin commands: `set`, `forceapply`, `get`, and `remove`.
- Added targeted equipment commands: `setfor`, `forcefor`, `getfrom`, and `removefrom` for main hand, off hand, and all four armor slots.
- Added admin reforge-stone delivery and a paginated in-game reforge/acquisition list.
- Added configurable `settings.allow-admin-force-apply`.
- Expanded the reforge documentation with the acquisition method for all 42 defaults and detailed sources for all six stone-only outcomes.

## 1.3.2

- Fixed Purpur 26.2 `NoSuchMethodError` spam caused by an offline-build stub using the wrong `RegistryAccess.getRegistry` return descriptor.
- Replaced Paper's registry access call with Bukkit's stable `Registry.ATTRIBUTE` lookup in both stat application and the numeric health HUD.
- Added a configurable attribute compatibility circuit breaker. Its default `DISABLE` policy prints at most one concise warning without a stack trace and suppresses all later scheduler failures.
- Added `SUPPRESS` and `THROW` diagnostic policies plus a completely silent `log-first-failure: false` option.
- `/incogrpg reload` now resets the circuit breaker and retries attribute application after configuration changes.

## 1.3.1

- Fixed repeated `Modifier is already applied on this attribute!` failures by making stat modifier application idempotent.
- Added an early duplicate-JAR guard with exact conflicting filenames and safe self-disable behavior.
- Added one-time, backup-first merging of missing defaults so upgraded servers receive the full 42-reforge and 26-item catalogs without losing configured values.
- Added 34 persistent, configurable achievements with parent branches, hidden nodes, multiple requirements, frames, broadcasts, title/sound notifications, item rewards, skill-XP rewards, messages, and console commands.
- Added SQLite tables for achievement metrics and unlock timestamps.
- Added `/achievements`/`/advancements`, a paginated advancement tree, profile-menu navigation, live requirement progress, and reward previews.
- Added administrator achievement get/grant/revoke/reset/setprogress/addprogress/check commands and permission.
- Added built-in gameplay metrics for skill progression, gathering, combat, crafting, fishing, reforges, enchant procs, custom items, and meta completion.
- Added achievement methods and `AchievementUnlockEvent` to the public API.
- Added PlaceholderAPI achievement, completion, and metric placeholders.
- Added `ACHIEVEMENTS.md` and `TROUBLESHOOTING.md`, and updated all player/admin/config/item documentation.

# IncogUtils 1.1.55 Update Notes

This update includes everything added after 1.1.51:

## Claims

- Claim Core Menu now uses the default inventory title color.
- Claim Info is magenta.
- Trusted Players displays the claim owner's actual Minecraft player head.
- Claim and Expand menus use barrier back buttons with simple titles and no lore.
- Clicking Delete Claim closes the menu immediately.
- Expand Claim has a back button.
- Downgrading is free.
- Once a larger claim size is unlocked, it stays unlocked permanently and can be selected again for free.
- Reaching the Large claim size automatically enables full-height protection.
- The full-height control uses a beacon instead of an elytra.

## Market

- Market category menu title is now `Market Main Menu`.
- Glass filler items were removed so unused slots remain empty.
- All Items uses a Nether Star at the top center.
- Category buttons are centered.
- Search uses a compass titled `Search`.
- The back control is a red Barrier titled `Back to Main Menu`.

## Menus and Build

- Added rank tabs to Daily Rewards: Secret, Unknown, Ominous, Cryptic, Incog, and Incog+.
- Added the project-local Maven cache configuration and fixed Paper API version for repeatable builds.

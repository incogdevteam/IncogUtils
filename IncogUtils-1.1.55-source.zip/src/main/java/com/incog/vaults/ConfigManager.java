package com.incog.vaults;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import com.incogdev.incogutils.branding.Branding;

import java.util.concurrent.ThreadLocalRandom;

public class ConfigManager {

    private final IncogVaults plugin;

    public ConfigManager(IncogVaults plugin) {
        this.plugin = plugin;
        plugin.saveDefaultConfig();
    }

    public void reload() {
        plugin.reloadConfig();
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    /** Rolls a fresh cooldown duration (in ms) for the given vault type. */
    public long randomCooldownMillis(VaultType type) {
        String path = type == VaultType.NORMAL ? "cooldowns.normal" : "cooldowns.ominous";
        int defaultMin = type == VaultType.NORMAL ? 45 : 90;
        int defaultMax = type == VaultType.NORMAL ? 45 : 120;

        int min = cfg().getInt(path + ".min-minutes", defaultMin);
        int max = cfg().getInt(path + ".max-minutes", defaultMax);
        if (max < min) max = min;

        int minutes = (min == max) ? min : ThreadLocalRandom.current().nextInt(min, max + 1);
        return minutes * 60_000L;
    }

    public String message(String key) {
        String raw = cfg().getString("messages." + key, "");
        return prefix() + ChatColor.translateAlternateColorCodes('&', raw);
    }

    public String prefix() {
        return Branding.legacyConfigured(cfg().getString("messages.prefix", ""), "Vaults");
    }

    public String logFileName() {
        return cfg().getString("logging.file", "logs.txt");
    }
}

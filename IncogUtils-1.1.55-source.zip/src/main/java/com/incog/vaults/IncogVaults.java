package com.incog.vaults;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogutils.module.ModuleContext;
import org.bukkit.ChatColor;

public class IncogVaults extends ModuleContext {
    public IncogVaults(IncogRpgPlugin host) { super(host, "vaults", "IncogVaults"); }

    private VaultDataManager dataManager;
    private ConfigManager configManager;
    private VaultLogger vaultLogger;

    public void enable() {
        configManager = new ConfigManager(this);
        dataManager = new VaultDataManager(this);
        vaultLogger = new VaultLogger(this, configManager);

        RecipeRegistrar.register(this);
        getServer().getPluginManager().registerEvents(
        new VaultListener(this, dataManager, configManager, vaultLogger), host());

        PluginCommand vaultsCommand = getCommand("incogvaults");
        if (vaultsCommand != null) vaultsCommand.setExecutor(this::onCommand);
        PluginCommand regenKeyCommand = getCommand("regenkey");
        if (regenKeyCommand != null) {
            RegenKeyCommand executor = new RegenKeyCommand(this);
            regenKeyCommand.setExecutor(executor);
            regenKeyCommand.setTabCompleter(executor);
        }

        getLogger().info("IncogVaults enabled.");
    }

    public void disable() {
        if (dataManager != null) {
            dataManager.persist();
        }
    }

    public void reload() { if (configManager != null) configManager.reload(); }

    public void message(CommandSender sender, String raw) {
        sender.sendMessage(configManager.prefix() + ChatColor.translateAlternateColorCodes('&', raw));
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            configManager.reload();
            message(sender, "&aVaults configuration reloaded.");
            return true;
        }
        message(sender, "&eUsage: /incogvaults reload");
        return true;
    }
}

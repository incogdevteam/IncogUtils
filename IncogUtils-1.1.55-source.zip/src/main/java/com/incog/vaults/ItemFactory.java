package com.incog.vaults;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.List;

public class ItemFactory {

    // Base materials for the two regen keys. Purely cosmetic - change freely
    // if either clashes with something else on your server. Neither has a
    // vanilla recipe that consumes it as a plain ingredient except:
    // HEART_OF_THE_SEA (conduit) and NETHER_STAR (beacon). Because matching
    // is done by our own PDC tag, a plain Heart of the Sea/Nether Star still
    // works fine in those vanilla recipes - only OUR tagged item is treated
    // as a Regen Key.
    private static final Material NORMAL_MATERIAL = Material.HEART_OF_THE_SEA;
    private static final Material OMINOUS_MATERIAL = Material.NETHER_STAR;

    public static NamespacedKey regenKeyTypeKey(Plugin plugin) {
        return new NamespacedKey(plugin, "regen_key_type");
    }

    public static ItemStack createRegenKey(Plugin plugin, VaultType type) {
        Material mat = (type == VaultType.NORMAL) ? NORMAL_MATERIAL : OMINOUS_MATERIAL;
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();

        String name = (type == VaultType.NORMAL)
                ? ChatColor.AQUA + "Vault Regen Key"
                : ChatColor.LIGHT_PURPLE + "Ominous Vault Regen Key";
        meta.setDisplayName(name);

        String keyName = (type == VaultType.NORMAL) ? "Trial Key" : "Ominous Trial Key";
        String vaultName = (type == VaultType.NORMAL) ? "Vault" : "Ominous Vault";
        meta.setLore(List.of(
                ChatColor.GRAY + "Right-click a locked " + vaultName,
                ChatColor.GRAY + "to remove its lock so it can be",
                ChatColor.GRAY + "opened again with a " + keyName + "."
        ));

        meta.getPersistentDataContainer().set(regenKeyTypeKey(plugin), PersistentDataType.STRING, type.name());
        item.setItemMeta(meta);
        return item;
    }

    /** Returns the vault type this item unlocks, or null if it isn't a Regen Key. */
    public static VaultType getRegenKeyType(Plugin plugin, ItemStack item) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) return null;
        String val = item.getItemMeta().getPersistentDataContainer()
                .get(regenKeyTypeKey(plugin), PersistentDataType.STRING);
        if (val == null) return null;
        try {
            return VaultType.valueOf(val);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}

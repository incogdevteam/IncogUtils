package com.incog.vaults;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;

import java.util.List;

public class RecipeRegistrar {

    public static void register(IncogVaults plugin) {
        ItemStack normalKey = ItemFactory.createRegenKey(plugin.host(), VaultType.NORMAL);
        ItemStack ominousKey = ItemFactory.createRegenKey(plugin.host(), VaultType.OMINOUS);

        // --- Normal Vault Regen Key ---
        // D G D
        // I K I
        // A Q A
        NamespacedKey normalId = new NamespacedKey(plugin.host(), "normal_regen_key");
        ShapedRecipe normalRecipe = new ShapedRecipe(normalId, normalKey);
        normalRecipe.shape("DGD", "IKI", "AQA");
        normalRecipe.setIngredient('D', Material.DIAMOND);
        normalRecipe.setIngredient('G', Material.GOLD_INGOT);
        normalRecipe.setIngredient('I', Material.IRON_INGOT);
        normalRecipe.setIngredient('K', Material.TRIAL_KEY);
        normalRecipe.setIngredient('A', Material.AMETHYST_SHARD);
        normalRecipe.setIngredient('Q', Material.QUARTZ);
        Bukkit.addRecipe(normalRecipe);

        // --- Ominous Vault Regen Key ---
        // N S N
        // S O S
        // N S N
        NamespacedKey ominousId = new NamespacedKey(plugin.host(), "ominous_regen_key");
        ShapedRecipe ominousRecipe = new ShapedRecipe(ominousId, ominousKey);
        ominousRecipe.shape("NSN", "SOS", "NSN");
        ominousRecipe.setIngredient('N', new RecipeChoice.ExactChoice(List.of(normalKey)));
        ominousRecipe.setIngredient('S', Material.NETHERITE_SCRAP);
        ominousRecipe.setIngredient('O', Material.OMINOUS_TRIAL_KEY);
        Bukkit.addRecipe(ominousRecipe);
    }
}

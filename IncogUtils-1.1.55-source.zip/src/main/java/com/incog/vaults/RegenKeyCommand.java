package com.incog.vaults;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Gives the exact PDC-tagged Regen Keys used by the vault listener. */
public final class RegenKeyCommand implements CommandExecutor, TabCompleter {
    public static final String PERMISSION = "incogvaults.admin.keys";

    private final IncogVaults module;

    public RegenKeyCommand(IncogVaults module) {
        this.module = module;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            module.message(sender, "&cYou do not have permission to give Vault Regen Keys.");
            return true;
        }
        if (args.length < 2 || args.length > 3) {
            usage(sender, label);
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            module.message(sender, "&cThat player must be online to receive a Regen Key.");
            return true;
        }

        VaultType type = parseType(args[1]);
        if (type == null) {
            module.message(sender, "&cUnknown key type. Use &fnormal &cor &fominous&c.");
            return true;
        }

        int amount = 1;
        if (args.length == 3) {
            try {
                amount = Integer.parseInt(args[2]);
            } catch (NumberFormatException ignored) {
                module.message(sender, "&cAmount must be a whole number from 1 to 64.");
                return true;
            }
            if (amount < 1 || amount > 64) {
                module.message(sender, "&cAmount must be between 1 and 64.");
                return true;
            }
        }

        ItemStack key = ItemFactory.createRegenKey(module.host(), type);
        key.setAmount(amount);
        Map<Integer, ItemStack> leftovers = target.getInventory().addItem(key);
        leftovers.values().forEach(leftover ->
                target.getWorld().dropItemNaturally(target.getLocation(), leftover));

        String keyName = type == VaultType.NORMAL ? "Vault Regen Key" : "Ominous Vault Regen Key";
        module.message(sender, "&aGave &f" + amount + "x " + keyName + " &ato &f" + target.getName() + "&a.");
        module.message(target, "&aYou received &f" + amount + "x " + keyName + "&a.");
        if (!leftovers.isEmpty()) {
            module.message(sender, "&e" + target.getName() + "'s inventory was full; the remaining key(s) were dropped safely at their feet.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission(PERMISSION)) return List.of();
        if (args.length == 1) {
            String input = args[0].toLowerCase(Locale.ROOT);
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(input))
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .toList();
        }
        if (args.length == 2) {
            String input = args[1].toLowerCase(Locale.ROOT);
            return List.of("normal", "ominous").stream()
                    .filter(type -> type.startsWith(input))
                    .toList();
        }
        return List.of();
    }

    private static VaultType parseType(String value) {
        return switch (value.toLowerCase(Locale.ROOT)) {
            case "normal", "regular", "vault" -> VaultType.NORMAL;
            case "ominous" -> VaultType.OMINOUS;
            default -> null;
        };
    }

    private void usage(CommandSender sender, String label) {
        module.message(sender, "&eUsage: /" + label + " <player> <normal|ominous> [amount]");
    }
}

package com.incog.vaults;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Tracks, per player and per vault location, the next time they're allowed
 * to use a Regen Key on that vault. Whether a vault is currently "locked"
 * for a player is read straight from the vault block itself (see
 * VaultResetHelper) - this class only needs to remember cooldowns, which
 * Minecraft has no concept of on its own.
 */
public class VaultDataManager {

    private final IncogVaults plugin;
    private final File file;
    private final Map<UUID, Map<String, Long>> nextUnlockTimes = new HashMap<>();

    public VaultDataManager(IncogVaults plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        load();
    }

    public long getNextUnlockAllowedAt(UUID player, VaultLocation loc) {
        Map<String, Long> map = nextUnlockTimes.get(player);
        if (map == null) return 0L;
        return map.getOrDefault(loc.key(), 0L);
    }

    public void setNextUnlockAllowedAt(UUID player, VaultLocation loc, long time) {
        nextUnlockTimes.computeIfAbsent(player, k -> new HashMap<>()).put(loc.key(), time);
        persist();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        if (yml.getConfigurationSection("players") == null) return;

        for (String uuidStr : yml.getConfigurationSection("players").getKeys(false)) {
            UUID uuid;
            try {
                uuid = UUID.fromString(uuidStr);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            Map<String, Long> map = new HashMap<>();
            String sectionPath = "players." + uuidStr;
            for (String locKey : yml.getConfigurationSection(sectionPath).getKeys(false)) {
                map.put(locKey, yml.getLong(sectionPath + "." + locKey, 0L));
            }
            nextUnlockTimes.put(uuid, map);
        }
    }

    public synchronized void persist() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Long>> e : nextUnlockTimes.entrySet()) {
            String base = "players." + e.getKey() + ".";
            for (Map.Entry<String, Long> e2 : e.getValue().entrySet()) {
                yml.set(base + e2.getKey(), e2.getValue());
            }
        }
        try {
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdirs();
            }
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.WARNING, "Failed to save data.yml", ex);
        }
    }
}

package com.incog.vaults;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

public class VaultListener implements Listener {

    private static final int POLL_INTERVAL_TICKS = 2;
    private static final int MAX_POLL_ATTEMPTS = 100; // ~10 seconds

    private final IncogVaults plugin;
    private final VaultDataManager data;
    private final ConfigManager config;
    private final VaultLogger logger;

    public VaultListener(IncogVaults plugin, VaultDataManager data, ConfigManager config, VaultLogger logger) {
        this.plugin = plugin;
        this.data = data;
        this.config = config;
        this.logger = logger;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;

        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.VAULT) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() == Material.AIR) return;

        VaultType vaultType = VaultResetHelper.isOminous(block) ? VaultType.OMINOUS : VaultType.NORMAL;
        VaultLocation loc = VaultLocation.of(block.getLocation());
        UUID uuid = player.getUniqueId();

        VaultType regenType = ItemFactory.getRegenKeyType(plugin.host(), item);
        if (regenType != null) {
            event.setCancelled(true);
            handleUnlock(player, block, loc, vaultType, regenType, item);
            return;
        }

        if (item.getType() == Material.TRIAL_KEY || item.getType() == Material.OMINOUS_TRIAL_KEY) {
            if (VaultResetHelper.hasRewardedPlayer(block, uuid)) {
                event.setCancelled(true);
                player.sendMessage(config.message("vault-locked"));
                return;
            }
            trackOpen(player, block, loc, vaultType, uuid);
        }
    }

    private void handleUnlock(Player p, Block block, VaultLocation loc, VaultType vaultType,
                               VaultType regenType, ItemStack regenItem) {
        if (regenType != vaultType) {
            p.sendMessage(config.message("wrong-key-type"));
            return;
        }

        UUID uuid = p.getUniqueId();
        if (!VaultResetHelper.hasRewardedPlayer(block, uuid)) {
            p.sendMessage(config.message("not-locked"));
            return;
        }

        long now = System.currentTimeMillis();
        long allowedAt = data.getNextUnlockAllowedAt(uuid, loc);
        if (now < allowedAt) {
            p.sendMessage(config.message("on-cooldown").replace("%time%", formatDuration(allowedAt - now)));
            return;
        }

        boolean removed = VaultResetHelper.removeRewardedPlayer(block, uuid);
        if (!removed) {
            p.sendMessage(config.message("reset-failed"));
            return;
        }

        consumeOne(p, regenItem);

        long nextAllowed = now + config.randomCooldownMillis(vaultType);
        data.setNextUnlockAllowedAt(uuid, loc, nextAllowed);

        p.sendMessage(config.message("unlocked"));
    }

    /**
     * Vaults reward players server-side on the same interaction that
     * consumed the key, with no dedicated event to hook. We poll the
     * vault's own rewarded-player record for a short window afterward and
     * log once it flips to true.
     */
    private void trackOpen(Player p, Block block, VaultLocation loc, VaultType vaultType, UUID uuid) {
        new BukkitRunnable() {
            int attempts = 0;

            @Override
            public void run() {
                attempts++;
                if (!p.isOnline() || attempts > MAX_POLL_ATTEMPTS) {
                    cancel();
                    return;
                }
                if (VaultResetHelper.hasRewardedPlayer(block, uuid)) {
                    logger.logOpen(p, vaultType, block.getLocation());
                    cancel();
                }
            }
        }.runTaskTimer(plugin.host(), POLL_INTERVAL_TICKS, POLL_INTERVAL_TICKS);
    }

    private void consumeOne(Player p, ItemStack template) {
        ItemStack inHand = p.getInventory().getItemInMainHand();
        if (inHand.isSimilar(template)) {
            inHand.setAmount(inHand.getAmount() - 1);
        }
    }

    private String formatDuration(long millis) {
        long totalSeconds = millis / 1000;
        long h = totalSeconds / 3600;
        long m = (totalSeconds % 3600) / 60;
        long s = totalSeconds % 60;
        if (h > 0) return h + "h " + m + "m";
        if (m > 0) return m + "m " + s + "s";
        return s + "s";
    }
}

package com.incog.vaults;

import org.bukkit.Location;

public record VaultLocation(String world, int x, int y, int z) {

    public static VaultLocation of(Location loc) {
        return new VaultLocation(loc.getWorld().getName(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }

    /** Stable key used for storage/lookup. */
    public String key() {
        return world + ";" + x + ";" + y + ";" + z;
    }

    @Override
    public String toString() {
        return world + " (" + x + ", " + y + ", " + z + ")";
    }
}

package com.incog.vaults;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;

public class VaultLogger {

    private final IncogVaults plugin;
    private final ConfigManager config;
    private final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public VaultLogger(IncogVaults plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
    }

    public synchronized void logOpen(Player player, VaultType type, Location loc) {
        String location = String.format("%s (%d, %d, %d)",
                loc.getWorld() != null ? loc.getWorld().getName() : "unknown",
                loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        String timestamp = format.format(new Date());

        String line = String.format("[Incog-vaults] =|= '%s' {%s} | Opened %s at %s <|> %s",
                player.getName(), player.getUniqueId(), type.label(), location, timestamp);

        File logFile = new File(plugin.getDataFolder(), config.logFileName());
        try {
            if (!logFile.getParentFile().exists()) {
                logFile.getParentFile().mkdirs();
            }
            try (PrintWriter out = new PrintWriter(new FileWriter(logFile, true))) {
                out.println(line);
            }
        } catch (IOException ex) {
            plugin.getLogger().log(Level.WARNING, "Failed to write vault log", ex);
        }
    }
}

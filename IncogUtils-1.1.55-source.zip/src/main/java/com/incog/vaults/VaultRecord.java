package com.incog.vaults;

public class VaultRecord {

    private boolean locked;
    private long nextUnlockAllowedAt; // epoch millis; 0 = no restriction yet

    public VaultRecord() {
    }

    public VaultRecord(boolean locked, long nextUnlockAllowedAt) {
        this.locked = locked;
        this.nextUnlockAllowedAt = nextUnlockAllowedAt;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public long getNextUnlockAllowedAt() {
        return nextUnlockAllowedAt;
    }

    public void setNextUnlockAllowedAt(long t) {
        this.nextUnlockAllowedAt = t;
    }
}

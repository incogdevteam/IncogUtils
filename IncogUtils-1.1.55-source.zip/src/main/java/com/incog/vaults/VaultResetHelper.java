package com.incog.vaults;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;

import java.util.UUID;

/**
 * Thin wrapper around Paper's org.bukkit.block.Vault API (added for the
 * Vault block entity). This gives us true per-player control over whether
 * a specific player has been "rewarded" by a specific vault, so unlocking
 * with a Regen Key only affects the player who used it - nobody else's
 * access to that vault is touched.
 */
public class VaultResetHelper {

    public static boolean isOminous(Block block) {
        BlockData data = block.getBlockData();
        if (data instanceof org.bukkit.block.data.type.Vault vaultData) {
            return vaultData.isOminous();
        }
        return false;
    }

    public static boolean hasRewardedPlayer(Block block, UUID uuid) {
        if (block.getType() != Material.VAULT) return false;
        BlockState state = block.getState();
        if (state instanceof org.bukkit.block.Vault vault) {
            return vault.hasRewardedPlayer(uuid);
        }
        return false;
    }

    /**
     * Removes the given player from this vault's rewarded-players record,
     * letting them use a key on it again. Only affects this one player.
     */
    public static boolean removeRewardedPlayer(Block block, UUID uuid) {
        if (block.getType() != Material.VAULT) return false;
        BlockState state = block.getState();
        if (state instanceof org.bukkit.block.Vault vault) {
            boolean changed = vault.removeRewardedPlayer(uuid);
            if (changed) {
                state.update(true, false);
            }
            return changed;
        }
        return false;
    }
}

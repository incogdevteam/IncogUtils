package com.incog.vaults;

public enum VaultType {
    NORMAL("Normal Vault"),
    OMINOUS("Ominous Vault");

    private final String label;

    VaultType(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}

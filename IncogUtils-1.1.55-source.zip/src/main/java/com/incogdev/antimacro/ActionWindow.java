package com.incogdev.antimacro;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ActionWindow {
    private final Deque<Sample> samples = new ArrayDeque<>();

    public void add(long timestampMs, String context, int maxSamples) {
        samples.addLast(new Sample(timestampMs, context == null ? "unknown" : context));
        while (samples.size() > Math.max(maxSamples, 2)) {
            samples.removeFirst();
        }
    }

    public Analysis analyze(int requiredSamples) {
        if (requiredSamples < 3 || samples.size() < requiredSamples) {
            return Analysis.notReady();
        }

        List<Sample> list = new ArrayList<>(samples);
        if (list.size() > requiredSamples) {
            list = list.subList(list.size() - requiredSamples, list.size());
        }

        int intervalCount = list.size() - 1;
        double[] intervals = new double[intervalCount];
        double sum = 0.0;
        Map<Long, Integer> tickBuckets = new HashMap<>();
        Map<String, Integer> contexts = new HashMap<>();

        for (Sample sample : list) {
            contexts.merge(sample.context(), 1, Integer::sum);
        }

        for (int i = 1; i < list.size(); i++) {
            double interval = list.get(i).timestampMs() - list.get(i - 1).timestampMs();
            intervals[i - 1] = interval;
            sum += interval;
            long bucket = Math.round(interval / 50.0);
            tickBuckets.merge(bucket, 1, Integer::sum);
        }

        double average = sum / intervalCount;
        if (average <= 0.0) {
            return new Analysis(true, average, Double.POSITIVE_INFINITY, 0.0, 0.0);
        }

        double variance = 0.0;
        for (double interval : intervals) {
            double d = interval - average;
            variance += d * d;
        }
        variance /= intervalCount;
        double standardDeviation = Math.sqrt(variance);
        double coefficientOfVariation = standardDeviation / average;

        int dominantBucketCount = tickBuckets.values().stream().mapToInt(Integer::intValue).max().orElse(0);
        double dominantBucketRatio = dominantBucketCount / (double) intervalCount;

        int dominantContextCount = contexts.values().stream().mapToInt(Integer::intValue).max().orElse(0);
        double sameContextRatio = dominantContextCount / (double) list.size();

        return new Analysis(true, average, coefficientOfVariation, dominantBucketRatio, sameContextRatio);
    }

    public void clear() {
        samples.clear();
    }

    public int size() {
        return samples.size();
    }

    private record Sample(long timestampMs, String context) {
    }

    public record Analysis(
            boolean ready,
            double averageIntervalMs,
            double coefficientOfVariation,
            double dominantBucketRatio,
            double sameContextRatio
    ) {
        public static Analysis notReady() {
            return new Analysis(false, 0.0, 0.0, 0.0, 0.0);
        }
    }
}

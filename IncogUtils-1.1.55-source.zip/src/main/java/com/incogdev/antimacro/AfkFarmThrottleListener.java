package com.incogdev.antimacro;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Bottlenecks passive ground-item collection after a player has been inactive.
 * The limiter is deliberately pickup-focused: it does not alter hopper rates,
 * mob spawning, crop growth, or item drops for active players.
 */
public final class AfkFarmThrottleListener implements Listener {
    private static final long MINUTE_MS = 60_000L;

    private final AntiMacroPlugin plugin;
    private final Map<UUID, AfkState> states = new HashMap<>();

    public AfkFarmThrottleListener(AntiMacroPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        states.put(event.getPlayer().getUniqueId(), new AfkState(System.currentTimeMillis()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        states.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() == null) return;
        Location from = event.getFrom();
        Location to = event.getTo();
        // Rotation by itself does not defeat AFK detection. Crossing a block
        // boundary does, which reliably counts ordinary walking/running.
        if (from.getBlockX() != to.getBlockX()
                || from.getBlockY() != to.getBlockY()
                || from.getBlockZ() != to.getBlockZ()) {
            markActive(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        markActive(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        markActive(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        markActive(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) markActive(player);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        markActive(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) markActive(player);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!enabled() || bypass(player)) return;

        AfkState state = state(player);
        long now = System.currentTimeMillis();
        long afkAfterMs = Math.max(30L, plugin.getConfig().getLong("afk-farm-throttle.afk-after-seconds", 300L)) * 1000L;
        if (now - state.lastActiveAt < afkAfterMs) return;

        int cap = Math.max(0, plugin.getConfig().getInt("afk-farm-throttle.max-items-per-minute", 64));
        if (cap <= 0) {
            throttleAll(event, player, state, now);
            return;
        }

        if (now - state.windowStartedAt >= MINUTE_MS) {
            state.windowStartedAt = now;
            state.itemsAccepted = 0;
        }

        ItemStack stack = event.getItem().getItemStack();
        int amount = Math.max(1, stack.getAmount());
        int remaining = Math.max(0, cap - state.itemsAccepted);

        if (remaining <= 0) {
            event.setCancelled(true);
            if (removeExcess()) event.getItem().remove();
            notifyThrottled(player, state, now, cap);
            return;
        }

        if (amount > remaining) {
            if (!removeExcess()) {
                // When configured not to destroy overflow, leave this stack on
                // the ground and wait for the next quota window.
                event.setCancelled(true);
                notifyThrottled(player, state, now, cap);
                return;
            }
            // Allow only the quota remainder to be collected. The excess is
            // discarded rather than left on the ground to create entity lag.
            ItemStack reduced = stack.clone();
            reduced.setAmount(remaining);
            event.getItem().setItemStack(reduced);
            state.itemsAccepted += remaining;
            notifyThrottled(player, state, now, cap);
            return;
        }

        state.itemsAccepted += amount;
    }

    private void throttleAll(EntityPickupItemEvent event, Player player, AfkState state, long now) {
        event.setCancelled(true);
        if (removeExcess()) event.getItem().remove();
        notifyThrottled(player, state, now, 0);
    }

    private void markActive(Player player) {
        if (player == null) return;
        AfkState state = state(player);
        state.lastActiveAt = System.currentTimeMillis();
        state.windowStartedAt = state.lastActiveAt;
        state.itemsAccepted = 0;
    }

    private AfkState state(Player player) {
        return states.computeIfAbsent(player.getUniqueId(), ignored -> new AfkState(System.currentTimeMillis()));
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("afk-farm-throttle.enabled", true);
    }

    private boolean bypass(Player player) {
        if (player.hasPermission("incogantimacro.afkfarm.bypass")) return true;
        String mode = player.getGameMode().name().toUpperCase(Locale.ROOT);
        for (String ignored : plugin.getConfig().getStringList("afk-farm-throttle.ignore-gamemodes")) {
            if (mode.equals(ignored.toUpperCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private boolean removeExcess() {
        return plugin.getConfig().getBoolean("afk-farm-throttle.remove-excess-drops", true);
    }

    private void notifyThrottled(Player player, AfkState state, long now, int cap) {
        long cooldown = Math.max(10L, plugin.getConfig().getLong("afk-farm-throttle.message-cooldown-seconds", 60L)) * 1000L;
        if (now - state.lastNoticeAt < cooldown) return;
        state.lastNoticeAt = now;
        if (!plugin.getConfig().getBoolean("afk-farm-throttle.notify-player", true)) return;

        String raw = plugin.getConfig().getString("afk-farm-throttle.message",
                "&eAFK farm limiter active. Passive item collection is capped at &f%limit% items/min&e until you become active again.");
        plugin.message(player, raw.replace("%limit%", Integer.toString(cap)));
    }

    private static final class AfkState {
        private long lastActiveAt;
        private long windowStartedAt;
        private long lastNoticeAt;
        private int itemsAccepted;

        private AfkState(long now) {
            this.lastActiveAt = now;
            this.windowStartedAt = now;
        }
    }
}

package com.incogdev.antimacro;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class AntiMacroCommand implements CommandExecutor, TabCompleter {
    private final AntiMacroPlugin plugin;
    private final DetectionEngine detector;

    public AntiMacroCommand(AntiMacroPlugin plugin, DetectionEngine detector) {
        this.plugin = plugin;
        this.detector = detector;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            if (!sender.hasPermission("incogantimacro.admin")) {
                plugin.message(sender, "&cYou do not have permission to use this command.");
                return true;
            }
            help(sender);
            return true;
        }

        String subcommand = args[0].toLowerCase(Locale.ROOT);
        if (subcommand.equals("alerts")) {
            if (!sender.hasPermission("incogantimacro.alerts") && !sender.hasPermission("incogantimacro.admin")) {
                plugin.message(sender, "&cYou do not have permission to use this command.");
                return true;
            }
        } else if (!sender.hasPermission("incogantimacro.admin")) {
            plugin.message(sender, "&cYou do not have permission to use this command.");
            return true;
        }

        switch (subcommand) {
            case "reload" -> {
                plugin.reloadConfig();
                detector.reload();
                plugin.message(sender, "&aAntiMacro configuration reloaded.");
            }
            case "status" -> {
                if (args.length < 2) {
                    plugin.message(sender, "&cUsage: /" + label + " status <player>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    plugin.message(sender, "&cThat player is not online.");
                    return true;
                }
                double score = plugin.currentScore(target.getUniqueId());
                boolean challenge = plugin.challengeManager().isChallenged(target.getUniqueId());
                plugin.message(sender, String.format(Locale.ROOT,
                        "&f%s &7score: &e%.1f &7challenge: %s",
                        target.getName(), score, challenge ? "&cACTIVE" : "&aNo"));
            }
            case "reset" -> {
                if (args.length < 2) {
                    plugin.message(sender, "&cUsage: /" + label + " reset <player>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    plugin.message(sender, "&cThat player is not online.");
                    return true;
                }
                PlayerState state = plugin.state(target.getUniqueId());
                state.setScore(0.0);
                state.clearHistories();
                plugin.challengeManager().clear(target.getUniqueId());
                plugin.message(sender, "&aReset anti-macro state for " + target.getName() + ".");
            }
            case "alerts" -> {
                if (!(sender instanceof Player player)) {
                    plugin.message(sender, "&cOnly players can toggle personal staff alerts.");
                    return true;
                }
                boolean enabled = plugin.toggleAlerts(player.getUniqueId());
                plugin.message(sender, enabled ? "&aAnti-macro alerts enabled." : "&cAnti-macro alerts disabled.");
            }
            default -> help(sender);
        }
        return true;
    }

    private void help(CommandSender sender) {
        plugin.message(sender, "&cAntiMacro commands:");
        sender.sendMessage(plugin.color("&f/antimacro status <player> &7- show current score"));
        sender.sendMessage(plugin.color("&f/antimacro reset <player> &7- clear score/challenge"));
        sender.sendMessage(plugin.color("&f/antimacro reload &7- reload config.yml"));
        sender.sendMessage(plugin.color("&f/antimacro alerts &7- toggle your staff alerts"));
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            return List.of("status", "reset", "reload", "alerts").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("status") || args[0].equalsIgnoreCase("reset"))) {
            List<String> names = new ArrayList<>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    names.add(player.getName());
                }
            }
            return names;
        }
        return List.of();
    }
}

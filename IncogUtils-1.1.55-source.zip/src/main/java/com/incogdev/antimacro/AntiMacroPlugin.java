package com.incogdev.antimacro;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogutils.module.ModuleContext;
import com.incogdev.incogutils.branding.Branding;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class AntiMacroPlugin extends ModuleContext {
    private final Map<UUID, PlayerState> states = new HashMap<>();
    private final Set<UUID> alertOptOut = new HashSet<>();

    private DetectionEngine detector;
    private ChallengeManager challengeManager;

    public AntiMacroPlugin(IncogRpgPlugin host) {
        super(host, "antimacro", "Incog-AntiMacro");
    }

    public void enable() {
        saveDefaultConfig();
        // Persist newly introduced defaults (such as AFK farm throttling) into
        // existing installations so administrators can see and edit them.
        saveConfig();

        detector = new DetectionEngine(this);
        challengeManager = new ChallengeManager(this);

        getServer().getPluginManager().registerEvents(new MacroListener(this, detector), host());
        getServer().getPluginManager().registerEvents(new AfkFarmThrottleListener(this), host());

        PluginCommand antiMacro = getCommand("antimacro");
        if (antiMacro == null) {
            throw new IllegalStateException("antimacro command is missing from plugin.yml");
        }
        AntiMacroCommand antiMacroExecutor = new AntiMacroCommand(this, detector);
        antiMacro.setExecutor(antiMacroExecutor);
        antiMacro.setTabCompleter(antiMacroExecutor);

        PluginCommand verify = getCommand("verify");
        if (verify == null) {
            throw new IllegalStateException("verify command is missing from plugin.yml");
        }
        verify.setExecutor(new VerifyCommand(this));

        getLogger().info("Incog-AntiMacro 1.0.1 enabled for Paper/Purpur 26.2.");
    }

    public void disable() {
        states.clear();
        alertOptOut.clear();
    }

    public PlayerState state(UUID uuid) {
        return states.computeIfAbsent(uuid, ignored -> new PlayerState());
    }

    public void removeState(UUID uuid) {
        states.remove(uuid);
        alertOptOut.remove(uuid);
    }

    public void scheduleStateCleanup(UUID uuid) {
        Bukkit.getScheduler().runTaskLater(host(), () -> {
            Player player = Bukkit.getPlayer(uuid);
            if ((player == null || !player.isOnline()) && !challengeManager.isChallenged(uuid)) {
                removeState(uuid);
            }
        }, 20L * 60L * 10L);
    }

    public double currentScore(UUID uuid) {
        return state(uuid).score(getConfig().getDouble("scoring.decay-per-second", 1.5));
    }

    public ChallengeManager challengeManager() {
        return challengeManager;
    }

    public boolean shouldFreeze(Player player) {
        return getConfig().getBoolean("challenge.freeze-monitored-actions", true)
                && challengeManager.isChallenged(player.getUniqueId())
                && !player.hasPermission("incogantimacro.bypass");
    }

    public void flag(Player player, CheckType type, double amount, String details) {
        PlayerState state = state(player.getUniqueId());
        double decay = getConfig().getDouble("scoring.decay-per-second", 1.5);
        double score = state.addScore(amount, decay);
        double alertThreshold = getConfig().getDouble("scoring.alert-threshold", 55.0);
        double challengeThreshold = getConfig().getDouble("scoring.challenge-threshold", 120.0);

        String alert = String.format("&e%s &7flagged &c%s &7(+%.1f, score %.1f) &8[%s]",
                player.getName(), type.displayName(), amount, score, details);

        if (getConfig().getBoolean("alerts.console", true)) {
            getLogger().warning(stripColor(alert));
        }
        if (score >= alertThreshold && getConfig().getBoolean("alerts.staff", true)) {
            alertStaff(alert);
        }
        if (score >= challengeThreshold) {
            challengeManager.start(player);
        }
    }

    public void alertStaff(String message) {
        String prefix = Branding.legacyConfigured(getConfig().getString("alerts.prefix", ""), "AntiMacro");
        String full = color(prefix + message);
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.hasPermission("incogantimacro.alerts") && !alertOptOut.contains(online.getUniqueId())) {
                online.sendMessage(full);
            }
        }
    }

    public void message(CommandSender sender, String raw) {
        String prefix = Branding.legacyConfigured(getConfig().getString("alerts.prefix", ""), "AntiMacro");
        sender.sendMessage(color(prefix + raw));
    }

    public boolean toggleAlerts(UUID uuid) {
        if (alertOptOut.remove(uuid)) {
            return true;
        }
        alertOptOut.add(uuid);
        return false;
    }

    public String color(String text) {
        if (text == null) {
            return "";
        }
        return text.replace('&', '§');
    }

    private String stripColor(String text) {
        return text.replaceAll("(?i)[&§][0-9A-FK-ORX]", "");
    }
}

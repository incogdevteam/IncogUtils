package com.incogdev.antimacro;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class ChallengeManager {
    private static final char[] CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".toCharArray();

    private final AntiMacroPlugin plugin;
    private final SecureRandom random = new SecureRandom();
    private final Map<UUID, Challenge> challenges = new HashMap<>();

    public ChallengeManager(AntiMacroPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin.host(), this::expireChallenges, 20L, 20L);
    }

    public boolean isChallenged(UUID uuid) {
        return challenges.containsKey(uuid);
    }

    public void onJoin(Player player) {
        Challenge challenge = challenges.get(player.getUniqueId());
        if (challenge == null) {
            return;
        }

        long remainingMs = challenge.expiresAt() - System.currentTimeMillis();
        if (remainingMs <= 0L) {
            challenges.remove(player.getUniqueId());
            fail(player);
            return;
        }

        int remainingSeconds = (int) Math.max(1L, (remainingMs + 999L) / 1000L);
        sendChallengeMessage(player, challenge.code(), remainingSeconds);
    }

    public void start(Player player) {
        if (!plugin.getConfig().getBoolean("challenge.enabled", true)
                || player.hasPermission("incogantimacro.bypass")
                || isChallenged(player.getUniqueId())) {
            return;
        }

        int seconds = Math.max(5, plugin.getConfig().getInt("challenge.duration-seconds", 30));
        int length = Math.max(3, Math.min(10, plugin.getConfig().getInt("challenge.code-length", 5)));
        String code = generateCode(length);
        long expiresAt = System.currentTimeMillis() + (seconds * 1000L);
        challenges.put(player.getUniqueId(), new Challenge(code, expiresAt));

        sendChallengeMessage(player, code, seconds);
        plugin.alertStaff("&e" + player.getName() + " &7was given a macro verification challenge.");
    }

    public VerifyResult verify(Player player, String submitted) {
        Challenge challenge = challenges.get(player.getUniqueId());
        if (challenge == null) {
            return VerifyResult.NONE;
        }

        if (System.currentTimeMillis() > challenge.expiresAt()) {
            challenges.remove(player.getUniqueId());
            fail(player);
            return VerifyResult.EXPIRED;
        }

        if (!challenge.code().equalsIgnoreCase(submitted)) {
            return VerifyResult.WRONG;
        }

        challenges.remove(player.getUniqueId());
        PlayerState state = plugin.state(player.getUniqueId());
        state.setScore(plugin.getConfig().getDouble("challenge.passed-score", 0.0));
        state.clearHistories();
        player.sendMessage(plugin.color(plugin.getConfig().getString("messages.challenge-passed",
                "&aVerification passed. You may continue.")));
        plugin.alertStaff("&a" + player.getName() + " &7passed the macro verification.");
        return VerifyResult.PASSED;
    }

    public void clear(UUID uuid) {
        challenges.remove(uuid);
    }

    private void expireChallenges() {
        long now = System.currentTimeMillis();
        for (UUID uuid : challenges.keySet().toArray(UUID[]::new)) {
            Challenge challenge = challenges.get(uuid);
            if (challenge == null || challenge.expiresAt() > now) {
                continue;
            }
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                challenges.remove(uuid);
                fail(player);
            }
            // If the player disconnected to avoid verification, keep the expired
            // challenge so it fails immediately when they reconnect.
        }
    }

    private void sendChallengeMessage(Player player, String code, int seconds) {
        for (String line : plugin.getConfig().getStringList("messages.challenge-start")) {
            player.sendMessage(plugin.color(line
                    .replace("%code%", code)
                    .replace("%seconds%", Integer.toString(seconds))));
        }

        if (plugin.getConfig().getBoolean("challenge.click-to-verify", true)) {
            String label = plugin.getConfig().getString("messages.challenge-click-text", "CLICK HERE TO VERIFY");
            String hover = plugin.getConfig().getString("messages.challenge-click-hover",
                    "Click to confirm that you are actively playing.");

            Component button = Component.text("[" + label + "]", NamedTextColor.GREEN)
                    .decorate(TextDecoration.BOLD)
                    .clickEvent(ClickEvent.runCommand("/verify " + code))
                    .hoverEvent(HoverEvent.showText(Component.text(hover, NamedTextColor.GRAY)));

            Component message = Component.text("If you are not macroing, ", NamedTextColor.GRAY)
                    .append(button)
                    .append(Component.text(" within " + seconds + " seconds.", NamedTextColor.GRAY));

            player.sendMessage(message);
        }
    }

    private void fail(Player player) {
        String action = plugin.getConfig().getString("challenge.failure-action", "KICK").toUpperCase();
        plugin.alertStaff("&c" + player.getName() + " &7failed the macro verification.");

        switch (action) {
            case "NONE" -> {
                // Staff alert only.
            }
            case "COMMAND" -> {
                String command = plugin.getConfig().getString("challenge.failure-command",
                        "kick %player% Failed anti-macro verification");
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command.replace("%player%", player.getName()));
            }
            default -> player.kickPlayer(plugin.color(plugin.getConfig().getString("challenge.kick-message",
                    "&cYou failed the anti-macro verification.")));
        }
    }

    private String generateCode(int length) {
        StringBuilder code = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            code.append(CODE_CHARS[random.nextInt(CODE_CHARS.length)]);
        }
        return code.toString();
    }

    private record Challenge(String code, long expiresAt) {
    }

    public enum VerifyResult {
        NONE,
        WRONG,
        PASSED,
        EXPIRED
    }
}

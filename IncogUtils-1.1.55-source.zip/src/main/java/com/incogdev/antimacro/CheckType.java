package com.incogdev.antimacro;

public enum CheckType {
    BLOCK_BREAK("block-break", "BlockBreak"),
    ATTACK("attack", "Attack"),
    INTERACT("interact", "Interact"),
    FISHING("fishing", "Fishing");

    private final String configKey;
    private final String displayName;

    CheckType(String configKey, String displayName) {
        this.configKey = configKey;
        this.displayName = displayName;
    }

    public String configKey() {
        return configKey;
    }

    public String displayName() {
        return displayName;
    }
}

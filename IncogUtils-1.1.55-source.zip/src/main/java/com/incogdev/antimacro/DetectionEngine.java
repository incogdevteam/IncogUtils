package com.incogdev.antimacro;

import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;

public final class DetectionEngine {
    private final AntiMacroPlugin plugin;
    private Set<GameMode> ignoredGameModes = EnumSet.noneOf(GameMode.class);

    public DetectionEngine(AntiMacroPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        ignoredGameModes = EnumSet.noneOf(GameMode.class);
        for (String value : plugin.getConfig().getStringList("ignore.gamemodes")) {
            try {
                ignoredGameModes.add(GameMode.valueOf(value.toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Unknown gamemode in ignore.gamemodes: " + value);
            }
        }
    }

    public boolean shouldCheck(Player player) {
        return plugin.getConfig().getBoolean("enabled", true)
                && !player.hasPermission("incogantimacro.bypass")
                && !ignoredGameModes.contains(player.getGameMode());
    }

    public void record(Player player, CheckType type, String context) {
        if (!shouldCheck(player) || type == CheckType.FISHING) {
            return;
        }

        String base = "checks." + type.configKey();
        if (!plugin.getConfig().getBoolean(base + ".enabled", true)) {
            return;
        }

        int sampleSize = Math.max(3, plugin.getConfig().getInt(base + ".sample-size", 24));
        PlayerState state = plugin.state(player.getUniqueId());
        long now = System.currentTimeMillis();
        ActionWindow window = state.window(type);
        window.add(now, context, sampleSize);

        ActionWindow.Analysis analysis = window.analyze(sampleSize);
        if (!analysis.ready()) {
            return;
        }

        double minAverage = plugin.getConfig().getDouble(base + ".min-average-interval-ms", 50.0);
        double maxAverage = plugin.getConfig().getDouble(base + ".max-average-interval-ms", 3000.0);
        double maxCv = plugin.getConfig().getDouble(base + ".max-coefficient-of-variation", 0.06);
        double minBucketRatio = plugin.getConfig().getDouble(base + ".dominant-50ms-bucket-ratio", 0.82);
        double minContextRatio = plugin.getConfig().getDouble(base + ".same-context-ratio", 0.80);

        boolean suspicious = analysis.averageIntervalMs() >= minAverage
                && analysis.averageIntervalMs() <= maxAverage
                && analysis.coefficientOfVariation() <= maxCv
                && analysis.dominantBucketRatio() >= minBucketRatio
                && analysis.sameContextRatio() >= minContextRatio;

        if (!suspicious) {
            return;
        }

        long cooldown = Math.max(0L, plugin.getConfig().getLong("scoring.flag-cooldown-ms", 5000L));
        if (!state.canFlag(type, now, cooldown)) {
            return;
        }

        double score = plugin.getConfig().getDouble(base + ".score-per-flag", 25.0);
        plugin.flag(player, type, score,
                String.format(Locale.ROOT,
                        "avg=%.0fms cv=%.3f bucket=%.0f%% context=%.0f%%",
                        analysis.averageIntervalMs(),
                        analysis.coefficientOfVariation(),
                        analysis.dominantBucketRatio() * 100.0,
                        analysis.sameContextRatio() * 100.0));
    }

    public void recordFishingBite(Player player) {
        if (!shouldCheck(player) || !plugin.getConfig().getBoolean("checks.fishing.enabled", true)) {
            return;
        }
        plugin.state(player.getUniqueId()).setLastFishingBiteAt(System.currentTimeMillis());
    }

    public void recordFishingReaction(Player player) {
        if (!shouldCheck(player) || !plugin.getConfig().getBoolean("checks.fishing.enabled", true)) {
            return;
        }

        PlayerState state = plugin.state(player.getUniqueId());
        long biteAt = state.lastFishingBiteAt();
        if (biteAt <= 0L) {
            return;
        }

        long now = System.currentTimeMillis();
        long reaction = now - biteAt;
        state.setLastFishingBiteAt(-1L);

        long maxReaction = Math.max(0L, plugin.getConfig().getLong("checks.fishing.max-reaction-ms", 125L));
        if (reaction > maxReaction) {
            state.fishingReactionTimes().clear();
            return;
        }

        int required = Math.max(2, plugin.getConfig().getInt("checks.fishing.reaction-samples", 5));
        state.fishingReactionTimes().addLast(reaction);
        while (state.fishingReactionTimes().size() > required) {
            state.fishingReactionTimes().removeFirst();
        }

        if (state.fishingReactionTimes().size() < required) {
            return;
        }

        long cooldown = Math.max(0L, plugin.getConfig().getLong("scoring.flag-cooldown-ms", 5000L));
        if (!state.canFlag(CheckType.FISHING, now, cooldown)) {
            return;
        }

        double score = plugin.getConfig().getDouble("checks.fishing.score-per-flag", 45.0);
        double average = state.fishingReactionTimes().stream().mapToLong(Long::longValue).average().orElse(0.0);
        plugin.flag(player, CheckType.FISHING, score,
                String.format(Locale.ROOT, "repeated fast fishing reactions avg=%.0fms (%d samples)", average, required));
        state.fishingReactionTimes().clear();
    }
}

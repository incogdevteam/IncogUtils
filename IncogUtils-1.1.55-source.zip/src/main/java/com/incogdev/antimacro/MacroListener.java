package com.incogdev.antimacro;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class MacroListener implements Listener {
    private final AntiMacroPlugin plugin;
    private final DetectionEngine detector;

    public MacroListener(AntiMacroPlugin plugin, DetectionEngine detector) {
        this.plugin = plugin;
        this.detector = detector;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreakMonitor(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        detector.record(player, CheckType.BLOCK_BREAK, block.getType().name());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBlockBreakFreeze(BlockBreakEvent event) {
        if (plugin.shouldFreeze(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAttackMonitor(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) {
            detector.record(player, CheckType.ATTACK, event.getEntity().getType().name());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onAttackFreeze(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player && plugin.shouldFreeze(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteractMonitor(PlayerInteractEvent event) {
        if (event.getHand() != null && event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        String context = event.getAction().name();
        if (event.getClickedBlock() != null) {
            context += ":" + event.getClickedBlock().getType().name();
        } else {
            context += ":" + event.getPlayer().getInventory().getItemInMainHand().getType().name();
        }
        detector.record(event.getPlayer(), CheckType.INTERACT, context);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInteractFreeze(PlayerInteractEvent event) {
        if (plugin.shouldFreeze(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFishMonitor(PlayerFishEvent event) {
        Player player = event.getPlayer();
        if (event.getState() == PlayerFishEvent.State.BITE) {
            detector.recordFishingBite(player);
            return;
        }

        switch (event.getState()) {
            case CAUGHT_FISH, CAUGHT_ENTITY, REEL_IN, FAILED_ATTEMPT -> detector.recordFishingReaction(player);
            default -> {
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onFishFreeze(PlayerFishEvent event) {
        if (plugin.shouldFreeze(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.challengeManager().onJoin(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.scheduleStateCleanup(event.getPlayer().getUniqueId());
    }
}

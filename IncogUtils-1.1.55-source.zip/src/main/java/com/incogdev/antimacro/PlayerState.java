package com.incogdev.antimacro;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.EnumMap;
import java.util.Map;

public final class PlayerState {
    private final Map<CheckType, ActionWindow> windows = new EnumMap<>(CheckType.class);
    private final Map<CheckType, Long> lastFlagAt = new EnumMap<>(CheckType.class);
    private final Deque<Long> fishingReactionTimes = new ArrayDeque<>();

    private double score;
    private long lastScoreUpdate = System.currentTimeMillis();
    private long lastFishingBiteAt = -1L;

    public PlayerState() {
        for (CheckType type : CheckType.values()) {
            windows.put(type, new ActionWindow());
        }
    }

    public ActionWindow window(CheckType type) {
        return windows.get(type);
    }

    public double score(double decayPerSecond) {
        decay(decayPerSecond);
        return score;
    }

    public double addScore(double amount, double decayPerSecond) {
        decay(decayPerSecond);
        score = Math.max(0.0, score + amount);
        return score;
    }

    public void setScore(double newScore) {
        score = Math.max(0.0, newScore);
        lastScoreUpdate = System.currentTimeMillis();
    }

    public boolean canFlag(CheckType type, long now, long cooldownMs) {
        long previous = lastFlagAt.getOrDefault(type, 0L);
        if (now - previous < cooldownMs) {
            return false;
        }
        lastFlagAt.put(type, now);
        return true;
    }

    public void clearHistories() {
        for (ActionWindow window : windows.values()) {
            window.clear();
        }
        fishingReactionTimes.clear();
        lastFishingBiteAt = -1L;
        lastFlagAt.clear();
    }

    public long lastFishingBiteAt() {
        return lastFishingBiteAt;
    }

    public void setLastFishingBiteAt(long timestamp) {
        this.lastFishingBiteAt = timestamp;
    }

    public Deque<Long> fishingReactionTimes() {
        return fishingReactionTimes;
    }

    private void decay(double decayPerSecond) {
        long now = System.currentTimeMillis();
        long elapsed = now - lastScoreUpdate;
        if (elapsed > 0 && score > 0.0 && decayPerSecond > 0.0) {
            score = Math.max(0.0, score - ((elapsed / 1000.0) * decayPerSecond));
        }
        lastScoreUpdate = now;
    }
}

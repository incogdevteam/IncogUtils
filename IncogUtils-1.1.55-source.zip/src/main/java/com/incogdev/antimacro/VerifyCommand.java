package com.incogdev.antimacro;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public final class VerifyCommand implements CommandExecutor {
    private final AntiMacroPlugin plugin;

    public VerifyCommand(AntiMacroPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.message(sender, "&cOnly players can use this command.");
            return true;
        }

        if (args.length != 1) {
            plugin.message(player, "&cUsage: /verify <code>");
            return true;
        }

        ChallengeManager.VerifyResult result = plugin.challengeManager().verify(player, args[0]);
        switch (result) {
            case NONE -> plugin.message(player, plugin.getConfig().getString("messages.no-challenge",
                    "&7You do not have an active verification challenge."));
            case WRONG -> plugin.message(player, plugin.getConfig().getString("messages.wrong-code",
                    "&cThat verification code is incorrect."));
            case PASSED, EXPIRED -> {
            }
        }
        return true;
    }
}

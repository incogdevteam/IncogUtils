package com.incogdev.incogclaims;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogutils.module.ModuleContext;
import com.incogdev.incogclaims.commands.ClaimsCommand;
import com.incogdev.incogclaims.config.ConfigManager;
import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.data.ClaimManager;
import com.incogdev.incogclaims.data.ClaimType;
import com.incogdev.incogclaims.data.PlayerData;
import com.incogdev.incogclaims.data.PlayerDataManager;
import com.incogdev.incogclaims.data.StorageManager;
import com.incogdev.incogclaims.integrations.ClaimBreakerAchievementManager;
import com.incogdev.incogclaims.integrations.LuckPermsIntegration;
import com.incogdev.incogclaims.integrations.TabListIntegration;
import com.incogdev.incogclaims.listeners.EnchantListener;
import com.incogdev.incogclaims.listeners.GUIListener;
import com.incogdev.incogclaims.listeners.JoinListener;
import com.incogdev.incogclaims.listeners.ProtectionListener;
import com.incogdev.incogclaims.pvp.CombatManager;
import com.incogdev.incogclaims.pvp.PvpCommand;
import com.incogdev.incogclaims.pvp.PvpListener;
import com.incogdev.incogclaims.pvp.PvpManager;
import com.incogdev.incogclaims.util.ItemBuilder;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class IncogClaims extends ModuleContext {
    private static IncogClaims instance;

    private ConfigManager configManager;
    private ClaimManager claimManager;
    private PlayerDataManager playerDataManager;
    private StorageManager storageManager;
    private NamespacedKey coreBlockKey;
    private NamespacedKey extraCoreBlockKey;
    private NamespacedKey claimBreakerKey;
    private NamespacedKey claimBreakerUsesKey;
    private ProtectionListener protectionListener;
    private PvpManager pvpManager;
    private CombatManager combatManager;
    private LuckPermsIntegration luckPermsIntegration;
    private TabListIntegration tabListIntegration;
    private ClaimBreakerAchievementManager claimBreakerAchievementManager;

    private final Map<UUID, Double> earnFractions = new ConcurrentHashMap<>();

    public IncogClaims(IncogRpgPlugin host) {
        super(host, "claims", "Incog-Claims");
    }

    public void enable() {
        instance = this;

        coreBlockKey = new NamespacedKey(host(), "claim_core");
        extraCoreBlockKey = new NamespacedKey(host(), "extra_claim_core");
        claimBreakerKey = new NamespacedKey(host(), "claim_breaker");
        claimBreakerUsesKey = new NamespacedKey(host(), "claim_breaker_uses");

        configManager = new ConfigManager(this);
        configManager.load();
        claimManager = new ClaimManager();
        playerDataManager = new PlayerDataManager();
        storageManager = new StorageManager(this);
        storageManager.loadAll();
        pvpManager = new PvpManager(this);
        combatManager = new CombatManager(this);

        if (getServer().getPluginManager().isPluginEnabled("LuckPerms")) {
            try {
                luckPermsIntegration = new LuckPermsIntegration(this);
                getLogger().info("LuckPerms playstyle suffix integration enabled.");
            } catch (Exception e) {
                getLogger().warning("Could not initialize LuckPerms integration: " + e.getMessage());
            }
        }
        tabListIntegration = new TabListIntegration(this);

        claimBreakerAchievementManager = new ClaimBreakerAchievementManager(this);
        claimBreakerAchievementManager.initialize();

        var pm = getServer().getPluginManager();
        pm.registerEvents(new JoinListener(this), host());
        protectionListener = new ProtectionListener(this);
        pm.registerEvents(protectionListener, host());
        pm.registerEvents(new GUIListener(this), host());
        pm.registerEvents(new EnchantListener(this), host());
        pm.registerEvents(new PvpListener(this), host());

        EnchantListener.registerRecipe(this);
        startClaimBreakerSanitizeTask();

        ClaimsCommand claimsCommand = new ClaimsCommand(this);
        Objects.requireNonNull(getCommand("claims")).setExecutor(claimsCommand);
        Objects.requireNonNull(getCommand("claims")).setTabCompleter(claimsCommand);
        Objects.requireNonNull(getCommand("pvp")).setExecutor(new PvpCommand(this));

        startEarnTask();
        startAutosaveTask();
        startBorderTask();
        startSuffixSyncTask();
        getLogger().info("Incog-Claims unified claims/PVP plugin enabled.");
    }

    public void disable() {
        if (tabListIntegration != null) tabListIntegration.close();
        if (storageManager != null) storageManager.saveAll();
    }

    private void startEarnTask() {
        getServer().getScheduler().runTaskTimer(host(), () -> {
            int cap = configManager.getMaxClaimBlocks();
            for (Player player : getServer().getOnlinePlayers()) {
                if (!claimManager.hasClaim(player.getUniqueId())) continue;
                double rate = configManager.getEarnRate(player);
                if (rate <= 0) {
                    rate = configManager.getEarnAmount()
                            / (double) Math.max(1, configManager.getEarnIntervalMinutes() * 60);
                }
                double total = earnFractions.getOrDefault(player.getUniqueId(), 0.0) + rate;
                int whole = (int) Math.floor(total);
                earnFractions.put(player.getUniqueId(), total - whole);
                if (whole > 0) {
                    PlayerData data = playerDataManager.get(player.getUniqueId());
                    data.setClaimBlocks(Math.min(cap, data.getClaimBlocks() + whole));
                }
            }
        }, 20L, 20L);
    }

    private void startAutosaveTask() {
        long interval = 20L * 60L * 5L;
        getServer().getScheduler().runTaskTimer(host(), storageManager::saveAllAsync, interval, interval);
    }

    private void startBorderTask() {
        getServer().getScheduler().runTaskTimer(host(), protectionListener::tickBorders, 10L, 10L);
    }

    /**
     * Backstop from the newer claims source: every five seconds force all Claim Breakers
     * back to the intended enchant/unbreakable state in case another plugin modified one.
     */
    private void startClaimBreakerSanitizeTask() {
        getServer().getScheduler().runTaskTimer(host(), () -> {
            for (Player player : getServer().getOnlinePlayers()) {
                for (var stack : player.getInventory().getContents()) {
                    EnchantListener.sanitize(this, stack);
                }
                EnchantListener.sanitize(this, player.getInventory().getItemInOffHand());
            }
        }, 100L, 100L);
    }

    public void applyTypeSelection(Player player, ClaimType newType) {
        PlayerData data = playerDataManager.get(player.getUniqueId());
        boolean first = !data.hasChosenType();
        data.setType(newType);
        data.setHasChosenType(true);

        if (!first) {
            data.setLastSwitchTimestamp(System.currentTimeMillis());
            for (Claim claim : claimManager.getClaimsOwnedBy(player.getUniqueId())) {
                claim.setType(newType);
                claim.getTrusted().removeIf(uuid -> playerDataManager.get(uuid).getType() != newType);
            }
        }
        updateLuckPermsSuffix(player);
    }

    public void logPvpToggle(Player player, boolean state) {
        String line = "[Incog-Claims/PVP] " + player.getName() + " (" + player.getUniqueId()
                + ") toggled PVP " + (state ? "on" : "off") + " @ "
                + DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(LocalDateTime.now());
        getLogger().info(line);
        Path path = getDataFolder().toPath().resolve("incog-pvp.log");
        getServer().getScheduler().runTaskAsynchronously(host(), () -> {
            try {
                Files.createDirectories(path.getParent());
                Files.writeString(path, line + System.lineSeparator(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException e) {
                getLogger().warning("Could not write incog-pvp.log: " + e.getMessage());
            }
        });
    }

    public void updateLuckPermsSuffix(Player player) {
        try {
            PlayerData data = playerDataManager.get(player.getUniqueId());
            ClaimType type = repairMissingType(player, data);
            if (luckPermsIntegration != null) luckPermsIntegration.ensure(player, type);
            if (tabListIntegration != null) tabListIntegration.ensure(player, type);
        } catch (Exception e) {
            getLogger().warning("Could not update playstyle suffix for " + player.getName() + ": " + e.getMessage());
        }
    }

    public void forgetTabListState(UUID playerId) {
        if (tabListIntegration != null) tabListIntegration.forget(playerId);
    }

    private ClaimType repairMissingType(Player player, PlayerData data) {
        if (data.getType() != null) return data.getType();
        var owned = claimManager.getClaimsOwnedBy(player.getUniqueId());
        if (!data.hasChosenType() && owned.isEmpty()) return null;
        ClaimType inferred = owned.stream().filter(Claim::isPrimary).map(Claim::getType).findFirst()
                .orElseGet(() -> owned.stream().map(Claim::getType).filter(Objects::nonNull).findFirst().orElse(ClaimType.PEACEFUL));
        data.setType(inferred);
        data.setHasChosenType(true);
        storageManager.saveAllAsync();
        return inferred;
    }

    private void startSuffixSyncTask() {
        // TAB player objects are loaded asynchronously and tab formatters may refresh
        // their own values later, so reconcile the displayed suffix frequently. The
        // LuckPerms integration only writes when its node actually needs repair.
        getServer().getScheduler().runTaskTimer(host(), () ->
                getServer().getOnlinePlayers().forEach(this::updateLuckPermsSuffix), 20L,
                configManager.getTabSuffixRefreshTicks());
    }

    public static IncogClaims getInstance() { return instance; }
    public ConfigManager getConfigManager() { return configManager; }
    public ClaimManager getClaimManager() { return claimManager; }
    public PlayerDataManager getPlayerDataManager() { return playerDataManager; }
    public StorageManager getStorageManager() { return storageManager; }
    public NamespacedKey getCoreBlockKey() { return coreBlockKey; }
    public NamespacedKey getExtraCoreBlockKey() { return extraCoreBlockKey; }
    public NamespacedKey getClaimBreakerKey() { return claimBreakerKey; }
    public NamespacedKey getClaimBreakerUsesKey() { return claimBreakerUsesKey; }
    public ProtectionListener getProtectionListener() { return protectionListener; }
    public PvpManager getPvpManager() { return pvpManager; }
    public CombatManager getCombatManager() { return combatManager; }
    public ClaimBreakerAchievementManager getClaimBreakerAchievementManager() { return claimBreakerAchievementManager; }

    /** Builds a tagged Claim Core for catalog and administrative item access. */
    public ItemStack createClaimCore(boolean extra) {
        ItemStack item = new ItemBuilder(configManager.getClaimCoreMaterial())
                .name(extra ? "&d&lAdditional Claim Core" : "&5&lClaim Core")
                .lore(extra
                        ? new String[]{"&7Purchased with &f/claim buy&7.", "&7Place to create an additional claim."}
                        : new String[]{"&7Your first Claim Core.", "&7Place to create your primary claim."})
                .build();
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(extra ? extraCoreBlockKey : coreBlockKey,
                    PersistentDataType.STRING, "core");
            item.setItemMeta(meta);
        }
        return item;
    }
}

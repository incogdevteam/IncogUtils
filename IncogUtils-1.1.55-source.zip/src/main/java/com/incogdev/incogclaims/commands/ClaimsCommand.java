package com.incogdev.incogclaims.commands;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.data.ClaimType;
import com.incogdev.incogclaims.data.PlayerData;
import com.incogdev.incogclaims.gui.ClaimMenuGUI;
import com.incogdev.incogclaims.gui.TypeSelectGUI;
import com.incogdev.incogclaims.listeners.EnchantListener;
import com.incogdev.incogclaims.util.ItemBuilder;
import com.incogdev.incogclaims.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class ClaimsCommand implements CommandExecutor, TabCompleter {
    private final IncogClaims plugin;

    public ClaimsCommand(IncogClaims plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            gui(sender);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "help" -> help(sender);
            case "core" -> core(sender);
            case "buy", "buycore" -> buy(sender);
            case "gui", "menu" -> gui(sender);
            case "showclaim" -> show(sender);
            case "select" -> select(sender);
            case "trust" -> trust(sender, args, true);
            case "untrust" -> trust(sender, args, false);
            case "switch" -> switchType(sender);
            case "info" -> info(sender);
            case "delete" -> delete(sender);
            case "merge" -> merge(sender, args);
            case "admin" -> admin(sender, args);
            case "reload" -> reload(sender);
            default -> help(sender);
        }
        return true;
    }

    private void help(CommandSender sender) {
        Msg.sendRaw(sender, "&8&m--------&r &5&lIC Claims &8&m--------");
        Msg.sendRaw(sender, "&d/claim core &7- Get your first Claim Core");
        Msg.sendRaw(sender, "&d/claim buy &7- Buy another Claim Core for an additional claim");
        Msg.sendRaw(sender, "&d/claim menu &7- Open the Claim Core Menu for the claim you're in");
        Msg.sendRaw(sender, "&d/claim info &7- Show your current claim and claim-block info");
        Msg.sendRaw(sender, "&d/claim trust <player> &7- Trust a player in your current claim");
        Msg.sendRaw(sender, "&d/claim untrust <player> &7- Remove trust from a player");
        Msg.sendRaw(sender, "&d/claim merge <claim-id> &7- Merge another owned claim into your primary claim");
        Msg.sendRaw(sender, "&d/claim showclaim &7- Toggle claim border particles");
        Msg.sendRaw(sender, "&d/claim select &7- Open the Peaceful/Aggressive selector");
        Msg.sendRaw(sender, "&d/claim switch &7- Switch playstyle when your cooldown is ready");
        Msg.sendRaw(sender, "&d/claim delete &7- Delete the claim you're standing in");
        if (sender.hasPermission("incogclaims.admin")) {
            Msg.sendRaw(sender, "&c/claim admin <list|info|delete|resize|transfer|trust|untrust|give|setblocks|removecooldown>");
            Msg.sendRaw(sender, "&8Tip: &7Admin claim arguments accept a simple ID like &f#12 &7or &fhere&7.");
        }
    }

    private Player player(CommandSender sender) {
        if (sender instanceof Player player) return player;
        Msg.sendRaw(sender, "&cPlayers only.");
        return null;
    }

    private ItemStack coreItem(boolean extra) {
        return plugin.createClaimCore(extra);
    }

    private boolean hasCoreItem(Player player, boolean extra) {
        if (containsCore(player.getInventory().getContents(), extra)) return true;

        // Claim Cores that overflowed into /stash still count as owned/unplaced.
        // This prevents a full inventory from being used to request duplicate cores.
        var economy = plugin.host().economyModule();
        if (economy != null && economy.stash() != null) {
            return containsCore(economy.stash().get(player.getUniqueId()), extra);
        }
        return false;
    }

    private boolean containsCore(Iterable<ItemStack> items, boolean extra) {
        for (ItemStack item : items) {
            if (item == null || !item.hasItemMeta()) continue;
            ItemMeta meta = item.getItemMeta();
            if (meta != null && meta.getPersistentDataContainer().has(
                    extra ? plugin.getExtraCoreBlockKey() : plugin.getCoreBlockKey(),
                    PersistentDataType.STRING)) return true;
        }
        return false;
    }

    private boolean containsCore(ItemStack[] items, boolean extra) {
        return containsCore(java.util.Arrays.asList(items), extra);
    }

    private int deliverCore(Player player, boolean extra) {
        ItemStack core = coreItem(extra);
        var economy = plugin.host().economyModule();
        if (economy != null && economy.stash() != null) {
            return economy.stash().deliverOrStash(player, core);
        }

        // Economy/stash should normally be available in IncogUtils. If it is not,
        // never delete the core: give what fits and safely drop any overflow at the player.
        var leftovers = player.getInventory().addItem(core);
        for (ItemStack leftover : leftovers.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), leftover);
        }
        return 0;
    }

    private void core(CommandSender sender) {
        Player player = player(sender);
        if (player == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());

        if (data.getType() == null) {
            Msg.send(player, "&cChoose Peaceful or Aggressive first with &f/claim select&c.");
            return;
        }
        if (plugin.getClaimManager().hasClaim(player.getUniqueId())) {
            if (hasCoreItem(player, true)) {
                Msg.send(player, "&eYou already purchased another Claim Core. Place that core to create your next claim.");
            } else {
                Msg.send(player, "&cYou already own a claim. Use &f/claim buy &cto purchase another Claim Core.");
            }
            return;
        }
        if (hasCoreItem(player, false)) {
            Msg.send(player, "&cYou already have your free Claim Core. Place it before requesting another one.");
            return;
        }

        long cooldown = TimeUnit.MINUTES.toMillis(plugin.getConfigManager().getCoreCooldownMinutes());
        long elapsed = System.currentTimeMillis() - data.getLastCoreTimestamp();
        if (data.getLastCoreTimestamp() != 0 && elapsed < cooldown) {
            Msg.send(player, "&cClaim Core cooldown: " + TimeUnit.MILLISECONDS.toMinutes(cooldown - elapsed) + "m remaining.");
            return;
        }

        data.setLastCoreTimestamp(System.currentTimeMillis());
        int stashed = deliverCore(player, false);
        if (stashed > 0) {
            Msg.send(player, "&aYour first Claim Core was sent to &f/stash &abecause your inventory is full.");
        } else {
            Msg.send(player, "&aYour first Claim Core was given. &7Place it to create your primary claim.");
        }
    }

    private void buy(CommandSender sender) {
        Player player = player(sender);
        if (player == null) return;
        if (!plugin.getClaimManager().hasClaim(player.getUniqueId())) {
            Msg.send(player, "&cCreate your first claim with &f/claim core &cbefore buying another Claim Core.");
            return;
        }

        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        int blockCost = plugin.getConfigManager().getExtraClaimCostBlocks();
        int crystalCost = plugin.getConfigManager().getExtraClaimCostEndCrystals();
        if (data.getClaimBlocks() < blockCost || count(player, Material.END_CRYSTAL) < crystalCost) {
            Msg.send(player, "&cAnother Claim Core costs &f" + blockCost + " claim blocks &cand &f"
                    + crystalCost + " end crystals&c.");
            return;
        }

        data.addClaimBlocks(-blockCost);
        remove(player, Material.END_CRYSTAL, crystalCost);
        int stashed = deliverCore(player, true);
        if (stashed > 0) {
            Msg.send(player, "&aPurchased another Claim Core! &7Your inventory was full, so it was sent to &f/stash&7.");
        } else {
            Msg.send(player, "&aPurchased another Claim Core! &7Place it to create an additional claim.");
        }
    }

    private int count(Player player, Material material) {
        int total = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == material) total += item.getAmount();
        }
        return total;
    }

    private void remove(Player player, Material material, int amount) {
        for (int slot = 0; slot < player.getInventory().getSize() && amount > 0; slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack == null || stack.getType() != material) continue;
            int take = Math.min(amount, stack.getAmount());
            stack.setAmount(stack.getAmount() - take);
            amount -= take;
            if (stack.getAmount() == 0) player.getInventory().setItem(slot, null);
        }
    }

    /** Current owned claim, preferring the claim the player is standing inside. */
    private Claim own(Player player) {
        Claim at = plugin.getClaimManager().getClaimAt(player.getLocation());
        if (at != null && at.getOwner().equals(player.getUniqueId())) return at;
        return plugin.getClaimManager().getClaimByOwner(player.getUniqueId());
    }

    private void gui(CommandSender sender) {
        Player player = player(sender);
        if (player == null) return;
        Claim claim = own(player);
        if (claim == null) {
            Msg.send(player, "&cYou don't own a claim. Use &f/claim core &cto get your first Claim Core.");
            return;
        }
        ClaimMenuGUI.open(player, claim, plugin.getPlayerDataManager().get(claim.getOwner()),
                plugin.getConfigManager().getLargestSize());
    }

    private void show(CommandSender sender) {
        Player player = player(sender);
        if (player == null) return;
        boolean enabled = plugin.getProtectionListener().toggleShowClaim(player.getUniqueId());
        Msg.send(player, enabled ? "&aClaim borders enabled." : "&eClaim borders disabled.");
    }

    private void select(CommandSender sender) {
        Player player = player(sender);
        if (player == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data.hasChosenType()
                && data.getSwitchCooldownRemainingMillis(plugin.getConfigManager().getSwitchCooldownDays()) > 0) {
            Msg.send(player, "&cYour claim-type switch is still on cooldown.");
            return;
        }
        TypeSelectGUI.open(player);
    }

    private void trust(CommandSender sender, String[] args, boolean add) {
        Player player = player(sender);
        if (player == null) return;
        if (args.length < 2) {
            Msg.send(player, "&cUsage: /claim " + (add ? "trust" : "untrust") + " <player>");
            return;
        }
        Claim claim = own(player);
        if (claim == null) {
            Msg.send(player, "&cYou don't own a claim.");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            Msg.send(player, "&cPlayer must be online.");
            return;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            Msg.send(player, "&eYou already own this claim.");
            return;
        }

        if (add) {
            if (plugin.getPlayerDataManager().get(target.getUniqueId()).getType() != claim.getType()) {
                Msg.send(player, "&cThey must use the same claim type.");
                return;
            }
            claim.getTrusted().add(target.getUniqueId());
        } else {
            claim.getTrusted().remove(target.getUniqueId());
        }
        Msg.send(player, add ? "&aTrusted " + target.getName() + "." : "&eUntrusted " + target.getName() + ".");
    }

    private void switchType(CommandSender sender) {
        Player player = player(sender);
        if (player == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data.getType() == null) {
            select(sender);
            return;
        }
        long remaining = data.getSwitchCooldownRemainingMillis(plugin.getConfigManager().getSwitchCooldownDays());
        if (remaining > 0) {
            Msg.send(player, "&cYour switch is on cooldown.");
            return;
        }
        plugin.applyTypeSelection(player,
                data.getType() == ClaimType.PVP ? ClaimType.PEACEFUL : ClaimType.PVP);
        Msg.send(player, "&aClaim type changed to " + data.getType() + ".");
    }

    private void info(CommandSender sender) {
        Player player = player(sender);
        if (player == null) return;
        Claim claim = own(player);
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        Msg.send(player, "&7Claim blocks: &f" + data.getClaimBlocks() + "/" + plugin.getConfigManager().getMaxClaimBlocks());
        if (claim == null) return;
        Msg.send(player, "&7Claim ID: &d" + claim.getDisplayId());
        Msg.send(player, "&7Size: &f" + claim.getSize() + " &7Full height: &f" + claim.isFullHeight());
        Msg.send(player, "&7Obsidian + crying obsidian: &f" + claim.getObsidianCount() + "/"
                + plugin.getConfigManager().getMaxObsidianPerClaim());
    }

    private void delete(CommandSender sender) {
        Player player = player(sender);
        if (player == null) return;
        Claim claim = plugin.getClaimManager().getClaimAt(player.getLocation());
        if (claim == null || !claim.getOwner().equals(player.getUniqueId())) {
            Msg.send(player, "&cStand inside one of your claims to delete it.");
            return;
        }
        String displayId = claim.getDisplayId();
        plugin.getClaimManager().removeClaim(claim);
        Msg.send(player, "&aClaim " + displayId + " deleted.");
    }

    private void merge(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return;
        if (args.length < 2) {
            Msg.send(player, "&cUsage: /claim merge <claim-id>");
            return;
        }

        Claim target = plugin.getClaimManager().getClaimAt(player.getLocation());
        if (target == null || !target.getOwner().equals(player.getUniqueId()) || !target.isPrimary()) {
            Msg.send(player, "&cStand inside your primary claim; it is the claim that remains after merging.");
            return;
        }

        Claim other = plugin.getClaimManager().findClaim(args[1]);
        if (other == null || other == target || !other.getOwner().equals(player.getUniqueId())
                || !other.getWorldName().equals(target.getWorldName())) {
            Msg.send(player, "&cThat is not another one of your claims in this world.");
            return;
        }

        int otherHalf = other.getHalf();
        int maxDist = Math.max(
                Math.max(Math.abs((other.getCoreX() - otherHalf) - target.getCoreX()),
                        Math.abs((other.getCoreX() + otherHalf) - target.getCoreX())),
                Math.max(Math.abs((other.getCoreY() - otherHalf) - target.getCoreY()),
                        Math.abs((other.getCoreY() + otherHalf) - target.getCoreY()))
        );
        maxDist = Math.max(maxDist,
                Math.max(Math.abs((other.getCoreZ() - otherHalf) - target.getCoreZ()),
                        Math.abs((other.getCoreZ() + otherHalf) - target.getCoreZ())));
        int newSize = Math.max(target.getSize(), maxDist * 2);
        if ((newSize & 1) == 1) newSize++;

        int cost = Math.max(0, newSize - target.getSize()) * plugin.getConfigManager().getMergeCostPerBlock();
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data.getClaimBlocks() < cost) {
            Msg.send(player, "&cMerging costs " + cost + " claim blocks; you have " + data.getClaimBlocks() + ".");
            return;
        }
        if (plugin.getClaimManager().wouldOverlapExcept(target, other, target.getWorldName(),
                target.getCoreX(), target.getCoreY(), target.getCoreZ(), newSize)) {
            Msg.send(player, "&cThe merged area would overlap another claim.");
            return;
        }

        boolean mergedFullHeight = target.isFullHeight() || other.isFullHeight();
        if (mergedFullHeight) {
            if (newSize < plugin.getConfigManager().getLargestSize()) {
                Msg.send(player, "&cA full-height claim cannot be merged into an area smaller than the Large claim size.");
                return;
            }
            if (plugin.getClaimManager().wouldOverlapFullHeightExcept(target, other, newSize)) {
                Msg.send(player, "&cThe merged full-height footprint would overlap another claim.");
                return;
            }
        }

        data.addClaimBlocks(-cost);
        target.getTrusted().addAll(other.getTrusted());
        target.setFullHeight(mergedFullHeight);
        plugin.getClaimManager().removeClaim(other);
        plugin.getClaimManager().resizeClaim(target, newSize);
        Msg.send(player, "&aClaims merged into " + target.getDisplayId() + ". New size: " + newSize
                + ". Cost: " + cost + " claim blocks.");
    }

    private void admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("incogclaims.admin")) {
            Msg.sendRaw(sender, "&cNo permission.");
            return;
        }
        if (args.length < 2) {
            adminHelp(sender);
            return;
        }

        String sub = args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> adminList(sender);
            case "info" -> adminInfo(sender, args);
            case "delete" -> adminDelete(sender, args);
            case "resize" -> adminResize(sender, args);
            case "transfer" -> adminTransfer(sender, args);
            case "trust" -> adminTrust(sender, args, true);
            case "untrust" -> adminTrust(sender, args, false);
            case "give" -> adminGive(sender, args);
            case "setblocks" -> adminSetBlocks(sender, args);
            case "removecooldown" -> adminRemoveCooldown(sender, args);
            default -> adminHelp(sender);
        }
    }

    private void adminHelp(CommandSender sender) {
        Msg.sendRaw(sender, "&8&m--------&r &c&lIC Admin &8&m--------");
        Msg.sendRaw(sender, "&c/claim admin list");
        Msg.sendRaw(sender, "&c/claim admin info <claim-id|here>");
        Msg.sendRaw(sender, "&c/claim admin delete <claim-id|here>");
        Msg.sendRaw(sender, "&c/claim admin resize <claim-id|here> <size>");
        Msg.sendRaw(sender, "&c/claim admin transfer <claim-id|here> <player>");
        Msg.sendRaw(sender, "&c/claim admin trust <claim-id|here> <player>");
        Msg.sendRaw(sender, "&c/claim admin untrust <claim-id|here> <player>");
        Msg.sendRaw(sender, "&c/claim admin give <claimbreaker|core|blocks> <player> [amount]");
        Msg.sendRaw(sender, "&c/claim admin setblocks <player> <amount>");
        Msg.sendRaw(sender, "&c/claim admin removecooldown <player>");
    }

    private Claim resolveAdminClaim(CommandSender sender, String token) {
        if (token != null && token.equalsIgnoreCase("here")) {
            Player player = player(sender);
            return player == null ? null : plugin.getClaimManager().getClaimAt(player.getLocation());
        }
        Claim claim = plugin.getClaimManager().findClaim(token);
        if (claim == null) Msg.sendRaw(sender, "&cUnknown claim ID. Use /claim admin list.");
        return claim;
    }

    private void adminList(CommandSender sender) {
        List<Claim> claims = plugin.getClaimManager().getAllClaimsSorted();
        if (claims.isEmpty()) {
            Msg.sendRaw(sender, "&7No claims exist.");
            return;
        }
        Msg.sendRaw(sender, "&5&lIC Claim List &7(" + claims.size() + ")");
        for (Claim claim : claims) {
            String owner = Bukkit.getOfflinePlayer(claim.getOwner()).getName();
            if (owner == null) owner = claim.getOwner().toString().substring(0, 8);
            Msg.sendRaw(sender, "&d" + claim.getDisplayId() + " &7| &f" + owner
                    + " &7| &f" + claim.getSize() + "x" + claim.getSize()
                    + " &7| &f" + claim.getWorldName());
        }
    }

    private void adminInfo(CommandSender sender, String[] args) {
        if (args.length < 3) {
            Msg.sendRaw(sender, "&cUsage: /claim admin info <claim-id|here>");
            return;
        }
        Claim claim = resolveAdminClaim(sender, args[2]);
        if (claim == null) return;
        String owner = Bukkit.getOfflinePlayer(claim.getOwner()).getName();
        Msg.sendRaw(sender, "&d" + claim.getDisplayId() + " &7Owner: &f" + owner
                + " &7Size: &f" + claim.getSize() + " &7Trusted: &f" + claim.getTrusted().size()
                + " &7World: &f" + claim.getWorldName());
    }

    private void adminDelete(CommandSender sender, String[] args) {
        if (args.length < 3) {
            Msg.sendRaw(sender, "&cUsage: /claim admin delete <claim-id|here>");
            return;
        }
        Claim claim = resolveAdminClaim(sender, args[2]);
        if (claim == null) return;
        String id = claim.getDisplayId();
        plugin.getClaimManager().removeClaim(claim);
        Msg.sendRaw(sender, "&aDeleted claim " + id + ".");
    }

    private void adminResize(CommandSender sender, String[] args) {
        if (args.length < 4) {
            Msg.sendRaw(sender, "&cUsage: /claim admin resize <claim-id|here> <size>");
            return;
        }
        Claim claim = resolveAdminClaim(sender, args[2]);
        if (claim == null) return;
        try {
            int size = Integer.parseInt(args[3]);
            plugin.getClaimManager().resizeClaim(claim, size);
            if (size < plugin.getConfigManager().getLargestSize()) claim.setFullHeight(false);
            Msg.sendRaw(sender, "&aResized " + claim.getDisplayId() + " to " + size + ".");
        } catch (NumberFormatException e) {
            Msg.sendRaw(sender, "&cInvalid size.");
        }
    }

    private void adminTransfer(CommandSender sender, String[] args) {
        if (args.length < 4) {
            Msg.sendRaw(sender, "&cUsage: /claim admin transfer <claim-id|here> <player>");
            return;
        }
        Claim claim = resolveAdminClaim(sender, args[2]);
        if (claim == null) return;
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[3]);
        plugin.getClaimManager().transferClaim(claim, target.getUniqueId());
        Msg.sendRaw(sender, "&aTransferred " + claim.getDisplayId() + " to " + args[3] + ".");
    }

    private void adminTrust(CommandSender sender, String[] args, boolean add) {
        if (args.length < 4) {
            Msg.sendRaw(sender, "&cUsage: /claim admin " + (add ? "trust" : "untrust")
                    + " <claim-id|here> <player>");
            return;
        }
        Claim claim = resolveAdminClaim(sender, args[2]);
        if (claim == null) return;
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[3]);
        if (add) claim.getTrusted().add(target.getUniqueId());
        else claim.getTrusted().remove(target.getUniqueId());
        Msg.sendRaw(sender, "&aUpdated trust for " + claim.getDisplayId() + ".");
    }

    private void adminGive(CommandSender sender, String[] args) {
        if (args.length < 4) {
            Msg.sendRaw(sender, "&cUsage: /claim admin give <claimbreaker|core|blocks> <player> [amount]");
            return;
        }
        Player target = Bukkit.getPlayer(args[3]);
        if (target == null) {
            Msg.sendRaw(sender, "&cPlayer must be online.");
            return;
        }

        switch (args[2].toLowerCase(Locale.ROOT)) {
            case "claimbreaker" -> target.getInventory().addItem(EnchantListener.buildClaimBreakerPickaxe(plugin));
            case "core" -> target.getInventory().addItem(coreItem(false));
            case "blocks" -> {
                if (args.length < 5) {
                    Msg.sendRaw(sender, "&cUsage: /claim admin give blocks <player> <amount>");
                    return;
                }
                try {
                    int amount = Integer.parseInt(args[4]);
                    PlayerData data = plugin.getPlayerDataManager().get(target.getUniqueId());
                    data.setClaimBlocks(Math.max(0, Math.min(plugin.getConfigManager().getMaxClaimBlocks(),
                            data.getClaimBlocks() + amount)));
                } catch (NumberFormatException e) {
                    Msg.sendRaw(sender, "&cInvalid block amount.");
                    return;
                }
            }
            default -> {
                Msg.sendRaw(sender, "&cUnknown give type.");
                return;
            }
        }
        Msg.sendRaw(sender, "&aDone.");
    }

    private void adminSetBlocks(CommandSender sender, String[] args) {
        if (args.length < 4) {
            Msg.sendRaw(sender, "&cUsage: /claim admin setblocks <player> <amount>");
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[2]);
        try {
            int amount = Integer.parseInt(args[3]);
            plugin.getPlayerDataManager().get(target.getUniqueId()).setClaimBlocks(
                    Math.max(0, Math.min(plugin.getConfigManager().getMaxClaimBlocks(), amount)));
            Msg.sendRaw(sender, "&aClaim blocks set.");
        } catch (NumberFormatException e) {
            Msg.sendRaw(sender, "&cInvalid block amount.");
        }
    }

    private void adminRemoveCooldown(CommandSender sender, String[] args) {
        if (args.length < 3) {
            Msg.sendRaw(sender, "&cUsage: /claim admin removecooldown <player>");
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[2]);
        PlayerData data = plugin.getPlayerDataManager().get(target.getUniqueId());
        data.setLastCoreTimestamp(0);
        data.setLastSwitchTimestamp(0);
        plugin.getPvpManager().clearCooldown(target.getUniqueId());
        Msg.sendRaw(sender, "&aAll IC cooldowns cleared.");
    }

    private void reload(CommandSender sender) {
        if (!sender.hasPermission("incogclaims.admin")) {
            Msg.sendRaw(sender, "&cNo permission.");
            return;
        }
        plugin.getConfigManager().load();
        Msg.sendRaw(sender, "&aIC config reloaded.");
    }

    // ---------------------------------------------------------------------
    // Tab completion: every command branch exposes useful next arguments.
    // ---------------------------------------------------------------------
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> roots = new ArrayList<>(List.of(
                    "help", "core", "buy", "menu", "showclaim", "select", "trust", "untrust",
                    "switch", "info", "delete", "merge"
            ));
            if (sender.hasPermission("incogclaims.admin")) {
                roots.add("admin");
                roots.add("reload");
            }
            return filter(roots, args[0]);
        }

        String root = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2) {
            if (root.equals("trust") || root.equals("untrust")) return onlinePlayers(args[1]);
            if (root.equals("merge") && sender instanceof Player player) {
                Claim primary = plugin.getClaimManager().getClaimByOwner(player.getUniqueId());
                return filter(plugin.getClaimManager().getClaimsOwnedBy(player.getUniqueId()).stream()
                        .filter(claim -> primary == null || claim != primary)
                        .map(Claim::getDisplayId)
                        .toList(), args[1]);
            }
            if (root.equals("admin") && sender.hasPermission("incogclaims.admin")) {
                return filter(List.of("list", "info", "delete", "resize", "transfer", "trust", "untrust",
                        "give", "setblocks", "removecooldown"), args[1]);
            }
            return List.of();
        }

        if (!root.equals("admin") || !sender.hasPermission("incogclaims.admin")) return List.of();
        String sub = args[1].toLowerCase(Locale.ROOT);

        if (args.length == 3) {
            if (List.of("info", "delete", "resize", "transfer", "trust", "untrust").contains(sub)) {
                return filter(claimIdsWithHere(sender), args[2]);
            }
            if (sub.equals("give")) return filter(List.of("claimbreaker", "core", "blocks"), args[2]);
            if (sub.equals("setblocks") || sub.equals("removecooldown")) return onlinePlayers(args[2]);
        }

        if (args.length == 4) {
            if (sub.equals("resize")) {
                return filter(plugin.getConfigManager().getClaimSizes().keySet().stream()
                        .map(String::valueOf).toList(), args[3]);
            }
            if (sub.equals("transfer") || sub.equals("trust") || sub.equals("untrust")) {
                return onlinePlayers(args[3]);
            }
            if (sub.equals("give")) return onlinePlayers(args[3]);
            if (sub.equals("setblocks")) return filter(List.of("100", "500", "1000", "5000"), args[3]);
        }

        if (args.length == 5 && sub.equals("give") && args[2].equalsIgnoreCase("blocks")) {
            return filter(List.of("100", "500", "1000", "5000"), args[4]);
        }
        return List.of();
    }

    private List<String> claimIdsWithHere(CommandSender sender) {
        List<String> values = plugin.getClaimManager().getAllClaimsSorted().stream()
                .map(Claim::getDisplayId)
                .collect(Collectors.toCollection(ArrayList::new));
        if (sender instanceof Player) values.add(0, "here");
        return values;
    }

    private List<String> onlinePlayers(String prefix) {
        return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), prefix);
    }

    private List<String> filter(Collection<String> values, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return values.stream()
                .filter(value -> value.toLowerCase(Locale.ROOT).startsWith(lower))
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .toList();
    }
}

package com.incogdev.incogclaims.config;

import com.incogdev.incogclaims.IncogClaims;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import java.util.*;

public class ConfigManager {
    private final IncogClaims plugin;
    private Material claimCoreMaterial; private final Map<Integer,Integer> claimSizes=new TreeMap<>();
    private int earnIntervalMinutes, earnAmount, switchCooldownDays, coreCooldownMinutes, maxObsidianPerClaim, obsidianBufferRadius, maxBedrockPerClaim, maxActiveRaidTntPerPlayer;
    private int extraClaimCostBlocks, extraClaimCostEndCrystals, maxClaimBlocks, borderParticleSpacing, combatTagSeconds, mergeCostPerBlock;
    private long tabSuffixRefreshTicks;
    private boolean tntRaidEnabled, requirePvpAttackerToRaid, opBypass, claimbreakerCraftable;
    private boolean claimbreakerAchievementEnabled, claimbreakerAchievementChatEnabled, claimBeaconTrustedOnly;
    private double claimbreakerLootChance, claimedBlockExplosionBreakChance; private long pvpCooldownMillis;
    private String claimbreakerAchievementTitle, claimbreakerAchievementDescription, claimbreakerCraftAnnouncement, claimbreakerAchievementChatMessage;
    private String peacefulIcon, aggressiveIcon;
    private final LinkedHashMap<String,Double> earnRates = new LinkedHashMap<>(); private final List<String> combatBlockedCommands=new ArrayList<>();

    public ConfigManager(IncogClaims plugin){this.plugin=plugin;}
    public void load(){
        plugin.saveDefaultConfig(); plugin.reloadConfig(); var c=plugin.getConfig();
        Material m=Material.matchMaterial(c.getString("claim-core-material","BEACON")); claimCoreMaterial=m==null?Material.BEACON:m;
        claimSizes.clear(); ConfigurationSection ss=c.getConfigurationSection("claim-sizes"); if(ss!=null)for(String k:ss.getKeys(false))try{claimSizes.put(Integer.parseInt(k),ss.getInt(k));}catch(Exception ignored){}
        if(claimSizes.isEmpty()){claimSizes.put(48,0);claimSizes.put(96,500);}
        earnIntervalMinutes=c.getInt("earn-interval-minutes",5); earnAmount=c.getInt("earn-amount",25); switchCooldownDays=c.getInt("switch-cooldown-days",3); coreCooldownMinutes=c.getInt("core-cooldown-minutes",30);
        maxObsidianPerClaim=c.getInt("max-obsidian-per-claim",120); obsidianBufferRadius=c.getInt("obsidian-buffer-radius",4); maxBedrockPerClaim=c.getInt("max-bedrock-per-claim",0);
        extraClaimCostBlocks=c.getInt("extra-claim-cost-blocks",500); extraClaimCostEndCrystals=c.getInt("extra-claim-cost-end-crystals",5); tntRaidEnabled=c.getBoolean("tnt-raid-enabled",true);
        requirePvpAttackerToRaid=c.getBoolean("require-pvp-attacker-to-raid",true); opBypass=c.getBoolean("op-bypass",true); claimbreakerLootChance=c.getDouble("claimbreaker-loot-chance",0.0015);
        maxActiveRaidTntPerPlayer=Math.max(1,c.getInt("tnt-raid.max-active-per-player",10));
        claimedBlockExplosionBreakChance=Math.max(0.0,Math.min(1.0,c.getDouble("raid-explosions.claimed-block-break-chance",0.35)));
        claimbreakerCraftable=c.getBoolean("claimbreaker-craftable",true); maxClaimBlocks=c.getInt("blocksLimit",c.getInt("max-claim-blocks",5000)); borderParticleSpacing=Math.max(1,c.getInt("border-particle-spacing",1));
        claimbreakerAchievementEnabled=c.getBoolean("claimbreaker-achievement.enabled",true);
        claimbreakerAchievementTitle=c.getString("claimbreaker-achievement.title","Claim Breaker!");
        claimbreakerAchievementDescription=c.getString("claimbreaker-achievement.description","Craft a Claim Breaker Pickaxe for the first time.");
        claimbreakerCraftAnnouncement=c.getString("claimbreaker-achievement.craft-announcement","%player% has forged a Claim Breaker!");
        // Migrate the old shipped default in memory so existing servers get the new announcement
        // without requiring owners to delete or regenerate config.yml. Custom announcements remain untouched.
        if ("&6&l[Server] &e%player% &7has crafted a &5&lClaim Breaker&7!".equals(claimbreakerCraftAnnouncement))
            claimbreakerCraftAnnouncement="%player% has forged a Claim Breaker!";
        claimbreakerAchievementChatEnabled=c.getBoolean("claimbreaker-achievement.chat.enabled",true);
        claimbreakerAchievementChatMessage=c.getString("claimbreaker-achievement.chat.message","&5%player% &7has made the advancement [&d&lClaim Breaker!&7]");
        claimBeaconTrustedOnly=c.getBoolean("claim-beacons.trusted-only",true);
        peacefulIcon=c.getString("playstyle-icons.peaceful","[P]");
        aggressiveIcon=c.getString("playstyle-icons.aggressive","[A]");
        if(peacefulIcon==null || peacefulIcon.isBlank()) peacefulIcon="[P]";
        if(aggressiveIcon==null || aggressiveIcon.isBlank()) aggressiveIcon="[A]";
        tabSuffixRefreshTicks=Math.max(20L,Math.min(1200L,c.getLong("playstyle-icons.tab-refresh-ticks",40L)));
        pvpCooldownMillis=c.getLong("pvp.cooldown-minutes",15)*60000L; combatTagSeconds=Math.max(1,c.getInt("combat.tag-seconds",15)); mergeCostPerBlock=Math.max(0,c.getInt("merge.cost-per-size-block",10));
        combatBlockedCommands.clear(); for(String s:c.getStringList("combat.blocked-commands")) combatBlockedCommands.add(s.toLowerCase(Locale.ROOT).replaceFirst("^/","")); if(combatBlockedCommands.isEmpty()){combatBlockedCommands.add("tpa");combatBlockedCommands.add("home");}
        earnRates.clear();
        ConfigurationSection er=c.getConfigurationSection("claim-block-earn-permissions");
        if(er!=null) for(String tierName:er.getKeys(false)) {
            ConfigurationSection tier=er.getConfigurationSection(tierName);
            if(tier==null) continue;
            String permission=tier.getString("permission","").trim();
            double rate=Math.max(0.0,tier.getDouble("blocks-per-second",0.0));
            if(!permission.isEmpty() && rate>0.0) earnRates.put(permission,rate);
        }
    }
    public Material getClaimCoreMaterial(){return claimCoreMaterial;} public Map<Integer,Integer> getClaimSizes(){return new LinkedHashMap<>(claimSizes);} public int getSmallestSize(){return claimSizes.keySet().stream().min(Integer::compareTo).orElse(48);} public int getLargestSize(){return claimSizes.keySet().stream().max(Integer::compareTo).orElse(48);}
    public int getEarnIntervalMinutes(){return earnIntervalMinutes;} public int getEarnAmount(){return earnAmount;} public int getSwitchCooldownDays(){return switchCooldownDays;} public int getCoreCooldownMinutes(){return coreCooldownMinutes;}
    public int getMaxObsidianPerClaim(){return maxObsidianPerClaim;} public int getObsidianBufferRadius(){return obsidianBufferRadius;} public int getMaxBedrockPerClaim(){return maxBedrockPerClaim;} public int getExtraClaimCostBlocks(){return extraClaimCostBlocks;} public int getExtraClaimCostEndCrystals(){return extraClaimCostEndCrystals;}
    public boolean isTntRaidEnabled(){return tntRaidEnabled;} public boolean isRequirePvpAttackerToRaid(){return requirePvpAttackerToRaid;} public int getMaxActiveRaidTntPerPlayer(){return maxActiveRaidTntPerPlayer;} public boolean isOpBypass(){return opBypass;} public double getClaimbreakerLootChance(){return claimbreakerLootChance;} public double getClaimedBlockExplosionBreakChance(){return claimedBlockExplosionBreakChance;} public boolean isClaimbreakerCraftable(){return claimbreakerCraftable;}
    public boolean isClaimbreakerAchievementEnabled(){return claimbreakerAchievementEnabled;} public boolean isClaimbreakerAchievementChatEnabled(){return claimbreakerAchievementChatEnabled;} public String getClaimbreakerAchievementTitle(){return claimbreakerAchievementTitle;} public String getClaimbreakerAchievementDescription(){return claimbreakerAchievementDescription;} public String getClaimbreakerCraftAnnouncement(){return claimbreakerCraftAnnouncement;} public String getClaimbreakerAchievementChatMessage(){return claimbreakerAchievementChatMessage;}
    public boolean isClaimBeaconTrustedOnly(){return claimBeaconTrustedOnly;}
    public String getPeacefulIcon(){return peacefulIcon;} public String getAggressiveIcon(){return aggressiveIcon;}
    public long getTabSuffixRefreshTicks(){return tabSuffixRefreshTicks;}
    public int getMaxClaimBlocks(){return maxClaimBlocks;} public int getBorderParticleSpacing(){return borderParticleSpacing;} public long getPvpCooldownMillis(){return pvpCooldownMillis;} public int getCombatTagSeconds(){return combatTagSeconds;} public int getMergeCostPerBlock(){return mergeCostPerBlock;}
    public List<String> getCombatBlockedCommands(){return Collections.unmodifiableList(combatBlockedCommands);} public String getMessage(String path){return plugin.getConfig().getString("messages."+path,"");}
    public double getEarnRate(org.bukkit.entity.Player player){ double best=0; for(var e:earnRates.entrySet())if(player.hasPermission(e.getKey()))best=Math.max(best,e.getValue()); return best; }
}

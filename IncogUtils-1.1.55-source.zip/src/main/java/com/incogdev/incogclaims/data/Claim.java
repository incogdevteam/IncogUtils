package com.incogdev.incogclaims.data;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.*;
import java.util.stream.Collectors;

public class Claim {
    private final UUID id;
    /** Human-friendly, stable ID used in commands and GUIs. The UUID remains the internal storage key. */
    private int simpleId;
    private UUID owner;
    private ClaimType type;
    private String world;
    private int coreX, coreY, coreZ;
    private int size;
    /** Largest claim size this claim has ever unlocked; shrinking never revokes it. */
    private int maxUnlockedSize;
    private final Set<UUID> trusted = new HashSet<>();
    private boolean primary = true;
    private int obsidianCount = 0; // includes regular + crying obsidian
    private int bedrockCount = 0;
    private boolean fullHeight = false;
    private final EnumMap<ClaimFlag, Boolean> flags = new EnumMap<>(ClaimFlag.class);

    public Claim(UUID id, UUID owner, ClaimType type, Location core, int size) {
        this.id = id;
        this.owner = owner;
        this.type = type;
        this.world = core.getWorld().getName();
        this.coreX = core.getBlockX();
        this.coreY = core.getBlockY();
        this.coreZ = core.getBlockZ();
        this.size = size;
        this.maxUnlockedSize = size;
    }

    public UUID getId() { return id; }
    public int getSimpleId() { return simpleId; }
    public void setSimpleId(int simpleId) { this.simpleId = simpleId; }
    public String getDisplayId() { return "#" + simpleId; }
    public UUID getOwner() { return owner; }
    public void setOwner(UUID owner) { this.owner = owner; }
    public ClaimType getType() { return type; }
    public void setType(ClaimType type) { this.type = type; }
    public int getSize() { return size; }
    public void setSize(int size) {
        this.size = size;
        this.maxUnlockedSize = Math.max(this.maxUnlockedSize, size);
    }
    public int getMaxUnlockedSize() { return maxUnlockedSize; }
    public void setMaxUnlockedSize(int maxUnlockedSize) {
        this.maxUnlockedSize = Math.max(this.size, maxUnlockedSize);
    }
    public Set<UUID> getTrusted() { return trusted; }
    public boolean isPrimary() { return primary; }
    public void setPrimary(boolean primary) { this.primary = primary; }
    public int getObsidianCount() { return obsidianCount; }
    public void incrementObsidian() { obsidianCount++; }
    public void decrementObsidian() { if (obsidianCount > 0) obsidianCount--; }
    public int getBedrockCount() { return bedrockCount; }
    public void incrementBedrock() { bedrockCount++; }
    public void decrementBedrock() { if (bedrockCount > 0) bedrockCount--; }
    public boolean isFullHeight() { return fullHeight; }
    public void setFullHeight(boolean fullHeight) { this.fullHeight = fullHeight; }

    /**
     * Bottom Y used by the extended-height mode. Claims at/above Y=63 protect from Y=63
     * upward. If the core itself is below Y=63, protection starts 30 blocks below the
     * core instead. The result is always clamped to the world's legal build range.
     */
    public int getFullHeightMinY() {
        int desired = coreY < 63 ? coreY - 30 : 63;
        World w = Bukkit.getWorld(world);
        if (w == null) return desired;
        return Math.max(w.getMinHeight(), Math.min(desired, w.getMaxHeight() - 1));
    }

    public String getWorldName() { return world; }
    public int getCoreX() { return coreX; }
    public int getCoreY() { return coreY; }
    public int getCoreZ() { return coreZ; }

    public boolean getFlag(ClaimFlag flag) {
        Boolean explicit = flags.get(flag);
        if (explicit != null) return explicit;
        return flag == ClaimFlag.PVP && type == ClaimType.PVP;
    }

    public void setFlag(ClaimFlag flag, boolean value) { flags.put(flag, value); }
    public Map<ClaimFlag, Boolean> getFlags() { return Collections.unmodifiableMap(flags); }

    public Location getCoreLocation() {
        World w = Bukkit.getWorld(world);
        return w == null ? null : new Location(w, coreX, coreY, coreZ);
    }

    public boolean isMember(UUID uuid) { return owner.equals(uuid) || trusted.contains(uuid); }

    public boolean isCoreBlock(int x, int y, int z, String worldName) {
        return worldName.equals(world) && x == coreX && y == coreY && z == coreZ;
    }

    public int getHalf() { return size / 2; }

    public boolean contains(Location loc) {
        if (loc == null || loc.getWorld() == null || !loc.getWorld().getName().equals(world)) return false;
        int half = getHalf();
        int x = loc.getBlockX(), y = loc.getBlockY(), z = loc.getBlockZ();
        boolean horizontal = x >= coreX - half && x <= coreX + half && z >= coreZ - half && z <= coreZ + half;
        if (!horizontal) return false;
        if (fullHeight) return y >= getFullHeightMinY() && y < loc.getWorld().getMaxHeight();
        return y >= coreY - half && y <= coreY + half;
    }

    public boolean isInHorizontalBuffer(Location loc, int padding) {
        if (loc.getWorld() == null || !loc.getWorld().getName().equals(world)) return false;
        int extended = getHalf() + padding;
        int x = loc.getBlockX(), z = loc.getBlockZ();
        return x >= coreX - extended && x <= coreX + extended
                && z >= coreZ - extended && z <= coreZ + extended;
    }

    public boolean overlapsCube(String worldName, int cx, int cy, int cz, int otherSize) {
        if (!worldName.equals(world)) return false;
        int half = getHalf(), otherHalf = otherSize / 2;
        boolean x = Math.abs(cx - coreX) <= half + otherHalf;
        boolean z = Math.abs(cz - coreZ) <= half + otherHalf;
        if (!x || !z) return false;
        if (fullHeight) {
            int otherMaxY = cy + otherHalf;
            return otherMaxY >= getFullHeightMinY();
        }
        return Math.abs(cy - coreY) <= half + otherHalf;
    }

    public Map<String,Object> serialize() {
        Map<String,Object> map = new HashMap<>();
        map.put("id", id.toString());
        map.put("simpleId", simpleId);
        map.put("owner", owner.toString());
        map.put("type", type.name());
        map.put("world", world);
        map.put("coreX", coreX);
        map.put("coreY", coreY);
        map.put("coreZ", coreZ);
        map.put("size", size);
        map.put("maxUnlockedSize", maxUnlockedSize);
        map.put("trusted", trusted.stream().map(UUID::toString).collect(Collectors.toList()));
        map.put("primary", primary);
        map.put("obsidianCount", obsidianCount);
        map.put("bedrockCount", bedrockCount);
        map.put("fullHeight", fullHeight);
        Map<String,Boolean> savedFlags = new LinkedHashMap<>();
        for (var e : flags.entrySet()) savedFlags.put(e.getKey().name(), e.getValue());
        map.put("flags", savedFlags);
        return map;
    }

    @SuppressWarnings("unchecked")
    public static Claim deserialize(Map<String,Object> map) {
        UUID id = UUID.fromString((String) map.get("id"));
        UUID owner = UUID.fromString((String) map.get("owner"));
        ClaimType type = ClaimType.fromString((String) map.get("type"));
        String world = (String) map.get("world");
        int cx = ((Number) map.get("coreX")).intValue();
        int cy = ((Number) map.get("coreY")).intValue();
        int cz = ((Number) map.get("coreZ")).intValue();
        int size = ((Number) map.get("size")).intValue();
        World w = Bukkit.getWorld(world);
        Claim claim = new Claim(id, owner, type, new Location(w, cx, cy, cz), size);
        Object maxUnlocked = map.get("maxUnlockedSize");
        if (maxUnlocked instanceof Number n) claim.maxUnlockedSize = Math.max(size, n.intValue());

        Object sid = map.get("simpleId");
        if (sid instanceof Number n) claim.simpleId = n.intValue();
        else if (sid != null) try { claim.simpleId = Integer.parseInt(sid.toString()); } catch (NumberFormatException ignored) {}

        Object t = map.get("trusted");
        if (t instanceof Iterable<?> it) {
            for (Object o : it) try { claim.trusted.add(UUID.fromString(o.toString())); } catch (Exception ignored) {}
        }
        Object p = map.get("primary");
        claim.primary = p == null || Boolean.parseBoolean(p.toString());
        Object o = map.get("obsidianCount");
        if (o instanceof Number n) claim.obsidianCount = n.intValue();
        Object b = map.get("bedrockCount");
        if (b instanceof Number n) claim.bedrockCount = n.intValue();
        Object fh = map.get("fullHeight");
        claim.fullHeight = fh != null && Boolean.parseBoolean(fh.toString());
        Object fo = map.get("flags");
        if (fo instanceof Map<?,?> fm) {
            for (var e : fm.entrySet()) {
                try {
                    claim.flags.put(ClaimFlag.valueOf(e.getKey().toString()), Boolean.parseBoolean(e.getValue().toString()));
                } catch (Exception ignored) {
                    // Removed/renamed legacy flags are intentionally ignored during migration.
                }
            }
        }
        return claim;
    }
}

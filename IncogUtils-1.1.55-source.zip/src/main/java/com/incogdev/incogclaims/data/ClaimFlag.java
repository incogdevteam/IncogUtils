package com.incogdev.incogclaims.data;

import org.bukkit.Material;

public enum ClaimFlag {
    BLOCK_BREAK("Public Block Breaking", Material.DIAMOND_PICKAXE),
    BLOCK_PLACE("Public Block Placing", Material.GRASS_BLOCK),
    CONTAINERS("Public Containers", Material.CHEST),
    INTERACT("Public Block Interaction", Material.LEVER),
    ENTITIES("Public Entity Interaction", Material.CREEPER_SPAWN_EGG),
    ITEM_PICKUP("Public Item Pickup", Material.HOPPER),
    ENDER_PEARLS("Public Ender Pearls", Material.ENDER_PEARL),
    PVP("PVP Inside Claim", Material.IRON_SWORD);

    private final String displayName;
    private final Material icon;

    ClaimFlag(String displayName, Material icon) {
        this.displayName = displayName;
        this.icon = icon;
    }

    public String getDisplayName() { return displayName; }
    public Material getIcon() { return icon; }
}

package com.incogdev.incogclaims.data;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.*;

public class ClaimManager {

    private final Map<UUID, Claim> claimsById = new HashMap<>();
    private final Map<Integer, Claim> claimsBySimpleId = new HashMap<>();
    private final Map<UUID, Claim> claimsByOwner = new HashMap<>();
    private final Map<UUID, List<Claim>> extraClaimsByOwner = new HashMap<>();
    private int nextSimpleId = 1;

    // Spatial index: "world:chunkX:chunkZ" -> claim IDs whose cuboid overlaps that chunk.
    private final Map<String, Set<UUID>> chunkIndex = new HashMap<>();

    public Claim getClaimByOwner(UUID owner) { return claimsByOwner.get(owner); }
    public Claim getClaimById(UUID id) { return claimsById.get(id); }
    public Claim getClaimBySimpleId(int id) { return claimsBySimpleId.get(id); }

    /** Accepts the new short ID ("12" or "#12") and legacy UUIDs for backwards compatibility. */
    public Claim findClaim(String input) {
        if (input == null || input.isBlank()) return null;
        String cleaned = input.trim();
        if (cleaned.startsWith("#")) cleaned = cleaned.substring(1);
        try {
            Claim byShort = getClaimBySimpleId(Integer.parseInt(cleaned));
            if (byShort != null) return byShort;
        } catch (NumberFormatException ignored) {}
        try { return getClaimById(UUID.fromString(cleaned)); }
        catch (IllegalArgumentException ignored) { return null; }
    }

    public Collection<Claim> getAllClaims() { return claimsById.values(); }

    public List<Claim> getAllClaimsSorted() {
        return claimsById.values().stream()
                .sorted(Comparator.comparingInt(Claim::getSimpleId))
                .toList();
    }

    public boolean hasClaim(UUID owner) { return claimsByOwner.containsKey(owner); }

    public List<Claim> getClaimsOwnedBy(UUID owner) {
        List<Claim> list = new ArrayList<>();
        Claim primary = claimsByOwner.get(owner);
        if (primary != null) list.add(primary);
        list.addAll(extraClaimsByOwner.getOrDefault(owner, Collections.emptyList()));
        return list;
    }

    public int countExtraClaims(UUID owner) {
        return extraClaimsByOwner.getOrDefault(owner, Collections.emptyList()).size();
    }

    public void addClaim(Claim claim) {
        int requested = claim.getSimpleId();
        if (requested <= 0 || claimsBySimpleId.containsKey(requested)) {
            claim.setSimpleId(allocateSimpleId());
        } else {
            nextSimpleId = Math.max(nextSimpleId, requested + 1);
        }

        claimsById.put(claim.getId(), claim);
        claimsBySimpleId.put(claim.getSimpleId(), claim);
        if (claim.isPrimary()) {
            claimsByOwner.put(claim.getOwner(), claim);
        } else {
            extraClaimsByOwner.computeIfAbsent(claim.getOwner(), k -> new ArrayList<>()).add(claim);
        }
        indexClaim(claim);
    }

    private int allocateSimpleId() {
        while (claimsBySimpleId.containsKey(nextSimpleId)) nextSimpleId++;
        return nextSimpleId++;
    }

    public void removeClaim(Claim claim) {
        deindexClaim(claim);
        claimsById.remove(claim.getId());
        claimsBySimpleId.remove(claim.getSimpleId());
        if (claim.isPrimary()) {
            claimsByOwner.remove(claim.getOwner());
        } else {
            List<Claim> list = extraClaimsByOwner.get(claim.getOwner());
            if (list != null) list.remove(claim);
        }
        clearCoreBlock(claim);
    }

    public void resizeClaim(Claim claim, int newSize) {
        deindexClaim(claim);
        claim.setSize(newSize);
        indexClaim(claim);
    }

    private void clearCoreBlock(Claim claim) {
        World world = Bukkit.getWorld(claim.getWorldName());
        if (world == null) return;
        world.getBlockAt(claim.getCoreX(), claim.getCoreY(), claim.getCoreZ()).setType(Material.AIR, false);
    }

    public Claim getClaimAt(Location loc) {
        if (loc == null || loc.getWorld() == null) return null;
        Set<UUID> candidates = chunkIndex.get(chunkKey(loc.getWorld().getName(),
                loc.getBlockX() >> 4, loc.getBlockZ() >> 4));
        if (candidates == null || candidates.isEmpty()) return null;
        for (UUID id : candidates) {
            Claim c = claimsById.get(id);
            if (c != null && c.contains(loc)) return c;
        }
        return null;
    }

    public Claim getClaimInBuffer(Location loc, int padding) {
        if (loc == null || loc.getWorld() == null || padding <= 0) return null;
        int chunkRadius = (padding >> 4) + 1;
        int baseCx = loc.getBlockX() >> 4, baseCz = loc.getBlockZ() >> 4;
        String worldName = loc.getWorld().getName();
        Set<UUID> candidates = new HashSet<>();
        for (int dx = -chunkRadius; dx <= chunkRadius; dx++) {
            for (int dz = -chunkRadius; dz <= chunkRadius; dz++) {
                Set<UUID> inChunk = chunkIndex.get(chunkKey(worldName, baseCx + dx, baseCz + dz));
                if (inChunk != null) candidates.addAll(inChunk);
            }
        }
        for (UUID id : candidates) {
            Claim c = claimsById.get(id);
            if (c != null && c.isInHorizontalBuffer(loc, padding)) return c;
        }
        return null;
    }

    public boolean wouldOverlap(Claim ignore, String world, int cx, int cy, int cz, int size) {
        return wouldOverlapExcept(ignore, null, world, cx, cy, cz, size);
    }

    public boolean wouldOverlapExcept(Claim ignoreA, Claim ignoreB, String world, int cx, int cy, int cz, int size) {
        for (Claim c : claimsById.values()) {
            if ((ignoreA != null && c.getId().equals(ignoreA.getId()))
                    || (ignoreB != null && c.getId().equals(ignoreB.getId()))) continue;
            if (c.overlapsCube(world, cx, cy, cz, size)) return true;
        }
        return false;
    }

    public boolean wouldOverlapFullHeight(Claim claim) {
        return wouldOverlapFullHeightExcept(claim, null, claim.getSize());
    }

    public boolean wouldOverlapFullHeightExcept(Claim claim, Claim ignoreOther, int proposedSize) {
        int half = Math.max(1, proposedSize / 2);
        for (Claim other : claimsById.values()) {
            if (other.getId().equals(claim.getId())
                    || (ignoreOther != null && other.getId().equals(ignoreOther.getId()))
                    || !other.getWorldName().equals(claim.getWorldName())) continue;
            int oh = other.getHalf();
            boolean x = Math.abs(claim.getCoreX() - other.getCoreX()) <= half + oh;
            boolean z = Math.abs(claim.getCoreZ() - other.getCoreZ()) <= half + oh;
            if (!x || !z) continue;
            int proposedMinY = claim.getFullHeightMinY();
            if (other.isFullHeight() || other.getCoreY() + oh >= proposedMinY) return true;
        }
        return false;
    }

    public void transferClaim(Claim claim, UUID newOwner) {
        UUID oldOwner = claim.getOwner();
        if (claim.isPrimary()) {
            claimsByOwner.remove(oldOwner);
            if (claimsByOwner.containsKey(newOwner)) {
                claim.setPrimary(false);
                extraClaimsByOwner.computeIfAbsent(newOwner, k -> new ArrayList<>()).add(claim);
            } else {
                claimsByOwner.put(newOwner, claim);
            }
        } else {
            List<Claim> old = extraClaimsByOwner.get(oldOwner);
            if (old != null) old.remove(claim);
            extraClaimsByOwner.computeIfAbsent(newOwner, k -> new ArrayList<>()).add(claim);
        }
        claim.setOwner(newOwner);
        claim.getTrusted().remove(newOwner);
    }

    private String chunkKey(String world, int chunkX, int chunkZ) {
        return world + ":" + chunkX + ":" + chunkZ;
    }

    private void indexClaim(Claim claim) {
        forEachChunk(claim, key -> chunkIndex.computeIfAbsent(key, k -> new HashSet<>()).add(claim.getId()));
    }

    private void deindexClaim(Claim claim) {
        forEachChunk(claim, key -> {
            Set<UUID> set = chunkIndex.get(key);
            if (set == null) return;
            set.remove(claim.getId());
            if (set.isEmpty()) chunkIndex.remove(key);
        });
    }

    private void forEachChunk(Claim claim, java.util.function.Consumer<String> action) {
        int half = claim.getHalf();
        int minChunkX = (claim.getCoreX() - half) >> 4;
        int maxChunkX = (claim.getCoreX() + half) >> 4;
        int minChunkZ = (claim.getCoreZ() - half) >> 4;
        int maxChunkZ = (claim.getCoreZ() + half) >> 4;
        for (int cx = minChunkX; cx <= maxChunkX; cx++) {
            for (int cz = minChunkZ; cz <= maxChunkZ; cz++) {
                action.accept(chunkKey(claim.getWorldName(), cx, cz));
            }
        }
    }
}

package com.incogdev.incogclaims.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PlayerData {
    private final UUID uuid;
    private ClaimType type;
    private boolean hasChosenType;
    private long lastSwitchTimestamp;
    private long lastCoreTimestamp;
    private long firstJoin;
    private int claimBlocks;
    private boolean pvpEnabled = true;
    private long lastPvpToggleTimestamp = 0L;
    // Exact LuckPerms suffix last installed by Incog-Claims; used to safely replace configurable icons.
    private String playstyleSuffix = "";

    // One-time Claim Breaker crafting achievement fallback state.
    private boolean craftedClaimBreaker = false;

    // Persistent notifications that must survive the player being offline (currently raid alerts).
    private final List<String> pendingNotifications = new ArrayList<>();

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.firstJoin = System.currentTimeMillis();
    }

    public UUID getUuid() { return uuid; }
    public ClaimType getType() { return type; }
    public void setType(ClaimType type) { this.type = type; }
    public boolean hasChosenType() { return hasChosenType; }
    public void setHasChosenType(boolean hasChosenType) { this.hasChosenType = hasChosenType; }
    public long getLastSwitchTimestamp() { return lastSwitchTimestamp; }
    public void setLastSwitchTimestamp(long lastSwitchTimestamp) { this.lastSwitchTimestamp = lastSwitchTimestamp; }
    public long getLastCoreTimestamp() { return lastCoreTimestamp; }
    public void setLastCoreTimestamp(long lastCoreTimestamp) { this.lastCoreTimestamp = lastCoreTimestamp; }
    public long getFirstJoin() { return firstJoin; }
    public void setFirstJoin(long firstJoin) { this.firstJoin = firstJoin; }
    public int getClaimBlocks() { return claimBlocks; }
    public void setClaimBlocks(int claimBlocks) { this.claimBlocks = claimBlocks; }
    public void addClaimBlocks(int amount) { claimBlocks += amount; }
    public boolean isPvpEnabled() { return pvpEnabled; }
    public void setPvpEnabled(boolean pvpEnabled) { this.pvpEnabled = pvpEnabled; }
    public long getLastPvpToggleTimestamp() { return lastPvpToggleTimestamp; }
    public void setLastPvpToggleTimestamp(long lastPvpToggleTimestamp) { this.lastPvpToggleTimestamp = lastPvpToggleTimestamp; }
    public String getPlaystyleSuffix() { return playstyleSuffix; }
    public void setPlaystyleSuffix(String playstyleSuffix) { this.playstyleSuffix = playstyleSuffix == null ? "" : playstyleSuffix; }
    public boolean hasCraftedClaimBreaker() { return craftedClaimBreaker; }
    public void setCraftedClaimBreaker(boolean craftedClaimBreaker) { this.craftedClaimBreaker = craftedClaimBreaker; }

    public synchronized void queueNotification(String message) {
        if (message != null && !message.isBlank()) pendingNotifications.add(message);
    }

    /** Returns and clears all queued notifications atomically. */
    public synchronized List<String> drainPendingNotifications() {
        List<String> copy = new ArrayList<>(pendingNotifications);
        pendingNotifications.clear();
        return copy;
    }

    public synchronized List<String> getPendingNotificationsSnapshot() {
        return new ArrayList<>(pendingNotifications);
    }

    public long getSwitchCooldownRemainingMillis(int days) {
        if (lastSwitchTimestamp == 0) return 0;
        return Math.max(0, java.util.concurrent.TimeUnit.DAYS.toMillis(days)
                - (System.currentTimeMillis() - lastSwitchTimestamp));
    }

    public long getPvpCooldownRemainingMillis(long cooldownMillis) {
        if (lastPvpToggleTimestamp == 0) return 0;
        return Math.max(0, cooldownMillis - (System.currentTimeMillis() - lastPvpToggleTimestamp));
    }

    public Map<String, Object> serialize() {
        Map<String, Object> map = new HashMap<>();
        map.put("type", type == null ? "NONE" : type.name());
        map.put("hasChosenType", hasChosenType);
        map.put("lastSwitchTimestamp", lastSwitchTimestamp);
        map.put("lastCoreTimestamp", lastCoreTimestamp);
        map.put("firstJoin", firstJoin);
        map.put("claimBlocks", claimBlocks);
        map.put("pvpEnabled", pvpEnabled);
        map.put("lastPvpToggleTimestamp", lastPvpToggleTimestamp);
        map.put("playstyleSuffix", playstyleSuffix);
        map.put("craftedClaimBreaker", craftedClaimBreaker);
        map.put("pendingNotifications", getPendingNotificationsSnapshot());
        return map;
    }

    public static PlayerData deserialize(UUID uuid, Map<String, Object> map) {
        PlayerData data = new PlayerData(uuid);
        Object type = map.get("type");
        if (type != null && !type.toString().equalsIgnoreCase("NONE")) {
            data.type = ClaimType.fromString(type.toString());
        }
        data.hasChosenType = Boolean.TRUE.equals(map.get("hasChosenType"));
        data.lastSwitchTimestamp = toLong(map.get("lastSwitchTimestamp"));
        data.lastCoreTimestamp = toLong(map.get("lastCoreTimestamp"));
        data.firstJoin = toLong(map.get("firstJoin"));
        Object claimBlocks = map.get("claimBlocks");
        data.claimBlocks = claimBlocks instanceof Number number ? number.intValue() : 0;
        Object pvpEnabled = map.get("pvpEnabled");
        data.pvpEnabled = pvpEnabled == null || Boolean.parseBoolean(pvpEnabled.toString());
        data.lastPvpToggleTimestamp = toLong(map.get("lastPvpToggleTimestamp"));
        Object playstyleSuffix = map.get("playstyleSuffix");
        data.playstyleSuffix = playstyleSuffix == null ? "" : playstyleSuffix.toString();
        Object crafted = map.get("craftedClaimBreaker");
        data.craftedClaimBreaker = crafted != null && Boolean.parseBoolean(crafted.toString());
        Object pending = map.get("pendingNotifications");
        if (pending instanceof Iterable<?> iterable) {
            for (Object item : iterable) {
                if (item != null && !item.toString().isBlank()) data.pendingNotifications.add(item.toString());
            }
        }
        return data;
    }

    private static long toLong(Object value) {
        if (value instanceof Number number) return number.longValue();
        try {
            return value == null ? 0 : Long.parseLong(value.toString());
        } catch (Exception ignored) {
            return 0;
        }
    }
}

package com.incogdev.incogclaims.data;

import com.incogdev.incogclaims.IncogClaims;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

public class StorageManager {
    private final IncogClaims plugin;
    private final File claimsFile, playersFile;
    public StorageManager(IncogClaims plugin){this.plugin=plugin;claimsFile=new File(plugin.getDataFolder(),"claims.yml");playersFile=new File(plugin.getDataFolder(),"players.yml");}
    public void loadAll(){loadClaims();loadPlayers();}

    /** Synchronous save, used during shutdown so nothing is lost. */
    public synchronized void saveAll(){writeSnapshots(snapshotClaims(),snapshotPlayers());}

    /** Copies the live data on the server thread, then performs only disk/YAML work asynchronously. */
    public void saveAllAsync(){
        Map<UUID,Map<String,Object>> claims=snapshotClaims();
        Map<UUID,Map<String,Object>> players=snapshotPlayers();
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.host(),()->writeSnapshots(claims,players));
    }

    private Map<UUID,Map<String,Object>> snapshotClaims(){Map<UUID,Map<String,Object>> out=new LinkedHashMap<>();for(Claim c:plugin.getClaimManager().getAllClaims())out.put(c.getId(),new LinkedHashMap<>(c.serialize()));return out;}
    private Map<UUID,Map<String,Object>> snapshotPlayers(){Map<UUID,Map<String,Object>> out=new LinkedHashMap<>();for(var e:plugin.getPlayerDataManager().getAll().entrySet())out.put(e.getKey(),new LinkedHashMap<>(e.getValue().serialize()));return out;}

    private synchronized void writeSnapshots(Map<UUID,Map<String,Object>> claims,Map<UUID,Map<String,Object>> players){
        YamlConfiguration cy=new YamlConfiguration();for(var e:claims.entrySet())for(var v:e.getValue().entrySet())cy.set("claims."+e.getKey()+"."+v.getKey(),v.getValue());
        YamlConfiguration py=new YamlConfiguration();for(var e:players.entrySet())for(var v:e.getValue().entrySet())py.set("players."+e.getKey()+"."+v.getKey(),v.getValue());
        try{cy.save(claimsFile);}catch(IOException e){plugin.getLogger().log(Level.SEVERE,"Failed to save claims.yml",e);}try{py.save(playersFile);}catch(IOException e){plugin.getLogger().log(Level.SEVERE,"Failed to save players.yml",e);}
    }
    private void loadClaims(){if(!claimsFile.exists())return;YamlConfiguration y=YamlConfiguration.loadConfiguration(claimsFile);ConfigurationSection s=y.getConfigurationSection("claims");if(s==null)return;for(String k:s.getKeys(false)){ConfigurationSection cs=s.getConfigurationSection(k);if(cs==null)continue;try{plugin.getClaimManager().addClaim(Claim.deserialize(cs.getValues(false)));}catch(Exception e){plugin.getLogger().log(Level.WARNING,"Failed to load claim "+k,e);}}}
    private void loadPlayers(){if(!playersFile.exists())return;YamlConfiguration y=YamlConfiguration.loadConfiguration(playersFile);ConfigurationSection s=y.getConfigurationSection("players");if(s==null)return;for(String k:s.getKeys(false)){ConfigurationSection cs=s.getConfigurationSection(k);if(cs==null)continue;try{UUID u=UUID.fromString(k);plugin.getPlayerDataManager().put(u,PlayerData.deserialize(u,cs.getValues(false)));}catch(Exception e){plugin.getLogger().log(Level.WARNING,"Failed to load player "+k,e);}}}
}

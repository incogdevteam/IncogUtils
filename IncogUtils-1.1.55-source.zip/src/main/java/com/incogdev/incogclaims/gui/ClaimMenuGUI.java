package com.incogdev.incogclaims.gui;

import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.data.ClaimType;
import com.incogdev.incogclaims.data.PlayerData;
import com.incogdev.incogclaims.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

public class ClaimMenuGUI implements InventoryHolder {
    // Four evenly-spaced main options centered across the middle row, plus delete centered below.
    public static final int INFO_SLOT = 10;
    public static final int EXPAND_SLOT = 12;
    public static final int TRUST_SLOT = 14;
    public static final int FLAGS_SLOT = 16;
    public static final int BACK_SLOT = 18;
    public static final int DELETE_SLOT = 22;

    private final Inventory inventory;
    private final Claim claim;

    public ClaimMenuGUI(Claim claim, PlayerData ownerData, int largestSize) {
        this.claim = claim;
        this.inventory = Bukkit.createInventory(this, 27,
                "Claim Core Menu");

        List<String> infoLore = new ArrayList<>();
        infoLore.add("&7Claim ID: &d" + claim.getDisplayId());
        infoLore.add("&7Type: " + (claim.getType() == ClaimType.PVP ? "&c&lAggressive" : "&a&lPeaceful"));
        infoLore.add("&7Size: &f" + claim.getSize() + "x" + claim.getSize()
                + (claim.isFullHeight() ? " &7(full height)" : "x" + claim.getSize()));
        infoLore.add("&7Trusted: &f" + claim.getTrusted().size());
        infoLore.add("&7Claim blocks: &f" + ownerData.getClaimBlocks());

        inventory.setItem(INFO_SLOT, new ItemBuilder(Material.BOOK)
                .name("&d&lClaim Info").lore(infoLore.toArray(new String[0])).build());
        inventory.setItem(EXPAND_SLOT, new ItemBuilder(Material.EMERALD)
                .name("&a&lExpand / Resize Claim")
                .lore("&7Grow, downsize, or configure", "&7full-height protection.", "&eClick to open")
                .build());
        ItemStack ownerHead = new ItemBuilder(Material.PLAYER_HEAD)
                .name("&b&lTrusted Players").lore("&7Click players to trust/untrust.", "&eClick to open").build();
        if (ownerHead.getItemMeta() instanceof SkullMeta skull) {
            skull.setOwningPlayer(Bukkit.getOfflinePlayer(claim.getOwner()));
            ownerHead.setItemMeta(skull);
        }
        inventory.setItem(TRUST_SLOT, ownerHead);
        inventory.setItem(FLAGS_SLOT, new ItemBuilder(Material.COMPARATOR)
                .name("&6&lClaim Flags").lore("&7Control what outsiders can do.", "&eClick to open").build());
    inventory.setItem(BACK_SLOT, new ItemBuilder(Material.BARRIER)
        .name("&eBack to Main Menu").build());
        inventory.setItem(DELETE_SLOT, new ItemBuilder(Material.TNT)
                .name("&c&lDelete Claim").lore("&7Use &f/claim delete &7to confirm.").build());
    }

    public static void open(Player player, Claim claim, PlayerData ownerData, int largestSize) {
        player.openInventory(new ClaimMenuGUI(claim, ownerData, largestSize).inventory);
    }

    public Claim getClaim() { return claim; }
    @Override public Inventory getInventory() { return inventory; }
}

package com.incogdev.incogclaims.gui;

import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.LinkedHashMap;
import java.util.Map;

public class ExpandGUI implements InventoryHolder {

    public static final int FULL_HEIGHT_SLOT = 22;
    public static final int BACK_SLOT = 18;
    private static final int[] SIZE_SLOTS = {10, 12, 14, 16};
    private static final String[] SIZE_LABELS = {"Default", "Small", "Medium", "Large"};

    private final Inventory inventory;
    private final Claim claim;
    private final Map<Integer, Integer> slotToSize = new LinkedHashMap<>();

    public ExpandGUI(Claim claim, Map<Integer, Integer> sizeCosts, int playerBlocks, int largestSize) {
        this.claim = claim;
        this.inventory = Bukkit.createInventory(this, 27,
                "Expand Claim");
        build(sizeCosts, playerBlocks, largestSize);
    }

    private void build(Map<Integer, Integer> sizeCosts, int playerBlocks, int largestSize) {
        int index = 0;
        for (Map.Entry<Integer, Integer> entry : sizeCosts.entrySet()) {
            if (index >= SIZE_SLOTS.length) break;
            int slot = SIZE_SLOTS[index];
            int size = entry.getKey();
            int configuredCost = entry.getValue();
            boolean current = claim.getSize() == size;
            boolean downsizing = size < claim.getSize();
            boolean unlocked = size <= claim.getMaxUnlockedSize();
            boolean freeResize = downsizing || unlocked;
            int transactionCost = freeResize ? 0 : configuredCost;
            boolean affordable = playerBlocks >= transactionCost;

            Material material = current
                    ? Material.LIME_CONCRETE
                    : (freeResize ? Material.YELLOW_CONCRETE
                    : (affordable ? Material.EMERALD_BLOCK : Material.REDSTONE_BLOCK));

            String status;
            if (current) status = "&a&lCURRENT SIZE";
            else if (freeResize) status = "&e&lClick to resize for free";
            else if (affordable) status = "&e&lClick to purchase";
            else status = "&c&lNot enough claim blocks";

            String tier = index < SIZE_LABELS.length ? SIZE_LABELS[index] : "Size " + (index + 1);
            String costLine = freeResize
                    ? "&7Cost: &aFREE &7(unlocked size)"
                    : "&7Cost: &f" + transactionCost + " claim blocks";

            inventory.setItem(slot, new ItemBuilder(material)
                    .name("&5&l" + size + "x" + size + "x" + size)
                    .lore(
                            "&d&l" + tier,
                            costLine,
                            "&7You have: &f" + playerBlocks,
                            "",
                            status
                    ).build());
            slotToSize.put(slot, size);
            index++;
        }

        inventory.setItem(BACK_SLOT, new ItemBuilder(Material.BARRIER)
                .name("&eBack to Claim Core Menu").build());

        ItemBuilder fullHeight = new ItemBuilder(Material.BEACON).name("&d&lFull Height Claim");
        if (claim.getSize() >= largestSize) {
            fullHeight.lore(
                    claim.isFullHeight()
                            ? "&aEnabled &7(Y=" + claim.getFullHeightMinY() + " to build limit)"
                            : "&cDisabled",
                    "&7At/above Y=63: starts at Y=63",
                    "&7Below Y=63: starts 30 blocks below the core",
                    "",
                    "&eClick to toggle"
            );
        } else {
            fullHeight.lore("&7Unlocks at the &fLarge &7claim size.");
        }
        inventory.setItem(FULL_HEIGHT_SLOT, fullHeight.build());
    }

    public Integer getSizeForSlot(int slot) { return slotToSize.get(slot); }
    public Claim getClaim() { return claim; }

    public static void open(Player player, Claim claim, Map<Integer, Integer> sizeCosts,
                            int playerBlocks, int largestSize) {
        player.openInventory(new ExpandGUI(claim, sizeCosts, playerBlocks, largestSize).inventory);
    }

    @Override public Inventory getInventory() { return inventory; }
}

package com.incogdev.incogclaims.gui;

import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.data.ClaimFlag;
import com.incogdev.incogclaims.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

public class FlagsGUI implements InventoryHolder {
    // Two centered rows of four flags each.
    private static final int[] FLAG_SLOTS = {10, 12, 14, 16, 19, 21, 23, 25};

    private final Inventory inventory;
    private final Claim claim;
    private final Map<Integer, ClaimFlag> flags = new HashMap<>();

    public FlagsGUI(Claim claim) {
        this.claim = claim;
        this.inventory = Bukkit.createInventory(this, 27,
                ChatColor.translateAlternateColorCodes('&', "&6Claim Flags"));

        ClaimFlag[] values = ClaimFlag.values();
        for (int i = 0; i < values.length && i < FLAG_SLOTS.length; i++) {
            ClaimFlag flag = values[i];
            int slot = FLAG_SLOTS[i];
            boolean on = claim.getFlag(flag);
            inventory.setItem(slot, new ItemBuilder(flag.getIcon())
                    .name((on ? "&a" : "&c") + flag.getDisplayName())
                    .lore("&7Public/non-trusted access: " + (on ? "&aAllowed" : "&cDenied"),
                            "&eClick to toggle")
                    .build());
            flags.put(slot, flag);
        }
    }

    public Claim getClaim() { return claim; }
    public ClaimFlag getFlag(int slot) { return flags.get(slot); }
    @Override public Inventory getInventory() { return inventory; }
    public static void open(Player player, Claim claim) { player.openInventory(new FlagsGUI(claim).inventory); }
}

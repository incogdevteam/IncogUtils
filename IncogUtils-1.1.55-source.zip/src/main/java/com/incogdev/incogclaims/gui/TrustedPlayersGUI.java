package com.incogdev.incogclaims.gui;

import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;

public class TrustedPlayersGUI implements InventoryHolder {
    public static final int PREVIOUS_SLOT = 45;
    public static final int NEXT_SLOT = 53;
    private static final int PAGE_SIZE = 45;

    private static final int[][] CENTERED_ROW_SLOTS = {
            {},
            {4},
            {3, 5},
            {3, 4, 5},
            {2, 3, 5, 6},
            {2, 3, 4, 5, 6},
            {1, 2, 3, 5, 6, 7},
            {1, 2, 3, 4, 5, 6, 7},
            {0, 1, 2, 3, 5, 6, 7, 8},
            {0, 1, 2, 3, 4, 5, 6, 7, 8}
    };

    private final Inventory inventory;
    private final Claim claim;
    private final int page;
    private final int maxPage;
    private final Map<Integer, UUID> players = new HashMap<>();

    public TrustedPlayersGUI(Claim claim, int requestedPage) {
        this.claim = claim;
        List<Player> online = new ArrayList<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.getUniqueId().equals(claim.getOwner())) online.add(player);
        }
        online.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));

        this.maxPage = Math.max(0, (online.size() - 1) / PAGE_SIZE);
        this.page = Math.max(0, Math.min(requestedPage, maxPage));
        this.inventory = Bukkit.createInventory(this, 54,
                ChatColor.translateAlternateColorCodes('&', "&bTrusted Players &7- Page " + (page + 1)));

        int start = page * PAGE_SIZE;
        int end = Math.min(online.size(), start + PAGE_SIZE);
        int onPage = end - start;

        for (int row = 0; row < 5; row++) {
            int rowStart = row * 9;
            int count = Math.min(9, Math.max(0, onPage - rowStart));
            if (count <= 0) break;
            int[] centered = CENTERED_ROW_SLOTS[count];
            for (int j = 0; j < count; j++) {
                Player target = online.get(start + rowStart + j);
                int slot = row * 9 + centered[j];
                boolean trusted = claim.getTrusted().contains(target.getUniqueId());

                ItemStack head = new ItemBuilder(Material.PLAYER_HEAD)
                        .name((trusted ? "&a" : "&c") + target.getName())
                        .lore(trusted ? "&aTrusted - click to untrust" : "&cNot trusted - click to trust")
                        .build();
                if (head.getItemMeta() instanceof SkullMeta skullMeta) {
                    // Use the actual player's profile so the menu displays their real skin/head.
                    skullMeta.setOwningPlayer(target);
                    head.setItemMeta(skullMeta);
                }
                inventory.setItem(slot, head);
                players.put(slot, target.getUniqueId());
            }
        }

        if (page > 0) inventory.setItem(PREVIOUS_SLOT,
                new ItemBuilder(Material.ARROW).name("&ePrevious Page").build());
        if (page < maxPage) inventory.setItem(NEXT_SLOT,
                new ItemBuilder(Material.ARROW).name("&eNext Page").build());
    }

    public Claim getClaim() { return claim; }
    public int getPage() { return page; }
    public UUID getPlayer(int slot) { return players.get(slot); }
    @Override public Inventory getInventory() { return inventory; }

    public static void open(Player player, Claim claim) { open(player, claim, 0); }
    public static void open(Player player, Claim claim, int page) {
        player.openInventory(new TrustedPlayersGUI(claim, page).inventory);
    }
}

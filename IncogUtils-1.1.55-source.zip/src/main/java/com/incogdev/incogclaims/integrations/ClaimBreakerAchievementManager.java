package com.incogdev.incogclaims.integrations;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.data.PlayerData;
import com.incogdev.incogclaims.util.Msg;
import org.bukkit.advancement.Advancement;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;


/**
 * Registers and awards the one-time Claim Breaker crafting advancement.
 *
 * The Bukkit runtime advancement loader is deprecated, but it is still the only Bukkit/Paper
 * API that can register a custom advancement dynamically from a plugin. The player-data boolean
 * is also persisted as a fallback so a player can never receive the first-craft achievement twice
 * if the runtime advancement fails to load on a future server version.
 */
public class ClaimBreakerAchievementManager {
    private final IncogClaims plugin;
    private final NamespacedKey key;
    private Advancement advancement;

    public ClaimBreakerAchievementManager(IncogClaims plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin.host(), "crafted_claim_breaker");
    }

    public void initialize() {
        if (!plugin.getConfigManager().isClaimbreakerAchievementEnabled()) return;

        advancement = Bukkit.getAdvancement(key);
        if (advancement != null) return;

        String title = escapeJson(plugin.getConfigManager().getClaimbreakerAchievementTitle());
        String description = escapeJson(plugin.getConfigManager().getClaimbreakerAchievementDescription());
        String json = "{" +
                "\"display\":{" +
                "\"icon\":{\"id\":\"minecraft:netherite_pickaxe\"}," +
                "\"title\":{\"text\":\"" + title + "\",\"color\":\"dark_purple\",\"bold\":true}," +
                "\"description\":{\"text\":\"" + description + "\",\"color\":\"gray\"}," +
                "\"frame\":\"challenge\"," +
                "\"show_toast\":true," +
                "\"announce_to_chat\":false," +
                "\"hidden\":false," +
                "\"background\":\"minecraft:gui/advancements/backgrounds/stone\"" +
                "}," +
                "\"criteria\":{\"crafted_claim_breaker\":{\"trigger\":\"minecraft:impossible\"}}," +
                "\"requirements\":[[\"crafted_claim_breaker\"]]," +
                "\"sends_telemetry_event\":false" +
                "}";

        try {
            advancement = Bukkit.getUnsafe().loadAdvancement(key, json);
            if (advancement == null) {
                plugin.getLogger().warning("Could not register the Claim Breaker crafting advancement; first-craft tracking will still work.");
            }
        } catch (Throwable t) {
            plugin.getLogger().warning("Could not register Claim Breaker advancement: " + t.getMessage());
        }
    }

    public boolean awardIfFirst(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data.hasCraftedClaimBreaker()) return false;

        // If the advancement itself already says completed (for example after a players.yml
        // rollback), synchronize our fallback bit without replaying the toast.
        if (advancement != null) {
            try {
                var progress = player.getAdvancementProgress(advancement);
                if (progress.isDone()) {
                    data.setCraftedClaimBreaker(true);
                    return false;
                }
            } catch (Throwable ignored) {}
        }

        data.setCraftedClaimBreaker(true);

        if (advancement != null) {
            try {
                var progress = player.getAdvancementProgress(advancement);
                for (String criterion : progress.getRemainingCriteria()) {
                    progress.awardCriteria(criterion);
                }
            } catch (Throwable t) {
                plugin.getLogger().warning("Could not award Claim Breaker advancement to " + player.getName() + ": " + t.getMessage());
            }
        }

        if (plugin.getConfigManager().isClaimbreakerAchievementChatEnabled()) {
            String raw = plugin.getConfigManager().getClaimbreakerAchievementChatMessage();
            if (raw != null && !raw.isBlank()) {
                String msg = Msg.color(raw.replace("%player%", player.getName()));
                Bukkit.broadcastMessage(msg);
            }
        }

        // Persist immediately enough that a crash shortly after crafting does not normally
        // cause the player to receive the first-craft achievement again on the next boot.
        plugin.getStorageManager().saveAllAsync();
        return true;
    }

    private static String escapeJson(String input) {
        if (input == null) return "";
        StringBuilder out = new StringBuilder(input.length() + 16);
        for (char c : input.toCharArray()) {
            switch (c) {
                case '\\' -> out.append("\\\\");
                case '"' -> out.append("\\\"");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> out.append(c);
            }
        }
        return out.toString();
    }
}

package com.incogdev.incogclaims.integrations;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.data.ClaimType;
import com.incogdev.incogclaims.data.PlayerData;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.SuffixNode;
import org.bukkit.entity.Player;

/**
 * Keeps an Incog-Claims playstyle marker in LuckPerms user suffix metadata.
 * The icon text is configurable while Peaceful remains green and Aggressive remains red.
 */
public final class LuckPermsIntegration {
    private static final int SUFFIX_PRIORITY = 100_000;

    // Historical suffixes are always recognized so upgrading does not leave duplicates behind.
    private static final String OLD_PEACEFUL_SUFFIX = " §a§l[P]§r";
    private static final String OLD_AGGRESSIVE_SUFFIX = " §c§l[A]§r";
    private static final String LEGACY_PEACEFUL_SUFFIX = "§a§l[P]§r";
    private static final String LEGACY_AGGRESSIVE_SUFFIX = "§c§l[A]§r";

    private final IncogClaims plugin;
    private final LuckPerms luckPerms;

    public LuckPermsIntegration(IncogClaims plugin) {
        this.plugin = plugin;
        this.luckPerms = LuckPermsProvider.get();
    }

    public void update(Player player, ClaimType type) {
        User user = luckPerms.getPlayerAdapter(Player.class).getUser(player);
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());

        String peacefulSuffix = buildSuffix(true, plugin.getConfigManager().getPeacefulIcon());
        String aggressiveSuffix = buildSuffix(false, plugin.getConfigManager().getAggressiveIcon());
        removeOurSuffixes(user, data.getPlaystyleSuffix(), peacefulSuffix, aggressiveSuffix);

        if (type != null) {
            String suffix = type == ClaimType.PEACEFUL ? peacefulSuffix : aggressiveSuffix;
            user.data().add(SuffixNode.builder(suffix, SUFFIX_PRIORITY).build());
            data.setPlaystyleSuffix(suffix);
        } else {
            data.setPlaystyleSuffix("");
        }

        luckPerms.getUserManager().saveUser(user);
    }

    /** Repairs suffixes removed or overwritten after join without writing LuckPerms on every check. */
    public void ensure(Player player, ClaimType type) {
        User user = luckPerms.getPlayerAdapter(Player.class).getUser(player);
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        String peacefulSuffix = buildSuffix(true, plugin.getConfigManager().getPeacefulIcon());
        String aggressiveSuffix = buildSuffix(false, plugin.getConfigManager().getAggressiveIcon());
        String desired = type == null ? "" : type == ClaimType.PEACEFUL ? peacefulSuffix : aggressiveSuffix;
        var suffixes = user.data().toCollection().stream()
                .filter(SuffixNode.class::isInstance)
                .map(SuffixNode.class::cast)
                .toList();
        long owned = suffixes.stream()
                .filter(node -> isOurSuffix(node.getMetaValue(), data.getPlaystyleSuffix(), peacefulSuffix, aggressiveSuffix))
                .count();
        boolean correct = desired.isBlank() ? owned == 0 : owned == 1 && suffixes.stream()
                .anyMatch(node -> desired.equals(node.getMetaValue()));
        if (correct) {
            data.setPlaystyleSuffix(desired);
            return;
        }
        update(player, type);
    }

    private static String buildSuffix(boolean peaceful, String icon) {
        String safeIcon = (icon == null || icon.isBlank()) ? (peaceful ? "[P]" : "[A]") : icon;
        // LuckPerms meta is conventionally stored with ampersand formatting. Chat formatters
        // consistently translate it, while raw section signs are not portable across bridges.
        return " " + (peaceful ? "&a" : "&c") + safeIcon + "&r";
    }

    private void removeOurSuffixes(User user, String storedSuffix, String currentPeaceful, String currentAggressive) {
        user.data().clear(NodeType.SUFFIX.predicate(node -> {
            return isOurSuffix(node.getMetaValue(), storedSuffix, currentPeaceful, currentAggressive);
        }));
    }

    private static boolean isOurSuffix(String value, String storedSuffix, String currentPeaceful, String currentAggressive) {
        if (value == null) return false;
        if (OLD_PEACEFUL_SUFFIX.equals(value) || OLD_AGGRESSIVE_SUFFIX.equals(value)
                || LEGACY_PEACEFUL_SUFFIX.equals(value) || LEGACY_AGGRESSIVE_SUFFIX.equals(value)
                || (!storedSuffix.isBlank() && storedSuffix.equals(value))
                || currentPeaceful.equals(value) || currentAggressive.equals(value)) return true;
        String plain = value.replaceAll("(?i)[&§][0-9A-FK-ORX]", "").trim();
        return plain.equals("[P]") || plain.equals("[A]");
    }
}

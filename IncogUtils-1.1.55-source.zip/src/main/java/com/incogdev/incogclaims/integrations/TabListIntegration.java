package com.incogdev.incogclaims.integrations;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.data.ClaimType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Keeps the claims playstyle marker visible in the actual player list.
 *
 * <p>LuckPerms remains the source for chat suffix metadata, but tab-list plugins
 * commonly cache or override that metadata. When NEZNAMY's TAB is present this
 * integration uses its public API (through reflection so TAB stays optional) and
 * preserves TAB's existing suffix. Without TAB it safely reconciles Paper's
 * player-list component instead.</p>
 */
public final class TabListIntegration {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();
    private static final long WARNING_INTERVAL_MILLIS = 60_000L;

    private final IncogClaims plugin;
    private final Map<UUID, TabState> tabStates = new HashMap<>();
    private final Map<UUID, BukkitState> bukkitStates = new HashMap<>();
    private final Class<?> tabApiClass;
    private final Method tabApiInstance;
    private long lastWarning;

    public TabListIntegration(IncogClaims plugin) {
        this.plugin = plugin;
        Class<?> apiClass = null;
        Method instanceMethod = null;
        if (plugin.getServer().getPluginManager().isPluginEnabled("TAB")) {
            try {
                apiClass = Class.forName("me.neznamy.tab.api.TabAPI");
                instanceMethod = apiClass.getMethod("getInstance");
            } catch (ReflectiveOperationException | LinkageError ex) {
                plugin.getLogger().warning("TAB is installed but its API could not be loaded; using the Bukkit player-list fallback: " + ex.getMessage());
            }
        }
        tabApiClass = apiClass;
        tabApiInstance = instanceMethod;
        plugin.getLogger().info(tabApiClass == null
                ? "Playstyle tab suffix reconciliation enabled (Bukkit mode)."
                : "Playstyle tab suffix reconciliation enabled (TAB API mode)."
        );
    }

    public void ensure(Player player, ClaimType type) {
        if (!player.isOnline()) return;
        if (tabApiClass != null && tabApiInstance != null) {
            try {
                TabResult result = ensureTab(player, type);
                if (result == TabResult.APPLIED || result == TabResult.PLAYER_PENDING) return;
                // TAB may still be loading this player asynchronously. Do not let the
                // Bukkit fallback fight TAB; the next periodic pass will retry its API.
            } catch (ReflectiveOperationException | RuntimeException | LinkageError ex) {
                warnThrottled("Could not reconcile TAB suffix for " + player.getName() + ": " + rootMessage(ex));
                return;
            }
        }
        ensureBukkit(player, type);
    }

    /** Restores pre-existing custom values when IncogUtils is disabled or reloaded. */
    public void close() {
        if (tabApiClass != null && tabApiInstance != null) {
            for (Player player : plugin.getServer().getOnlinePlayers()) {
                TabState state = tabStates.get(player.getUniqueId());
                if (state == null) continue;
                try {
                    Object api = tabApiInstance.invoke(null);
                    Object tabPlayer = invoke(api, "getPlayer", player.getUniqueId());
                    Object manager = invoke(api, "getTabListFormatManager");
                    if (tabPlayer == null || manager == null) continue;
                    String current = stringValue(invoke(manager, "getCustomSuffix", tabPlayer));
                    if (Objects.equals(current, state.rendered())) {
                        invoke(manager, "setSuffix", tabPlayer, state.fromOriginal() ? null : state.base());
                    }
                } catch (ReflectiveOperationException | RuntimeException | LinkageError ignored) {
                    // TAB may already be shutting down. Its temporary API values are
                    // cleared by TAB itself when the player or plugin unloads.
                }
            }
        } else {
            for (Player player : plugin.getServer().getOnlinePlayers()) {
                BukkitState state = bukkitStates.get(player.getUniqueId());
                if (state != null && Objects.equals(player.playerListName(), state.rendered())) {
                    player.playerListName(state.fromDefault() ? null : state.base());
                }
            }
        }
        tabStates.clear();
        bukkitStates.clear();
    }

    public void forget(UUID playerId) {
        tabStates.remove(playerId);
        bukkitStates.remove(playerId);
    }

    private TabResult ensureTab(Player player, ClaimType type) throws ReflectiveOperationException {
        Object api = tabApiInstance.invoke(null);
        if (api == null || !tabApiClass.isInstance(api)) return TabResult.PLAYER_PENDING;
        Object manager = invoke(api, "getTabListFormatManager");
        // A null manager means TAB's tablist formatting feature is disabled, in
        // which case Paper's normal player-list value is the correct API to use.
        if (manager == null) return TabResult.FEATURE_DISABLED;
        Object tabPlayer = invoke(api, "getPlayer", player.getUniqueId());
        if (tabPlayer == null) return TabResult.PLAYER_PENDING;

        String current = stringValue(invoke(manager, "getCustomSuffix", tabPlayer));
        String original = stringValue(invoke(manager, "getOriginalReplacedSuffix", tabPlayer));
        String originalBase = stripPlaystyleSuffix(original,
                plugin.getConfigManager().getPeacefulIcon(), plugin.getConfigManager().getAggressiveIcon());
        TabState last = tabStates.get(player.getUniqueId());

        String base;
        boolean fromOriginal;
        if (last != null && Objects.equals(current, last.rendered())) {
            fromOriginal = last.fromOriginal();
            base = fromOriginal ? originalBase : last.base();
        } else if (current != null) {
            base = stripPlaystyleSuffix(current,
                    plugin.getConfigManager().getPeacefulIcon(), plugin.getConfigManager().getAggressiveIcon());
            // This also recognizes a custom suffix left by IncogUtils across a
            // hot reload, allowing the underlying TAB value to remain dynamic.
            fromOriginal = Objects.equals(base, originalBase);
        } else {
            base = originalBase;
            fromOriginal = true;
        }

        String rendered = type == null ? (fromOriginal ? null : base)
                : appendMarker(base, marker(type,
                plugin.getConfigManager().getPeacefulIcon(), plugin.getConfigManager().getAggressiveIcon()));
        if (!Objects.equals(current, rendered)) invoke(manager, "setSuffix", tabPlayer, rendered);
        tabStates.put(player.getUniqueId(), new TabState(base, rendered, fromOriginal));
        return TabResult.APPLIED;
    }

    private void ensureBukkit(Player player, ClaimType type) {
        Component current = player.playerListName();
        BukkitState last = bukkitStates.get(player.getUniqueId());
        Component base;
        boolean fromDefault;

        if (last != null && Objects.equals(current, last.rendered())) {
            base = last.base();
            fromDefault = last.fromDefault();
        } else if (current == null) {
            base = Component.text(player.getName());
            fromDefault = true;
        } else {
            base = LEGACY.deserialize(stripPlaystyleSuffix(LEGACY.serialize(current),
                    plugin.getConfigManager().getPeacefulIcon(), plugin.getConfigManager().getAggressiveIcon()));
            fromDefault = false;
        }

        Component rendered = type == null ? (fromDefault ? null : base)
                : base.append(LegacyComponentSerializer.legacyAmpersand().deserialize(marker(type,
                plugin.getConfigManager().getPeacefulIcon(), plugin.getConfigManager().getAggressiveIcon())));
        if (!Objects.equals(current, rendered)) player.playerListName(rendered);
        bukkitStates.put(player.getUniqueId(), new BukkitState(base, rendered, fromDefault));
    }

    public static String marker(ClaimType type, String peacefulIcon, String aggressiveIcon) {
        if (type == null) return "";
        String icon = type == ClaimType.PEACEFUL ? safeIcon(peacefulIcon, "[P]") : safeIcon(aggressiveIcon, "[A]");
        return " " + (type == ClaimType.PEACEFUL ? "&a" : "&c") + icon + "&r";
    }

    static String stripPlaystyleSuffix(String value, String peacefulIcon, String aggressiveIcon) {
        if (value == null || value.isEmpty()) return "";
        String stripped = value;
        for (String icon : new String[]{safeIcon(peacefulIcon, "[P]"), safeIcon(aggressiveIcon, "[A]"), "[P]", "[A]"}) {
            Pattern trailing = Pattern.compile("(?i)\\s*(?:[&§][0-9A-FK-ORX])*" + Pattern.quote(icon)
                    + "(?:[&§][0-9A-FK-ORX])*(?=\\s*$)");
            String previous;
            do {
                previous = stripped;
                stripped = trailing.matcher(stripped).replaceFirst("");
            } while (!previous.equals(stripped));
        }
        return stripped.stripTrailing();
    }

    private static String appendMarker(String base, String marker) {
        return (base == null ? "" : base.stripTrailing()) + marker;
    }

    private static String safeIcon(String configured, String fallback) {
        return configured == null || configured.isBlank() ? fallback : configured;
    }

    private static String stringValue(Object value) {
        return value == null ? null : value.toString();
    }

    private static Object invoke(Object target, String name, Object... args) throws ReflectiveOperationException {
        Method selected = null;
        for (Method method : target.getClass().getMethods()) {
            if (!method.getName().equals(name) || method.getParameterCount() != args.length) continue;
            Class<?>[] parameterTypes = method.getParameterTypes();
            boolean compatible = true;
            for (int i = 0; i < args.length; i++) {
                if (args[i] != null && !wrap(parameterTypes[i]).isInstance(args[i])) {
                    compatible = false;
                    break;
                }
            }
            if (compatible && (Modifier.isPublic(method.getModifiers()))) {
                selected = method;
                break;
            }
        }
        if (selected == null) throw new NoSuchMethodException(target.getClass().getName() + "#" + name);
        if (!selected.canAccess(target)) selected.trySetAccessible();
        return selected.invoke(target, args);
    }

    private static Class<?> wrap(Class<?> type) {
        if (!type.isPrimitive()) return type;
        if (type == boolean.class) return Boolean.class;
        if (type == byte.class) return Byte.class;
        if (type == short.class) return Short.class;
        if (type == int.class) return Integer.class;
        if (type == long.class) return Long.class;
        if (type == float.class) return Float.class;
        if (type == double.class) return Double.class;
        if (type == char.class) return Character.class;
        return Void.class;
    }

    private void warnThrottled(String message) {
        long now = System.currentTimeMillis();
        if (now - lastWarning < WARNING_INTERVAL_MILLIS) return;
        lastWarning = now;
        plugin.getLogger().warning(message);
    }

    private static String rootMessage(Throwable error) {
        Throwable root = error;
        while (root.getCause() != null) root = root.getCause();
        return root.getMessage() == null ? root.getClass().getSimpleName() : root.getMessage();
    }

    private record TabState(String base, String rendered, boolean fromOriginal) {}
    private record BukkitState(Component base, Component rendered, boolean fromDefault) {}
    private enum TabResult { APPLIED, PLAYER_PENDING, FEATURE_DISABLED }
}

package com.incogdev.incogclaims.listeners;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.util.ItemBuilder;
import com.incogdev.incogclaims.util.Msg;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.enchantment.PrepareItemEnchantEvent;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class EnchantListener implements Listener {

    private final IncogClaims plugin;
    private final Random random = new Random();

    /** Claim Breaker "shatters" for good after raiding this many claim cores. */
    public static final int MAX_CORE_USES = 3;
    /** CustomModelData used by the optional Claim Breaker resource pack. */
    public static final int CLAIM_BREAKER_CUSTOM_MODEL_DATA = 860001;

    public EnchantListener(IncogClaims plugin) {
        this.plugin = plugin;
    }

    /** Builds the rare Claim Breaker pickaxe - only tool capable of breaking a claim's core block. */
    public static ItemStack buildClaimBreakerPickaxe(IncogClaims plugin) {
        ItemStack item = new ItemBuilder(Material.NETHERITE_PICKAXE)
                .name("&5&l✦ Claim Breaker ✦")
                .lore(
                        "&7A rare tool said to be forged",
                        "&7by raiders themselves.",
                        "",
                        "&dLets a PVP player break another",
                        "&dPVP player's claim core, ending",
                        "&dtheir claim for good.",
                        "",
                        "&8Only breaks claim cores and TNT-immune",
                        "&8blocks (obsidian, etc). Not bedrock.",
                        "&8Shatters for good after raiding 3 cores.",
                        "&8Cannot be enchanted. Cannot be obtained from villagers."
                )
                .build();
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.addEnchant(Enchantment.EFFICIENCY, 5, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(plugin.getClaimBreakerKey(), PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(plugin.getClaimBreakerUsesKey(), PersistentDataType.INTEGER, 0);
        meta.setCustomModelData(CLAIM_BREAKER_CUSTOM_MODEL_DATA);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Registers the NEWER source version's Claim Breaker recipe:
     *   N H N   (N = Netherite Ingot, H = Heavy Core)
     *   K P K   (K = Trial Key, P = Netherite Pickaxe)
     *   X T X   (X = TNT, T = Totem of Undying)
     */
    public static void registerRecipe(IncogClaims plugin) {
        if (!plugin.getConfigManager().isClaimbreakerCraftable()) return;

        NamespacedKey key = plugin.getClaimBreakerKey();
        // Avoid duplicate-recipe errors on plugin reloads where the key already exists.
        plugin.getServer().removeRecipe(key);
        ShapedRecipe recipe = new ShapedRecipe(key, buildClaimBreakerPickaxe(plugin));
        recipe.shape("NHN", "KPK", "XTX");
        recipe.setIngredient('N', Material.NETHERITE_INGOT);
        recipe.setIngredient('H', Material.HEAVY_CORE);
        recipe.setIngredient('K', Material.TRIAL_KEY);
        recipe.setIngredient('P', Material.NETHERITE_PICKAXE);
        recipe.setIngredient('X', Material.TNT);
        recipe.setIngredient('T', Material.TOTEM_OF_UNDYING);
        plugin.getServer().addRecipe(recipe);
    }

    // Every successful craft is announced. The achievement itself is only awarded once.
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCraftClaimBreaker(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!isClaimBreaker(plugin, event.getRecipe().getResult())) return;

        plugin.getClaimBreakerAchievementManager().awardIfFirst(player);

        String announcement = plugin.getConfigManager().getClaimbreakerCraftAnnouncement()
                .replace("%player%", player.getName());
        if (!announcement.isBlank()) {
            plugin.getServer().broadcastMessage(Msg.color(announcement));
        }
    }

    // Extremely rare chance to inject the Claim Breaker pickaxe into generated structure loot.
    @EventHandler
    public void onLootGenerate(LootGenerateEvent event) {
        double chance = plugin.getConfigManager().getClaimbreakerLootChance();
        if (chance <= 0) return;
        if (random.nextDouble() > chance) return;
        List<ItemStack> loot = event.getLoot();
        loot.add(buildClaimBreakerPickaxe(plugin));
    }

    // Safety net: never allow the Claim Breaker pickaxe to be offered in villager trades.
    @EventHandler
    public void onVillagerTrade(VillagerAcquireTradeEvent event) {
        if (isClaimBreaker(plugin, event.getRecipe().getResult())) event.setCancelled(true);
    }

    // ---------------------------------------------------------------
    // Anti-enchant guards from the newer source version.
    // ---------------------------------------------------------------
    @EventHandler
    public void onPrepareEnchant(PrepareItemEnchantEvent event) {
        if (isClaimBreaker(plugin, event.getItem())) event.setCancelled(true);
    }

    @EventHandler
    public void onEnchantItem(EnchantItemEvent event) {
        if (isClaimBreaker(plugin, event.getItem())) event.setCancelled(true);
    }

    @EventHandler
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        ItemStack left = event.getInventory().getItem(0);
        ItemStack right = event.getInventory().getItem(1);
        if (isClaimBreaker(plugin, left) || isClaimBreaker(plugin, right)) event.setResult(null);
    }

    public static boolean isClaimBreaker(IncogClaims plugin, ItemStack item) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer()
                .has(plugin.getClaimBreakerKey(), PersistentDataType.BYTE);
    }

    /** Forces a Claim Breaker back to exactly hidden Efficiency V + unbreakable. */
    public static void sanitize(IncogClaims plugin, ItemStack item) {
        if (!isClaimBreaker(plugin, item)) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        boolean changed = false;
        for (Enchantment ench : new HashSet<>(meta.getEnchants().keySet())) {
            if (ench != Enchantment.EFFICIENCY || meta.getEnchantLevel(ench) != 5) {
                meta.removeEnchant(ench);
                changed = true;
            }
        }
        if (meta.getEnchantLevel(Enchantment.EFFICIENCY) != 5) {
            meta.addEnchant(Enchantment.EFFICIENCY, 5, true);
            changed = true;
        }
        if (!meta.hasItemFlag(ItemFlag.HIDE_ENCHANTS)) {
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            changed = true;
        }
        if (!meta.isUnbreakable()) {
            meta.setUnbreakable(true);
            changed = true;
        }
        if (!meta.getPersistentDataContainer().has(plugin.getClaimBreakerUsesKey(), PersistentDataType.INTEGER)) {
            meta.getPersistentDataContainer().set(plugin.getClaimBreakerUsesKey(), PersistentDataType.INTEGER, 0);
            changed = true;
        }
        if (!meta.hasCustomModelData() || meta.getCustomModelData() != CLAIM_BREAKER_CUSTOM_MODEL_DATA) {
            meta.setCustomModelData(CLAIM_BREAKER_CUSTOM_MODEL_DATA);
            changed = true;
        }
        if (changed) item.setItemMeta(meta);
    }

    /** Consumes one of the newer source version's three successful core-raid charges. */
    public static void consumeCoreBreakCharge(IncogClaims plugin, Player player, ItemStack item) {
        if (!isClaimBreaker(plugin, item)) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        Integer stored = meta.getPersistentDataContainer().get(plugin.getClaimBreakerUsesKey(), PersistentDataType.INTEGER);
        int uses = (stored == null ? 0 : stored) + 1;

        if (uses >= MAX_CORE_USES) {
            player.getInventory().setItemInMainHand(null);
            Msg.send(player, "&cYour Claim Breaker shatters into pieces after destroying its 3rd claim core!");
            return;
        }

        meta.getPersistentDataContainer().set(plugin.getClaimBreakerUsesKey(), PersistentDataType.INTEGER, uses);
        if (meta instanceof Damageable damageable) {
            short maxDurability = Material.NETHERITE_PICKAXE.getMaxDurability();
            damageable.setDamage((int) Math.round(maxDurability * ((double) uses / MAX_CORE_USES)));
        }
        item.setItemMeta(meta);
        Msg.send(player, "&eYour Claim Breaker is wearing down - " + (MAX_CORE_USES - uses)
                + " claim core(s) left before it shatters.");
    }
}

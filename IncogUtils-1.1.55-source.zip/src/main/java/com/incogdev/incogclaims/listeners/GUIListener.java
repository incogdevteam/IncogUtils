package com.incogdev.incogclaims.listeners;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.data.ClaimFlag;
import com.incogdev.incogclaims.data.ClaimType;
import com.incogdev.incogclaims.data.PlayerData;
import com.incogdev.incogclaims.gui.ClaimMenuGUI;
import com.incogdev.incogclaims.gui.ExpandGUI;
import com.incogdev.incogclaims.gui.FlagsGUI;
import com.incogdev.incogclaims.gui.TrustedPlayersGUI;
import com.incogdev.incogclaims.gui.TypeSelectGUI;
import com.incogdev.incogclaims.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class GUIListener implements Listener {
    private final IncogClaims plugin;

    public GUIListener(IncogClaims plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Object holder = event.getInventory().getHolder();

        if (holder instanceof TypeSelectGUI) {
            handleTypeSelect(event, player);
            return;
        }
        if (holder instanceof ClaimMenuGUI gui) {
            handleClaimMenu(event, player, gui);
            return;
        }
        if (holder instanceof TrustedPlayersGUI gui) {
            handleTrustedPlayers(event, player, gui);
            return;
        }
        if (holder instanceof FlagsGUI gui) {
            handleFlags(event, player, gui);
            return;
        }
        if (holder instanceof ExpandGUI gui) {
            handleExpand(event, player, gui);
        }
    }

    private void handleTypeSelect(InventoryClickEvent event, Player player) {
        event.setCancelled(true);
        int slot = event.getRawSlot();
        if (slot == TypeSelectGUI.BACK_SLOT) {
            player.performCommand("menus");
            return;
        }
        ClaimType chosen = slot == TypeSelectGUI.PVP_SLOT
                ? ClaimType.PVP
                : slot == TypeSelectGUI.PEACEFUL_SLOT ? ClaimType.PEACEFUL : null;
        if (chosen == null) return;

        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data.hasChosenType()) {
            long remaining = data.getSwitchCooldownRemainingMillis(plugin.getConfigManager().getSwitchCooldownDays());
            if (remaining > 0) {
                Msg.send(player, "&cYou can change your playstyle again in "
                        + TimeUnit.MILLISECONDS.toDays(remaining) + "d "
                        + (TimeUnit.MILLISECONDS.toHours(remaining) % 24) + "h.");
                player.closeInventory();
                return;
            }
            if (chosen == data.getType()) {
                Msg.send(player, "&eYou're already " + chosen.name() + ".");
                player.closeInventory();
                return;
            }
        }

        plugin.applyTypeSelection(player, chosen);
        player.closeInventory();
        Msg.send(player, chosen == ClaimType.PVP
                ? plugin.getConfigManager().getMessage("pvp-warning")
                : plugin.getConfigManager().getMessage("peaceful-info"));
    }

    private void handleClaimMenu(InventoryClickEvent event, Player player, ClaimMenuGUI gui) {
        event.setCancelled(true);
        Claim claim = gui.getClaim();
        boolean owner = claim.getOwner().equals(player.getUniqueId());
        boolean admin = player.hasPermission("incogclaims.admin");
        int slot = event.getRawSlot();

        if (slot == ClaimMenuGUI.BACK_SLOT) {
            player.closeInventory();
            Bukkit.getScheduler().runTask(plugin.host(), () -> player.performCommand("menus"));
            return;
        }

        if (slot == ClaimMenuGUI.EXPAND_SLOT) {
            if (!owner && !admin) {
                Msg.send(player, "&cOnly the owner can resize this claim.");
                return;
            }
            PlayerData ownerData = plugin.getPlayerDataManager().get(claim.getOwner());
            ExpandGUI.open(player, claim, plugin.getConfigManager().getClaimSizes(),
                    ownerData.getClaimBlocks(), plugin.getConfigManager().getLargestSize());
            return;
        }
        if (slot == ClaimMenuGUI.TRUST_SLOT) {
            if (!owner && !admin) {
                Msg.send(player, "&cOnly the owner can manage trusted players.");
                return;
            }
            TrustedPlayersGUI.open(player, claim);
            return;
        }
        if (slot == ClaimMenuGUI.FLAGS_SLOT) {
            if (!owner && !admin) {
                Msg.send(player, "&cOnly the owner can change claim flags.");
                return;
            }
            FlagsGUI.open(player, claim);
            return;
        }
        if (slot == ClaimMenuGUI.DELETE_SLOT) {
            Msg.send(player, "&7Use &f/claim delete &7to confirm deletion.");
            player.closeInventory();
        }
    }

    private void handleTrustedPlayers(InventoryClickEvent event, Player player, TrustedPlayersGUI gui) {
        event.setCancelled(true);
        Claim claim = gui.getClaim();
        if (!claim.getOwner().equals(player.getUniqueId()) && !player.hasPermission("incogclaims.admin")) return;

        int slot = event.getRawSlot();
        if (slot == TrustedPlayersGUI.PREVIOUS_SLOT) {
            TrustedPlayersGUI.open(player, claim, gui.getPage() - 1);
            return;
        }
        if (slot == TrustedPlayersGUI.NEXT_SLOT) {
            TrustedPlayersGUI.open(player, claim, gui.getPage() + 1);
            return;
        }

        UUID targetId = gui.getPlayer(slot);
        if (targetId == null) return;
        Player target = Bukkit.getPlayer(targetId);
        if (target == null) {
            Msg.send(player, "&cThat player is no longer online.");
            TrustedPlayersGUI.open(player, claim, gui.getPage());
            return;
        }

        if (claim.getTrusted().contains(targetId)) {
            claim.getTrusted().remove(targetId);
            Msg.send(player, "&eUntrusted " + target.getName() + ".");
        } else {
            ClaimType targetType = plugin.getPlayerDataManager().get(targetId).getType();
            if (targetType == null || targetType != claim.getType()) {
                Msg.send(player, "&cYou can only trust players using the same Peaceful/Aggressive claim type.");
                return;
            }
            claim.getTrusted().add(targetId);
            Msg.send(player, "&aTrusted " + target.getName() + ".");
        }
        TrustedPlayersGUI.open(player, claim, gui.getPage());
    }

    private void handleFlags(InventoryClickEvent event, Player player, FlagsGUI gui) {
        event.setCancelled(true);
        Claim claim = gui.getClaim();
        if (!claim.getOwner().equals(player.getUniqueId()) && !player.hasPermission("incogclaims.admin")) return;

        ClaimFlag flag = gui.getFlag(event.getRawSlot());
        if (flag == null) return;
        claim.setFlag(flag, !claim.getFlag(flag));
        FlagsGUI.open(player, claim);
    }

    private void handleExpand(InventoryClickEvent event, Player player, ExpandGUI gui) {
        event.setCancelled(true);
        Claim claim = gui.getClaim();
        if (!claim.getOwner().equals(player.getUniqueId()) && !player.hasPermission("incogclaims.admin")) {
            Msg.send(player, "&cOnly the owner can resize this claim.");
            return;
        }

        if (event.getRawSlot() == ExpandGUI.BACK_SLOT) {
            PlayerData ownerData = plugin.getPlayerDataManager().get(claim.getOwner());
            ClaimMenuGUI.open(player, claim, ownerData, plugin.getConfigManager().getLargestSize());
            return;
        }

        if (event.getRawSlot() == ExpandGUI.FULL_HEIGHT_SLOT) {
            toggleFullHeight(player, claim);
            return;
        }

        Integer size = gui.getSizeForSlot(event.getRawSlot());
        if (size == null) return;
        if (claim.getSize() == size) {
            Msg.send(player, "&eThat is already your current size.");
            return;
        }

        PlayerData data = plugin.getPlayerDataManager().get(claim.getOwner());
        Integer configuredCost = plugin.getConfigManager().getClaimSizes().get(size);
        if (configuredCost == null) return;

        boolean downsizing = size < claim.getSize();
        boolean previouslyUnlocked = size <= claim.getMaxUnlockedSize();
        boolean freeResize = downsizing || previouslyUnlocked;
        int cost = freeResize ? 0 : configuredCost;
        if (cost > 0 && data.getClaimBlocks() < cost) {
            Msg.send(player, "&cYou don't have enough claim blocks.");
            return;
        }

        // Shrinking cannot create a new overlap, but expansion still must be checked.
        if (size > claim.getSize() && plugin.getClaimManager().wouldOverlap(claim, claim.getWorldName(),
                claim.getCoreX(), claim.getCoreY(), claim.getCoreZ(), size)) {
            Msg.send(player, "&cThat size would overlap another claim.");
            return;
        }

        int oldSize = claim.getSize();
        if (cost > 0) data.addClaimBlocks(-cost);
        plugin.getClaimManager().resizeClaim(claim, size);
        int largest = plugin.getConfigManager().getLargestSize();
        if (size >= largest) {
            if (!claim.isFullHeight() && plugin.getClaimManager().wouldOverlapFullHeight(claim)) {
                plugin.getClaimManager().resizeClaim(claim, oldSize);
                if (cost > 0) data.addClaimBlocks(cost);
                Msg.send(player, "&cFull-height mode would overlap another claim in its protected vertical range.");
                return;
            }
            claim.setFullHeight(true);
        } else {
            claim.setFullHeight(false);
        }

        if (freeResize) {
            Msg.send(player, downsizing
                    ? "&aClaim downsized to &f" + size + "&a for free."
                    : "&aClaim resized to your previously unlocked &f" + size + "&a size for free.");
        } else {
            Msg.send(player, "&aClaim resized to &f" + size + "&a. Cost: &f" + cost + " claim blocks&a.");
        }
        player.closeInventory();
    }

    private void toggleFullHeight(Player player, Claim claim) {
        int largest = plugin.getConfigManager().getLargestSize();
        if (claim.getSize() < largest) {
            Msg.send(player, "&cFull-height mode only unlocks at the Large claim size.");
            return;
        }
        if (!claim.isFullHeight() && plugin.getClaimManager().wouldOverlapFullHeight(claim)) {
            Msg.send(player, "&cExtended-height mode would overlap another claim in its protected vertical range.");
            return;
        }

        claim.setFullHeight(!claim.isFullHeight());
        Msg.send(player, claim.isFullHeight()
                ? "&aThis claim now protects from Y=" + claim.getFullHeightMinY() + " to the world build limit."
                : "&eThis claim is back to its normal fixed height.");

        PlayerData ownerData = plugin.getPlayerDataManager().get(claim.getOwner());
        ExpandGUI.open(player, claim, plugin.getConfigManager().getClaimSizes(),
                ownerData.getClaimBlocks(), largest);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (!(event.getInventory().getHolder() instanceof TypeSelectGUI)) return;
        plugin.getServer().getScheduler().runTask(plugin.host(), () -> {
            PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
            if (!data.hasChosenType()) {
                plugin.applyTypeSelection(player, ClaimType.PEACEFUL);
                Msg.send(player, "&aNo playstyle was selected, so you were defaulted to Peaceful.");
            }
        });
    }
}

package com.incogdev.incogclaims.listeners;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.data.PlayerData;
import com.incogdev.incogclaims.gui.TypeSelectGUI;
import com.incogdev.incogclaims.util.Msg;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.List;

public class JoinListener implements Listener {

    private final IncogClaims plugin;

    public JoinListener(IncogClaims plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        var player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());

        // Deliver any raid alerts that happened while this player was offline. We only drain
        // the queue after confirming the player is still online, then save the cleared queue.
        plugin.getServer().getScheduler().runTaskLater(plugin.host(), () -> {
            if (!player.isOnline()) return;
            PlayerData current = plugin.getPlayerDataManager().get(player.getUniqueId());
            List<String> pending = current.drainPendingNotifications();
            if (pending.isEmpty()) return;
            for (String message : pending) Msg.send(player, message);
            plugin.getStorageManager().saveAllAsync();
        }, 30L);

        if (data.hasChosenType()) {
            plugin.getServer().getScheduler().runTaskLater(plugin.host(), () -> {
                if (player.isOnline()) plugin.updateLuckPermsSuffix(player);
            }, 10L);
            // A second pass runs after common chat/permissions plugins finish their join work.
            plugin.getServer().getScheduler().runTaskLater(plugin.host(), () -> {
                if (player.isOnline()) plugin.updateLuckPermsSuffix(player);
            }, 100L);
            return;
        }

        // Slight delay so the GUI opens cleanly after the player fully loads in. Recheck the
        // choice inside the scheduled task to avoid reopening the selector after /claims select.
        plugin.getServer().getScheduler().runTaskLater(plugin.host(), () -> {
            if (!player.isOnline()) return;
            PlayerData current = plugin.getPlayerDataManager().get(player.getUniqueId());
            if (!current.hasChosenType()) TypeSelectGUI.open(player);
        }, 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.forgetTabListState(event.getPlayer().getUniqueId());
    }
}

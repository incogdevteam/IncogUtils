package com.incogdev.incogclaims.listeners;

import com.destroystokyo.paper.event.block.BeaconEffectEvent;
import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.data.ClaimType;
import com.incogdev.incogclaims.data.ClaimFlag;
import com.incogdev.incogclaims.data.PlayerData;
import com.incogdev.incogclaims.gui.ClaimMenuGUI;
import com.incogdev.incogclaims.util.Msg;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.TNTPrimeEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.Material;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public class ProtectionListener implements Listener {

    private static final String RAID_TNT_PLACER_METADATA = "incogclaims_raid_tnt_placer";

    private final IncogClaims plugin;

    // Tracks which player primed a TNT block, keyed by block location, briefly, so we can
    // tag the resulting PrimedTnt entity with the responsible player's UUID.
    private final Map<String, UUID> pendingPrimers = new ConcurrentHashMap<>();

    // Newer-source behavior: remember who placed an unlit TNT block so a PVP player may
    // retrieve their OWN raid TNT with a Claim Breaker without being able to steal/break
    // TNT placed by somebody else.
    private final Map<String, UUID> tntPlacedBy = new ConcurrentHashMap<>();

    // Raid TNT is tracked from placement until the primed TNT entity explodes or is
    // otherwise removed. This makes the cap apply to both unlit blocks and lit TNT,
    // instead of allowing a player to bypass it by priming a batch immediately.
    private final Map<String, UUID> raidTntPlacedBy = new ConcurrentHashMap<>();
    private final Map<UUID, Set<String>> activeRaidTnt = new ConcurrentHashMap<>();

    // Tracks which claim (by ID) each online player is currently standing inside, so we
    // only send the "entered a claim" notice once per entry, not every tick.
    private final Map<UUID, UUID> currentClaim = new ConcurrentHashMap<>();

    // Guards against log/TPS spam: if onMove ever throws, we log it once instead of every tick.
    private volatile boolean loggedMoveError = false;

    // Players who've toggled /claims showclaim on - they see a particle border around
    // whichever one of their claims they're currently standing in, redrawn once a second
    // by tickBorders().
    private final Set<UUID> showingBorder = ConcurrentHashMap.newKeySet();

    public ProtectionListener(IncogClaims plugin) {
        this.plugin = plugin;
    }

    /** Toggles the claim-border particle display for this player. Returns the new state. */
    public boolean toggleShowClaim(UUID uuid) {
        if (showingBorder.remove(uuid)) return false;
        showingBorder.add(uuid);
        return true;
    }

    /**
     * Redraws a particle wireframe (green "happy villager" sparkles, same as trading with
     * villagers) around ONLY the claim the toggled-on player is currently standing inside
     * (and only if it's a claim they're actually a member of - owner or trusted). If
     * they're not standing in one of their own claims right now, nothing is drawn. This
     * intentionally does not scan/render every claim they own from a distance anymore -
     * it's a live "which claim am I in, and where's its edge" indicator, not a claim map.
     */
    public void tickBorders() {
        if (showingBorder.isEmpty()) return;

        for (UUID uuid : showingBorder) {
            Player player = plugin.getServer().getPlayer(uuid);
            if (player == null || !player.isOnline()) continue;

            Claim claim = plugin.getClaimManager().getClaimAt(player.getLocation());
            if (claim == null || !claim.isMember(uuid)) continue;

            drawClaimBorder(player, claim);
        }
    }

    private void drawClaimBorder(Player player, Claim claim) {
        org.bukkit.World world = player.getWorld();
        int half = claim.getHalf();
        int minX = claim.getCoreX()-half, maxX = claim.getCoreX()+half;
        int minZ = claim.getCoreZ()-half, maxZ = claim.getCoreZ()+half;
        int step = plugin.getConfigManager().getBorderParticleSpacing();
        int y = Math.max(world.getMinHeight()+1, Math.min(world.getMaxHeight()-2, player.getLocation().getBlockY()+1));
        for(int x=minX;x<=maxX;x+=step){spawnBorderParticle(player,x,y,minZ);spawnBorderParticle(player,x,y,maxZ);}
        for(int z=minZ;z<=maxZ;z+=step){spawnBorderParticle(player,minX,y,z);spawnBorderParticle(player,maxX,y,z);}
        // Bright corner pillars make the outline much easier to see at a glance.
        for(int dy=-6;dy<=6;dy+=2){int py=y+dy;if(py<=world.getMinHeight()||py>=world.getMaxHeight())continue;spawnBorderParticle(player,minX,py,minZ);spawnBorderParticle(player,minX,py,maxZ);spawnBorderParticle(player,maxX,py,minZ);spawnBorderParticle(player,maxX,py,maxZ);}
        if(!claim.isFullHeight()){
            int minY=claim.getCoreY()-half,maxY=claim.getCoreY()+half;
            if(Math.abs(player.getLocation().getY()-minY)<20||Math.abs(player.getLocation().getY()-maxY)<20){
                for(int x=minX;x<=maxX;x+=Math.max(step,2)){spawnBorderParticle(player,x,minY,minZ);spawnBorderParticle(player,x,minY,maxZ);spawnBorderParticle(player,x,maxY,minZ);spawnBorderParticle(player,x,maxY,maxZ);}
            }
        }
    }

    private void spawnBorderParticle(Player player, int x, int y, int z) {
        player.spawnParticle(org.bukkit.Particle.END_ROD, x+0.5, y+0.5, z+0.5, 1, 0, 0, 0, 0);
    }

    private boolean bypasses(Player player) {
        return plugin.getConfigManager().isOpBypass() && player.hasPermission("incogclaims.admin");
    }


    // ---------------------------------------------------------------
    // Beacon effect protection
    // ---------------------------------------------------------------
    /**
     * Paper exposes a dedicated event for the exact moment a beacon applies an effect.
     * Cancelling that event is intentionally much safer than removing potion effects from
     * the player afterward: custom enchant plugins may grant the same PotionEffectType,
     * and those effects must remain untouched.
     *
     * A beacon located inside a claim only benefits the owner, trusted players, or an
     * administrator using the normal Incog-Claims bypass. Beacons outside claims are
     * unaffected.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBeaconEffect(BeaconEffectEvent event) {
        if (!plugin.getConfigManager().isClaimBeaconTrustedOnly()) return;

        Claim claim = plugin.getClaimManager().getClaimAt(event.getBlock().getLocation());
        if (claim == null) return;

        Player player = event.getPlayer();
        if (claim.isMember(player.getUniqueId()) || bypasses(player)) return;

        // Cancel ONLY this beacon application. Do not remove the player's current potion
        // effect, because it may have been supplied by a custom enchant or another plugin.
        event.setCancelled(true);
    }

    // ---------------------------------------------------------------
    // Ender pearl protection
    // ---------------------------------------------------------------
    /**
     * Outsiders cannot ender-pearl into a claim unless the owner enables the
     * Public Ender Pearls flag. Cancelling the teleport lets an outsider pearl
     * back OUT of a claim while preventing pearls from being used to bypass walls.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEnderPearlTeleport(PlayerTeleportEvent event) {
        if (event.getCause() != PlayerTeleportEvent.TeleportCause.ENDER_PEARL) return;
        Location destination = event.getTo();
        if (destination == null) return;

        Player player = event.getPlayer();
        if (bypasses(player)) return;
        Claim claim = plugin.getClaimManager().getClaimAt(destination);
        if (claim == null || claim.isMember(player.getUniqueId()) || claim.getFlag(ClaimFlag.ENDER_PEARLS)) return;

        event.setCancelled(true);
        Msg.send(player, "&cEnder pearls are disabled for untrusted players in this claim.");
    }

    // ---------------------------------------------------------------
    // Block break
    // ---------------------------------------------------------------
    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        Claim claim = plugin.getClaimManager().getClaimAt(block.getLocation());

        boolean isCore = claim != null && claim.isCoreBlock(block.getX(), block.getY(),
                block.getZ(), block.getWorld().getName());
        boolean wieldingClaimBreaker = hasClaimBreaker(player.getInventory().getItemInMainHand());

        // The Claim Breaker's job is breaking claim cores. It's ALSO the only thing that
        // can break TNT-immune blocks (obsidian, ancient debris, etc.) - people wall
        // those in as raid-proofing, so the tool needs to be able to clear them. Bedrock
        // is never breakable, no exceptions.
        if (wieldingClaimBreaker && !isCore) {
            if (isTntImmune(block.getType())) {
                // Even with the Claim Breaker, a Peaceful claim's protection is absolute.
                boolean memberOrBypass = claim != null
                        && (claim.isMember(player.getUniqueId()) || bypasses(player));
                if (claim != null && claim.getType() == ClaimType.PEACEFUL && !memberOrBypass) {
                    event.setCancelled(true);
                    Msg.send(player, "&cThis is a peaceful claim - it cannot be broken into.");
                    return;
                }
                if (claim != null && isObsidianLike(block.getType())) claim.decrementObsidian();
                if (claim != null && block.getType() == Material.BEDROCK) claim.decrementBedrock();
                return; // allowed - vanilla break proceeds
            }

            // A PVP player may pick back up TNT they personally placed, even if that TNT
            // is inside somebody else's claim. This is from the newer claims source.
            if (block.getType() == Material.TNT && isPvpPlayer(player)
                    && player.getUniqueId().equals(tntPlacedBy.get(locKey(block.getLocation())))) {
                removeTntPlacement(block.getLocation());
                return;
            }

            event.setCancelled(true);
            Msg.send(player, "&cThis is not a claim block; you cannot break non-claimblocks with the Claim Breaker. It's in the name...");
            return;
        }

        if (claim == null) return;

        boolean isMember = claim.isMember(player.getUniqueId());
        boolean isBypass = bypasses(player);

        if (isCore) {
            boolean isRaidBreak = !isMember && !isBypass && claim.getType() == ClaimType.PVP
                    && wieldingClaimBreaker && isPvpPlayer(player);

            if (isMember || isBypass || isRaidBreak) {
                // Core destroyed -> the claim ceases to exist. Cancel the vanilla break
                // and delete the claim ourselves so the block just stops existing
                // (no item drop, no leftover "plain" beacon sitting there).
                event.setCancelled(true);
                plugin.getClaimManager().removeClaim(claim);

                if (isRaidBreak) {
                    Msg.send(player, "&a&lRaid Successful! &7You destroyed a player's claim core.");
                    notifyOwnerOfRaid(claim);
                    EnchantListener.consumeCoreBreakCharge(plugin, player, player.getInventory().getItemInMainHand());
                } else {
                    Msg.send(player, "&eClaim core broken. Your claim has been deleted.");
                }
                return;
            }

            event.setCancelled(true);
            Msg.send(player, "&cYou cannot break another player's claim core.");
            return;
        }

        if (isMember || isBypass) {
            if (isObsidianLike(block.getType())) claim.decrementObsidian();
            if (block.getType() == Material.BEDROCK) claim.decrementBedrock();
            if (block.getType() == Material.TNT) removeTntPlacement(block.getLocation());
            return;
        }

        if (claim.getFlag(ClaimFlag.BLOCK_BREAK)) {
            if (isObsidianLike(block.getType())) claim.decrementObsidian();
            if (block.getType() == Material.BEDROCK) claim.decrementBedrock();
            if (block.getType() == Material.TNT) removeTntPlacement(block.getLocation());
            return;
        }

        if (claim.getType() == ClaimType.PEACEFUL) {
            event.setCancelled(true);
            Msg.send(player, "&cThis is a peaceful claim - it cannot be broken into.");
            return;
        }

        // PVP claim, non-core block: hand-mining isn't a thing anymore (the Claim
        // Breaker only touches cores now) - raiding regular blocks is done via TNT.
        event.setCancelled(true);
        Msg.send(player, "&cYou don't have permission to break blocks in this claim. Try blowing it up.");
    }

    /**
     * Lets a raided claim's owner know their core was destroyed, without naming the raider.
     * If the owner is offline, persist the exact same alert and deliver it on their next join.
     */
    private void notifyOwnerOfRaid(Claim claim) {
        String message = plugin.getConfigManager().getMessage("raid-notification");
        if (message == null || message.isBlank()) {
            message = "&c&lYour claim was raided! &7Your claim core has been destroyed and the claim deleted.";
        }

        Player owner = plugin.getServer().getPlayer(claim.getOwner());
        if (owner != null && owner.isOnline()) {
            Msg.send(owner, message);
            return;
        }

        plugin.getPlayerDataManager().get(claim.getOwner()).queueNotification(message);
        plugin.getStorageManager().saveAllAsync();
    }

    // ---------------------------------------------------------------
    // Block place
    // ---------------------------------------------------------------
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();

        ItemStack inHand = event.getItemInHand();
        ItemMeta meta = inHand.getItemMeta();
        boolean isCoreItem = meta != null && meta.getPersistentDataContainer()
                .has(plugin.getCoreBlockKey(), PersistentDataType.STRING);
        boolean isExtraCoreItem = meta != null && meta.getPersistentDataContainer()
                .has(plugin.getExtraCoreBlockKey(), PersistentDataType.STRING);

        if (isCoreItem) {
            handleCorePlacement(event, player);
            return;
        }
        if (isExtraCoreItem) {
            handleExtraCorePlacement(event, player);
            return;
        }

        if (bypasses(player)) return;

        Location placedLoc = event.getBlockPlaced().getLocation();
        Material placedType = event.getBlockPlaced().getType();
        Claim claim = plugin.getClaimManager().getClaimAt(placedLoc);

        if (claim == null) {
            // Not inside any claim - but obsidian still can't go in the buffer band
            // immediately outside a claim's border (see ClaimManager#getClaimInBuffer),
            // whether it's your own claim or someone else's. This is what stops the
            // "obsidian-box the outside of my claim so it can never be raided" trick.
            if (isObsidianLike(placedType)) {
                int buffer = plugin.getConfigManager().getObsidianBufferRadius();
                if (buffer > 0 && plugin.getClaimManager().getClaimInBuffer(placedLoc, buffer) != null) {
                    event.setCancelled(true);
                    Msg.send(player, "&cYou can't place obsidian this close to a claim border.");
                    return;
                }
            }
            if (placedType == Material.TNT) trackTntPlacement(placedLoc, player.getUniqueId());
            return;
        }

        if (claim.isMember(player.getUniqueId())) {
            if (isObsidianLike(placedType)) {
                int max = plugin.getConfigManager().getMaxObsidianPerClaim();
                if (max > 0 && claim.getObsidianCount() >= max) {
                    event.setCancelled(true);
                    Msg.send(player, "&cThis claim already has the max of " + max + " obsidian blocks.");
                    return;
                }
                claim.incrementObsidian();
            }
            if (placedType == Material.BEDROCK) {
                int max = plugin.getConfigManager().getMaxBedrockPerClaim();
                if (claim.getBedrockCount() >= max) {
                    event.setCancelled(true);
                    Msg.send(player, max <= 0
                            ? "&cBedrock can't be placed inside a claim."
                            : "&cThis claim already has the max of " + max + " bedrock blocks.");
                    return;
                }
                claim.incrementBedrock();
            }
            if (placedType == Material.TNT) trackTntPlacement(placedLoc, player.getUniqueId());
            return;
        }

        if (placedType == Material.TNT) {
            // Aggressive claims are raidable. Any Aggressive player may place TNT in
            // another Aggressive claim; this deliberately does NOT depend on their
            // separate /pvp toggle, which only controls player-vs-player damage.
            if (canRaidWithTnt(player, claim)) {
                if (!canPlaceRaidTnt(player)) {
                    event.setCancelled(true);
                    Msg.send(player, "&cYou can only have " + plugin.getConfigManager().getMaxActiveRaidTntPerPlayer()
                            + " raid TNT active at a time. Light or recover one before placing more.");
                    return;
                }
                trackRaidTntPlacement(placedLoc, player.getUniqueId());
                return;
            }
            event.setCancelled(true);
            Msg.send(player, claim.getType() == ClaimType.PEACEFUL
                    ? "&cThis is a peaceful claim - TNT cannot be placed here."
                    : "&cOnly Aggressive players can place TNT inside this claim.");
            return;
        }

        if (claim.getFlag(ClaimFlag.BLOCK_PLACE)) {
            if (isObsidianLike(placedType)) {
                int max = plugin.getConfigManager().getMaxObsidianPerClaim();
                if (max > 0 && claim.getObsidianCount() >= max) {
                    event.setCancelled(true);
                    Msg.send(player, "&cThis claim already has the max of " + max + " obsidian/crying obsidian blocks.");
                    return;
                }
                claim.incrementObsidian();
            }
            return;
        }
        event.setCancelled(true);
        Msg.send(player, "&cYou can't place blocks in this claim.");
    }

    // ---------------------------------------------------------------
    // Lighting existing TNT blocks by hand inside a claim. Peaceful claims never allow
    // this. Any Aggressive player may ignite TNT in an Aggressive claim, regardless of
    // their /pvp toggle, until the claim's core is broken and it ceases to exist.
    // ---------------------------------------------------------------
    @EventHandler(priority = EventPriority.HIGH)
    public void onTntIgnite(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.TNT) return;

        ItemStack item = event.getItem();
        if (item == null || (item.getType() != Material.FLINT_AND_STEEL && item.getType() != Material.FIRE_CHARGE)) return;

        Player player = event.getPlayer();
        if (bypasses(player)) return;

        Claim claim = plugin.getClaimManager().getClaimAt(block.getLocation());
        if (claim == null) return;
        if (claim.isMember(player.getUniqueId())) return;

        if (canRaidWithTnt(player, claim)) {
            return;
        }

        event.setCancelled(true);
        Msg.send(player, claim.getType() == ClaimType.PEACEFUL
                ? "&cThis is a peaceful claim - TNT cannot be lit here."
                : "&cOnly Aggressive players can light TNT inside this claim.");
    }

    private void handleCorePlacement(BlockPlaceEvent event, Player player) {
        if (plugin.getClaimManager().hasClaim(player.getUniqueId())) {
            event.setCancelled(true);
            Msg.send(player, "&cYou already own a claim. Use &f/claim buy &cto purchase another Claim Core.");
            return;
        }

        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data.getType() == null) {
            event.setCancelled(true);
            Msg.send(player, "&cYou must choose Peaceful or Aggressive before placing a claim core.");
            return;
        }

        int size = plugin.getConfigManager().getSmallestSize();
        Location loc = event.getBlockPlaced().getLocation();
        boolean overlaps = plugin.getClaimManager().wouldOverlap(null, loc.getWorld().getName(),
                loc.getBlockX(), loc.getBlockY(), loc.getBlockZ(), size);
        if (overlaps) {
            event.setCancelled(true);
            Msg.send(player, "&cToo close to another claim.");
            return;
        }

        Claim claim = new Claim(UUID.randomUUID(), player.getUniqueId(), data.getType(), loc, size);
        plugin.getClaimManager().addClaim(claim);
        Msg.send(player, "&aClaim " + claim.getDisplayId() + " created! Size: " + size + "x" + size + "x" + size
                + ". Right-click the core block to manage it.");
    }

    /** Places an "extra" (purchased) claim core - same overlap rules, but never inherits
     *  another claim's size and is tracked separately from your primary claim. */
    private void handleExtraCorePlacement(BlockPlaceEvent event, Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        if (data.getType() == null) {
            event.setCancelled(true);
            Msg.send(player, "&cYou must choose Peaceful or Aggressive before placing a claim core.");
            return;
        }

        int size = plugin.getConfigManager().getSmallestSize();
        Location loc = event.getBlockPlaced().getLocation();
        boolean overlaps = plugin.getClaimManager().wouldOverlap(null, loc.getWorld().getName(),
                loc.getBlockX(), loc.getBlockY(), loc.getBlockZ(), size);
        if (overlaps) {
            event.setCancelled(true);
            Msg.send(player, "&cToo close to another claim.");
            return;
        }

        Claim claim = new Claim(UUID.randomUUID(), player.getUniqueId(), data.getType(), loc, size);
        claim.setPrimary(false);
        plugin.getClaimManager().addClaim(claim);
        Msg.send(player, "&aExtra claim " + claim.getDisplayId() + " created! Size: " + size + "x" + size + "x" + size
                + ". Right-click the core block to manage it.");
    }

    // ---------------------------------------------------------------
    // Right-click core -> open claim menu
    // ---------------------------------------------------------------
    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null) return;
        if (block.getType() != plugin.getConfigManager().getClaimCoreMaterial()) return;

        Claim claim = plugin.getClaimManager().getClaimAt(block.getLocation());
        if (claim == null) return;
        if (!claim.isCoreBlock(block.getX(), block.getY(), block.getZ(), block.getWorld().getName())) return;

        Player player = event.getPlayer();
        if (!claim.isMember(player.getUniqueId()) && !bypasses(player)) return;

        event.setCancelled(true);
        PlayerData ownerData = plugin.getPlayerDataManager().get(claim.getOwner());
        ClaimMenuGUI.open(player, claim, ownerData, plugin.getConfigManager().getLargestSize());
    }

    // ---------------------------------------------------------------
    // Container access
    // ---------------------------------------------------------------
    @EventHandler
    public void onContainerOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (bypasses(player)) return;

        var holder = event.getInventory().getLocation();
        if (holder == null) return;

        Claim claim = plugin.getClaimManager().getClaimAt(holder);
        if (claim == null) return;
        if (claim.isMember(player.getUniqueId()) || claim.getFlag(ClaimFlag.CONTAINERS)) return;

        event.setCancelled(true);
        Msg.send(player, "&cYou don't have permission to open containers in this claim.");
    }

    // ---------------------------------------------------------------
    // PVP damage - blocked entirely inside peaceful claims
    // ---------------------------------------------------------------
    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;

        Player attacker = resolvePlayerAttacker(event.getDamager());
        if (attacker == null) return;

        Claim victimClaim = plugin.getClaimManager().getClaimAt(victim.getLocation());
        Claim attackerClaim = plugin.getClaimManager().getClaimAt(attacker.getLocation());

        if ((victimClaim != null && victimClaim.getType() == ClaimType.PEACEFUL)
                || (attackerClaim != null && attackerClaim.getType() == ClaimType.PEACEFUL)) {
            event.setCancelled(true);
        }
    }

    private Player resolvePlayerAttacker(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof org.bukkit.entity.Projectile proj && proj.getShooter() instanceof Player p) return p;
        return null;
    }

    // ---------------------------------------------------------------
    // TNT raiding
    // ---------------------------------------------------------------
    @EventHandler
    public void onTntPrime(TNTPrimeEvent event) {
        if (event.getPrimingEntity() instanceof Player player) {
            pendingPrimers.put(locKey(event.getBlock().getLocation()), player.getUniqueId());
        }
    }

    @EventHandler
    public void onTntSpawn(EntitySpawnEvent event) {
        if (!(event.getEntity() instanceof TNTPrimed tnt)) return;
        String key = locKey(event.getLocation());
        UUID primer = pendingPrimers.remove(key);
        if (primer != null) {
            tnt.setMetadata("incogclaims_primer", new org.bukkit.metadata.FixedMetadataValue(plugin.host(), primer.toString()));
        }
        moveRaidTntToPrimedEntity(key, tnt);
        // The TNT block has become a primed entity, so there is no placed block to retrieve.
        tntPlacedBy.remove(key);
    }

    // End crystals are a valid raiding method too (crystal PvP style base-breaking) -
    // whoever detonates one (melee or projectile) is tagged as the "primer", the exact
    // same way TNT is, so onExplode below treats it identically. This also means it
    // naturally works when the crystal is detonated from outside the claim - onExplode
    // checks each affected block's claim membership individually, not the crystal's
    // location.
    @EventHandler
    public void onCrystalDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof org.bukkit.entity.EnderCrystal crystal)) return;
        Player attacker = resolvePlayerAttacker(event.getDamager());
        if (attacker == null) return;
        crystal.setMetadata("incogclaims_primer",
                new org.bukkit.metadata.FixedMetadataValue(plugin.host(), attacker.getUniqueId().toString()));
    }

    private String locKey(Location loc) {
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }

    private void trackTntPlacement(Location loc, UUID placer) {
        tntPlacedBy.put(locKey(loc), placer);
    }

    private void trackRaidTntPlacement(Location loc, UUID placer) {
        String key = locKey(loc);
        tntPlacedBy.put(key, placer);
        raidTntPlacedBy.put(key, placer);
        activeRaidTnt.computeIfAbsent(placer, ignored -> ConcurrentHashMap.newKeySet()).add(blockTntKey(key));
    }

    private boolean canPlaceRaidTnt(Player player) {
        Set<String> active = activeRaidTnt.get(player.getUniqueId());
        return active == null || active.size() < plugin.getConfigManager().getMaxActiveRaidTntPerPlayer();
    }

    private void removeTntPlacement(Location loc) {
        String key = locKey(loc);
        tntPlacedBy.remove(key);
        UUID raidPlacer = raidTntPlacedBy.remove(key);
        if (raidPlacer != null) removeActiveRaidTnt(raidPlacer, blockTntKey(key));
    }

    private void moveRaidTntToPrimedEntity(String blockKey, TNTPrimed tnt) {
        UUID raidPlacer = raidTntPlacedBy.remove(blockKey);
        if (raidPlacer == null) return;
        Set<String> active = activeRaidTnt.computeIfAbsent(raidPlacer, ignored -> ConcurrentHashMap.newKeySet());
        active.remove(blockTntKey(blockKey));
        active.add(entityTntKey(tnt.getUniqueId()));
        tnt.setMetadata(RAID_TNT_PLACER_METADATA,
                new org.bukkit.metadata.FixedMetadataValue(plugin.host(), raidPlacer.toString()));
    }

    private void removeActiveRaidTnt(UUID placer, String key) {
        Set<String> active = activeRaidTnt.get(placer);
        if (active == null) return;
        active.remove(key);
        if (active.isEmpty()) activeRaidTnt.remove(placer, active);
    }

    private String blockTntKey(String locationKey) {
        return "block:" + locationKey;
    }

    private String entityTntKey(UUID entityId) {
        return "entity:" + entityId;
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent event) {
        UUID primer = null;
        if (event.getEntity().hasMetadata("incogclaims_primer")) {
            try {
                primer = UUID.fromString(event.getEntity().getMetadata("incogclaims_primer").get(0).asString());
            } catch (Exception ignored) {}
        }

        boolean primerIsPvp = false;
        if (primer != null) {
            PlayerData primerData = plugin.getPlayerDataManager().get(primer);
            primerIsPvp = primerData.getType() == ClaimType.PVP;
        }

        List<Block> blocks = event.blockList();
        Iterator<Block> it = blocks.iterator();
        while (it.hasNext()) {
            Block b = it.next();
            Claim claim = plugin.getClaimManager().getClaimAt(b.getLocation());
            if (claim == null) continue;

            // The core block itself is always immune to explosions - it must be manually
            // broken (see onBreak) to actually delete a claim.
            if (claim.isCoreBlock(b.getX(), b.getY(), b.getZ(), b.getWorld().getName())) {
                it.remove();
                continue;
            }

            if (claim.getType() == ClaimType.PEACEFUL) {
                it.remove();
                continue;
            }

            // Aggressive/PVP claims are always raidable by explosions; there is no per-claim
            // explosion-disable flag anymore. The global raid settings still determine who may
            // cause raid explosions.
            if (!plugin.getConfigManager().isTntRaidEnabled()) {
                it.remove();
                continue;
            }
            if (plugin.getConfigManager().isRequirePvpAttackerToRaid() && !primerIsPvp) {
                it.remove();
                continue;
            }

            // Explosions are the normal way through claimed walls, but claimed blocks are
            // intentionally more resistant than unclaimed blocks. Bukkit already gives us only
            // blocks the vanilla explosion would break; retain only the configured fraction.
            double breakChance = plugin.getConfigManager().getClaimedBlockExplosionBreakChance();
            if (breakChance <= 0.0 || (breakChance < 1.0 && ThreadLocalRandom.current().nextDouble() > breakChance)) {
                it.remove();
                continue;
            }

            if (isObsidianLike(b.getType())) claim.decrementObsidian();
        }
    }

    /** Cleans up TNT-cap tracking only after all protection listeners finalize the explosion. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onRaidTntExplosionComplete(EntityExplodeEvent event) {
        if (event.getEntity().hasMetadata(RAID_TNT_PLACER_METADATA)) {
            try {
                UUID placer = UUID.fromString(event.getEntity().getMetadata(RAID_TNT_PLACER_METADATA).get(0).asString());
                removeActiveRaidTnt(placer, entityTntKey(event.getEntity().getUniqueId()));
            } catch (Exception ignored) {
                // Invalid third-party metadata must never disrupt explosions.
            }
        }
        for (Block block : event.blockList()) {
            if (block.getType() == Material.TNT) removeTntPlacement(block.getLocation());
        }
    }

    // ---------------------------------------------------------------
    // General interaction protection, including entity-click plugins such as ClickVillagers.
    // ---------------------------------------------------------------
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onProtectedInteract(PlayerInteractEvent event) {
        if (event.getClickedBlock() == null) return;
        Player player = event.getPlayer();
        if (bypasses(player)) return;
        Block clicked = event.getClickedBlock();
        if (clicked.getType() == Material.TNT) return;
        Claim claim = plugin.getClaimManager().getClaimAt(clicked.getLocation());
        if (claim == null || claim.isMember(player.getUniqueId()) || claim.getFlag(ClaimFlag.INTERACT)) return;
        // Core and TNT have dedicated handlers above; still deny outsiders here when appropriate.
        event.setCancelled(true);
        Msg.send(player, "&cYou cannot interact with blocks in this claim.");
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onEntityInteract(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        if (bypasses(player)) return;
        Claim claim = plugin.getClaimManager().getClaimAt(event.getRightClicked().getLocation());
        if (claim == null || claim.isMember(player.getUniqueId()) || claim.getFlag(ClaimFlag.ENTITIES)) return;
        event.setCancelled(true);
        Msg.send(player, "&cYou cannot interact with entities in this claim.");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onProtectedEntityDamage(EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof Player) return;
        Player attacker = resolvePlayerAttacker(event.getDamager());
        if (attacker == null || bypasses(attacker)) return;
        Claim claim = plugin.getClaimManager().getClaimAt(event.getEntity().getLocation());
        if (claim == null || claim.isMember(attacker.getUniqueId()) || claim.getFlag(ClaimFlag.ENTITIES)) return;
        event.setCancelled(true);
        Msg.send(attacker, "&cYou cannot damage entities in this claim.");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player) || bypasses(player)) return;
        Claim claim = plugin.getClaimManager().getClaimAt(event.getItem().getLocation());
        if (claim == null || claim.isMember(player.getUniqueId()) || claim.getFlag(ClaimFlag.ITEM_PICKUP)) return;
        event.setCancelled(true);
    }

    private boolean isObsidianLike(Material material) {
        return material == Material.OBSIDIAN || material == Material.CRYING_OBSIDIAN;
    }

    // ---------------------------------------------------------------
    // Claim Breaker pickaxe check
    // ---------------------------------------------------------------
    private boolean hasClaimBreaker(ItemStack item) {
        if (item == null || item.getItemMeta() == null) return false;
        return item.getItemMeta().getPersistentDataContainer()
                .has(plugin.getClaimBreakerKey(), PersistentDataType.BYTE);
    }

    private boolean isPvpPlayer(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        return data.getType() == ClaimType.PVP;
    }

    /**
     * Central raid-entry rule used for both placing and igniting TNT. A player's
     * Aggressive/PVP playstyle is the only player-side requirement: their optional
     * /pvp setting must not lock them out of raiding an Aggressive claim.
     */
    private boolean canRaidWithTnt(Player attacker, Claim targetClaim) {
        return plugin.getConfigManager().isTntRaidEnabled()
                && targetClaim.getType() == ClaimType.PVP
                && isPvpPlayer(attacker);
    }

    // Blocks that survive a standard TNT explosion in vanilla. Bedrock is deliberately
    // excluded - the Claim Breaker must never be able to touch it.
    private static final Set<Material> TNT_IMMUNE = EnumSet.of(
            Material.OBSIDIAN,
            Material.CRYING_OBSIDIAN,
            Material.ANCIENT_DEBRIS,
            Material.NETHERITE_BLOCK,
            Material.RESPAWN_ANCHOR,
            Material.REINFORCED_DEEPSLATE,
            Material.ENCHANTING_TABLE
    );

    private boolean isTntImmune(Material type) {
        if (type == Material.BEDROCK) return false;
        return TNT_IMMUNE.contains(type);
    }

    // ---------------------------------------------------------------
    // Claim enter notification - "You have entered a Peaceful/Aggressive claim (size)".
    // Never reveals the owner's name or the claim's location.
    // ---------------------------------------------------------------
    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        try {
            // PlayerMoveEvent#getTo() can be null (some teleport edge cases) - this was
            // almost certainly the actual cause of the "Could not pass event
            // PlayerMoveEvent" log spam and TPS drop, since an NPE here fires on every
            // single move for every player.
            Location to = event.getTo();
            Location from = event.getFrom();
            if (to == null || to.getWorld() == null || from == null) return;

            if (from.getBlockX() == to.getBlockX()
                    && from.getBlockY() == to.getBlockY()
                    && from.getBlockZ() == to.getBlockZ()) {
                return; // only care about actual block-position changes
            }

            Player player = event.getPlayer();
            Claim claim = plugin.getClaimManager().getClaimAt(to);
            UUID newId = claim == null ? null : claim.getId();
            UUID oldId = currentClaim.put(player.getUniqueId(), newId);

            if (newId != null && !newId.equals(oldId)) {
                String typeName = claim.getType() == ClaimType.PVP ? "&c&lAggressive" : "&a&lPeaceful";
                Msg.actionBar(player, "&7You have entered a " + typeName + "&7 claim &f(" + claim.getSize()
                        + "x" + claim.getSize() + "x" + claim.getSize() + ")");
            }
        } catch (Exception e) {
            // Never let this handler spam the console/TPS - log once, then stay quiet.
            if (!loggedMoveError) {
                loggedMoveError = true;
                plugin.getLogger().warning("Incog-Claims: suppressing repeated errors in claim-enter tracking: " + e);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        currentClaim.remove(event.getPlayer().getUniqueId());
    }
}

package com.incogdev.incogclaims.pvp;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class PvpCommand implements CommandExecutor {
    private final IncogClaims plugin;
    public PvpCommand(IncogClaims plugin){this.plugin=plugin;}

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args){
        if(args.length>=1 && (args[0].equalsIgnoreCase("bypass") || args[0].equalsIgnoreCase("clearcooldown"))){
            if(!sender.hasPermission("incogclaims.pvp.admin")){Msg.sendRaw(sender,"&cNo permission.");return true;}
            if(args.length<2){Msg.sendRaw(sender,"&cUsage: /pvp bypass <player>");return true;}
            Player target=Bukkit.getPlayer(args[1]); if(target==null){Msg.sendRaw(sender,"&cPlayer must be online.");return true;}
            plugin.getPvpManager().clearCooldown(target.getUniqueId()); Msg.sendRaw(sender,"&aCleared "+target.getName()+"'s PVP toggle cooldown."); Msg.send(target,"&aAn admin cleared your PVP toggle cooldown."); return true;
        }
        if(!(sender instanceof Player player)){Msg.sendRaw(sender,"&cPlayers only.");return true;}
        long remaining=plugin.getPvpManager().remaining(player.getUniqueId());
        if(remaining>0 && !player.hasPermission("incogclaims.pvp.cooldown.bypass")){Msg.send(player,"&cYou must wait "+format(remaining)+" before toggling PVP again.");return true;}
        boolean state=plugin.getPvpManager().toggle(player.getUniqueId());
        Msg.send(player,state?"&aPVP is now ON.":"&cPVP is now OFF. &7Mob and environmental damage still apply normally.");
        plugin.logPvpToggle(player,state); return true;
    }
    private String format(long ms){long s=Math.max(1,(ms+999)/1000),m=s/60; s%=60; return m>0?m+"m "+s+"s":s+"s";}
}

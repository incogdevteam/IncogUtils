package com.incogdev.incogclaims.pvp;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.data.ClaimType;
import com.incogdev.incogclaims.data.PlayerData;
import com.incogdev.incogclaims.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.TNTPrimeEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class PvpListener implements Listener {
    private final IncogClaims plugin;
    private final Set<UUID> kicked=ConcurrentHashMap.newKeySet();
    private final Map<BlockKey,UUID> placedTnt=new ConcurrentHashMap<>();
    private final Map<BlockKey,UUID> primingTnt=new ConcurrentHashMap<>();
    private final NamespacedKey playerTntOwnerKey;
    public PvpListener(IncogClaims plugin){
        this.plugin=plugin;
        this.playerTntOwnerKey=new NamespacedKey(plugin.host(),"player_tnt_owner");
    }

    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onAnyDamage(EntityDamageEvent event){
        if(!(event.getEntity() instanceof Player victim))return;
        if(!hasNonMobDamageProtection(victim))return;

        // PVP protection is deliberately narrow: cancel only damage whose source can be
        // traced to another player. Lava, fire, falling, drowning, suffocation, starvation,
        // lightning, world explosions, and attacks from untamed mobs all remain normal.
        UUID attacker=resolvePlayerSourceId(event);
        if(attacker!=null&&!attacker.equals(victim.getUniqueId()))event.setCancelled(true);
    }

    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onPvp(EntityDamageByEntityEvent event){
        if(!(event.getEntity() instanceof Player victim))return;

        Player attacker=resolvePlayerAttacker(event);
        if(attacker==null||attacker.getUniqueId().equals(victim.getUniqueId()))return;

        PlayerData attackerData=plugin.getPlayerDataManager().get(attacker.getUniqueId());
        PlayerData victimData=plugin.getPlayerDataManager().get(victim.getUniqueId());

        // Peaceful is a global playstyle rule, not a claim-location rule. A Peaceful
        // player cannot deal player damage anywhere, and a Peaceful player cannot be
        // damaged by another player anywhere. This is independent of the /pvp toggle.
        if(attackerData.getType()==ClaimType.PEACEFUL || victimData.getType()==ClaimType.PEACEFUL){
            event.setCancelled(true);
            return;
        }

        // Aggressive players still respect the separate /pvp opt-in toggle.
        if(!plugin.getPvpManager().isEnabled(attacker.getUniqueId())||!plugin.getPvpManager().isEnabled(victim.getUniqueId())){
            event.setCancelled(true);
            return;
        }

        Claim vc=plugin.getClaimManager().getClaimAt(victim.getLocation()), ac=plugin.getClaimManager().getClaimAt(attacker.getLocation());
        if((vc!=null&&!vc.getFlag(com.incogdev.incogclaims.data.ClaimFlag.PVP))||(ac!=null&&!ac.getFlag(com.incogdev.incogclaims.data.ClaimFlag.PVP)))event.setCancelled(true);
    }

    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void tagCombat(EntityDamageByEntityEvent event){
        if(!(event.getEntity() instanceof Player victim))return; Player attacker=resolvePlayerAttacker(event); if(attacker==null||attacker.equals(victim))return;
        plugin.getCombatManager().tag(attacker.getUniqueId()); plugin.getCombatManager().tag(victim.getUniqueId());
    }

    /** Remembers block ownership so TNT ignited by redstone, fire, or a chain explosion is still player-sourced. */
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onTntPlaced(BlockPlaceEvent event){
        if(event.getBlockPlaced().getType()==Material.TNT)
            placedTnt.put(BlockKey.of(event.getBlockPlaced().getLocation()),event.getPlayer().getUniqueId());
    }

    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onTntBroken(BlockBreakEvent event){
        if(event.getBlock().getType()==Material.TNT)placedTnt.remove(BlockKey.of(event.getBlock().getLocation()));
    }

    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onTntPrimed(TNTPrimeEvent event){
        BlockKey key=BlockKey.of(event.getBlock().getLocation());
        UUID owner=resolvePlayerId(event.getPrimingEntity());
        UUID placedBy=placedTnt.remove(key);
        if(owner==null)owner=placedBy;
        if(owner!=null)primingTnt.put(key,owner);
    }

    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onTntSpawn(EntitySpawnEvent event){
        if(!(event.getEntity() instanceof TNTPrimed tnt))return;
        UUID primedOwner=primingTnt.remove(BlockKey.of(tnt.getLocation()));
        UUID owner=resolvePlayerId(tnt);
        if(owner==null)owner=primedOwner;
        if(owner==null)return;
        tnt.getPersistentDataContainer().set(playerTntOwnerKey,PersistentDataType.STRING,owner.toString());
        Player player=Bukkit.getPlayer(owner);
        if(player!=null)tnt.setSource(player);
    }

    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onCommand(PlayerCommandPreprocessEvent event){
        String raw=event.getMessage().substring(1).trim(); if(raw.isEmpty())return; String root=raw.split("\\s+")[0].toLowerCase(Locale.ROOT); if(root.contains(":"))root=root.substring(root.indexOf(':')+1);
        Player p=event.getPlayer();
        if(root.equals("sethome")){Claim c=plugin.getClaimManager().getClaimAt(p.getLocation());if(c!=null&&!c.isMember(p.getUniqueId())&&!p.hasPermission("incogclaims.admin")){event.setCancelled(true);Msg.send(p,"&cYou cannot set a home inside another player's claim unless they trust you.");return;}}
        if(plugin.getCombatManager().isInCombat(p.getUniqueId())&&plugin.getConfigManager().getCombatBlockedCommands().contains(root)&&!p.hasPermission("incogclaims.combat.bypass")){event.setCancelled(true);Msg.send(p,"&cYou cannot use /"+root+" while in combat. &7("+plugin.getCombatManager().remainingSeconds(p.getUniqueId())+"s)");}
    }

    @EventHandler public void onKick(PlayerKickEvent event){kicked.add(event.getPlayer().getUniqueId());plugin.getServer().getScheduler().runTaskLater(plugin.host(),()->kicked.remove(event.getPlayer().getUniqueId()),40L);}
    @EventHandler(priority=EventPriority.HIGHEST) public void onQuit(PlayerQuitEvent event){Player p=event.getPlayer();UUID u=p.getUniqueId();if(kicked.remove(u)){plugin.getCombatManager().clear(u);return;}if(!plugin.getCombatManager().isInCombat(u))return;p.getInventory().clear();p.getInventory().setArmorContents(new ItemStack[]{null,null,null,null});p.getInventory().setItemInOffHand(new ItemStack(Material.AIR));plugin.getCombatManager().clear(u);plugin.getLogger().info(p.getName()+" combat logged and lost their carried items.");}

    private boolean hasNonMobDamageProtection(Player player){
        PlayerData data=plugin.getPlayerDataManager().get(player.getUniqueId());
        return data.getType()==ClaimType.PEACEFUL || !data.isPvpEnabled();
    }

    private UUID resolvePlayerSourceId(EntityDamageEvent event){
        UUID causing=resolvePlayerId(event.getDamageSource().getCausingEntity());
        if(causing!=null)return causing;
        UUID direct=resolvePlayerId(event.getDamageSource().getDirectEntity());
        if(direct!=null)return direct;
        return event instanceof EntityDamageByEntityEvent byEntity ? resolvePlayerId(byEntity.getDamager()) : null;
    }

    private Player resolvePlayerAttacker(EntityDamageByEntityEvent event){
        UUID uuid=resolvePlayerSourceId(event);
        return uuid==null?null:Bukkit.getPlayer(uuid);
    }

    private UUID resolvePlayerId(Entity damager){
        if(damager instanceof Player p)return p.getUniqueId();
        if(damager instanceof Projectile projectile&&projectile.getShooter() instanceof Player p)return p.getUniqueId();
        if(damager instanceof Tameable tameable&&tameable.getOwner() instanceof Player p)return p.getUniqueId();
        if(damager instanceof TNTPrimed tnt){
            if(tnt.getSource() instanceof Player p)return p.getUniqueId();
            String stored=tnt.getPersistentDataContainer().get(playerTntOwnerKey,PersistentDataType.STRING);
            if(stored!=null)try{return UUID.fromString(stored);}catch(IllegalArgumentException ignored){}
        }
        return null;
    }

    private record BlockKey(UUID world,int x,int y,int z){
        private static BlockKey of(org.bukkit.Location location){
            return new BlockKey(location.getWorld().getUID(),location.getBlockX(),location.getBlockY(),location.getBlockZ());
        }
    }
}

package com.incogdev.incogclaims.util;

import com.incogdev.incogclaims.IncogClaims;
import com.incogdev.incogutils.branding.Branding;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Msg {

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    /** Chat-facing branding is abbreviated to IC even if an older config still says Incog-Claims. */
    private static String abbreviateBrand(String message) {
        if (message == null) return "";
        return message
                .replace("Incog-Claims", "IC")
                .replace("Incog Claims", "IC")
                .replace("INCOG-CLAIMS", "IC")
                .replace("INCOG CLAIMS", "IC");
    }

    public static void send(CommandSender sender, String message) {
        String configured = IncogClaims.getInstance().getConfigManager().getMessage("prefix");
        sender.sendMessage(Branding.legacyConfigured(configured, "Claims") + color(abbreviateBrand(message)));
    }

    public static void sendRaw(CommandSender sender, String message) {
        sender.sendMessage(color(abbreviateBrand(message)));
    }

    /** Shows a short-lived action bar message (used for claim enter/leave notices). */
    public static void actionBar(Player player, String message) {
        Component component = LegacyComponentSerializer.legacyAmpersand().deserialize(abbreviateBrand(message));
        player.sendActionBar(component);
    }
}

package com.incogdev.incogrpg;

import com.incogdev.incogrpg.api.IncogRpgApi;
import com.incogdev.incogrpg.api.IncogRpgApiImpl;
import com.incogdev.incogrpg.command.RpgCommands;
import com.incogdev.incogrpg.command.FreezeCommand;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.cosmetics.RankCrownDisplayService;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.data.SqliteDatabase;
import com.incogdev.incogrpg.integration.IncogPlaceholderExpansion;
import com.incogdev.incogrpg.integration.IncogUtilsPlaceholderExpansion;
import com.incogdev.incogrpg.integration.VaultEconomyBridge;
import com.incogdev.incogrpg.listener.*;
import com.incogdev.incogrpg.menu.MenuService;
import com.incogdev.incogrpg.service.*;
import com.incogdev.incogrpg.util.Messages;
import com.incogdev.incogutils.maintenance.MaintenanceCommand;
import com.incogdev.incogutils.maintenance.MaintenanceListener;
import com.incogdev.incogutils.maintenance.MaintenanceManager;
import com.incogdev.incogutils.settings.FeatureAccessListener;
import com.incogdev.incogutils.settings.FeatureSettingsManager;
import com.incogdev.incogutils.settings.PlayerSettingsManager;
import com.incogdev.antimacro.AntiMacroPlugin;
import com.incogdev.incogclaims.IncogClaims;
import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.incogdev.homes.IncogHomes;
import com.incog.vaults.IncogVaults;
import dev.itemforge.ItemForgePlugin;
import org.bukkit.Bukkit;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.ConfigurationSection;

import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.jar.JarFile;

public final class IncogRpgPlugin extends JavaPlugin {
    private ConfigManager configs;
    private Messages messages;
    private SqliteDatabase database;
    private PlayerDataService data;
    private SkillService skills;
    private EnchantService enchants;
    private ReforgeService reforges;
    private CustomItemService customItems;
    private PetService pets;
    private AccessoryService accessories;
    private AchievementService achievements;
    private StatService stats;
    private HudService hud;
    private CooldownService cooldowns;
    private MenuService menus;
    private MenuListener menuListener;
    private EnchantCombatListener combatListener;
    private VaultEconomyBridge vault;
    private IncogRpgApi api;
    private AntiMacroPlugin antiMacroModule;
    private IncogClaims claimsModule;
    private IncogShopPlugin economyModule;
    private ItemForgePlugin itemForgeModule;
    private IncogHomes homesModule;
    private IncogVaults vaultsModule;
    private FreezeService freezes;
    private RankCrownDisplayService rankCrownDisplays;
    private MaintenanceManager maintenance;
    private FeatureSettingsManager featureSettings;
    private PlayerSettingsManager playerSettings;

    @Override
    public void onEnable() {
        List<String> duplicateJars = duplicatePluginJars();
        if (duplicateJars.size() > 1) {
            getLogger().severe("============================================================");
            getLogger().severe("DUPLICATE INCOG SUITE JARS DETECTED: " + String.join(", ", duplicateJars));
            getLogger().severe("Stop the server and remove old IncogRPG, IncogEcon, Incog-Claims, Incog-AntiMacro, and ItemForge JARs. Keep only IncogUtils.");
            getLogger().severe("IncogUtils is disabling itself to prevent two copies from modifying player data.");
            getLogger().severe("============================================================");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        saveDefaults();
        mergeMissingDefaultsOnUpgrade();
        configs = new ConfigManager(this);
        ConfigManager.ReloadResult loaded = configs.reload();
        if (!loaded.success()) { getLogger().severe("IncogRPG has been disabled because no valid configuration could be loaded."); getServer().getPluginManager().disablePlugin(this); return; }
        messages = new Messages(configs);
        playerSettings = new PlayerSettingsManager(this);
        playerSettings.load();
        featureSettings = new FeatureSettingsManager(this);
        featureSettings.load();
        freezes = new FreezeService(this, configs, messages);
        freezes.load();
        database = new SqliteDatabase(this);
        try {
            File dbFile = new File(getDataFolder(), configs.get().core().getString("persistence.database-file", "player-data.db"));
            database.open(dbFile, configs.get().core().getInt("persistence.sqlite-busy-timeout-ms", 5000));
        } catch (SQLException ex) {
            getLogger().severe("Could not initialize player data: " + ex.getMessage()); getServer().getPluginManager().disablePlugin(this); return;
        }
        data = new PlayerDataService(this, database);
        cooldowns = new CooldownService();
        enchants = new EnchantService(this, configs, messages);
        reforges = new ReforgeService(this, configs, messages);
        customItems = new CustomItemService(this, configs, messages, enchants, reforges);
        hud = new HudService(this, configs, messages, playerSettings);
        pets = new PetService(this, configs, data, messages);
        accessories = new AccessoryService(configs, data, customItems);
        skills = new SkillService(this, configs, data, messages, customItems, hud, pets);
        stats = new StatService(this, configs, data, reforges, enchants, customItems, pets, accessories);
        pets.setStatUpdater(stats::recompute);
        achievements = new AchievementService(this, configs, data, customItems, messages, playerSettings);
        achievements.setSkillService(skills);
        skills.setXpBonusProvider(player -> stats.value(player, "CUSTOM_XP_GAIN"));
        skills.setStatUpdater(stats::recompute);
        menus = new MenuService(this, configs, data, stats, reforges, customItems, achievements, pets, accessories, messages);
        rankCrownDisplays = new RankCrownDisplayService(this);
        vault = new VaultEconomyBridge(); vault.connect();
        api = new IncogRpgApiImpl(configs, data, skills, stats, enchants, reforges, customItems, achievements);
        Bukkit.getServicesManager().register(IncogRpgApi.class, api, this, ServicePriority.Normal);
        int recipes = customItems.reloadRecipes();
        maintenance = new MaintenanceManager(this);
        maintenance.load();
        validateCommandDeclarations();
        registerListeners(); registerCommands(); registerTasks(); registerIntegrations();
        rankCrownDisplays.start();
        enableModules();
        getLogger().info("Enabled with " + loaded.skills() + " skills, " + loaded.enchants() + " unique enchants, "
                + loaded.reforges() + " reforges, " + loaded.items() + " custom items, " + loaded.achievements()
                + " achievements, " + loaded.pets() + " pets, and " + recipes + " recipes. Pets are "
                + (configs.get().petSettings().enabled() ? "enabled" : "disabled") + ".");
    }

    @Override
    public void onDisable() {
        if (rankCrownDisplays != null) rankCrownDisplays.shutdown();
        disableModules();
        if (menuListener != null) Bukkit.getOnlinePlayers().forEach(menuListener::recoverOpenReforgeInput);
        if (hud != null) Bukkit.getOnlinePlayers().forEach(hud::clear);
        if (pets != null) pets.shutdown();
        if (freezes != null) freezes.save();
        if (data != null) data.close();
        if (database != null) database.close();
        if (api != null) Bukkit.getServicesManager().unregister(IncogRpgApi.class, api);
    }

    private void saveDefaults() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) getLogger().warning("Could not create plugin data directory yet.");
        for (String name : new String[]{"config.yml", "messages.yml", "skills.yml", "enchants.yml", "reforges.yml", "items.yml", "relics.yml", "achievements.yml", "pets.yml"})
            if (!new File(getDataFolder(), name).exists()) saveResource(name, false);
    }

    private void mergeMissingDefaultsOnUpgrade() {
        String version = getPluginMeta().getVersion();
        File coreFile = new File(getDataFolder(), "config.yml");
        YamlConfiguration core = YamlConfiguration.loadConfiguration(coreFile);
        if (!core.getBoolean("general.merge-missing-defaults-on-upgrade", true) ||
                version.equals(core.getString("general.last-default-merge-version", ""))) return;
        int added = 0;
        for (String name : new String[]{"config.yml", "messages.yml", "skills.yml", "enchants.yml", "reforges.yml", "items.yml", "relics.yml", "achievements.yml", "pets.yml"}) {
            File file = new File(getDataFolder(), name);
            try (var stream = getResource(name)) {
                if (stream == null) continue;
                YamlConfiguration live = new YamlConfiguration();
                live.load(file);
                YamlConfiguration defaults = YamlConfiguration.loadConfiguration(new InputStreamReader(stream, StandardCharsets.UTF_8));
                int fileAdded = mergeMissing(live, defaults);
                // Pet pools are YAML lists, so the normal map-path migration
                // intentionally leaves them alone. Merge newly bundled pets by
                // ID instead, preserving every existing custom pet unchanged.
                if (name.equals("pets.yml")) fileAdded += mergeMissingPets(live, defaults);
                if (fileAdded == 0) continue;
                File backup = new File(getDataFolder(), name + ".pre-" + version + ".bak");
                if (!backup.exists()) Files.copy(file.toPath(), backup.toPath());
                live.save(file);
                added += fileAdded;
                getLogger().info("Merged " + fileAdded + " missing default path(s) into " + name + " (backup: " + backup.getName() + ").");
            } catch (Exception ex) {
                getLogger().warning("Could not merge missing " + name + " defaults: " + ex.getMessage());
            }
        }
        try {
            core = YamlConfiguration.loadConfiguration(coreFile);
            core.set("general.last-default-merge-version", version);
            core.save(coreFile);
        } catch (Exception ex) {
            getLogger().warning("Could not record the default-merge version: " + ex.getMessage());
        }
        if (added > 0) getLogger().info("Default migration added " + added + " missing path(s) without replacing configured values.");
    }

    private static int mergeMissing(ConfigurationSection live, ConfigurationSection defaults) {
        int added = 0;
        for (String key : defaults.getKeys(false)) {
            ConfigurationSection defaultSection = defaults.getConfigurationSection(key);
            if (defaultSection != null) {
                ConfigurationSection liveSection = live.getConfigurationSection(key);
                if (liveSection == null) {
                    if (live.contains(key)) continue;
                    liveSection = live.createSection(key);
                    added++;
                }
                added += mergeMissing(liveSection, defaultSection);
            } else if (!live.contains(key)) {
                live.set(key, defaults.get(key));
                added++;
            }
        }
        return added;
    }

    private static int mergeMissingPets(YamlConfiguration live, YamlConfiguration defaults) {
        ConfigurationSection bundledPools = defaults.getConfigurationSection("skill-pools");
        if (bundledPools == null) return 0;
        int added = 0;
        for (String skill : bundledPools.getKeys(false)) {
            String path = "skill-pools." + skill + ".pets";
            List<Map<?, ?>> configured = new ArrayList<>(live.getMapList(path));
            int poolAdded = 0;
            java.util.Set<String> knownIds = new java.util.HashSet<>();
            for (Map<?, ?> pet : configured) {
                Object id = pet.get("id");
                if (id != null) knownIds.add(id.toString().trim().toLowerCase(java.util.Locale.ROOT));
            }
            for (Map<?, ?> pet : defaults.getMapList(path)) {
                Object id = pet.get("id");
                if (id == null || id.toString().isBlank()) continue;
                if (!knownIds.add(id.toString().trim().toLowerCase(java.util.Locale.ROOT))) continue;
                configured.add(new java.util.LinkedHashMap<>(pet));
                poolAdded++;
            }
            if (poolAdded > 0) live.set(path, configured);
            added += poolAdded;
        }
        return added;
    }

    private void registerListeners() {
        combatListener = new EnchantCombatListener(this, configs, enchants, cooldowns, stats, data, skills);
        var manager = getServer().getPluginManager();
        manager.registerEvents(new ProfileListener(this, data, stats, cooldowns, hud, achievements, pets), this);
        manager.registerEvents(new FallDamageListener(this), this);
        manager.registerEvents(pets, this);
        manager.registerEvents(new EquipmentListener(this, stats, enchants, reforges), this);
        manager.registerEvents(new SkillXpListener(configs, skills, stats), this);
        manager.registerEvents(combatListener, this);
        manager.registerEvents(new EnchantGatheringListener(configs, enchants, cooldowns, skills), this);
        manager.registerEvents(new CustomBookListener(configs, enchants), this);
        manager.registerEvents(new EnchantingTableListener(configs, enchants, messages), this);
        manager.registerEvents(new NaturalEnchantDropListener(configs, enchants), this);
        manager.registerEvents(new ReforgeStoneListener(configs, customItems, reforges), this);
        manager.registerEvents(new AchievementListener(configs, data, achievements, customItems), this);
        manager.registerEvents(new CustomStatListener(this, stats), this);
        manager.registerEvents(new BrewingListener(skills), this);
        manager.registerEvents(new CustomItemDropListener(configs, customItems), this);
        manager.registerEvents(new NaturalReforgeListener(configs, customItems, reforges), this);
        manager.registerEvents(freezes, this);
        menuListener = new MenuListener(this, configs, menus, reforges, stats, data, achievements, pets, accessories, messages, vault);
        manager.registerEvents(menuListener, this);
        manager.registerEvents(new MaintenanceListener(maintenance), this);
        manager.registerEvents(new FeatureAccessListener(featureSettings), this);
    }

    private void registerCommands() {
        RpgCommands commands = new RpgCommands(this);
        for (String name : new String[]{"skills", "skill", "stats", "items", "enchants", "achievements", "pets", "pet", "accessories", "reforge", "menus", "settings", "adminsettings", "incogutils", "reload"}) {
            var command = Objects.requireNonNull(getCommand(name), "Missing command " + name);
            command.setExecutor(commands); command.setTabCompleter(commands);
        }
        var freezeCommand = Objects.requireNonNull(getCommand("freeze"), "Missing command freeze");
        FreezeCommand freezeExecutor = new FreezeCommand(this.freezes, messages);
        freezeCommand.setExecutor(freezeExecutor); freezeCommand.setTabCompleter(freezeExecutor);
        var maintenanceCommand = Objects.requireNonNull(getCommand("incogmaintenance"), "Missing command incogmaintenance");
        MaintenanceCommand maintenanceExecutor = new MaintenanceCommand(this, maintenance);
        maintenanceCommand.setExecutor(maintenanceExecutor); maintenanceCommand.setTabCompleter(maintenanceExecutor);
        if (homesModule != null) {
            var set = new com.incogdev.homes.commands.SetHomeCommand(homesModule, false);
            getCommand("sethome").setExecutor(set); getCommand("forcesethome").setExecutor(new com.incogdev.homes.commands.SetHomeCommand(homesModule, true));
            getCommand("home").setExecutor(new com.incogdev.homes.commands.HomeCommand(homesModule)); getCommand("home").setTabCompleter(new com.incogdev.homes.commands.HomeNameTabCompleter(homesModule));
            getCommand("delhome").setExecutor(new com.incogdev.homes.commands.DelHomeCommand(homesModule)); getCommand("delhome").setTabCompleter(new com.incogdev.homes.commands.HomeNameTabCompleter(homesModule));
            getCommand("homes").setExecutor(new com.incogdev.homes.commands.HomesListCommand(homesModule)); getCommand("homeadmin").setExecutor(new com.incogdev.homes.commands.HomeAdminCommand(homesModule));
        }
    }

    /**
     * Fails early when plugin.yml and the actual module command wiring drift apart.
     * This prevents a command from appearing to exist in documentation while being
     * absent (or silently unhandled) in a released IncogUtils JAR.
     */
    private void validateCommandDeclarations() {
        String[] required = {
                "skills", "skill", "stats", "items", "enchants", "achievements", "pets", "pet",
                "accessories", "reforge", "menus", "settings", "adminsettings", "freeze", "incogutils", "reload",
                "antimacro", "verify", "claims", "pvp", "itemforge",
                "market", "sell", "stash", "xpvault", "ah", "pshop", "shopdistrict", "sellwand", "trade", "hex", "marketadmin", "globalrestock", "weeklystock", "daily",
                "incogvaults", "regenkey", "incogmaintenance"
        };
        List<String> missing = new ArrayList<>();
        for (String name : required) if (getCommand(name) == null) missing.add(name);
        if (!missing.isEmpty()) {
            throw new IllegalStateException("plugin.yml is missing required IncogUtils command(s): "
                    + String.join(", ", missing));
        }
    }

    private void registerTasks() {
        long autosave = Math.max(20, configs.get().core().getLong("persistence.autosave-seconds", 120) * 20L);
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> data.saveAll(false), autosave, autosave);
        Bukkit.getScheduler().runTaskTimer(this, () -> { combatListener.tickPassives(); cooldowns.prune(); }, 20L, 20L);
        long hudRefresh = Math.max(1, configs.get().core().getLong("hud.refresh-ticks", 5));
        Bukkit.getScheduler().runTaskTimer(this, hud::tick, 1L, hudRefresh);
        long petRefresh = Math.max(1, configs.get().petSettings().updateTicks());
        Bukkit.getScheduler().runTaskTimer(this, pets::tick, 1L, petRefresh);
    }

    private void registerIntegrations() {
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new IncogPlaceholderExpansion(this).register();
            new IncogUtilsPlaceholderExpansion(this).register();
            getLogger().info("PlaceholderAPI integration enabled.");
        }
        if (Bukkit.getPluginManager().isPluginEnabled("ExcellentEnchants"))
            getLogger().info("ExcellentEnchants detected; IncogRPG's catalog is limited to non-overlapping RPG enchants.");
    }

    public ConfigManager configs() { return configs; }
    public Messages messages() { return messages; }
    public PlayerDataService data() { return data; }
    public SkillService skills() { return skills; }
    public EnchantService enchants() { return enchants; }
    public ReforgeService reforges() { return reforges; }
    public CustomItemService customItems() { return customItems; }
    public PetService pets() { return pets; }
    public AccessoryService accessories() { return accessories; }
    public AchievementService achievements() { return achievements; }
    public StatService stats() { return stats; }
    public HudService hud() { return hud; }
    public FreezeService freezes() { return freezes; }
    public MenuService menus() { return menus; }
    public RankCrownDisplayService rankCrownDisplays() { return rankCrownDisplays; }
    public MaintenanceManager maintenance() { return maintenance; }
    public FeatureSettingsManager featureSettings() { return featureSettings; }
    public PlayerSettingsManager playerSettings() { return playerSettings; }
    public IncogRpgApi api() { return api; }
    public IncogShopPlugin economyModule() { return economyModule; }
    public IncogClaims claimsModule() { return claimsModule; }
    public IncogHomes homesModule() { return homesModule; }
    public IncogVaults vaultsModule() { return vaultsModule; }
    public AntiMacroPlugin antiMacroModule() { return antiMacroModule; }
    public boolean antiMacroModuleAvailable() { return antiMacroModule != null; }
    public boolean claimsModuleAvailable() { return claimsModule != null; }
    public boolean itemForgeModuleAvailable() { return itemForgeModule != null; }
    public boolean economyModuleAvailable() { return economyModule != null && economyModule.wallets() != null; }

    public void reloadModules() {
        playerSettings.load();
        featureSettings.load();
        if (antiMacroModule != null) antiMacroModule.reloadConfig();
        if (claimsModule != null) {
            claimsModule.getConfigManager().load();
            Bukkit.getOnlinePlayers().forEach(claimsModule::updateLuckPermsSuffix);
        }
        if (economyModule != null && economyModule.wallets() != null) economyModule.reloadAll();
        if (homesModule != null) homesModule.reload();
        if (vaultsModule != null) vaultsModule.reload();
        if (itemForgeModule != null) itemForgeModule.reloadEverything();
        if (rankCrownDisplays != null) rankCrownDisplays.reload();
    }

    private void enableModules() {
        var core = configs.get().core();
        if (core.getBoolean("modules.antimacro.enabled", true)) {
            antiMacroModule = new AntiMacroPlugin(this);
            enableModule("AntiMacro", antiMacroModule::enable);
        }
        if (core.getBoolean("modules.claims.enabled", true)) {
            claimsModule = new IncogClaims(this);
            enableModule("Claims", claimsModule::enable);
        }
        if (core.getBoolean("modules.itemforge.enabled", true)) {
            itemForgeModule = new ItemForgePlugin(this);
            enableModule("ItemForge", itemForgeModule::enable);
        }
        if (core.getBoolean("modules.economy.enabled", true)) {
            economyModule = new IncogShopPlugin(this);
            enableModule("Economy/Hex", economyModule::enable);
        }
        homesModule = new IncogHomes(this);
        enableModule("Homes", homesModule::enable);
        vaultsModule = new IncogVaults(this);
        enableModule("Vaults", vaultsModule::enable);
    }

    private void enableModule(String name, Runnable enable) {
        try {
            enable.run();
            getLogger().info("IncogUtils module enabled: " + name + ".");
        } catch (Throwable error) {
            getLogger().log(java.util.logging.Level.SEVERE,
                    "Could not enable the " + name + " module. Other IncogUtils modules will remain available.", error);
        }
    }

    private void disableModules() {
        try { if (economyModule != null) economyModule.disable(); } catch (Throwable error) { getLogger().warning("Economy shutdown: " + error.getMessage()); }
        try { if (itemForgeModule != null) itemForgeModule.disable(); } catch (Throwable error) { getLogger().warning("ItemForge shutdown: " + error.getMessage()); }
        try { if (claimsModule != null) claimsModule.disable(); } catch (Throwable error) { getLogger().warning("Claims shutdown: " + error.getMessage()); }
        try { if (antiMacroModule != null) antiMacroModule.disable(); } catch (Throwable error) { getLogger().warning("AntiMacro shutdown: " + error.getMessage()); }
        try { if (vaultsModule != null) vaultsModule.disable(); } catch (Throwable error) { getLogger().warning("Vaults shutdown: " + error.getMessage()); }
        try { if (homesModule != null) homesModule.disable(); } catch (Throwable error) { getLogger().warning("Homes shutdown: " + error.getMessage()); }
    }

    private List<String> duplicatePluginJars() {
        File directory = getDataFolder().getParentFile();
        File[] jars = directory == null ? null : directory.listFiles((ignored, name) -> name.toLowerCase().endsWith(".jar"));
        if (jars == null) return List.of();
        List<String> matches = new ArrayList<>();
        for (File jar : jars) {
            try (JarFile archive = new JarFile(jar)) {
                var entry = archive.getJarEntry("plugin.yml");
                if (entry == null) continue;
                try (InputStreamReader reader = new InputStreamReader(archive.getInputStream(entry), StandardCharsets.UTF_8)) {
                    YamlConfiguration description = YamlConfiguration.loadConfiguration(reader);
                    String name = description.getString("name", "");
                    if (java.util.Set.of("IncogUtils", "IncogRPG", "IncogEcon", "Incog-Claims", "Incog-AntiMacro", "ItemForge")
                            .stream().anyMatch(name::equalsIgnoreCase)) matches.add(jar.getName());
                }
            } catch (Exception ignored) { }
        }
        return matches.stream().sorted().toList();
    }
}

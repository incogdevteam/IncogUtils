package com.incogdev.incogrpg.api;

import com.incogdev.incogrpg.model.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public interface IncogRpgApi {
    Optional<PlayerProfile> profile(UUID playerId);
    Optional<SkillDefinition> skill(String id);
    Map<String, SkillDefinition> skills();
    Map<String, EnchantDefinition> enchants();
    Map<String, ReforgeDefinition> reforges();
    Map<String, CustomItemDefinition> items();
    Map<String, AchievementDefinition> achievements();
    SkillProgress progress(UUID playerId, String skillId);
    double addXp(Player player, String skillId, double amount, String source);
    StatSnapshot stats(Player player);
    Map<String, Integer> itemEnchants(ItemStack item);
    Optional<ReforgeDefinition> itemReforge(ItemStack item);
    Optional<CustomItemDefinition> itemDefinition(ItemStack item);
    ItemStack createItem(String id, int amount);
    StatBreakdown statBreakdown(Player player);
    double achievementProgress(UUID playerId, String metric, String target);
    void recordAchievementProgress(Player player, String metric, String target, double amount);
    boolean hasAchievement(UUID playerId, String achievementId);
}

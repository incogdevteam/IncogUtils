package com.incogdev.incogrpg.api;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.model.*;
import com.incogdev.incogrpg.service.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class IncogRpgApiImpl implements IncogRpgApi {
    private final ConfigManager configs; private final PlayerDataService data; private final SkillService skills;
    private final StatService stats; private final EnchantService enchants; private final ReforgeService reforges;
    private final CustomItemService items; private final AchievementService achievements;
    public IncogRpgApiImpl(ConfigManager configs, PlayerDataService data, SkillService skills, StatService stats,
                          EnchantService enchants, ReforgeService reforges, CustomItemService items,
                          AchievementService achievements) {
        this.configs = configs; this.data = data; this.skills = skills; this.stats = stats; this.enchants = enchants;
        this.reforges = reforges; this.items = items; this.achievements = achievements;
    }
    @Override public Optional<PlayerProfile> profile(UUID playerId) { return data.find(playerId); }
    @Override public Optional<SkillDefinition> skill(String id) { return skills.definition(id); }
    @Override public Map<String, SkillDefinition> skills() { return configs.get().skills(); }
    @Override public Map<String, EnchantDefinition> enchants() { return configs.get().enchants(); }
    @Override public Map<String, ReforgeDefinition> reforges() { return configs.get().reforges(); }
    @Override public Map<String, CustomItemDefinition> items() { return configs.get().items(); }
    @Override public Map<String, AchievementDefinition> achievements() { return configs.get().achievements(); }
    @Override public SkillProgress progress(UUID playerId, String skillId) { return data.find(playerId).map(p -> p.progress(skillId)).orElse(new SkillProgress(0, 0)); }
    @Override public double addXp(Player player, String skillId, double amount, String source) { return skills.addXp(player, skillId, source, amount).added(); }
    @Override public StatSnapshot stats(Player player) { return stats.get(player); }
    @Override public Map<String, Integer> itemEnchants(ItemStack item) { return enchants.get(item); }
    @Override public Optional<ReforgeDefinition> itemReforge(ItemStack item) { return reforges.get(item); }
    @Override public Optional<CustomItemDefinition> itemDefinition(ItemStack item) { return items.definition(item); }
    @Override public ItemStack createItem(String id, int amount) { return items.create(id, amount).orElseThrow(() -> new IllegalArgumentException("Unknown custom item " + id)); }
    @Override public StatBreakdown statBreakdown(Player player) { return stats.breakdown(player); }
    @Override public double achievementProgress(UUID playerId, String metric, String target) {
        return data.find(playerId).map(profile -> profile.achievementProgress(AchievementService.key(metric, target))).orElse(0.0);
    }
    @Override public void recordAchievementProgress(Player player, String metric, String target, double amount) {
        achievements.add(player, metric, target, amount);
    }
    @Override public boolean hasAchievement(UUID playerId, String achievementId) {
        return data.find(playerId).map(profile -> profile.achievementCompleted(achievementId.toLowerCase(java.util.Locale.ROOT).replace('-', '_'))).orElse(false);
    }
}

package com.incogdev.incogrpg.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/** Fired after an IncogRPG achievement is persistently unlocked. */
public final class AchievementUnlockEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private final String achievementId;
    private final boolean administered;

    public AchievementUnlockEvent(Player player, String achievementId, boolean administered) {
        this.player = player;
        this.achievementId = achievementId;
        this.administered = administered;
    }

    public Player getPlayer() { return player; }
    public String getAchievementId() { return achievementId; }
    public boolean isAdministered() { return administered; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static @NotNull HandlerList getHandlerList() { return HANDLERS; }
}

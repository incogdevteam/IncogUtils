package com.incogdev.incogrpg.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public final class CustomEnchantProcEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private final String enchantId;
    private final int level;
    private final ItemStack item;
    public CustomEnchantProcEvent(Player player, String enchantId, int level, ItemStack item) {
        this.player = player; this.enchantId = enchantId; this.level = level; this.item = item.clone();
    }
    public Player getPlayer() { return player; }
    public String getEnchantId() { return enchantId; }
    public int getLevel() { return level; }
    public ItemStack getItem() { return item.clone(); }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static @NotNull HandlerList getHandlerList() { return HANDLERS; }
}

package com.incogdev.incogrpg.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public final class SkillLevelUpEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private final String skillId;
    private final int oldLevel;
    private final int newLevel;

    public SkillLevelUpEvent(Player player, String skillId, int oldLevel, int newLevel) {
        this.player = player; this.skillId = skillId; this.oldLevel = oldLevel; this.newLevel = newLevel;
    }
    public Player getPlayer() { return player; }
    public String getSkillId() { return skillId; }
    public int getOldLevel() { return oldLevel; }
    public int getNewLevel() { return newLevel; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static @NotNull HandlerList getHandlerList() { return HANDLERS; }
}

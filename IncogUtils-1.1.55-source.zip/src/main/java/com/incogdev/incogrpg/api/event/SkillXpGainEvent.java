package com.incogdev.incogrpg.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public final class SkillXpGainEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private final String skillId;
    private final String source;
    private double amount;
    private boolean cancelled;

    public SkillXpGainEvent(Player player, String skillId, String source, double amount) {
        this.player = player;
        this.skillId = skillId;
        this.source = source;
        this.amount = amount;
    }
    public Player getPlayer() { return player; }
    public String getSkillId() { return skillId; }
    public String getSource() { return source; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = Math.max(0, amount); }
    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static @NotNull HandlerList getHandlerList() { return HANDLERS; }
}

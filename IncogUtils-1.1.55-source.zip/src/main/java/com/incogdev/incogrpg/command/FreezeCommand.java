package com.incogdev.incogrpg.command;

import com.incogdev.incogrpg.service.FreezeService;
import com.incogdev.incogrpg.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** /freeze <player> [reason], /freeze <player> off, and /freeze list. */
public final class FreezeCommand implements TabExecutor {
    private final FreezeService freezes;
    private final Messages messages;

    public FreezeCommand(FreezeService freezes, Messages messages) {
        this.freezes = freezes;
        this.messages = messages;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String @NotNull [] args) {
        if (!sender.hasPermission("incogutils.freeze")) { messages.send(sender, "no-permission"); return true; }
        if (!freezes.enabled()) { sender.sendMessage(messages.raw("<red>The freeze system is disabled in config.yml.")); return true; }
        if (args.length == 0) { usage(sender, label); return true; }
        if (args[0].equalsIgnoreCase("list")) { list(sender); return true; }

        String targetName = args[0];
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            var stored = freezes.findByName(targetName).orElse(null);
            if (stored != null && (args.length == 1 || args[1].equalsIgnoreCase("off") || args[1].equalsIgnoreCase("unfreeze"))) {
                freezes.unfreeze(stored.getKey());
                sender.sendMessage(messages.raw("<green>Unfroze <white>" + stored.getValue().playerName() + "</white> while they are offline."));
            } else messages.send(sender, "player-not-found", Map.of("player", targetName));
            return true;
        }
        if (target.hasPermission("incogutils.freeze.bypass")) {
            sender.sendMessage(messages.raw("<red>" + target.getName() + " cannot be frozen because they have the bypass permission."));
            return true;
        }

        boolean explicitlyUnfreeze = args.length > 1 && (args[1].equalsIgnoreCase("off") || args[1].equalsIgnoreCase("unfreeze"));
        if (explicitlyUnfreeze || freezes.record(target.getUniqueId()).isPresent()) {
            if (freezes.unfreeze(target.getUniqueId()).isEmpty()) {
                sender.sendMessage(messages.raw("<yellow>" + target.getName() + " is not currently frozen."));
            } else {
                sender.sendMessage(messages.raw("<green>Unfroze <white>" + target.getName() + "</white>."));
                target.sendMessage(messages.raw("<green><bold>You have been unfrozen.</bold> <gray>You may move again."));
            }
            return true;
        }

        String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "Under staff review";
        freezes.freeze(target, sender.getName(), reason);
        sender.sendMessage(messages.raw("<aqua>Froze <white>" + target.getName() + "</white><aqua>. Reason: <white>" + reason));
        return true;
    }

    private void list(CommandSender sender) {
        var records = freezes.records();
        if (records.isEmpty()) { sender.sendMessage(messages.raw("<gray>No players are currently frozen.")); return; }
        sender.sendMessage(messages.raw("<aqua><bold>Frozen Players</bold> <dark_gray>(" + records.size() + ")"));
        records.forEach(entry -> sender.sendMessage(messages.raw("<dark_gray>•</dark_gray> <white>" + entry.getValue().playerName()
                + " <gray>by <aqua>" + entry.getValue().frozenBy() + " <dark_gray>—</dark_gray> <gray>" + entry.getValue().reason())));
    }

    private void usage(CommandSender sender, String label) {
        sender.sendMessage(messages.raw("<yellow>/" + label + " <player> [reason] <gray>— freeze or unfreeze a player"));
        sender.sendMessage(messages.raw("<yellow>/" + label + " <player> off <gray>— explicitly unfreeze"));
        sender.sendMessage(messages.raw("<yellow>/" + label + " list <gray>— show frozen players"));
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String @NotNull [] args) {
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            options.add("list");
            Bukkit.getOnlinePlayers().forEach(player -> options.add(player.getName()));
            freezes.records().forEach(entry -> { if (!options.contains(entry.getValue().playerName())) options.add(entry.getValue().playerName()); });
        } else if (args.length == 2) options.addAll(List.of("off", "unfreeze"));
        String prefix = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        return options.stream().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(prefix)).sorted().toList();
    }
}

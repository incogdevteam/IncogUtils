package com.incogdev.incogrpg.command;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.model.*;
import com.incogdev.incogrpg.service.EnchantService;
import com.incogdev.incogrpg.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public final class RpgCommands implements TabExecutor {
    private final IncogRpgPlugin plugin;
    private final Messages messages;
    public RpgCommands(IncogRpgPlugin plugin) { this.plugin = plugin; this.messages = plugin.messages(); }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String @NotNull [] args) {
        return switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "skills" -> skills(sender, args);
            case "skill" -> skill(sender, args);
            case "stats" -> stats(sender, args);
            case "items" -> items(sender, args);
            case "enchants" -> enchants(sender, args);
            case "achievements" -> achievements(sender, args);
            case "pets" -> pets(sender, args);
            case "pet" -> pet(sender, args);
            case "accessories" -> accessories(sender);
            case "reforge" -> reforge(sender);
            case "menus" -> menus(sender);
            case "settings" -> settings(sender, args);
            case "adminsettings" -> adminSettings(sender);
            case "incogutils" -> admin(sender, args);
            case "reload" -> reload(sender);
            default -> false;
        };
    }

    private boolean skills(CommandSender sender, String[] args) {
        Player viewer = player(sender); if (viewer == null) return true;
        Player target = viewer;
        if (args.length > 0) {
            if (!sender.hasPermission("incogrpg.inspect")) { messages.send(sender, "no-permission"); return true; }
            target = Bukkit.getPlayerExact(args[0]); if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[0])); return true; }
        }
        plugin.menus().openSkills(viewer, target); return true;
    }

    private boolean skill(CommandSender sender, String[] args) {
        Player viewer = player(sender); if (viewer == null) return true;
        if (args.length == 0) { plugin.menus().openSkills(viewer, viewer); return true; }
        SkillDefinition definition = plugin.skills().definition(args[0]).orElse(null);
        if (definition == null) { messages.send(sender, "unknown-skill", Map.of("skill", args[0])); return true; }
        Player target = viewer;
        if (args.length > 1) {
            if (!sender.hasPermission("incogrpg.inspect")) { messages.send(sender, "no-permission"); return true; }
            target = Bukkit.getPlayerExact(args[1]); if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[1])); return true; }
        }
        plugin.menus().openSkill(viewer, target, definition); return true;
    }

    private boolean enchants(CommandSender sender, String[] args) {
        Player player = player(sender); if (player == null) return true;
        int page = args.length == 0 ? 0 : Math.max(0, integer(args[0], 1) - 1);
        plugin.menus().openEnchants(player, page); return true;
    }

    private boolean stats(CommandSender sender, String[] args) {
        Player viewer = player(sender); if (viewer == null) return true;
        Player target = viewer;
        int pageArgument = 0;
        if (args.length > 0 && !args[0].matches("\\d+")) {
            if (!sender.hasPermission("incogrpg.inspect")) { messages.send(sender, "no-permission"); return true; }
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[0])); return true; }
            pageArgument = 1;
        }
        int page = args.length > pageArgument ? Math.max(0, integer(args[pageArgument], 1) - 1) : 0;
        plugin.menus().openStats(viewer, target, page);
        return true;
    }

    private boolean items(CommandSender sender, String[] args) {
        Player player = player(sender); if (player == null) return true;
        int page = args.length == 0 ? 0 : Math.max(0, integer(args[0], 1) - 1);
        plugin.menus().openItems(player, page);
        return true;
    }

    private boolean achievements(CommandSender sender, String[] args) {
        Player viewer = player(sender); if (viewer == null) return true;
        Player target = viewer;
        int pageArgument = 0;
        if (args.length > 0 && !args[0].matches("\\d+")) {
            if (!sender.hasPermission("incogrpg.inspect")) { messages.send(sender, "no-permission"); return true; }
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[0])); return true; }
            pageArgument = 1;
        }
        int page = args.length > pageArgument ? Math.max(0, integer(args[pageArgument], 1) - 1) : 0;
        plugin.menus().openAchievements(viewer, target, page);
        return true;
    }

    private boolean pets(CommandSender sender, String[] args) {
        Player player = player(sender); if (player == null) return true;
        if (!sender.hasPermission("incogrpg.pets")) { messages.send(sender, "no-permission"); return true; }
        String skill = "all";
        int pageArgument = 0;
        if (args.length > 0 && !args[0].matches("\\d+")) {
            skill = normalize(args[0]);
            if (!skill.equals("all") && !plugin.configs().get().skills().containsKey(skill)) {
                messages.send(sender, "unknown-skill", Map.of("skill", args[0])); return true;
            }
            pageArgument = 1;
        }
        int page = args.length > pageArgument ? Math.max(0, integer(args[pageArgument], 1) - 1) : 0;
        plugin.menus().openPets(player, skill, page);
        return true;
    }

    private boolean pet(CommandSender sender, String[] args) {
        Player player = player(sender); if (player == null) return true;
        if (!sender.hasPermission("incogrpg.pets")) { messages.send(sender, "no-permission"); return true; }
        if (args.length == 0) { plugin.menus().openPets(player, "all", 0); return true; }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "dismiss", "remove", "unsummon" -> plugin.pets().dismiss(player);
            case "summon" -> {
                if (args.length < 2) { sender.sendMessage(messages.raw("<yellow>/pet summon <pet-id>")); return true; }
                var result = plugin.pets().summon(player, args[1]);
                if (result == com.incogdev.incogrpg.service.PetService.SummonResult.DISABLED) messages.send(sender, "pets-disabled");
                if (result == com.incogdev.incogrpg.service.PetService.SummonResult.UNKNOWN) messages.send(sender, "unknown-pet", Map.of("pet", args[1]));
                if (result == com.incogdev.incogrpg.service.PetService.SummonResult.LOCKED) messages.send(sender, "pet-locked-simple", Map.of("pet", args[1]));
            }
            case "info" -> {
                PlayerProfile profile = plugin.data().getOrCreate(player.getUniqueId(), player.getName());
                PetDefinition definition = plugin.pets().active(player).orElse(null);
                if (definition == null) messages.send(sender, "pet-none-active");
                else {
                    PetProgress progress = profile.petProgress(definition.id());
                    sender.sendMessage(messages.raw("<gradient:#F9A8D4:#A78BFA><bold>" + definition.displayName() + "</bold></gradient>"));
                    sender.sendMessage(messages.raw("<gray>Pet level <white>" + progress.level() + "</white><dark_gray>/</dark_gray><gray>" + definition.maxLevel()
                            + " <dark_gray>•</dark_gray> <gray>XP <white>" + number(progress.xp())));
                }
            }
            default -> sender.sendMessage(messages.raw("<yellow>/pet <summon <id>|dismiss|info>"));
        }
        return true;
    }

    private boolean accessories(CommandSender sender) {
        Player player = player(sender); if (player == null) return true;
        if (!sender.hasPermission("incogrpg.accessories")) { messages.send(sender, "no-permission"); return true; }
        if (!plugin.accessories().enabled()) { messages.send(sender, "accessories-disabled"); return true; }
        plugin.menus().openAccessories(player);
        return true;
    }

    private boolean reforge(CommandSender sender) {
        Player player = player(sender); if (player == null) return true;
        if (!sender.hasPermission("incogrpg.reforge")) { messages.send(sender, "no-permission"); return true; }
        if (!plugin.configs().get().reforgeSettings().enabled()) { sender.sendMessage(messages.raw("<red>The reforge station is disabled.")); return true; }
        plugin.menus().openReforge(player); return true;
    }

    private boolean menus(CommandSender sender) {
        Player player = player(sender); if (player == null) return true;
        if (!sender.hasPermission("incogutils.menus")) { messages.send(sender, "no-permission"); return true; }
        plugin.menus().openMenuHub(player);
        return true;
    }

    private boolean settings(CommandSender sender, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("admin")) return adminSettings(sender);
        Player player = player(sender); if (player == null) return true;
        if (!sender.hasPermission("incogutils.settings")) { messages.send(sender, "no-permission"); return true; }
        plugin.menus().openPlayerSettings(player);
        return true;
    }

    private boolean adminSettings(CommandSender sender) {
        Player player = player(sender); if (player == null) return true;
        if (!sender.hasPermission("incogutils.settings.admin")) { messages.send(sender, "no-permission"); return true; }
        plugin.menus().openAdminSettings(player);
        return true;
    }

    private boolean admin(CommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) { help(sender); return true; }
        return switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> reload(sender);
            case "save" -> save(sender);
            case "skill" -> adminSkill(sender, Arrays.copyOfRange(args, 1, args.length));
            case "enchant" -> adminEnchant(sender, Arrays.copyOfRange(args, 1, args.length));
            case "reforge" -> adminReforge(sender, Arrays.copyOfRange(args, 1, args.length));
            case "item" -> adminItem(sender, Arrays.copyOfRange(args, 1, args.length));
            case "achievement", "advancement" -> adminAchievement(sender, Arrays.copyOfRange(args, 1, args.length));
            case "pet", "pets" -> adminPet(sender, Arrays.copyOfRange(args, 1, args.length));
            case "stats" -> adminStats(sender, Arrays.copyOfRange(args, 1, args.length));
            case "debug" -> debug(sender);
            default -> { help(sender); yield true; }
        };
    }

    private boolean reload(CommandSender sender) {
        if (!permission(sender, "incogrpg.admin.reload")) return true;
        var result = plugin.configs().reload();
        if (result.success()) {
            int recipes = plugin.customItems().reloadRecipes();
            plugin.stats().resetAttributeCircuitBreaker();
            Bukkit.getOnlinePlayers().forEach(plugin.stats()::recompute);
            Bukkit.getOnlinePlayers().forEach(plugin.pets()::bootstrap);
            plugin.reloadModules();
            messages.send(sender, "reload-success", Map.of("skills", result.skills(), "enchants", result.enchants(),
                    "reforges", result.reforges(), "items", result.items(), "achievements", result.achievements(),
                    "pets", result.pets(), "recipes", recipes, "time", result.elapsedMs()));
        } else messages.send(sender, "reload-failed");
        return true;
    }

    private boolean save(CommandSender sender) {
        if (!permission(sender, "incogrpg.admin.save")) return true;
        plugin.data().saveAll(true); messages.send(sender, "save-started"); return true;
    }

    private boolean adminSkill(CommandSender sender, String[] args) {
        if (!permission(sender, "incogrpg.admin.skills")) return true;
        if (args.length < 2) { skillUsage(sender); return true; }
        String action = args[0].toLowerCase(Locale.ROOT);
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[1])); return true; }
        PlayerProfile profile = plugin.data().getOrCreate(target.getUniqueId(), target.getName());
        switch (action) {
            case "get", "info" -> showSkillProgress(sender, target, profile, args.length > 2 ? args[2] : "all");
            case "reset" -> {
                if (args.length < 3 || args[2].equalsIgnoreCase("all")) {
                    profile.reset();
                    finishBulkSkillEdit(sender, target, profile, "Reset every skill");
                } else {
                    SkillDefinition def = skill(sender, args[2]); if (def == null) return true;
                    plugin.skills().setProgress(profile, def.id(), 0, 0);
                    finishSkillEdit(sender, target, profile, def, "Reset");
                }
            }
            case "max" -> {
                if (args.length < 3 || args[2].equalsIgnoreCase("all")) {
                    plugin.configs().get().skills().values().stream().filter(SkillDefinition::enabled)
                            .forEach(def -> plugin.skills().setProgress(profile, def.id(), def.maxLevel(), 0));
                    finishBulkSkillEdit(sender, target, profile, "Maxed every enabled skill");
                } else {
                    SkillDefinition def = skill(sender, args[2]); if (def == null) return true;
                    plugin.skills().setProgress(profile, def.id(), def.maxLevel(), 0);
                    finishSkillEdit(sender, target, profile, def, "Maxed");
                }
            }
            case "set", "setlevel" -> {
                if (args.length < 4) { skillUsage(sender); return true; }
                SkillDefinition def = skill(sender, args[2]); if (def == null) return true;
                SkillProgress current = profile.progress(def.id());
                int level = integer(args[3], current.level());
                double xp = action.equals("set") ? (args.length > 4 ? decimal(args[4], 0) : 0) : current.xp();
                plugin.skills().setProgress(profile, def.id(), level, xp);
                finishSkillEdit(sender, target, profile, def, "Set level");
            }
            case "setxp" -> {
                if (args.length < 4) { skillUsage(sender); return true; }
                SkillDefinition def = skill(sender, args[2]); if (def == null) return true;
                SkillProgress current = profile.progress(def.id());
                plugin.skills().setProgress(profile, def.id(), current.level(), decimal(args[3], current.xp()));
                finishSkillEdit(sender, target, profile, def, "Set current XP");
            }
            case "settotalxp" -> {
                if (args.length < 4) { skillUsage(sender); return true; }
                SkillDefinition def = skill(sender, args[2]); if (def == null) return true;
                plugin.skills().setTotalXp(profile, def.id(), decimal(args[3], 0));
                finishSkillEdit(sender, target, profile, def, "Set total XP");
            }
            case "addxp" -> {
                if (args.length < 4) { skillUsage(sender); return true; }
                SkillDefinition def = skill(sender, args[2]); if (def == null) return true;
                double amount = Math.max(0, decimal(args[3], 0));
                plugin.skills().addXp(target, def.id(), "ADMIN", amount);
                finishSkillEdit(sender, target, profile, def, "Granted " + number(amount) + " XP");
            }
            case "removexp" -> {
                if (args.length < 4) { skillUsage(sender); return true; }
                SkillDefinition def = skill(sender, args[2]); if (def == null) return true;
                double currentTotal = com.incogdev.incogrpg.service.SkillService.totalXp(def, profile.progress(def.id()));
                plugin.skills().setTotalXp(profile, def.id(), currentTotal - Math.max(0, decimal(args[3], 0)));
                finishSkillEdit(sender, target, profile, def, "Removed XP");
            }
            case "addlevels" -> {
                if (args.length < 4) { skillUsage(sender); return true; }
                SkillDefinition def = skill(sender, args[2]); if (def == null) return true;
                SkillProgress current = profile.progress(def.id());
                plugin.skills().setProgress(profile, def.id(), current.level() + integer(args[3], 0), current.xp());
                finishSkillEdit(sender, target, profile, def, "Adjusted levels");
            }
            default -> skillUsage(sender);
        }
        return true;
    }

    private SkillDefinition skill(CommandSender sender, String id) {
        SkillDefinition definition = plugin.skills().definition(id).orElse(null);
        if (definition == null) messages.send(sender, "unknown-skill", Map.of("skill", id));
        return definition;
    }

    private void showSkillProgress(CommandSender sender, Player target, PlayerProfile profile, String requestedSkill) {
        if (!requestedSkill.equalsIgnoreCase("all")) {
            SkillDefinition definition = skill(sender, requestedSkill); if (definition == null) return;
            sendSkillProgress(sender, target, profile, definition);
            return;
        }
        sender.sendMessage(messages.raw("<gradient:#22D3EE:#A78BFA><bold>" + target.getName() + "'s Skill Progress</bold></gradient>"));
        plugin.configs().get().skills().values().stream().filter(SkillDefinition::enabled)
                .forEach(definition -> sendSkillProgress(sender, target, profile, definition));
    }

    private void sendSkillProgress(CommandSender sender, Player target, PlayerProfile profile, SkillDefinition definition) {
        SkillProgress progress = profile.progress(definition.id());
        String required = progress.level() >= definition.maxLevel() ? "MAX" : number(definition.xpRequired(progress.level()));
        messages.send(sender, "admin-skill-progress", Map.of("player", target.getName(), "skill", definition.displayName(),
                "level", progress.level(), "max_level", definition.maxLevel(), "xp", number(progress.xp()), "required", required,
                "total_xp", number(com.incogdev.incogrpg.service.SkillService.totalXp(definition, progress))));
    }

    private void finishSkillEdit(CommandSender sender, Player target, PlayerProfile profile,
                                 SkillDefinition definition, String action) {
        plugin.stats().recompute(target);
        plugin.achievements().bootstrap(target);
        plugin.pets().refreshUnlocks(target, false);
        plugin.data().saveAsync(profile, false);
        SkillProgress progress = profile.progress(definition.id());
        String required = progress.level() >= definition.maxLevel() ? "MAX" : number(definition.xpRequired(progress.level()));
        messages.send(sender, "admin-skill-updated", Map.of("action", action, "player", target.getName(),
                "skill", definition.displayName(), "level", progress.level(), "max_level", definition.maxLevel(),
                "xp", number(progress.xp()), "required", required,
                "total_xp", number(com.incogdev.incogrpg.service.SkillService.totalXp(definition, progress))));
    }

    private void finishBulkSkillEdit(CommandSender sender, Player target, PlayerProfile profile, String action) {
        plugin.stats().recompute(target);
        plugin.achievements().bootstrap(target);
        plugin.pets().refreshUnlocks(target, false);
        plugin.data().saveAsync(profile, false);
        messages.send(sender, "admin-skills-bulk-updated", Map.of("action", action, "player", target.getName(),
                "total_level", profile.totalLevels()));
    }

    private void skillUsage(CommandSender sender) {
        sender.sendMessage(messages.raw("<gradient:#22D3EE:#A78BFA><bold>Skill Administration</bold></gradient>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill get <player> [skill|all]"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill setlevel <player> <skill> <level>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill setxp <player> <skill> <current-xp>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill settotalxp <player> <skill> <total-xp>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill addxp <player> <skill> <amount>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill removexp <player> <skill> <amount>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill addlevels <player> <skill> <amount>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill max <player> [skill|all]"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill reset <player> [skill|all]"));
        sender.sendMessage(messages.raw("<dark_gray>Legacy: /incogrpg skill set <player> <skill> <level> [xp]"));
    }

    private boolean adminEnchant(CommandSender sender, String[] args) {
        if (!permission(sender, "incogrpg.admin.enchants")) return true;
        Player player = player(sender); if (player == null) return true;
        if (args.length == 0) { sender.sendMessage(messages.raw("<yellow>/incogrpg enchant <apply|remove|clear|book> ...")); return true; }
        ItemStack held = player.getInventory().getItemInMainHand();
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "clear" -> { if (held.getType().isAir()) messages.send(sender, "hold-item"); else { plugin.enchants().clear(held); messages.send(sender, "enchant-cleared"); plugin.stats().recompute(player); } }
            case "remove" -> {
                if (args.length < 2) return adminEnchant(sender, new String[0]);
                EnchantDefinition def = plugin.configs().get().enchants().get(normalize(args[1]));
                if (def == null) messages.send(sender, "unknown-enchant", Map.of("enchant", args[1]));
                else if (plugin.enchants().remove(held, def.id())) { messages.send(sender, "enchant-removed", Map.of("enchant", def.displayName())); plugin.stats().recompute(player); }
            }
            case "apply" -> {
                if (args.length < 2) return adminEnchant(sender, new String[0]);
                EnchantDefinition def = plugin.configs().get().enchants().get(normalize(args[1]));
                if (def == null) { messages.send(sender, "unknown-enchant", Map.of("enchant", args[1])); return true; }
                int level = args.length > 2 ? integer(args[2], 1) : 1;
                var result = plugin.enchants().apply(held, def, level, false);
                if (result == EnchantService.ApplyResult.SUCCESS) { messages.send(sender, "enchant-applied", Map.of("enchant", def.displayName(), "level", level)); plugin.stats().recompute(player); }
                else sendEnchantError(sender, result, def);
            }
            case "book" -> {
                if (args.length < 2) return adminEnchant(sender, new String[0]);
                EnchantDefinition def = plugin.configs().get().enchants().get(normalize(args[1]));
                if (def == null) { messages.send(sender, "unknown-enchant", Map.of("enchant", args[1])); return true; }
                int level = args.length > 2 ? Math.max(1, Math.min(def.maxLevel(), integer(args[2], 1))) : 1;
                Player target = args.length > 3 ? Bukkit.getPlayerExact(args[3]) : player;
                if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[3])); return true; }
                target.getInventory().addItem(plugin.enchants().book(def, level));
                messages.send(sender, "enchant-book-given", Map.of("player", target.getName(), "enchant", def.displayName(), "level", level));
            }
            default -> sender.sendMessage(messages.raw("<yellow>/incogrpg enchant <apply|remove|clear|book> ..."));
        }
        return true;
    }

    private boolean adminReforge(CommandSender sender, String[] args) {
        if (!permission(sender, "incogrpg.admin.reforges")) return true;
        if (args.length == 0) { reforgeUsage(sender); return true; }
        String action = args[0].toLowerCase(Locale.ROOT);
        if (action.equals("list")) { listReforges(sender, args.length > 1 ? integer(args[1], 1) : 1); return true; }
        if (action.equals("stone")) return giveReforgeStone(sender, args);

        if (Set.of("setfor", "applyfor", "forcefor", "removefrom", "getfrom", "inspectfrom").contains(action)) {
            if (args.length < 3) { reforgeUsage(sender); return true; }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[1])); return true; }
            String slot = normalizeReforgeSlot(args[2]);
            if (slot == null) { unknownReforgeSlot(sender, args[2]); return true; }
            ItemStack item = reforgeSlot(target.getInventory(), slot);
            if (empty(item)) { sender.sendMessage(messages.raw("<red>" + target.getName() + " has no item in " + slot + ".")); return true; }
            if (action.equals("removefrom")) return removeReforge(sender, target, item, slot);
            if (action.equals("getfrom") || action.equals("inspectfrom")) return inspectReforge(sender, target, item, slot);
            if (args.length < 4) { reforgeUsage(sender); return true; }
            boolean force = action.equals("forcefor") || (args.length > 4 && args[4].equalsIgnoreCase("force"));
            return setReforge(sender, target, item, slot, args[3], force);
        }

        Player target = player(sender); if (target == null) return true;
        ItemStack held = target.getInventory().getItemInMainHand();
        if (empty(held)) { messages.send(sender, "hold-item"); return true; }
        return switch (action) {
            case "remove", "clear" -> removeReforge(sender, target, held, "mainhand");
            case "get", "inspect", "info" -> inspectReforge(sender, target, held, "mainhand");
            case "set", "apply", "forceapply" -> {
                if (args.length < 2) { reforgeUsage(sender); yield true; }
                boolean force = action.equals("forceapply") || (args.length > 2 && args[2].equalsIgnoreCase("force"));
                yield setReforge(sender, target, held, "mainhand", args[1], force);
            }
            default -> { reforgeUsage(sender); yield true; }
        };
    }

    private boolean setReforge(CommandSender sender, Player target, ItemStack item, String slot,
                               String requested, boolean force) {
        ReforgeDefinition definition = plugin.configs().get().reforges().get(normalize(requested));
        if (definition == null) { sender.sendMessage(messages.raw("<red>Unknown reforge <white>" + requested + "</white>.")); return true; }
        if (force && !plugin.configs().get().reforgeSettings().allowAdminForceApply()) {
            sender.sendMessage(messages.raw("<red>Forced reforge application is disabled in reforges.yml."));
            return true;
        }
        if (!plugin.reforges().apply(item, definition, force)) {
            sender.sendMessage(messages.raw("<red>" + definition.displayName() + " <red>is incompatible with that item. Add <white>force</white> to bypass item groups."));
            return true;
        }
        plugin.stats().recompute(target);
        sender.sendMessage(messages.raw("<green>Set " + definition.displayName() + " <green>on <white>" + target.getName()
                + "</white>'s <white>" + slot + "</white> item" + (force ? " <yellow>(forced)</yellow>" : "") + "."));
        return true;
    }

    private boolean removeReforge(CommandSender sender, Player target, ItemStack item, String slot) {
        if (!plugin.reforges().remove(item)) {
            sender.sendMessage(messages.raw("<yellow>That item does not have an IncogRPG reforge."));
            return true;
        }
        plugin.stats().recompute(target);
        sender.sendMessage(messages.raw("<green>Removed the reforge from <white>" + target.getName()
                + "</white>'s <white>" + slot + "</white> item."));
        return true;
    }

    private boolean inspectReforge(CommandSender sender, Player target, ItemStack item, String slot) {
        ReforgeDefinition definition = plugin.reforges().get(item).orElse(null);
        if (definition == null) {
            sender.sendMessage(messages.raw("<yellow>" + target.getName() + "'s " + slot + " item has no IncogRPG reforge."));
            return true;
        }
        String acquisition = reforgeAcquisition(definition);
        sender.sendMessage(messages.raw("<gradient:#FDE047:#A78BFA><bold>Reforge Inspection</bold></gradient>"));
        sender.sendMessage(messages.raw("<gray>Owner/slot: <white>" + target.getName() + " / " + slot));
        sender.sendMessage(messages.raw("<gray>ID: <white>" + definition.id() + " <dark_gray>•</dark_gray> <gray>Name: " + definition.displayName()));
        sender.sendMessage(messages.raw("<gray>Rarity: <white>" + definition.rarity() + " <dark_gray>•</dark_gray> <gray>Obtain: <white>" + acquisition));
        definition.stats().forEach((stat, amount) -> sender.sendMessage(messages.raw(
                "<dark_gray>  •</dark_gray> <gray>" + stat + " <white>" + (amount >= 0 ? "+" : "") + number(amount))));
        return true;
    }

    private boolean giveReforgeStone(CommandSender sender, String[] args) {
        if (args.length < 3) { reforgeUsage(sender); return true; }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[1])); return true; }
        ReforgeDefinition definition = plugin.configs().get().reforges().get(normalize(args[2]));
        if (definition == null) { sender.sendMessage(messages.raw("<red>Unknown reforge.")); return true; }
        CustomItemDefinition stone = reforgeStone(definition);
        if (stone == null) {
            sender.sendMessage(messages.raw("<yellow>" + definition.displayName() + " <yellow>has no configured reforge stone; it is obtained from station rolls."));
            return true;
        }
        int amount = args.length > 3 ? Math.max(1, integer(args[3], 1)) : 1;
        plugin.customItems().give(target, stone, amount);
        sender.sendMessage(messages.raw("<green>Gave <white>" + amount + "x</white> " + stone.displayName()
                + " <green>to <white>" + target.getName() + "</white>."));
        return true;
    }

    private void listReforges(CommandSender sender, int requestedPage) {
        List<ReforgeDefinition> definitions = new ArrayList<>(plugin.configs().get().reforges().values());
        int perPage = 8;
        int pages = Math.max(1, (int) Math.ceil(definitions.size() / (double) perPage));
        int page = Math.max(1, Math.min(pages, requestedPage));
        sender.sendMessage(messages.raw("<gradient:#FDE047:#A78BFA><bold>Reforges " + page + "/" + pages + "</bold></gradient>"));
        for (int i = (page - 1) * perPage; i < Math.min(definitions.size(), page * perPage); i++) {
            ReforgeDefinition definition = definitions.get(i);
            sender.sendMessage(messages.raw("<gray>• <white>" + definition.id() + "</white> " + definition.displayName()
                    + " <dark_gray>[" + definition.rarity() + "]</dark_gray> <gray>— <white>" + reforgeAcquisition(definition)));
        }
        sender.sendMessage(messages.raw("<dark_gray>Use /incogrpg reforge list " + Math.min(pages, page + 1) + " for the next page."));
    }

    private String reforgeAcquisition(ReforgeDefinition definition) {
        CustomItemDefinition stone = reforgeStone(definition);
        if (!definition.rollEnabled() && stone != null)
            return "anvil + " + stone.displayName().replaceAll("<[^>]+>", "");
        return "random /reforge station roll";
    }

    private CustomItemDefinition reforgeStone(ReforgeDefinition definition) {
        return plugin.configs().get().items().values().stream()
                .filter(CustomItemDefinition::enabled)
                .filter(item -> item.appliesReforge().equals(definition.id()))
                .findFirst().orElse(null);
    }

    private ItemStack reforgeSlot(PlayerInventory inventory, String slot) {
        return switch (slot) {
            case "mainhand" -> inventory.getItemInMainHand();
            case "offhand" -> inventory.getItemInOffHand();
            case "helmet" -> inventory.getHelmet();
            case "chestplate" -> inventory.getChestplate();
            case "leggings" -> inventory.getLeggings();
            case "boots" -> inventory.getBoots();
            default -> null;
        };
    }

    private static String normalizeReforgeSlot(String raw) {
        return switch (normalize(raw)) {
            case "hand", "main", "main_hand", "mainhand" -> "mainhand";
            case "off", "off_hand", "offhand" -> "offhand";
            case "head", "helm", "helmet" -> "helmet";
            case "chest", "body", "chestplate" -> "chestplate";
            case "legs", "leggings" -> "leggings";
            case "feet", "boot", "boots" -> "boots";
            default -> null;
        };
    }

    private void unknownReforgeSlot(CommandSender sender, String slot) {
        sender.sendMessage(messages.raw("<red>Unknown equipment slot <white>" + slot
                + "</white>. Use mainhand, offhand, helmet, chestplate, leggings, or boots."));
    }

    private void reforgeUsage(CommandSender sender) {
        sender.sendMessage(messages.raw("<gradient:#FDE047:#A78BFA><bold>Reforge Administration</bold></gradient>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg reforge set <id> [force] <dark_gray>— held item"));
        sender.sendMessage(messages.raw("<gray>/incogrpg reforge remove|get <dark_gray>— held item"));
        sender.sendMessage(messages.raw("<gray>/incogrpg reforge setfor <player> <slot> <id> [force]"));
        sender.sendMessage(messages.raw("<gray>/incogrpg reforge removefrom|getfrom <player> <slot>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg reforge stone <player> <reforge> [amount]"));
        sender.sendMessage(messages.raw("<gray>/incogrpg reforge list [page]"));
    }

    private static boolean empty(ItemStack item) { return item == null || item.getType().isAir(); }

    private boolean adminItem(CommandSender sender, String[] args) {
        if (!permission(sender, "incogrpg.admin.items")) return true;
        if (args.length == 0) {
            sender.sendMessage(messages.raw("<yellow>/incogrpg item <give|refresh> ..."));
            return true;
        }
        if (args[0].equalsIgnoreCase("give")) {
            if (args.length < 3) {
                sender.sendMessage(messages.raw("<yellow>/incogrpg item give <player> <item> [amount]"));
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[1])); return true; }
            CustomItemDefinition definition = plugin.customItems().definition(args[2]).orElse(null);
            if (definition == null) { messages.send(sender, "unknown-item", Map.of("item", args[2])); return true; }
            int amount = args.length > 3 ? Math.max(1, integer(args[3], 1)) : 1;
            plugin.customItems().give(target, definition, amount);
            plugin.stats().recompute(target);
            messages.send(sender, "item-given", Map.of("amount", amount, "item", definition.displayName(), "player", target.getName()));
            return true;
        }
        if (args[0].equalsIgnoreCase("refresh")) {
            Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : sender instanceof Player p ? p : null;
            if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args.length > 1 ? args[1] : "")); return true; }
            ItemStack held = target.getInventory().getItemInMainHand();
            CustomItemDefinition definition = plugin.customItems().definition(held).orElse(null);
            if (definition == null) { messages.send(sender, "not-custom-item"); return true; }
            plugin.customItems().refresh(held);
            plugin.stats().recompute(target);
            messages.send(sender, "item-refreshed", Map.of("item", definition.displayName(), "player", target.getName()));
            return true;
        }
        sender.sendMessage(messages.raw("<yellow>/incogrpg item <give|refresh> ..."));
        return true;
    }

    private boolean adminStats(CommandSender sender, String[] args) {
        if (!permission(sender, "incogrpg.admin.debug")) return true;
        Player target = args.length > 0 ? Bukkit.getPlayerExact(args[0]) : sender instanceof Player p ? p : null;
        if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args.length > 0 ? args[0] : "")); return true; }
        sender.sendMessage(messages.raw("<gradient:#22D3EE:#A78BFA><bold>" + target.getName() + "'s Stats</bold></gradient>"));
        plugin.stats().recompute(target).values().entrySet().stream().filter(e -> Math.abs(e.getValue()) > 0.0001).sorted(Map.Entry.comparingByKey())
                .forEach(entry -> sender.sendMessage(messages.raw("<gray>• " + entry.getKey() + ": <white>" + entry.getValue())));
        return true;
    }

    private boolean adminAchievement(CommandSender sender, String[] args) {
        if (!permission(sender, "incogrpg.admin.achievements")) return true;
        if (args.length < 2) { achievementUsage(sender); return true; }
        String action = args[0].toLowerCase(Locale.ROOT);
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[1])); return true; }
        PlayerProfile profile = plugin.data().getOrCreate(target.getUniqueId(), target.getName());
        switch (action) {
            case "get", "info" -> {
                String requested = args.length > 2 ? normalize(args[2]) : "all";
                sender.sendMessage(messages.raw("<gradient:#FDE047:#F97316><bold>" + target.getName() + "'s Achievements</bold></gradient>"));
                plugin.configs().get().achievements().values().stream()
                        .filter(def -> requested.equals("all") || def.id().equals(requested))
                        .forEach(def -> sender.sendMessage(messages.raw((profile.achievementCompleted(def.id()) ? "<green>✓ " : "<gray>○ ") +
                                def.displayName() + " <dark_gray>•</dark_gray> <white>" + number(plugin.achievements().completionRatio(profile, def) * 100) + "%")));
            }
            case "grant" -> {
                if (args.length < 3) { achievementUsage(sender); return true; }
                boolean rewards = args.length < 4 || Boolean.parseBoolean(args[3]);
                if (plugin.achievements().grant(target, args[2], rewards))
                    messages.send(sender, "achievement-admin-granted", Map.of("player", target.getName(), "achievement", args[2], "rewards", rewards));
                else messages.send(sender, "achievement-admin-unchanged");
            }
            case "revoke" -> {
                if (args.length < 3) { achievementUsage(sender); return true; }
                if (plugin.achievements().revoke(target, args[2]))
                    messages.send(sender, "achievement-admin-revoked", Map.of("player", target.getName(), "achievement", args[2]));
                else messages.send(sender, "achievement-admin-unchanged");
            }
            case "reset" -> {
                plugin.achievements().reset(target);
                messages.send(sender, "achievement-admin-reset", Map.of("player", target.getName()));
            }
            case "setprogress", "addprogress" -> {
                if (args.length < 5) { achievementUsage(sender); return true; }
                String metric = args[2]; String metricTarget = args[3]; double value = Math.max(0, decimal(args[4], 0));
                if (action.equals("addprogress")) plugin.achievements().add(target, metric, metricTarget, value);
                else plugin.achievements().set(target, metric, metricTarget, value);
                messages.send(sender, "achievement-admin-progress", Map.of("player", target.getName(), "metric", metric,
                        "target", metricTarget, "value", number(value)));
            }
            case "check" -> {
                plugin.achievements().bootstrap(target);
                messages.send(sender, "achievement-admin-checked", Map.of("player", target.getName()));
            }
            default -> achievementUsage(sender);
        }
        plugin.data().saveAsync(profile, false);
        return true;
    }

    private void achievementUsage(CommandSender sender) {
        sender.sendMessage(messages.raw("<gradient:#FDE047:#F97316><bold>Achievement Administration</bold></gradient>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg achievement get <player> [achievement|all]"));
        sender.sendMessage(messages.raw("<gray>/incogrpg achievement grant <player> <achievement> [give-rewards:true|false]"));
        sender.sendMessage(messages.raw("<gray>/incogrpg achievement revoke <player> <achievement>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg achievement reset <player>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg achievement setprogress <player> <metric> <target> <value>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg achievement addprogress <player> <metric> <target> <value>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg achievement check <player>"));
    }

    private boolean adminPet(CommandSender sender, String[] args) {
        if (!permission(sender, "incogrpg.admin.pets")) return true;
        if (args.length < 2) { petUsage(sender); return true; }
        String action = args[0].toLowerCase(Locale.ROOT);
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) { messages.send(sender, "player-not-found", Map.of("player", args[1])); return true; }
        PlayerProfile profile = plugin.data().getOrCreate(target.getUniqueId(), target.getName());
        if (action.equals("dismiss")) {
            plugin.pets().dismiss(target);
            messages.send(sender, "pet-admin-updated", Map.of("action", "Dismissed active pet", "player", target.getName()));
            return true;
        }
        if (args.length < 3) { petUsage(sender); return true; }
        String id = normalize(args[2]);
        PetDefinition definition = plugin.pets().definition(id).orElse(null);
        if (!id.equals("all") && definition == null) { messages.send(sender, "unknown-pet", Map.of("pet", args[2])); return true; }
        switch (action) {
            case "get", "info" -> {
                if (definition == null) { petUsage(sender); return true; }
                PetProgress progress = profile.petProgress(definition.id());
                sender.sendMessage(messages.raw((profile.petUnlocked(definition.id()) ? "<green>Unlocked " : "<red>Locked ")
                        + definition.displayName() + " <dark_gray>•</dark_gray> <gray>Level <white>" + progress.level()
                        + "</white><dark_gray>/</dark_gray><gray>" + definition.maxLevel() + " <dark_gray>•</dark_gray> <gray>XP <white>" + number(progress.xp())));
            }
            case "unlock" -> {
                if (id.equals("all")) plugin.configs().get().pets().keySet().forEach(petId -> plugin.pets().unlock(target, petId));
                else plugin.pets().unlock(target, id);
                messages.send(sender, "pet-admin-updated", Map.of("action", "Unlocked " + id, "player", target.getName()));
            }
            case "lock" -> {
                if (id.equals("all")) plugin.configs().get().pets().keySet().forEach(petId -> plugin.pets().lock(target, petId));
                else plugin.pets().lock(target, id);
                messages.send(sender, "pet-admin-updated", Map.of("action", "Locked " + id, "player", target.getName()));
            }
            case "summon" -> {
                if (id.equals("all")) { petUsage(sender); return true; }
                plugin.pets().unlock(target, id);
                var result = plugin.pets().summon(target, id);
                if (result == com.incogdev.incogrpg.service.PetService.SummonResult.SUCCESS)
                    messages.send(sender, "pet-admin-updated", Map.of("action", "Summoned " + id, "player", target.getName()));
                else if (result == com.incogdev.incogrpg.service.PetService.SummonResult.DISABLED)
                    messages.send(sender, "pets-disabled");
                else messages.send(sender, "unknown-pet", Map.of("pet", id));
            }
            case "setlevel", "setxp" -> {
                if (definition == null || args.length < 4) { petUsage(sender); return true; }
                PetProgress current = profile.petProgress(id);
                int level = action.equals("setlevel") ? integer(args[3], current.level()) : current.level();
                double xp = action.equals("setxp") ? decimal(args[3], current.xp()) : current.xp();
                plugin.pets().setProgress(target, id, level, xp);
                messages.send(sender, "pet-admin-updated", Map.of("action", action + " " + id, "player", target.getName()));
            }
            default -> petUsage(sender);
        }
        plugin.stats().recompute(target);
        plugin.data().saveAsync(profile, false);
        return true;
    }

    private void petUsage(CommandSender sender) {
        sender.sendMessage(messages.raw("<gradient:#F9A8D4:#A78BFA><bold>Pet Administration</bold></gradient>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg pet get <player> <pet>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg pet unlock|lock <player> <pet|all>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg pet summon|dismiss <player> [pet]"));
        sender.sendMessage(messages.raw("<gray>/incogrpg pet setlevel|setxp <player> <pet> <value>"));
    }

    private boolean debug(CommandSender sender) {
        if (!permission(sender, "incogrpg.admin.debug")) return true;
        sender.sendMessage(messages.raw("<gray>Skills: <white>" + plugin.configs().get().skills().size() + " <gray>Enchants: <white>" + plugin.configs().get().enchants().size()
                + " <gray>Reforges: <white>" + plugin.configs().get().reforges().size() + " <gray>Items: <white>" + plugin.configs().get().items().size()
                + " <gray>Achievements: <white>" + plugin.configs().get().achievements().size()
                + " <gray>Pets: <white>" + plugin.configs().get().pets().size()
                + " <gray>Loaded profiles: <white>" + plugin.data().loadedProfiles().size()));
        return true;
    }

    private void help(CommandSender sender) {
        sender.sendMessage(messages.raw("<gradient:#7C3AED:#22D3EE><bold>IncogRPG Admin</bold></gradient>"));
        sender.sendMessage(messages.raw("<gray>/incogrpg reload <dark_gray>• <white>Reload every YAML file"));
        sender.sendMessage(messages.raw("<gray>/incogrpg skill <get|setlevel|setxp|settotalxp|addxp|removexp|addlevels|max|reset> ..."));
        sender.sendMessage(messages.raw("<gray>/incogrpg enchant <apply|remove|clear|book> ..."));
        sender.sendMessage(messages.raw("<gray>/incogrpg reforge <set|setfor|remove|removefrom|get|getfrom|stone|list> ..."));
        sender.sendMessage(messages.raw("<gray>/incogrpg item <give|refresh> ..."));
        sender.sendMessage(messages.raw("<gray>/incogrpg achievement <get|grant|revoke|reset|setprogress|addprogress|check> ..."));
        sender.sendMessage(messages.raw("<gray>/incogrpg pet <get|unlock|lock|summon|dismiss|setlevel|setxp> ..."));
        sender.sendMessage(messages.raw("<gray>/incogrpg stats [player] <dark_gray>• <white>Inspect calculated stats"));
        sender.sendMessage(messages.raw("<gray>/incogrpg save <dark_gray>• <white>Save all profiles"));
    }

    private void sendEnchantError(CommandSender sender, EnchantService.ApplyResult result, EnchantDefinition def) {
        switch (result) {
            case INCOMPATIBLE -> messages.send(sender, "incompatible-item");
            case INVALID_LEVEL -> messages.send(sender, "invalid-level", Map.of("max", def.maxLevel()));
            case LIMIT -> messages.send(sender, "enchant-limit", Map.of("max", plugin.configs().get().core().getInt("enchanting.max-custom-enchants-per-item", 8)));
            case CONFLICT -> messages.send(sender, "enchant-conflict", Map.of("conflict", "another enchant"));
            default -> { }
        }
    }
    private Player player(CommandSender sender) { if (sender instanceof Player p) return p; messages.send(sender, "player-only"); return null; }
    private boolean permission(CommandSender sender, String permission) { if (sender.hasPermission(permission)) return true; messages.send(sender, "no-permission"); return false; }
    private static int integer(String value, int fallback) { try { return Integer.parseInt(value); } catch (NumberFormatException ex) { return fallback; } }
    private static double decimal(String value, double fallback) { try { return Double.parseDouble(value); } catch (NumberFormatException ex) { return fallback; } }
    private static String number(double value) { return value == Math.rint(value) ? String.format(Locale.US, "%,.0f", value) : String.format(Locale.US, "%,.2f", value); }
    private static String normalize(String value) { return value.toLowerCase(Locale.ROOT).replace('-', '_'); }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String @NotNull [] args) {
        List<String> options = new ArrayList<>();
        if (command.getName().equals("skill") && args.length == 1) options.addAll(plugin.configs().get().skills().keySet());
        if (command.getName().equals("skills") && args.length == 1) Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
        if (command.getName().equals("stats") && args.length == 1) Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
        if (command.getName().equals("achievements") && args.length == 1) Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
        if (command.getName().equals("pets") && args.length == 1) { options.add("all"); options.addAll(plugin.configs().get().skills().keySet()); }
        if (command.getName().equals("pet") && args.length == 1) options.addAll(List.of("summon", "dismiss", "info"));
        if (command.getName().equals("pet") && args.length == 2 && args[0].equalsIgnoreCase("summon")) options.addAll(plugin.configs().get().pets().keySet());
        if (!command.getName().equals("incogrpg")) return filter(options, args.length == 0 ? "" : args[args.length - 1]);
        if (args.length == 1) options.addAll(List.of("reload", "save", "skill", "enchant", "reforge", "item", "achievement", "pet", "stats", "debug"));
        else if (args[0].equalsIgnoreCase("skill")) {
            if (args.length == 2) options.addAll(List.of("get", "setlevel", "setxp", "settotalxp", "addxp", "removexp", "addlevels", "max", "reset", "set"));
            if (args.length == 3) Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
            if (args.length == 4) {
                options.addAll(plugin.configs().get().skills().keySet());
                if (Set.of("get", "reset", "max").contains(args[1].toLowerCase(Locale.ROOT))) options.add("all");
            }
            if (args.length == 5 && args[1].equalsIgnoreCase("setlevel")) options.addAll(List.of("1", "25", "50", "100"));
            if (args.length == 5 && args[1].equalsIgnoreCase("addlevels")) options.addAll(List.of("1", "5", "10", "-1"));
        } else if (args[0].equalsIgnoreCase("enchant")) {
            if (args.length == 2) options.addAll(List.of("apply", "remove", "clear", "book"));
            if (args.length == 3 && !args[1].equalsIgnoreCase("clear")) options.addAll(plugin.configs().get().enchants().keySet());
        } else if (args[0].equalsIgnoreCase("reforge")) {
            if (args.length == 2) options.addAll(List.of("set", "apply", "forceapply", "remove", "get", "setfor", "forcefor", "removefrom", "getfrom", "stone", "list"));
            if (args.length == 3 && Set.of("set", "apply", "forceapply").contains(args[1].toLowerCase(Locale.ROOT)))
                options.addAll(plugin.configs().get().reforges().keySet());
            if (args.length == 3 && Set.of("setfor", "forcefor", "removefrom", "getfrom", "stone").contains(args[1].toLowerCase(Locale.ROOT)))
                Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
            if (args.length == 4 && Set.of("setfor", "forcefor", "removefrom", "getfrom").contains(args[1].toLowerCase(Locale.ROOT)))
                options.addAll(List.of("mainhand", "offhand", "helmet", "chestplate", "leggings", "boots"));
            if (args.length == 4 && args[1].equalsIgnoreCase("stone"))
                plugin.configs().get().reforges().values().stream().filter(def -> reforgeStone(def) != null).forEach(def -> options.add(def.id()));
            if (args.length == 5 && Set.of("setfor", "forcefor").contains(args[1].toLowerCase(Locale.ROOT)))
                options.addAll(plugin.configs().get().reforges().keySet());
            if ((args.length == 4 && Set.of("set", "apply", "forceapply").contains(args[1].toLowerCase(Locale.ROOT)))
                    || (args.length == 6 && Set.of("setfor", "forcefor").contains(args[1].toLowerCase(Locale.ROOT))))
                options.add("force");
            if (args.length == 5 && args[1].equalsIgnoreCase("stone")) options.addAll(List.of("1", "5", "16", "64"));
        } else if (args[0].equalsIgnoreCase("item")) {
            if (args.length == 2) options.addAll(List.of("give", "refresh"));
            if (args.length == 3) Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
            if (args.length == 4 && args[1].equalsIgnoreCase("give")) options.addAll(plugin.configs().get().items().keySet());
        } else if (args[0].equalsIgnoreCase("achievement") || args[0].equalsIgnoreCase("advancement")) {
            if (args.length == 2) options.addAll(List.of("get", "grant", "revoke", "reset", "setprogress", "addprogress", "check"));
            if (args.length == 3) Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
            if (args.length == 4 && Set.of("get", "grant", "revoke").contains(args[1].toLowerCase(Locale.ROOT))) {
                options.addAll(plugin.configs().get().achievements().keySet()); options.add("all");
            }
            if (args.length == 4 && Set.of("setprogress", "addprogress").contains(args[1].toLowerCase(Locale.ROOT)))
                options.addAll(com.incogdev.incogrpg.service.AchievementService.BUILT_IN_METRICS);
        } else if (args[0].equalsIgnoreCase("pet") || args[0].equalsIgnoreCase("pets")) {
            if (args.length == 2) options.addAll(List.of("get", "unlock", "lock", "summon", "dismiss", "setlevel", "setxp"));
            if (args.length == 3) Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
            if (args.length == 4 && !args[1].equalsIgnoreCase("dismiss")) { options.addAll(plugin.configs().get().pets().keySet()); options.add("all"); }
        } else if (args[0].equalsIgnoreCase("stats") && args.length == 2) Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
        return filter(options, args[args.length - 1]);
    }
    private static List<String> filter(Collection<String> values, String prefix) { String p = prefix.toLowerCase(Locale.ROOT); return values.stream().filter(v -> v.toLowerCase(Locale.ROOT).startsWith(p)).sorted().toList(); }
}

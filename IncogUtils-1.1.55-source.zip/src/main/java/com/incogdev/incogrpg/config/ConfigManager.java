package com.incogdev.incogrpg.config;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.model.AchievementDefinition;
import com.incogdev.incogrpg.model.EnchantDefinition;
import com.incogdev.incogrpg.model.CustomItemDefinition;
import com.incogdev.incogrpg.model.ReforgeDefinition;
import com.incogdev.incogrpg.model.SkillDefinition;
import com.incogdev.incogrpg.model.PetDefinition;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.logging.Level;

public final class ConfigManager {
    private final IncogRpgPlugin plugin;
    private volatile Snapshot snapshot;

    public ConfigManager(IncogRpgPlugin plugin) {
        this.plugin = plugin;
    }

    public synchronized ReloadResult reload() {
        long started = System.nanoTime();
        List<String> errors = new ArrayList<>();
        try {
            YamlConfiguration core = load("config.yml");
            YamlConfiguration messages = loadWithBundledDefaults("messages.yml");
            YamlConfiguration skillsFile = load("skills.yml");
            YamlConfiguration enchantsFile = load("enchants.yml");
            YamlConfiguration reforgesFile = load("reforges.yml");
            YamlConfiguration itemsFile = load("items.yml");
            YamlConfiguration relicsFile = load("relics.yml");
            YamlConfiguration achievementsFile = load("achievements.yml");
            YamlConfiguration petsFile = load("pets.yml");
            int globalCap = Math.max(1, core.getInt("progression.global-skill-cap", 100));
            Map<String, SkillDefinition> skills = parseSkills(skillsFile, globalCap, errors);
            Map<String, EnchantDefinition> enchants = parseEnchants(enchantsFile, errors);
            Map<String, ReforgeDefinition> reforges = parseReforges(reforgesFile, errors);
            Map<String, CustomItemDefinition> baseItems = parseItems(itemsFile, errors);
            Map<String, CustomItemDefinition> relicItems = parseItems(relicsFile, errors);
            Map<String, CustomItemDefinition> combinedItems = new LinkedHashMap<>(baseItems);
            relicItems.forEach((id, definition) -> {
                if (combinedItems.putIfAbsent(id, definition) != null) errors.add("Duplicate custom item/relic id " + id);
            });
            Map<String, CustomItemDefinition> items = Collections.unmodifiableMap(combinedItems);
            Map<String, AchievementDefinition> achievements = parseAchievements(achievementsFile, errors);
            Map<String, PetDefinition> pets = parsePets(petsFile, errors);
            validateReferences(skills, enchants, reforges, items, achievements, pets, errors);
            if (skills.isEmpty()) errors.add("No enabled or valid skills were loaded.");
            if (reforges.isEmpty()) errors.add("No enabled or valid reforges were loaded.");
            if (!errors.isEmpty()) {
                errors.forEach(error -> plugin.getLogger().severe("Configuration: " + error));
                return new ReloadResult(false, errors, elapsedMs(started), skills.size(), enchants.size(), reforges.size(), items.size(), achievements.size(), pets.size());
            }
            snapshot = new Snapshot(core, messages, skills, enchants, reforges, items, achievements, pets, globalCap,
                    Math.max(0, core.getInt("progression.total-level-cap", 0)),
                    new ReforgeSettings(
                            reforgesFile.getBoolean("settings.enabled", true),
                            reforgesFile.getString("settings.station-title", "<dark_gray>Reforge Anvil"),
                            reforgesFile.getString("settings.cost-type", "XP_LEVELS").toUpperCase(Locale.ROOT),
                            Math.max(0, reforgesFile.getDouble("settings.base-cost", 12)),
                            Math.max(0, reforgesFile.getDouble("settings.reroll-cost-multiplier", 1.35)),
                            reforgesFile.getBoolean("settings.allow-same-reforge", false),
                            reforgesFile.getBoolean("settings.announce-mythic-rolls", true),
                            reforgesFile.getString("settings.lore-format", "<dark_gray>Reforge: <reforge>"),
                            reforgesFile.getString("settings.name-format", "<reforge> <item>"),
                            reforgesFile.getBoolean("settings.preserve-original-name", true),
                            reforgesFile.getBoolean("settings.allow-admin-force-apply", true)
                    ), new NaturalReforgeSettings(
                            reforgesFile.getBoolean("natural-generation.enabled", true),
                            reforgesFile.getBoolean("natural-generation.preserve-existing-reforges", true),
                            reforgesFile.getBoolean("natural-generation.equipment-only", true),
                            naturalSource(reforgesFile, "natural-generation.crafting", 7.5, false),
                            naturalSource(reforgesFile, "natural-generation.mob-drops", 10.0, true),
                            naturalSource(reforgesFile, "natural-generation.chest-loot", 12.0, false)
                    ), new PetSettings(
                            petsFile.getBoolean("settings.enabled", false),
                            Math.max(1, petsFile.getInt("settings.global-level-cap", 100)),
                            Math.max(0, petsFile.getDouble("settings.active-pet-xp-share", 0.25)),
                            petsFile.getBoolean("settings.auto-unlock-from-skill-level", true),
                            petsFile.getBoolean("settings.visuals.enabled", true),
                            Math.max(0.5, petsFile.getDouble("settings.visuals.follow-distance", 2.5)),
                            Math.max(1.0, petsFile.getDouble("settings.visuals.teleport-distance", 12.0)),
                            petsFile.getBoolean("settings.visuals.show-name", true),
                            petsFile.getBoolean("settings.visuals.glowing", false),
                            Math.max(1, petsFile.getLong("settings.visuals.update-ticks", 10))
                    ), new AccessorySettings(
                            core.getBoolean("accessory-bag.enabled", true),
                            Math.max(1, Math.min(9, core.getInt("accessory-bag.slots", 3))),
                            upperSet(core.getStringList("accessory-bag.allowed-categories")),
                            core.getBoolean("accessory-bag.include-milestone-rewards", true),
                            core.getBoolean("accessory-bag.allow-duplicates", false)
                    ));
            return new ReloadResult(true, List.of(), elapsedMs(started), skills.size(), enchants.size(), reforges.size(), items.size(), achievements.size(), pets.size());
        } catch (Exception ex) {
            plugin.getLogger().log(Level.SEVERE, "Could not load configuration; retaining the previous valid snapshot.", ex);
            return new ReloadResult(false, List.of(ex.getMessage()), elapsedMs(started), 0, 0, 0, 0, 0, 0);
        }
    }

    public Snapshot get() {
        Snapshot current = snapshot;
        if (current == null) throw new IllegalStateException("Configuration has not been loaded");
        return current;
    }

    private YamlConfiguration load(String name) throws Exception {
        File file = new File(plugin.getDataFolder(), name);
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.load(file);
        return yaml;
    }

    private YamlConfiguration loadWithBundledDefaults(String name) throws Exception {
        YamlConfiguration yaml = load(name);
        try (var stream = plugin.getResource(name)) {
            if (stream != null) yaml.setDefaults(YamlConfiguration.loadConfiguration(
                    new InputStreamReader(stream, StandardCharsets.UTF_8)));
        }
        return yaml;
    }

    private Map<String, SkillDefinition> parseSkills(YamlConfiguration yaml, int globalCap, List<String> errors) {
        Map<String, SkillDefinition> result = new LinkedHashMap<>();
        ConfigurationSection root = yaml.getConfigurationSection("skills");
        if (root == null) return result;
        for (String rawId : root.getKeys(false)) {
            String id = normalizeId(rawId);
            ConfigurationSection section = root.getConfigurationSection(rawId);
            if (section == null) continue;
            try {
                Material icon = requireMaterial(section.getString("icon", "BOOK"));
                int configuredMax = section.getInt("max-level", -1);
                int maxLevel = configuredMax < 0 ? globalCap : Math.max(1, configuredMax);
                List<SkillDefinition.XpSourceDefinition> sources = new ArrayList<>();
                for (Map<?, ?> raw : section.getMapList("xp-sources")) {
                    String type = text(raw.get("type"), "").toUpperCase(Locale.ROOT);
                    double amount = number(raw.get("amount"), 0);
                    Set<String> targets = stringSet(raw.get("targets"));
                    String mode = text(raw.get("target-mode"), "EXACT").toUpperCase(Locale.ROOT);
                    if (type.isBlank() || amount <= 0) throw new IllegalArgumentException("invalid XP source");
                    sources.add(new SkillDefinition.XpSourceDefinition(type, amount, targets, mode));
                }
                Map<Integer, SkillDefinition.Milestone> milestones = new TreeMap<>();
                ConfigurationSection milestoneRoot = section.getConfigurationSection("milestones");
                if (milestoneRoot != null) {
                    for (String levelKey : milestoneRoot.getKeys(false)) {
                        int level = Integer.parseInt(levelKey);
                        ConfigurationSection m = milestoneRoot.getConfigurationSection(levelKey);
                        if (m != null) milestones.put(level, new SkillDefinition.Milestone(
                                doubles(m.getConfigurationSection("stats")), integers(m.getConfigurationSection("items")),
                                m.getStringList("description"), m.getStringList("commands"), m.getStringList("messages")));
                    }
                }
                result.put(id, new SkillDefinition(id, section.getString("display-name", id),
                        section.getStringList("description"), icon, section.getBoolean("enabled", true), maxLevel,
                        section.getDouble("xp-curve.base", 100), section.getDouble("xp-curve.multiplier", 1),
                        section.getDouble("xp-curve.exponent", 1.6), List.copyOf(sources),
                        doubles(section.getConfigurationSection("per-level-stats")), Map.copyOf(milestones)));
            } catch (Exception ex) {
                errors.add("skills." + rawId + ": " + ex.getMessage());
            }
        }
        return Collections.unmodifiableMap(result);
    }

    private Map<String, EnchantDefinition> parseEnchants(YamlConfiguration yaml, List<String> errors) {
        Map<String, EnchantDefinition> result = new LinkedHashMap<>();
        ConfigurationSection root = yaml.getConfigurationSection("enchants");
        if (root == null) return result;
        for (String rawId : root.getKeys(false)) {
            String id = normalizeId(rawId);
            ConfigurationSection section = root.getConfigurationSection(rawId);
            if (section == null) continue;
            try {
                List<EnchantDefinition.EffectDefinition> effects = new ArrayList<>();
                for (Map<?, ?> raw : section.getMapList("effects")) {
                    String type = text(raw.get("type"), "").toUpperCase(Locale.ROOT);
                    Map<String, Object> options = new HashMap<>();
                    raw.forEach((key, value) -> options.put(String.valueOf(key), value));
                    if (type.isBlank()) throw new IllegalArgumentException("effect type is required");
                    effects.add(new EnchantDefinition.EffectDefinition(type, Map.copyOf(options)));
                }
                result.put(id, new EnchantDefinition(id, section.getString("display-name", id),
                        section.getStringList("description"), section.getString("rarity", "COMMON").toUpperCase(Locale.ROOT),
                        section.getBoolean("enabled", true), Math.max(1, section.getInt("max-level", 1)),
                        upperSet(section.getStringList("item-groups")), lowerSet(section.getStringList("conflicts")),
                        section.getString("trigger", "ATTACK").toUpperCase(Locale.ROOT),
                        section.getDouble("chance.base", 100), section.getDouble("chance.per-level", 0),
                        Math.max(0, section.getLong("cooldown-ms", 0)), List.copyOf(effects)));
            } catch (Exception ex) {
                errors.add("enchants." + rawId + ": " + ex.getMessage());
            }
        }
        return Collections.unmodifiableMap(result);
    }

    private Map<String, ReforgeDefinition> parseReforges(YamlConfiguration yaml, List<String> errors) {
        Map<String, ReforgeDefinition> result = new LinkedHashMap<>();
        ConfigurationSection root = yaml.getConfigurationSection("reforges");
        if (root == null) return result;
        for (String rawId : root.getKeys(false)) {
            String id = normalizeId(rawId);
            ConfigurationSection section = root.getConfigurationSection(rawId);
            if (section == null) continue;
            try {
                double weight = section.getDouble("weight", 1);
                if (weight <= 0) throw new IllegalArgumentException("weight must be positive");
                Set<String> naturalSources = upperSet(section.getStringList("natural-sources"));
                Set<String> unknownSources = new LinkedHashSet<>(naturalSources);
                unknownSources.removeAll(Set.of("CRAFTING", "MOB_DROP", "CHEST_LOOT"));
                if (!unknownSources.isEmpty()) throw new IllegalArgumentException("unknown natural-sources " + unknownSources);
                result.put(id, new ReforgeDefinition(id, section.getString("display-name", id),
                        section.getStringList("description"), section.getString("rarity", "COMMON").toUpperCase(Locale.ROOT),
                        section.getBoolean("enabled", true), section.getBoolean("roll-enabled", true), weight,
                        Math.max(0.000001, section.getDouble("natural-weight", weight)),
                        Math.max(0, section.getDouble("cost-multiplier", 1)),
                        upperSet(section.getStringList("item-groups")), naturalSources,
                        entitySet(section.getStringList("natural-entities")), doubles(section.getConfigurationSection("stats"))));
            } catch (Exception ex) {
                errors.add("reforges." + rawId + ": " + ex.getMessage());
            }
        }
        return Collections.unmodifiableMap(result);
    }

    private Map<String, CustomItemDefinition> parseItems(YamlConfiguration yaml, List<String> errors) {
        Map<String, CustomItemDefinition> result = new LinkedHashMap<>();
        ConfigurationSection root = yaml.getConfigurationSection("items");
        if (root == null) return result;
        for (String rawId : root.getKeys(false)) {
            String id = normalizeId(rawId);
            ConfigurationSection section = root.getConfigurationSection(rawId);
            if (section == null) continue;
            try {
                Material material = requireMaterial(section.getString("material", "PAPER"));
                ConfigurationSection recipeSection = section.getConfigurationSection("recipe");
                CustomItemDefinition.RecipeDefinition recipe = null;
                if (recipeSection != null) {
                    List<String> shape = recipeSection.getStringList("shape");
                    Map<Character, Material> ingredients = new LinkedHashMap<>();
                    ConfigurationSection ingredientSection = recipeSection.getConfigurationSection("ingredients");
                    if (ingredientSection != null) for (String symbol : ingredientSection.getKeys(false)) {
                        if (symbol.length() != 1) throw new IllegalArgumentException("recipe ingredient keys must be one character");
                        ingredients.put(symbol.charAt(0), requireMaterial(ingredientSection.getString(symbol, "AIR")));
                    }
                    boolean enabled = recipeSection.getBoolean("enabled", true);
                    if (enabled && (shape.isEmpty() || shape.size() > 3 || shape.stream().anyMatch(row -> row.isEmpty() || row.length() > 3)))
                        throw new IllegalArgumentException("recipe shape must contain one to three rows of one to three characters");
                    recipe = new CustomItemDefinition.RecipeDefinition(enabled, List.copyOf(shape), Map.copyOf(ingredients),
                            Math.max(1, recipeSection.getInt("result-amount", 1)));
                }
                List<CustomItemDefinition.DropDefinition> drops = new ArrayList<>();
                for (Map<?, ?> raw : section.getMapList("drops")) {
                    Set<EntityType> entities = new LinkedHashSet<>();
                    for (String entity : stringSet(raw.get("entities"))) entities.add(EntityType.valueOf(entity));
                    double chance = Math.max(0, Math.min(100, number(raw.get("chance"), 0)));
                    int minimum = Math.max(1, (int) number(raw.get("minimum"), 1));
                    int maximum = Math.max(minimum, (int) number(raw.get("maximum"), minimum));
                    drops.add(new CustomItemDefinition.DropDefinition(Set.copyOf(entities), chance, minimum, maximum,
                            Math.max(0, number(raw.get("looting-bonus-per-level"), 0)), Boolean.parseBoolean(text(raw.get("player-kill-only"), "true"))));
                }
                result.put(id, new CustomItemDefinition(id, section.getString("display-name", id), section.getStringList("description"),
                        material, section.getString("rarity", "COMMON").toUpperCase(Locale.ROOT), section.getString("category", "MISC"),
                        section.getBoolean("enabled", true), section.getBoolean("glint", false), section.getBoolean("unbreakable", false),
                        Math.max(0, section.getInt("custom-model-data", 0)), doubles(section.getConfigurationSection("stats")),
                        integers(section.getConfigurationSection("enchants")), normalizeOptional(section.getString("reforge", "")),
                        normalizeOptional(section.getString("applies-reforge", "")),
                        Math.max(0, section.getInt("anvil-level-cost", 0)), section.getStringList("obtainment"),
                        section.getBoolean("milestone-exclusive", false), recipe, List.copyOf(drops)));
            } catch (Exception ex) {
                errors.add("items." + rawId + ": " + ex.getMessage());
            }
        }
        return Collections.unmodifiableMap(result);
    }

    private Map<String, AchievementDefinition> parseAchievements(YamlConfiguration yaml, List<String> errors) {
        Map<String, AchievementDefinition> result = new LinkedHashMap<>();
        ConfigurationSection root = yaml.getConfigurationSection("achievements");
        if (root == null) return result;
        for (String rawId : root.getKeys(false)) {
            String id = normalizeId(rawId);
            ConfigurationSection section = root.getConfigurationSection(rawId);
            if (section == null) continue;
            try {
                List<AchievementDefinition.Requirement> requirements = new ArrayList<>();
                for (Map<?, ?> raw : section.getMapList("requirements")) {
                    String metric = text(raw.get("metric"), "").toUpperCase(Locale.ROOT);
                    String target = normalizeOptional(text(raw.get("target"), "all"));
                    double amount = number(raw.get("amount"), 0);
                    if (metric.isBlank() || amount <= 0) throw new IllegalArgumentException("requirements need a metric and positive amount");
                    requirements.add(new AchievementDefinition.Requirement(metric, target.isBlank() ? "all" : target, amount));
                }
                if (requirements.isEmpty()) throw new IllegalArgumentException("at least one requirement is required");
                String frame = section.getString("frame", "TASK").toUpperCase(Locale.ROOT);
                if (!Set.of("TASK", "GOAL", "CHALLENGE").contains(frame))
                    throw new IllegalArgumentException("frame must be TASK, GOAL, or CHALLENGE");
                ConfigurationSection reward = section.getConfigurationSection("rewards");
                result.put(id, new AchievementDefinition(id, section.getString("display-name", id),
                        section.getStringList("description"), requireMaterial(section.getString("icon", "BOOK")), frame,
                        section.getBoolean("enabled", true), section.getBoolean("hidden", false),
                        section.getBoolean("announce", frame.equals("CHALLENGE")), normalizeOptional(section.getString("parent", "")),
                        requirements, new AchievementDefinition.Reward(
                        integers(reward == null ? null : reward.getConfigurationSection("items")),
                        lowerDoubles(reward == null ? null : reward.getConfigurationSection("skill-xp")),
                        reward == null ? List.of() : reward.getStringList("commands"),
                        reward == null ? List.of() : reward.getStringList("messages"))));
            } catch (Exception ex) {
                errors.add("achievements." + rawId + ": " + ex.getMessage());
            }
        }
        return Collections.unmodifiableMap(result);
    }

    private Map<String, PetDefinition> parsePets(YamlConfiguration yaml, List<String> errors) {
        Map<String, PetDefinition> result = new LinkedHashMap<>();
        ConfigurationSection pools = yaml.getConfigurationSection("skill-pools");
        if (pools == null) return result;
        int globalCap = Math.max(1, yaml.getInt("settings.global-level-cap", 100));
        double globalBase = Math.max(1, yaml.getDouble("settings.xp-curve.base", 50));
        double globalMultiplier = Math.max(0.0001, yaml.getDouble("settings.xp-curve.multiplier", 1));
        double globalExponent = Math.max(0, yaml.getDouble("settings.xp-curve.exponent", 1.45));
        for (String rawSkill : pools.getKeys(false)) {
            String skill = normalizeId(rawSkill);
            ConfigurationSection pool = pools.getConfigurationSection(rawSkill);
            if (pool == null || !pool.getBoolean("enabled", true)) continue;
            Map<String, Double> defaultBaseStats = doubles(pool.getConfigurationSection("base-stats"));
            Map<String, Double> defaultPerLevelStats = doubles(pool.getConfigurationSection("per-level-stats"));
            double defaultXpBase = Math.max(1, pool.getDouble("xp-curve.base", globalBase));
            double defaultXpMultiplier = Math.max(0.0001, pool.getDouble("xp-curve.multiplier", globalMultiplier));
            double defaultXpExponent = Math.max(0, pool.getDouble("xp-curve.exponent", globalExponent));
            double defaultBonusBase = Math.max(0, pool.getDouble("skill-xp-bonus.base", 0));
            double defaultBonusPerLevel = Math.max(0, pool.getDouble("skill-xp-bonus.per-level", 0));
            for (Map<?, ?> raw : pool.getMapList("pets")) {
                String id = normalizeId(text(raw.get("id"), ""));
                if (id.isBlank()) { errors.add("pets." + skill + " contains a pet without an id"); continue; }
                if (result.containsKey(id)) { errors.add("pets contains duplicate id " + id); continue; }
                try {
                    double power = Math.max(0, number(raw.get("power"), 1));
                    Map<String, Double> baseStats = scaled(defaultBaseStats, power);
                    baseStats.putAll(mapDoubles(raw.get("base-stats")));
                    Map<String, Double> perLevelStats = scaled(defaultPerLevelStats, power);
                    perLevelStats.putAll(mapDoubles(raw.get("per-level-stats")));
                    result.put(id, new PetDefinition(id, text(raw.get("display-name"), id), strings(raw.get("description")),
                            skill, requireMaterial(text(raw.get("icon"), "BONE")),
                            EntityType.valueOf(text(raw.get("entity"), "WOLF").toUpperCase(Locale.ROOT)),
                            text(raw.get("head-texture"), ""), text(raw.get("head-owner"), ""),
                            text(raw.get("rarity"), "COMMON").toUpperCase(Locale.ROOT),
                            Boolean.parseBoolean(text(raw.get("enabled"), "true")),
                            Boolean.parseBoolean(text(raw.get("auto-unlock"), "true")), text(raw.get("required-permission"), ""),
                            text(raw.get("special-modifier"), "").toUpperCase(Locale.ROOT),
                            Math.max(0, number(raw.get("special-modifier-base"), 0)),
                            Math.max(0, number(raw.get("special-modifier-per-level"), 0)),
                            Math.max(0, (long) number(raw.get("special-modifier-cooldown-ms"), 0)),
                            Math.max(1, (int) number(raw.get("max-level"), globalCap)),
                            Math.max(0, (int) number(raw.get("unlock-skill-level"), 0)),
                            Math.max(1, number(raw.get("xp-base"), defaultXpBase)),
                            Math.max(0.0001, number(raw.get("xp-multiplier"), defaultXpMultiplier)),
                            Math.max(0, number(raw.get("xp-exponent"), defaultXpExponent)),
                            Map.copyOf(baseStats), Map.copyOf(perLevelStats),
                            Math.max(0, number(raw.get("skill-xp-bonus-base"), defaultBonusBase * power)),
                            Math.max(0, number(raw.get("skill-xp-bonus-per-level"), defaultBonusPerLevel * power))));
                } catch (Exception ex) {
                    errors.add("pets." + skill + "." + id + ": " + ex.getMessage());
                }
            }
        }
        return Collections.unmodifiableMap(result);
    }

    private void validateReferences(Map<String, SkillDefinition> skills, Map<String, EnchantDefinition> enchants,
                                    Map<String, ReforgeDefinition> reforges, Map<String, CustomItemDefinition> items,
                                    Map<String, AchievementDefinition> achievements, Map<String, PetDefinition> pets,
                                    List<String> errors) {
        items.values().forEach(item -> {
            item.enchants().keySet().stream().filter(id -> !enchants.containsKey(id))
                    .forEach(id -> errors.add("items." + item.id() + " references unknown enchant " + id));
            if (!item.reforge().isBlank() && !reforges.containsKey(item.reforge()))
                errors.add("items." + item.id() + " references unknown reforge " + item.reforge());
            if (!item.appliesReforge().isBlank() && !reforges.containsKey(item.appliesReforge()))
                errors.add("items." + item.id() + " applies unknown reforge " + item.appliesReforge());
        });
        skills.values().forEach(skill -> skill.milestones().forEach((level, milestone) -> milestone.items().keySet().stream()
                .filter(id -> !items.containsKey(id)).forEach(id -> errors.add("skills." + skill.id() + ".milestones." + level + " references unknown item " + id))));
        achievements.values().forEach(achievement -> {
            if (!achievement.parent().isBlank() && !achievements.containsKey(achievement.parent()))
                errors.add("achievements." + achievement.id() + " references unknown parent " + achievement.parent());
            achievement.reward().items().keySet().stream().filter(id -> !items.containsKey(id))
                    .forEach(id -> errors.add("achievements." + achievement.id() + " references unknown item " + id));
            achievement.reward().skillXp().keySet().stream().filter(id -> !skills.containsKey(id))
                    .forEach(id -> errors.add("achievements." + achievement.id() + " references unknown skill " + id));
        });
        pets.values().stream().filter(pet -> !skills.containsKey(pet.skill()))
                .forEach(pet -> errors.add("pets." + pet.id() + " references unknown skill " + pet.skill()));
    }

    private static Map<String, Double> doubles(ConfigurationSection section) {
        if (section == null) return Map.of();
        Map<String, Double> result = new LinkedHashMap<>();
        section.getKeys(false).forEach(key -> result.put(key.toUpperCase(Locale.ROOT), section.getDouble(key)));
        return Map.copyOf(result);
    }

    private static Map<String, Integer> integers(ConfigurationSection section) {
        if (section == null) return Map.of();
        Map<String, Integer> result = new LinkedHashMap<>();
        section.getKeys(false).forEach(key -> result.put(normalizeId(key), Math.max(1, section.getInt(key, 1))));
        return Map.copyOf(result);
    }

    private static Map<String, Double> lowerDoubles(ConfigurationSection section) {
        if (section == null) return Map.of();
        Map<String, Double> result = new LinkedHashMap<>();
        section.getKeys(false).forEach(key -> result.put(normalizeId(key), Math.max(0, section.getDouble(key))));
        return Map.copyOf(result);
    }

    private static Set<String> stringSet(Object raw) {
        if (!(raw instanceof Collection<?> values)) return Set.of();
        Set<String> result = new LinkedHashSet<>();
        values.forEach(value -> result.add(String.valueOf(value).toUpperCase(Locale.ROOT)));
        return Set.copyOf(result);
    }

    private static List<String> strings(Object raw) {
        if (!(raw instanceof Collection<?> values)) return List.of();
        return values.stream().map(String::valueOf).toList();
    }

    private static Map<String, Double> mapDoubles(Object raw) {
        if (!(raw instanceof Map<?, ?> values)) return Map.of();
        Map<String, Double> result = new LinkedHashMap<>();
        values.forEach((key, value) -> result.put(String.valueOf(key).toUpperCase(Locale.ROOT), number(value, 0)));
        return result;
    }

    private static Map<String, Double> scaled(Map<String, Double> source, double multiplier) {
        Map<String, Double> result = new LinkedHashMap<>();
        source.forEach((key, value) -> result.put(key, value * multiplier));
        return result;
    }

    private static Set<String> upperSet(Collection<String> values) {
        Set<String> result = new LinkedHashSet<>();
        values.forEach(value -> result.add(value.toUpperCase(Locale.ROOT)));
        return Set.copyOf(result);
    }

    private static Set<EntityType> entitySet(Collection<String> values) {
        Set<EntityType> result = new LinkedHashSet<>();
        values.forEach(value -> result.add(EntityType.valueOf(value.toUpperCase(Locale.ROOT))));
        return Set.copyOf(result);
    }

    private static NaturalSourceSettings naturalSource(YamlConfiguration yaml, String path, double defaultChance,
                                                       boolean defaultPlayerKillOnly) {
        return new NaturalSourceSettings(yaml.getBoolean(path + ".enabled", true),
                Math.max(0, Math.min(100, yaml.getDouble(path + ".chance", defaultChance))),
                yaml.getBoolean(path + ".include-custom-items", true),
                yaml.getBoolean(path + ".player-kill-only", defaultPlayerKillOnly));
    }

    private static Set<String> lowerSet(Collection<String> values) {
        Set<String> result = new LinkedHashSet<>();
        values.forEach(value -> result.add(normalizeId(value)));
        return Set.copyOf(result);
    }

    private static Material requireMaterial(String name) {
        Material material = Material.matchMaterial(name);
        if (material == null) throw new IllegalArgumentException("unknown material " + name);
        return material;
    }

    private static String normalizeId(String value) {
        return value.toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
    }
    private static String normalizeOptional(String value) { return value == null || value.isBlank() ? "" : normalizeId(value); }

    private static String text(Object value, String fallback) { return value == null ? fallback : value.toString(); }
    private static double number(Object value, double fallback) {
        if (value instanceof Number n) return n.doubleValue();
        try { return value == null ? fallback : Double.parseDouble(value.toString()); }
        catch (NumberFormatException ignored) { return fallback; }
    }
    private static long elapsedMs(long start) { return (System.nanoTime() - start) / 1_000_000; }

    public record Snapshot(YamlConfiguration core, YamlConfiguration messages,
                           Map<String, SkillDefinition> skills, Map<String, EnchantDefinition> enchants,
                           Map<String, ReforgeDefinition> reforges, Map<String, CustomItemDefinition> items,
                           Map<String, AchievementDefinition> achievements, Map<String, PetDefinition> pets,
                           int globalSkillCap, int totalLevelCap,
                           ReforgeSettings reforgeSettings, NaturalReforgeSettings naturalReforgeSettings,
                           PetSettings petSettings, AccessorySettings accessorySettings) {
        public boolean disabledWorld(String world) {
            return core.getStringList("general.disabled-worlds").stream().anyMatch(world::equalsIgnoreCase);
        }
    }

    public record ReforgeSettings(boolean enabled, String stationTitle, String costType, double baseCost,
                                  double rerollCostMultiplier, boolean allowSame, boolean announceMythic,
                                  String loreFormat, String nameFormat, boolean preserveOriginalName,
                                  boolean allowAdminForceApply) {}
    public record NaturalReforgeSettings(boolean enabled, boolean preserveExistingReforges, boolean equipmentOnly,
                                         NaturalSourceSettings crafting, NaturalSourceSettings mobDrops,
                                         NaturalSourceSettings chestLoot) {}
    public record NaturalSourceSettings(boolean enabled, double chance, boolean includeCustomItems,
                                        boolean playerKillOnly) {}
    public record PetSettings(boolean enabled, int globalLevelCap, double activePetXpShare,
                              boolean autoUnlockFromSkillLevel, boolean visualsEnabled,
                              double followDistance, double teleportDistance, boolean showName,
                              boolean glowing, long updateTicks) {}
    public record AccessorySettings(boolean enabled, int slots, Set<String> allowedCategories,
                                    boolean includeMilestoneRewards,
                                    boolean allowDuplicates) {}
    public record ReloadResult(boolean success, List<String> errors, long elapsedMs, int skills, int enchants, int reforges, int items, int achievements, int pets) {}
}

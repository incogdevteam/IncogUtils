package com.incogdev.incogrpg.cosmetics;

import com.incogdev.incogrpg.IncogRpgPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Renders an ItemDisplay directly above a player who has one of the configured
 * UltraCosmetics rank crowns equipped. UltraCosmetics owns the actual hat
 * unlock/equip lifecycle; this service only supplies the crossplay visual.
 */
public final class RankCrownDisplayService implements Listener {
    private final IncogRpgPlugin plugin;
    private final NamespacedKey markerKey;
    private final Map<UUID, ItemDisplay> displays = new HashMap<>();
    private Set<NamespacedKey> crownModels = Set.of();
    private BukkitTask task;
    private boolean enabled;
    private double yOffset;
    private long refreshTicks;

    public RankCrownDisplayService(IncogRpgPlugin plugin) {
        this.plugin = plugin;
        this.markerKey = new NamespacedKey(plugin, "rank_crown_display");
        reload();
    }

    public void start() {
        cleanupOrphans();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        schedule();
    }

    public void reload() {
        enabled = plugin.configs().get().core().getBoolean("rank-crown-display.enabled", true);
        yOffset = plugin.configs().get().core().getDouble("rank-crown-display.y-offset", 1.92D);
        refreshTicks = Math.max(1L, plugin.configs().get().core().getLong("rank-crown-display.refresh-ticks", 2L));
        Set<NamespacedKey> configured = new HashSet<>();
        for (String raw : plugin.configs().get().core().getStringList("rank-crown-display.item-models")) {
            NamespacedKey model = NamespacedKey.fromString(raw);
            if (model != null) configured.add(model);
            else plugin.getLogger().warning("Ignoring invalid rank crown item model: " + raw);
        }
        crownModels = Set.copyOf(configured);
        schedule();
    }

    public void shutdown() {
        if (task != null) task.cancel();
        task = null;
        displays.values().forEach(this::remove);
        displays.clear();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        remove(displays.remove(event.getPlayer().getUniqueId()));
    }

    private void schedule() {
        if (task != null) task.cancel();
        task = null;
        if (!enabled || crownModels.isEmpty() || !plugin.isEnabled()) return;
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, refreshTicks);
    }

    /** Clears non-persistent displays left behind by a plugin reload before this instance started. */
    private void cleanupOrphans() {
        Bukkit.getWorlds().forEach(world -> world.getEntitiesByClass(ItemDisplay.class).stream()
                .filter(display -> display.getPersistentDataContainer().has(markerKey, PersistentDataType.BYTE))
                .forEach(ItemDisplay::remove));
    }

    private void tick() {
        if (!enabled) {
            displays.values().forEach(this::remove);
            displays.clear();
            return;
        }
        Set<UUID> online = new HashSet<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            online.add(player.getUniqueId());
            ItemStack crown = equippedCrown(player);
            if (crown == null || player.isDead() || player.isInvisible()) {
                remove(displays.remove(player.getUniqueId()));
                continue;
            }
            ItemDisplay display = displays.get(player.getUniqueId());
            if (display == null || !display.isValid() || !display.getWorld().equals(player.getWorld())) {
                remove(display);
                display = spawn(player, crown);
                displays.put(player.getUniqueId(), display);
            } else {
                display.setItemStack(crown);
            }
            Location location = player.getLocation().add(0.0D, yOffset, 0.0D);
            location.setPitch(0.0F);
            display.teleport(location);
            display.setRotation(player.getLocation().getYaw(), 0.0F);
        }
        displays.entrySet().removeIf(entry -> {
            if (online.contains(entry.getKey())) return false;
            remove(entry.getValue());
            return true;
        });
    }

    private ItemStack equippedCrown(Player player) {
        ItemStack helmet = player.getInventory().getHelmet();
        if (helmet == null || helmet.isEmpty()) return null;
        ItemMeta meta = helmet.getItemMeta();
        if (meta == null || !meta.hasItemModel()) return null;
        NamespacedKey model = meta.getItemModel();
        return crownModels.contains(model) ? helmet.clone() : null;
    }

    private ItemDisplay spawn(Player player, ItemStack crown) {
        Location location = player.getLocation().add(0.0D, yOffset, 0.0D);
        return player.getWorld().spawn(location, ItemDisplay.class, display -> {
            display.setItemStack(crown);
            display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.HEAD);
            display.setBillboard(Display.Billboard.FIXED);
            display.setViewRange(64.0F);
            display.setPersistent(false);
            display.setInvulnerable(true);
            display.setGravity(false);
            display.setRotation(player.getLocation().getYaw(), 0.0F);
            display.getPersistentDataContainer().set(markerKey, PersistentDataType.BYTE, (byte) 1);
        });
    }

    private void remove(ItemDisplay display) {
        if (display != null && display.isValid()) display.remove();
    }
}

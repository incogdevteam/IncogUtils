package com.incogdev.incogrpg.data;

import com.incogdev.incogrpg.model.PlayerProfile;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;

import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Level;

public final class PlayerDataService implements AutoCloseable {
    private final Plugin plugin;
    private final SqliteDatabase database;
    private final Map<UUID, PlayerProfile> profiles = new ConcurrentHashMap<>();
    private final ExecutorService writer = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "IncogRPG-Database");
        thread.setDaemon(true);
        return thread;
    });

    public PlayerDataService(Plugin plugin, SqliteDatabase database) {
        this.plugin = plugin;
        this.database = database;
    }

    public PlayerProfile load(UUID uuid, String name) throws SQLException {
        PlayerProfile profile = database.load(uuid, name);
        profiles.put(uuid, profile);
        return profile;
    }

    public PlayerProfile getOrCreate(UUID uuid, String name) {
        return profiles.computeIfAbsent(uuid, ignored -> new PlayerProfile(uuid, name));
    }

    public Optional<PlayerProfile> find(OfflinePlayer player) { return Optional.ofNullable(profiles.get(player.getUniqueId())); }
    public Optional<PlayerProfile> find(UUID uuid) { return Optional.ofNullable(profiles.get(uuid)); }
    public Collection<PlayerProfile> loadedProfiles() { return List.copyOf(profiles.values()); }

    public CompletableFuture<Void> saveAsync(PlayerProfile profile, boolean force) {
        if (!force && !profile.dirty()) return CompletableFuture.completedFuture(null);
        return CompletableFuture.runAsync(() -> {
            try { database.save(profile); }
            catch (SQLException ex) { plugin.getLogger().log(Level.SEVERE, "Could not save profile " + profile.uuid(), ex); }
        }, writer);
    }

    public void unload(UUID uuid) {
        PlayerProfile profile = profiles.remove(uuid);
        if (profile != null) saveAsync(profile, true);
    }

    public void saveAll(boolean force) { loadedProfiles().forEach(profile -> saveAsync(profile, force)); }

    @Override
    public void close() {
        List<CompletableFuture<Void>> saves = loadedProfiles().stream().map(profile -> saveAsync(profile, true)).toList();
        try { CompletableFuture.allOf(saves.toArray(CompletableFuture[]::new)).get(10, TimeUnit.SECONDS); }
        catch (Exception ex) { plugin.getLogger().warning("Timed out while saving profiles during shutdown: " + ex.getMessage()); }
        writer.shutdown();
        try { writer.awaitTermination(5, TimeUnit.SECONDS); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
    }
}

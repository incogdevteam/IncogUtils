package com.incogdev.incogrpg.data;

import com.incogdev.incogrpg.model.PlayerProfile;
import com.incogdev.incogrpg.model.SkillProgress;
import com.incogdev.incogrpg.model.PetProgress;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.sql.*;
import java.util.UUID;

public final class SqliteDatabase implements AutoCloseable {
    private final Plugin plugin;
    private Connection connection;

    public SqliteDatabase(Plugin plugin) { this.plugin = plugin; }

    public synchronized void open(File file, int busyTimeoutMs) throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException ex) {
            throw new SQLException("SQLite driver was not loaded by Paper's library loader", ex);
        }
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA journal_mode=WAL");
            statement.execute("PRAGMA synchronous=NORMAL");
            statement.execute("PRAGMA foreign_keys=ON");
            statement.execute("PRAGMA busy_timeout=" + Math.max(0, busyTimeoutMs));
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS rpg_players (
                      uuid TEXT PRIMARY KEY,
                      last_known_name TEXT NOT NULL,
                      last_seen INTEGER NOT NULL
                    )
                    """);
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS rpg_skill_progress (
                      uuid TEXT NOT NULL,
                      skill_id TEXT NOT NULL,
                      level INTEGER NOT NULL,
                      xp REAL NOT NULL,
                      PRIMARY KEY (uuid, skill_id),
                      FOREIGN KEY (uuid) REFERENCES rpg_players(uuid) ON DELETE CASCADE
                    )
                    """);
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_rpg_skill_level ON rpg_skill_progress(skill_id, level DESC)");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS rpg_achievement_progress (
                      uuid TEXT NOT NULL,
                      progress_key TEXT NOT NULL,
                      value REAL NOT NULL,
                      PRIMARY KEY (uuid, progress_key),
                      FOREIGN KEY (uuid) REFERENCES rpg_players(uuid) ON DELETE CASCADE
                    )
                    """);
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS rpg_achievement_unlocks (
                      uuid TEXT NOT NULL,
                      achievement_id TEXT NOT NULL,
                      completed_at INTEGER NOT NULL,
                      PRIMARY KEY (uuid, achievement_id),
                      FOREIGN KEY (uuid) REFERENCES rpg_players(uuid) ON DELETE CASCADE
                    )
                    """);
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_rpg_achievement_unlock ON rpg_achievement_unlocks(achievement_id, completed_at)");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS rpg_pet_progress (
                      uuid TEXT NOT NULL,
                      pet_id TEXT NOT NULL,
                      level INTEGER NOT NULL,
                      xp REAL NOT NULL,
                      PRIMARY KEY (uuid, pet_id),
                      FOREIGN KEY (uuid) REFERENCES rpg_players(uuid) ON DELETE CASCADE
                    )
                    """);
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS rpg_active_pet (
                      uuid TEXT PRIMARY KEY,
                      pet_id TEXT NOT NULL,
                      FOREIGN KEY (uuid) REFERENCES rpg_players(uuid) ON DELETE CASCADE
                    )
                    """);
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS rpg_accessories (
                      uuid TEXT NOT NULL,
                      slot INTEGER NOT NULL,
                      item_data BLOB NOT NULL,
                      PRIMARY KEY (uuid, slot),
                      FOREIGN KEY (uuid) REFERENCES rpg_players(uuid) ON DELETE CASCADE
                    )
                    """);
        }
    }

    public synchronized PlayerProfile load(UUID uuid, String name) throws SQLException {
        ensureOpen();
        PlayerProfile profile = new PlayerProfile(uuid, name);
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT skill_id, level, xp FROM rpg_skill_progress WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    profile.setProgress(result.getString(1), new SkillProgress(result.getInt(2), result.getDouble(3)));
                }
            }
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT progress_key, value FROM rpg_achievement_progress WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) profile.setAchievementProgress(result.getString(1), result.getDouble(2));
            }
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT achievement_id, completed_at FROM rpg_achievement_unlocks WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) profile.completeAchievement(result.getString(1), result.getLong(2));
            }
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT pet_id, level, xp FROM rpg_pet_progress WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) profile.setPetProgress(result.getString(1),
                        new PetProgress(result.getInt(2), result.getDouble(3)));
            }
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT pet_id FROM rpg_active_pet WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) profile.setActivePetId(result.getString(1));
            }
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT slot, item_data FROM rpg_accessories WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    try {
                        profile.setAccessory(result.getInt(1), org.bukkit.inventory.ItemStack.deserializeBytes(result.getBytes(2)));
                    } catch (RuntimeException ex) {
                        plugin.getLogger().warning("Skipped unreadable accessory data for " + uuid + " in slot " + result.getInt(1) + ".");
                    }
                }
            }
        }
        profile.markClean();
        return profile;
    }

    public synchronized void save(PlayerProfile profile) throws SQLException {
        ensureOpen();
        long savedAtRevision = profile.revision();
        boolean autoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try {
            try (PreparedStatement statement = connection.prepareStatement("""
                    INSERT INTO rpg_players(uuid, last_known_name, last_seen) VALUES(?, ?, ?)
                    ON CONFLICT(uuid) DO UPDATE SET last_known_name=excluded.last_known_name, last_seen=excluded.last_seen
                    """)) {
                statement.setString(1, profile.uuid().toString());
                statement.setString(2, profile.lastKnownName());
                statement.setLong(3, profile.lastSeen());
                statement.executeUpdate();
            }
            try (PreparedStatement delete = connection.prepareStatement("DELETE FROM rpg_skill_progress WHERE uuid = ?")) {
                delete.setString(1, profile.uuid().toString());
                delete.executeUpdate();
            }
            try (PreparedStatement insert = connection.prepareStatement(
                    "INSERT INTO rpg_skill_progress(uuid, skill_id, level, xp) VALUES(?, ?, ?, ?)")) {
                for (var entry : profile.snapshot().entrySet()) {
                    insert.setString(1, profile.uuid().toString());
                    insert.setString(2, entry.getKey());
                    insert.setInt(3, entry.getValue().level());
                    insert.setDouble(4, entry.getValue().xp());
                    insert.addBatch();
                }
                insert.executeBatch();
            }
            try (PreparedStatement delete = connection.prepareStatement("DELETE FROM rpg_achievement_progress WHERE uuid = ?")) {
                delete.setString(1, profile.uuid().toString());
                delete.executeUpdate();
            }
            try (PreparedStatement insert = connection.prepareStatement(
                    "INSERT INTO rpg_achievement_progress(uuid, progress_key, value) VALUES(?, ?, ?)")) {
                for (var entry : profile.achievementProgressSnapshot().entrySet()) {
                    insert.setString(1, profile.uuid().toString());
                    insert.setString(2, entry.getKey());
                    insert.setDouble(3, entry.getValue());
                    insert.addBatch();
                }
                insert.executeBatch();
            }
            try (PreparedStatement delete = connection.prepareStatement("DELETE FROM rpg_achievement_unlocks WHERE uuid = ?")) {
                delete.setString(1, profile.uuid().toString());
                delete.executeUpdate();
            }
            try (PreparedStatement insert = connection.prepareStatement(
                    "INSERT INTO rpg_achievement_unlocks(uuid, achievement_id, completed_at) VALUES(?, ?, ?)")) {
                for (var entry : profile.completedAchievementsSnapshot().entrySet()) {
                    insert.setString(1, profile.uuid().toString());
                    insert.setString(2, entry.getKey());
                    insert.setLong(3, entry.getValue());
                    insert.addBatch();
                }
                insert.executeBatch();
            }
            try (PreparedStatement delete = connection.prepareStatement("DELETE FROM rpg_pet_progress WHERE uuid = ?")) {
                delete.setString(1, profile.uuid().toString());
                delete.executeUpdate();
            }
            try (PreparedStatement insert = connection.prepareStatement(
                    "INSERT INTO rpg_pet_progress(uuid, pet_id, level, xp) VALUES(?, ?, ?, ?)")) {
                for (var entry : profile.petProgressSnapshot().entrySet()) {
                    insert.setString(1, profile.uuid().toString());
                    insert.setString(2, entry.getKey());
                    insert.setInt(3, entry.getValue().level());
                    insert.setDouble(4, entry.getValue().xp());
                    insert.addBatch();
                }
                insert.executeBatch();
            }
            try (PreparedStatement delete = connection.prepareStatement("DELETE FROM rpg_active_pet WHERE uuid = ?")) {
                delete.setString(1, profile.uuid().toString());
                delete.executeUpdate();
            }
            if (!profile.activePetId().isBlank()) {
                try (PreparedStatement insert = connection.prepareStatement(
                        "INSERT INTO rpg_active_pet(uuid, pet_id) VALUES(?, ?)")) {
                    insert.setString(1, profile.uuid().toString());
                    insert.setString(2, profile.activePetId());
                    insert.executeUpdate();
                }
            }
            try (PreparedStatement delete = connection.prepareStatement("DELETE FROM rpg_accessories WHERE uuid = ?")) {
                delete.setString(1, profile.uuid().toString());
                delete.executeUpdate();
            }
            try (PreparedStatement insert = connection.prepareStatement(
                    "INSERT INTO rpg_accessories(uuid, slot, item_data) VALUES(?, ?, ?)")) {
                for (var entry : profile.accessorySnapshot().entrySet()) {
                    insert.setString(1, profile.uuid().toString());
                    insert.setInt(2, entry.getKey());
                    insert.setBytes(3, entry.getValue().serializeAsBytes());
                    insert.addBatch();
                }
                insert.executeBatch();
            }
            connection.commit();
            profile.markClean(savedAtRevision);
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(autoCommit);
        }
    }

    private void ensureOpen() throws SQLException {
        if (connection == null || connection.isClosed()) throw new SQLException("database is not open");
    }

    @Override
    public synchronized void close() {
        if (connection != null) {
            try { connection.close(); }
            catch (SQLException ex) { plugin.getLogger().warning("Could not close database: " + ex.getMessage()); }
            connection = null;
        }
    }
}

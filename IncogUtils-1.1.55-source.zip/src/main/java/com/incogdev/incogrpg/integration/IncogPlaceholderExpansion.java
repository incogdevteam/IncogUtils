package com.incogdev.incogrpg.integration;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.model.SkillDefinition;
import com.incogdev.incogrpg.model.SkillProgress;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;

public final class IncogPlaceholderExpansion extends PlaceholderExpansion {
    private final IncogRpgPlugin plugin;
    public IncogPlaceholderExpansion(IncogRpgPlugin plugin) { this.plugin = plugin; }
    @Override public @NotNull String getIdentifier() { return "incogrpg"; }
    @Override public @NotNull String getAuthor() { return "IncogDev"; }
    @Override public @NotNull String getVersion() { return plugin.getPluginMeta().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override public @Nullable String onRequest(OfflinePlayer offline, @NotNull String params) {
        if (offline == null) return "";
        var profile = plugin.data().find(offline.getUniqueId()).orElse(null);
        if (profile == null) return "0";
        if (params.equalsIgnoreCase("total_level")) return String.valueOf(profile.totalLevels());
        if (params.equalsIgnoreCase("achievements_completed"))
            return String.valueOf(profile.completedAchievementsSnapshot().size());
        if (params.startsWith("achievement_")) {
            String rest = params.substring(12).toLowerCase(Locale.ROOT);
            for (var definition : plugin.configs().get().achievements().values()) {
                String prefix = definition.id() + "_";
                if (!rest.startsWith(prefix)) continue;
                return switch (rest.substring(prefix.length())) {
                    case "completed" -> profile.achievementCompleted(definition.id()) ? "true" : "false";
                    case "percent" -> String.format(Locale.US, "%.1f", plugin.achievements().completionRatio(profile, definition) * 100);
                    default -> null;
                };
            }
        }
        if (params.startsWith("metric_")) {
            String rest = params.substring(7).toLowerCase(Locale.ROOT);
            for (String metric : com.incogdev.incogrpg.service.AchievementService.BUILT_IN_METRICS.stream()
                    .sorted((a, b) -> Integer.compare(b.length(), a.length())).toList()) {
                String prefix = metric.toLowerCase(Locale.ROOT) + "_";
                if (rest.startsWith(prefix)) return String.format(Locale.US, "%.2f",
                        profile.achievementProgress(com.incogdev.incogrpg.service.AchievementService.key(metric, rest.substring(prefix.length()))));
            }
        }
        if (params.startsWith("skill_")) {
            String rest = params.substring(6).toLowerCase(Locale.ROOT);
            for (SkillDefinition def : plugin.configs().get().skills().values()) {
                String prefix = def.id() + "_";
                if (!rest.startsWith(prefix)) continue;
                SkillProgress progress = profile.progress(def.id()); String field = rest.substring(prefix.length());
                return switch (field) {
                    case "level" -> String.valueOf(progress.level());
                    case "xp" -> String.format(Locale.US, "%.2f", progress.xp());
                    case "required" -> String.format(Locale.US, "%.2f", progress.level() >= def.maxLevel() ? 0 : def.xpRequired(progress.level()));
                    case "percent" -> String.format(Locale.US, "%.1f", progress.level() >= def.maxLevel() ? 100 : progress.xp() / def.xpRequired(progress.level()) * 100);
                    default -> null;
                };
            }
        }
        if (params.startsWith("stat_") && offline instanceof Player player)
            return String.format(Locale.US, "%.3f", plugin.stats().value(player, params.substring(5)));
        if (params.equalsIgnoreCase("reforge") && offline instanceof Player player)
            return plugin.reforges().get(player.getInventory().getItemInMainHand()).map(r -> r.id()).orElse("none");
        return null;
    }
}

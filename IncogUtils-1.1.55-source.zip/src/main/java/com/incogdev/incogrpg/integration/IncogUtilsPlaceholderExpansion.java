package com.incogdev.incogrpg.integration;

import com.incogdev.incogclaims.data.Claim;
import com.incogdev.incogclaims.integrations.TabListIntegration;
import com.incogdev.incogclaims.data.PlayerData;
import com.incogdev.incogrpg.IncogRpgPlugin;
import com.snipeyfresh.incogshop.market.WeeklyInfiniteStockManager;
import com.snipeyfresh.incogshop.shopping.ShopPlot;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.time.Duration;
import java.time.Instant;
import java.util.Locale;
import java.util.Optional;

/**
 * Player-facing cross-module PlaceholderAPI expansion. Values deliberately use
 * plain text/numbers so they remain safe in scoreboards, holograms, menus and
 * chat plugins. Module-specific placeholders return 0/none when that module is
 * disabled instead of throwing or exposing server administration data.
 */
public final class IncogUtilsPlaceholderExpansion extends PlaceholderExpansion {
    private final IncogRpgPlugin plugin;

    public IncogUtilsPlaceholderExpansion(IncogRpgPlugin plugin) { this.plugin = plugin; }

    @Override public @NotNull String getIdentifier() { return "incogutils"; }
    @Override public @NotNull String getAuthor() { return "IncogDev"; }
    @Override public @NotNull String getVersion() { return plugin.getPluginMeta().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override public @Nullable String onRequest(OfflinePlayer offline, @NotNull String raw) {
        if (offline == null) return "0";
        String key = raw.toLowerCase(Locale.ROOT);
        Player player = offline.getPlayer();

        if (key.startsWith("claims_")) return claims(offline, player, key.substring(7));
        if (key.startsWith("homes_")) return homes(player, key.substring(6));
        if (key.startsWith("economy_")) return economy(offline, player, key.substring(8));
        if (key.startsWith("market_")) return market(player, key.substring(7));
        if (key.startsWith("daily_")) return daily(player, key.substring(6));
        if (key.startsWith("shopdistrict_")) return district(offline, key.substring(13));
        if (key.startsWith("xp_")) return xp(player, key.substring(3));
        if (key.equals("version")) return plugin.getPluginMeta().getVersion();
        if (key.equals("modules_claims")) return yes(plugin.claimsModuleAvailable());
        if (key.equals("modules_economy")) return yes(plugin.economyModuleAvailable());
        if (key.equals("modules_homes")) return yes(plugin.homesModule() != null);
        if (key.equals("modules_vaults")) return yes(plugin.vaultsModule() != null);
        if (key.equals("modules_itemforge")) return yes(plugin.itemForgeModuleAvailable());
        if (key.equals("modules_antimacro")) return yes(plugin.antiMacroModuleAvailable());
        return null;
    }

    private String claims(OfflinePlayer offline, Player player, String key) {
        if (!plugin.claimsModuleAvailable()) return unavailable(key);
        PlayerData data = plugin.claimsModule().getPlayerDataManager().get(offline.getUniqueId());
        int blocks = data.getClaimBlocks();
        int maximum = plugin.claimsModule().getConfigManager().getMaxClaimBlocks();
        if (key.equals("blocks")) return String.valueOf(blocks);
        if (key.equals("blocks_max")) return String.valueOf(maximum);
        if (key.equals("blocks_remaining")) return String.valueOf(Math.max(0, maximum - blocks));
        if (key.equals("count")) return String.valueOf(plugin.claimsModule().getClaimManager().getClaimsOwnedBy(offline.getUniqueId()).size());
        if (key.equals("extra_count")) return String.valueOf(plugin.claimsModule().getClaimManager().countExtraClaims(offline.getUniqueId()));
        if (key.equals("playstyle")) return data.getType() == null ? "none" : data.getType().name().toLowerCase(Locale.ROOT);
        if (key.equals("playstyle_suffix")) return TabListIntegration.marker(data.getType(),
                plugin.claimsModule().getConfigManager().getPeacefulIcon(),
                plugin.claimsModule().getConfigManager().getAggressiveIcon());
        if (key.equals("pvp_enabled")) return yes(data.isPvpEnabled());
        if (key.equals("pvp_cooldown_seconds")) return seconds(data.getPvpCooldownRemainingMillis(plugin.claimsModule().getConfigManager().getPvpCooldownMillis()));
        if (key.equals("playstyle_cooldown_seconds")) return seconds(data.getSwitchCooldownRemainingMillis(plugin.claimsModule().getConfigManager().getSwitchCooldownDays()));
        if (player == null) return unavailable(key);
        Claim claim = plugin.claimsModule().getClaimManager().getClaimAt(player.getLocation());
        if (key.equals("current_id")) return claim == null ? "none" : claim.getDisplayId();
        if (key.equals("current_owner")) return claim == null ? "none" : Optional.ofNullable(org.bukkit.Bukkit.getOfflinePlayer(claim.getOwner()).getName()).orElse("Unknown");
        if (key.equals("current_type")) return claim == null || claim.getType() == null ? "none" : claim.getType().name().toLowerCase(Locale.ROOT);
        if (key.equals("current_size")) return claim == null ? "0" : String.valueOf(claim.getSize());
        if (key.equals("current_members")) return claim == null ? "0" : String.valueOf(claim.getTrusted().size() + 1);
        if (key.equals("current_full_height")) return claim == null ? "false" : yes(claim.isFullHeight());
        if (key.equals("current_obsidian")) return claim == null ? "0" : String.valueOf(claim.getObsidianCount());
        if (key.equals("current_bedrock")) return claim == null ? "0" : String.valueOf(claim.getBedrockCount());
        return null;
    }

    private String homes(Player player, String key) {
        if (plugin.homesModule() == null || player == null) return unavailable(key);
        int count = plugin.homesModule().getHomeManager().getHomeCount(player.getUniqueId());
        int limit = plugin.homesModule().getHomesConfig().getLimitFor(player);
        if (key.equals("count")) return String.valueOf(count);
        if (key.equals("limit")) return String.valueOf(limit);
        if (key.equals("remaining")) return String.valueOf(Math.max(0, limit - count));
        if (key.equals("cooldown_seconds")) return String.valueOf(plugin.homesModule().getCooldownManager().getRemainingSeconds(player.getUniqueId(), plugin.homesModule().getHomesConfig().getCooldownSeconds()));
        if (key.equals("teleport_pending")) return yes(plugin.homesModule().getPendingTeleportManager().isPending(player.getUniqueId()));
        if (key.equals("in_combat")) return yes(plugin.homesModule().getCombatTracker().isRecentlyInCombat(player.getUniqueId(), plugin.homesModule().getHomesConfig().getCombatTagSeconds()));
        return null;
    }

    private String economy(OfflinePlayer offline, Player player, String key) {
        if (!plugin.economyModuleAvailable()) return unavailable(key);
        if (key.equals("balance")) return money(plugin.economyModule().wallets().get(offline.getUniqueId()));
        if (key.equals("provider")) return plugin.economyModule().wallets().providerName();
        if (player == null) return unavailable(key);
        if (key.equals("buy_discount_percent")) return decimal(plugin.economyModule().rankPerks().buyDiscountPercent(player));
        if (key.equals("sell_bonus_percent")) return decimal(plugin.economyModule().rankPerks().sellBonusPercent(player));
        return null;
    }

    private String xp(Player player, String key) {
        if (!plugin.economyModuleAvailable() || player == null) return unavailable(key);
        if (key.equals("vault")) return String.valueOf(plugin.economyModule().xpVault().stored(player.getUniqueId()));
        if (key.equals("current")) return String.valueOf(plugin.economyModule().xpVault().current(player));
        if (key.equals("total")) return String.valueOf(plugin.economyModule().xpVault().stored(player.getUniqueId()) + plugin.economyModule().xpVault().current(player));
        return null;
    }

    private String daily(Player player, String key) {
        if (!plugin.economyModuleAvailable() || player == null) return unavailable(key);
        var rewards = plugin.economyModule().dailyRewards();
        var status = rewards.status(player);
        if (key.equals("rewards_enabled")) return yes(status.enabled());
        if (key.equals("rewards_claimable")) return yes(status.claimable());
        if (key.equals("rewards_next_day")) return String.valueOf(status.nextDay());
        if (key.equals("rewards_streak")) return String.valueOf(status.streak());
        if (key.equals("rewards_cycle_days")) return String.valueOf(rewards.cycleDays());
        if (key.equals("rewards_interval_days")) return String.valueOf(status.intervalDays());
        if (key.equals("rewards_rank")) return rewards.selectedRankId(player);
        return null;
    }

    private String market(Player player, String key) {
        if (!plugin.economyModuleAvailable() || player == null) return unavailable(key);
        if (key.equals("daily_flux_enabled")) return yes(plugin.economyModule().dailyMarketFlux().enabled());
        if (key.equals("daily_flux_item_count")) return String.valueOf(plugin.economyModule().dailyMarketFlux().activeModifiers().size());
        WeeklyInfiniteStockManager.EventStatus weekly = plugin.economyModule().weeklyInfiniteStock().statusFor(player);
        if (key.equals("weekly_enabled")) return yes(weekly.enabled());
        if (key.equals("weekly_active")) return yes(weekly.active());
        if (key.equals("weekly_revealed")) return yes(weekly.selectionsRevealed());
        if (key.equals("weekly_item_limit")) return String.valueOf(weekly.itemLimit());
        if (key.equals("weekly_items")) return weekly.playerItems().isEmpty() ? "none" : weekly.playerItems().stream().map(Material::name).collect(java.util.stream.Collectors.joining(", "));
        if (key.equals("weekly_seconds_until_start")) return secondsUntil(weekly.eventStart());
        if (key.equals("weekly_seconds_remaining")) return weekly.active() ? secondsUntil(weekly.eventEnd()) : "0";
        return null;
    }

    private String district(OfflinePlayer offline, String key) {
        if (!plugin.economyModuleAvailable() || !plugin.economyModule().shoppingDistrict().enabled()) return unavailable(key);
        var district = plugin.economyModule().shoppingDistrict();
        var plots = district.plots(offline.getUniqueId());
        if (key.equals("plots")) return String.valueOf(plots.size());
        Optional<ShopPlot> primary = district.primary(offline.getUniqueId());
        if (key.equals("primary_name")) return primary.map(ShopPlot::displayName).orElse("none");
        if (key.equals("primary_size")) return primary.map(plot -> String.valueOf(plot.size())).orElse("0");
        if (key.equals("primary_layout")) return primary.map(ShopPlot::layout).orElse("none");
        if (key.equals("primary_expansions")) return primary.map(plot -> String.valueOf(plot.expansions())).orElse("0");
        return null;
    }

    private static String unavailable(String key) {
        if (key.endsWith("enabled") || key.endsWith("pending") || key.endsWith("combat")
                || key.endsWith("active") || key.endsWith("revealed") || key.endsWith("claimable")
                || key.endsWith("full_height")) return "false";
        if (key.endsWith("type") || key.endsWith("owner") || key.endsWith("name")
                || key.endsWith("layout") || key.endsWith("items") || key.endsWith("rank")
                || key.endsWith("provider") || key.endsWith("id")) return "none";
        return "0";
    }
    private static String yes(boolean value) { return value ? "true" : "false"; }
    private static String money(double value) { return String.format(Locale.US, "%.2f", value); }
    private static String decimal(double value) { return String.format(Locale.US, "%.2f", value); }
    private static String seconds(long milliseconds) { return String.valueOf(Math.max(0L, (milliseconds + 999L) / 1000L)); }
    private static String secondsUntil(Instant instant) { return seconds(Duration.between(Instant.now(), instant).toMillis()); }
}

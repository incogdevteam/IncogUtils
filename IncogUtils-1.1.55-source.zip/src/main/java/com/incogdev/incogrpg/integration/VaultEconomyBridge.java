package com.incogdev.incogrpg.integration;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.lang.reflect.Method;

public final class VaultEconomyBridge {
    private Object economy;
    private Method has;
    private Method withdraw;

    @SuppressWarnings({"unchecked", "rawtypes"})
    public boolean connect() {
        try {
            Class type = Class.forName("net.milkbowl.vault.economy.Economy");
            Object registration = Bukkit.getServicesManager().getRegistration(type);
            if (registration == null) return false;
            economy = registration.getClass().getMethod("getProvider").invoke(registration);
            has = type.getMethod("has", OfflinePlayer.class, double.class);
            withdraw = type.getMethod("withdrawPlayer", OfflinePlayer.class, double.class);
            return true;
        } catch (ReflectiveOperationException ex) { economy = null; return false; }
    }

    public boolean available() { return economy != null; }
    public boolean charge(OfflinePlayer player, double amount) {
        if (amount <= 0) return true;
        try {
            if (!(boolean) has.invoke(economy, player, amount)) return false;
            Object response = withdraw.invoke(economy, player, amount);
            return (boolean) response.getClass().getMethod("transactionSuccess").invoke(response);
        } catch (ReflectiveOperationException ex) { return false; }
    }
}

package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.api.event.CustomEnchantProcEvent;
import com.incogdev.incogrpg.api.event.SkillLevelUpEvent;
import com.incogdev.incogrpg.api.event.SkillXpGainEvent;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.model.CustomItemDefinition;
import com.incogdev.incogrpg.service.AchievementService;
import com.incogdev.incogrpg.service.CustomItemService;
import org.bukkit.GameMode;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;

/** Converts normal gameplay and IncogRPG API events into configurable achievement metrics. */
public final class AchievementListener implements Listener {
    private final ConfigManager configs;
    private final PlayerDataService data;
    private final AchievementService achievements;
    private final CustomItemService items;

    public AchievementListener(ConfigManager configs, PlayerDataService data, AchievementService achievements,
                               CustomItemService items) {
        this.configs = configs;
        this.data = data;
        this.achievements = achievements;
        this.items = items;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onXp(SkillXpGainEvent event) {
        achievements.add(event.getPlayer(), "SKILL_XP_EARNED", event.getSkillId(), event.getAmount());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onLevel(SkillLevelUpEvent event) {
        achievements.set(event.getPlayer(), "SKILL_LEVEL", event.getSkillId(), event.getNewLevel());
        achievements.set(event.getPlayer(), "TOTAL_SKILL_LEVEL", "all",
                data.getOrCreate(event.getPlayer().getUniqueId(), event.getPlayer().getName()).totalLevels());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (ignored(event.getPlayer())) return;
        achievements.add(event.getPlayer(), "BLOCKS_BROKEN", event.getBlock().getType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null || ignored(killer)) return;
        if (event.getEntity() instanceof Player)
            achievements.add(killer, "PLAYERS_KILLED", "all", 1);
        else achievements.add(killer, "MOBS_KILLED", event.getEntityType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        Player attacker = attackingPlayer(event.getDamager());
        if (attacker == null || ignored(attacker) || event.getFinalDamage() <= 0) return;
        achievements.add(attacker, "DAMAGE_DEALT", event.getEntityType().name(), event.getFinalDamage());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || ignored(player)) return;
        ItemStack result = event.getRecipe().getResult();
        int amount = Math.max(1, result.getAmount());
        achievements.add(player, "ITEMS_CRAFTED", result.getType().name(), amount);
        items.definition(result).ifPresent(definition -> {
            achievements.add(player, "CUSTOM_ITEMS_OBTAINED", definition.id(), amount);
        });
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player) || ignored(player)) return;
        ItemStack stack = event.getItem().getItemStack();
        items.definition(stack).ifPresent(definition ->
                achievements.add(player, "CUSTOM_ITEMS_OBTAINED", definition.id(), stack.getAmount()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH || ignored(event.getPlayer())) return;
        if (event.getCaught() instanceof Item caught) {
            ItemStack stack = caught.getItemStack();
            achievements.add(event.getPlayer(), "FISH_CAUGHT", stack.getType().name(), stack.getAmount());
        } else achievements.add(event.getPlayer(), "FISH_CAUGHT", "all", 1);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEnchantProc(CustomEnchantProcEvent event) {
        achievements.add(event.getPlayer(), "ENCHANT_PROCS", event.getEnchantId(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onReforgeStoneTaken(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || event.getRawSlot() != 2) return;
        if (!(event.getView().getTopInventory() instanceof AnvilInventory anvil)) return;
        ItemStack catalyst = anvil.getSecondItem();
        CustomItemDefinition definition = items.definition(catalyst).orElse(null);
        if (definition == null || definition.appliesReforge().isBlank() || event.getCurrentItem() == null) return;
        achievements.add(player, "REFORGES_APPLIED", definition.appliesReforge(), 1);
    }

    private boolean ignored(Player player) {
        return configs.get().disabledWorld(player.getWorld().getName()) ||
                (configs.get().core().getBoolean("anti-exploit.ignore-creative-mode", true) && player.getGameMode() == GameMode.CREATIVE);
    }

    private static Player attackingPlayer(Entity entity) {
        if (entity instanceof Player player) return player;
        if (entity instanceof Projectile projectile && projectile.getShooter() instanceof Player player) return player;
        return null;
    }
}

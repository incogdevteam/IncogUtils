package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.service.SkillService;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.BrewEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class BrewingListener implements Listener {
    private final SkillService skills;
    private final Map<BlockKey, Brewer> lastBrewers = new HashMap<>();
    public BrewingListener(SkillService skills) { this.skills = skills; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBrewInventory(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getType() != InventoryType.BREWING || !(event.getWhoClicked() instanceof Player player)) return;
        Location location = event.getView().getTopInventory().getLocation();
        if (location != null) lastBrewers.put(new BlockKey(location), new Brewer(player.getUniqueId(), System.currentTimeMillis()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBrew(BrewEvent event) {
        BlockKey key = new BlockKey(event.getBlock().getLocation()); Brewer brewer = lastBrewers.get(key);
        if (brewer == null || System.currentTimeMillis() - brewer.time > 300_000) return;
        Player player = Bukkit.getPlayer(brewer.player);
        if (player != null) skills.awardSource(player, "BREW_POTION", "BREWING_STAND", 1);
    }
    private record BlockKey(UUID world, int x, int y, int z) { BlockKey(Location l) { this(l.getWorld().getUID(), l.getBlockX(), l.getBlockY(), l.getBlockZ()); } }
    private record Brewer(UUID player, long time) {}
}

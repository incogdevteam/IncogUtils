package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.EnchantDefinition;
import com.incogdev.incogrpg.service.EnchantService;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public final class CustomBookListener implements Listener {
    private final ConfigManager configs;
    private final EnchantService enchants;
    public CustomBookListener(ConfigManager configs, EnchantService enchants) { this.configs = configs; this.enchants = enchants; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPrepare(PrepareAnvilEvent event) {
        if (!configs.get().core().getBoolean("enchanting.book-application-enabled", true)) return;
        AnvilInventory inventory = event.getInventory();
        ItemStack base = inventory.getItem(0); ItemStack book = inventory.getItem(1);
        if (base == null || base.getType().isAir() || book == null || book.getType() != Material.ENCHANTED_BOOK) return;
        Map<String, Integer> stored = enchants.get(book); if (stored.isEmpty()) return;
        ItemStack result = base.clone(); boolean applied = false; int levels = 0;
        for (var entry : stored.entrySet()) {
            EnchantDefinition definition = configs.get().enchants().get(entry.getKey());
            if (definition == null) continue;
            EnchantService.ApplyResult outcome = enchants.apply(result, definition, entry.getValue(), false);
            if (outcome == EnchantService.ApplyResult.SUCCESS) { applied = true; levels += entry.getValue(); }
        }
        if (!applied) return;
        event.setResult(result);
        event.getView().setRepairCost(Math.max(1, levels * configs.get().core().getInt("enchanting.anvil-level-cost-per-enchant-level", 3)));
    }
}

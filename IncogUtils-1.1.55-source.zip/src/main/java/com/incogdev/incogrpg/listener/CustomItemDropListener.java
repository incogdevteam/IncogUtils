package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.CustomItemDefinition;
import com.incogdev.incogrpg.service.CustomItemService;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.concurrent.ThreadLocalRandom;

public final class CustomItemDropListener implements Listener {
    private final ConfigManager configs;
    private final CustomItemService items;

    public CustomItemDropListener(ConfigManager configs, CustomItemService items) {
        this.configs = configs;
        this.items = items;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        int looting = killer == null ? 0 : killer.getInventory().getItemInMainHand().getEnchantmentLevel(Enchantment.LOOTING);
        for (CustomItemDefinition definition : configs.get().items().values()) {
            if (!definition.enabled() || !items.canAcquire(definition, CustomItemService.AcquisitionSource.MOB_DROP)) continue;
            for (CustomItemDefinition.DropDefinition drop : definition.drops()) {
                if (!drop.entities().contains(event.getEntityType()) || (drop.playerKillOnly() && killer == null)) continue;
                double chance = Math.min(100, drop.chance() + looting * drop.lootingBonusPerLevel());
                if (ThreadLocalRandom.current().nextDouble(100) >= chance) continue;
                int amount = ThreadLocalRandom.current().nextInt(drop.minimum(), drop.maximum() + 1);
                event.getDrops().add(items.create(definition, amount));
            }
        }
    }
}

package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.service.StatService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public final class CustomStatListener implements Listener {
    private final Plugin plugin;
    private final StatService stats;
    public CustomStatListener(Plugin plugin, StatService stats) { this.plugin = plugin; this.stats = stats; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPetDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Tameable pet && pet.getOwner() instanceof Player owner) {
            double bonus = stats.value(owner, "CUSTOM_PET_DAMAGE");
            if (bonus != 0) event.setDamage(event.getDamage() * (1 + bonus / 100.0));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHeal(EntityRegainHealthEvent event) {
        if (event.getEntity() instanceof Player player) {
            double power = stats.value(player, "CUSTOM_HEALING_POWER");
            if (power != 0) event.setAmount(event.getAmount() * (1 + power / 100.0));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH || !(event.getCaught() instanceof Item caught)) return;
        double fortune = stats.value(event.getPlayer(), "CUSTOM_FISHING_FORTUNE");
        if (fortune <= 0) return;
        int copies = (int) (fortune / 100.0) + (ThreadLocalRandom.current().nextDouble(100) < fortune % 100 ? 1 : 0);
        if (copies <= 0) return;
        var extra = caught.getItemStack().clone();
        extra.setAmount(Math.min(extra.getMaxStackSize(), Math.max(1, extra.getAmount() * copies)));
        event.getPlayer().getWorld().dropItemNaturally(event.getPlayer().getLocation(), extra);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent event) {
        if (event.getItem().getType() != Material.POTION) return;
        double durationBonus = stats.value(event.getPlayer(), "CUSTOM_POTION_DURATION");
        if (durationBonus <= 0) return;
        Map<PotionEffectType, Integer> before = new HashMap<>();
        event.getPlayer().getActivePotionEffects().forEach(effect -> before.put(effect.getType(), effect.getDuration()));
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player player = event.getPlayer();
            for (PotionEffect effect : player.getActivePotionEffects()) {
                if (effect.getDuration() <= before.getOrDefault(effect.getType(), -1)) continue;
                int duration = Math.min(20 * 60 * 60, (int) Math.round(effect.getDuration() * (1 + durationBonus / 100.0)));
                player.addPotionEffect(new PotionEffect(effect.getType(), duration, effect.getAmplifier(),
                        effect.isAmbient(), effect.hasParticles(), effect.hasIcon()));
            }
        });
    }
}

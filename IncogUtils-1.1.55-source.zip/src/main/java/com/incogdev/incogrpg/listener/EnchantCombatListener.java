package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.api.event.CustomEnchantProcEvent;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.model.EnchantDefinition;
import com.incogdev.incogrpg.model.SkillProgress;
import com.incogdev.incogrpg.service.CooldownService;
import com.incogdev.incogrpg.service.EnchantService;
import com.incogdev.incogrpg.service.SkillService;
import com.incogdev.incogrpg.service.StatService;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class EnchantCombatListener implements Listener {
    private final IncogRpgPlugin plugin;
    private final ConfigManager configs;
    private final EnchantService enchants;
    private final CooldownService cooldowns;
    private final StatService stats;
    private final PlayerDataService data;
    private final SkillService skills;
    private final Map<UUID, ItemStack> projectileWeapons = new HashMap<>();
    private final Map<String, Combo> combos = new HashMap<>();
    private final Map<String, Mark> marks = new HashMap<>();
    private final Map<UUID, Long> lastMoved = new HashMap<>();
    private final Map<UUID, Long> lastAttack = new HashMap<>();
    private final Map<UUID, Long> lastDamaged = new HashMap<>();
    private final Map<UUID, KillStreak> killStreaks = new HashMap<>();
    private final Map<UUID, KillStreak> combatKillStreaks = new HashMap<>();
    private boolean syntheticDamage;

    public EnchantCombatListener(IncogRpgPlugin plugin, ConfigManager configs, EnchantService enchants,
                                 CooldownService cooldowns, StatService stats, PlayerDataService data, SkillService skills) {
        this.plugin = plugin; this.configs = configs; this.enchants = enchants; this.cooldowns = cooldowns;
        this.stats = stats; this.data = data; this.skills = skills;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent event) {
        if (event.getEntity().getShooter() instanceof Player player)
            projectileWeapons.put(event.getEntity().getUniqueId(), player.getInventory().getItemInMainHand().clone());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onProjectileHit(ProjectileHitEvent event) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> projectileWeapons.remove(event.getEntity().getUniqueId()), 1L);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (event.hasChangedPosition()) lastMoved.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (syntheticDamage || !(event.getEntity() instanceof LivingEntity target)) return;
        Player attacker = attacker(event.getDamager());
        boolean projectile = event.getDamager() instanceof Projectile;
        if (attacker != null && !configs.get().disabledWorld(attacker.getWorld().getName())) {
            ItemStack weapon = projectile ? projectileWeapons.getOrDefault(event.getDamager().getUniqueId(), attacker.getInventory().getItemInMainHand()) : attacker.getInventory().getItemInMainHand();
            lastAttack.put(attacker.getUniqueId(), System.currentTimeMillis());
            applyOffensiveStats(event, attacker, target, projectile);
            processAttackEnchants(event, attacker, target, weapon, projectile);
        }
        if (target instanceof Player victim && !configs.get().disabledWorld(victim.getWorld().getName())) {
            lastDamaged.put(victim.getUniqueId(), System.currentTimeMillis());
            applyDefensiveStats(event, victim);
            if (!event.isCancelled()) processDefenseEnchants(event, victim, attacker);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null || configs.get().disabledWorld(killer.getWorld().getName())) return;
        recordCombatKill(killer);
        ItemStack weapon = killer.getInventory().getItemInMainHand();
        forEachProc(killer, weapon, "KILL", (definition, level) ->
                applyKillEffects(killer, event.getEntity(), event.getDrops(), definition, level));
    }

    public void tickPassives() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            ItemStack held = player.getInventory().getItemInMainHand();
            forEachProc(player, held, "PASSIVE_TICK", (definition, level) -> {
                for (EnchantDefinition.EffectDefinition effect : definition.effects()) {
                    switch (effect.type()) {
                        case "ITEM_MAGNET" -> magnet(player, effect, level);
                        case "SECOND_WIND" -> {
                            double healthPercent = player.getHealth() / maxHealth(player) * 100.0;
                            if (healthPercent <= effect.number("threshold", 35)) heal(player, effect.scaled("amount", level, 0.5));
                        }
                        case "WARD" -> {
                            if (System.currentTimeMillis() - lastAttack.getOrDefault(player.getUniqueId(), 0L) >= effect.integer("out-of-combat-ms", 10000))
                                player.setAbsorptionAmount(Math.min(effect.scaled("max-absorption", level, 2), player.getAbsorptionAmount() + effect.scaled("amount", level, 0.5)));
                        }
                    }
                }
            });
        }
        long expiry = System.currentTimeMillis() - 120_000;
        combos.values().removeIf(combo -> combo.updated < expiry);
        marks.values().removeIf(mark -> mark.expires < System.currentTimeMillis());
    }

    private void applyOffensiveStats(EntityDamageByEntityEvent event, Player attacker, LivingEntity target, boolean projectile) {
        double damage = event.getDamage();
        if (projectile) damage *= 1.0 + stats.value(attacker, "CUSTOM_PROJECTILE_DAMAGE") / 100.0;
        double critChance = stats.value(attacker, "CUSTOM_CRIT_CHANCE");
        if (ThreadLocalRandom.current().nextDouble(100) < critChance) {
            damage *= 1.0 + stats.value(attacker, "CUSTOM_CRIT_DAMAGE") / 100.0;
            target.getWorld().spawnParticle(Particle.CRIT, target.getEyeLocation(), 12, 0.3, 0.4, 0.3, 0.08);
        }
        event.setDamage(Math.max(0, damage));
        double lifesteal = stats.value(attacker, "CUSTOM_LIFESTEAL");
        if (lifesteal > 0) heal(attacker, damage * lifesteal / 100.0);
    }

    private void applyDefensiveStats(EntityDamageByEntityEvent event, Player victim) {
        double dodge = stats.value(victim, "CUSTOM_DODGE_CHANCE");
        if (ThreadLocalRandom.current().nextDouble(100) < dodge) {
            event.setCancelled(true);
            victim.getWorld().spawnParticle(Particle.CLOUD, victim.getLocation().add(0, 1, 0), 8, 0.3, 0.3, 0.3, 0.02);
        }
    }

    private void processAttackEnchants(EntityDamageByEntityEvent event, Player attacker, LivingEntity target, ItemStack weapon, boolean projectile) {
        List<String> triggers = projectile ? List.of("ATTACK", "PROJECTILE_HIT") : List.of("ATTACK");
        for (String trigger : triggers) forEachProc(attacker, weapon, trigger, (definition, level) -> {
            for (EnchantDefinition.EffectDefinition effect : definition.effects()) {
                double current = event.getDamage();
                switch (effect.type()) {
                    case "MISSING_HEALTH_DAMAGE" -> event.setDamage(current * (1 + missingHealth(target) * effect.scaled("max-percent", level, 10) / 10_000.0));
                    case "CLOSE_DAMAGE" -> { if (attacker.getLocation().distance(target.getLocation()) <= effect.number("max-distance", 8)) event.setDamage(current * (1 + effect.scaled("percent", level, 5) / 100)); }
                    case "TARGET_MAX_HEALTH_DAMAGE" -> event.setDamage(current * (1 + Math.min(effect.scaled("max-percent", level, 25), maxHealth(target) * effect.scaled("percent-per-health", level, 0.1)) / 100));
                    case "FULL_HEALTH_DAMAGE" -> { if (target.getHealth() >= maxHealth(target) * effect.number("threshold", 0.95)) event.setDamage(current * (1 + effect.scaled("percent", level, 10) / 100)); }
                    case "ISOLATED_DAMAGE" -> { if (nearbyLiving(target, effect.number("radius", 5), attacker).isEmpty()) event.setDamage(current * (1 + effect.scaled("percent", level, 8) / 100)); }
                    case "HEIGHT_ADVANTAGE_DAMAGE" -> { double height = attacker.getY() - target.getY(); if (height > 0) event.setDamage(current * (1 + Math.min(effect.number("max-percent", 30), height * effect.scaled("percent-per-block", level, 1)) / 100)); }
                    case "LOW_HEALTH_DAMAGE" -> { if (attacker.getHealth() / maxHealth(attacker) * 100 <= effect.number("threshold", 40)) event.setDamage(current * (1 + effect.scaled("percent", level, 8) / 100)); }
                    case "SKILL_SCALE_DAMAGE" -> { int skillLevel = skillLevel(attacker, effect.text("skill", "combat")); event.setDamage(current * (1 + Math.min(effect.number("max-percent", 40), skillLevel * effect.scaled("percent-per-skill-level", level, 0.1)) / 100)); }
                    case "STATUS_COUNT_DAMAGE" -> event.setDamage(current * (1 + Math.min(effect.integer("max-effects", 5), target.getActivePotionEffects().size()) * effect.scaled("percent-per-effect", level, 2) / 100));
                    case "COMBO_DAMAGE" -> event.setDamage(comboDamage(attacker, target, definition.id(), level, effect, current));
                    case "DELAYED_ECHO" -> delayedDamage(attacker, target, current * effect.scaled("percent", level, 10) / 100, effect.integer("delay-ticks", 20));
                    case "GRAVITY_WELL" -> gravityWell(attacker, target, effect, level);
                    case "RICOCHET" -> ricochet(attacker, target, current, effect, level);
                    case "MARK_DAMAGE" -> event.setDamage(markDamage(attacker, target, definition.id(), current, effect, level));
                    case "REAR_DAMAGE" -> { if (isBehind(attacker, target, effect.number("dot-threshold", -0.35))) event.setDamage(current * (1 + effect.scaled("percent", level, 8) / 100)); }
                    case "AIRBORNE_DAMAGE" -> { if (isAirborne(attacker)) event.setDamage(current * (1 + effect.scaled("percent", level, 6) / 100)); }
                    case "SPRINT_DAMAGE" -> { if (attacker.isSprinting()) event.setDamage(current * (1 + effect.scaled("percent", level, 5) / 100)); }
                    case "SURROUNDED_DAMAGE" -> {
                        int nearby = Math.min(effect.integer("max-targets", 6), nearbyLiving(attacker, effect.number("radius", 4), attacker).size());
                        if (nearby >= effect.integer("minimum-targets", 2)) event.setDamage(current * (1 + nearby * effect.scaled("percent-per-target", level, 2) / 100));
                    }
                    case "HEALTH_GAP_DAMAGE" -> {
                        double gap = target.getHealth() / maxHealth(target) - attacker.getHealth() / maxHealth(attacker);
                        if (gap > 0) event.setDamage(current * (1 + Math.min(effect.number("max-percent", 35), gap * 100 * effect.scaled("percent-per-gap", level, 0.25)) / 100));
                    }
                    case "RECENT_HURT_DAMAGE" -> {
                        if (System.currentTimeMillis() - lastDamaged.getOrDefault(attacker.getUniqueId(), 0L) <= effect.integer("window-ms", 5000))
                            event.setDamage(current * (1 + effect.scaled("percent", level, 7) / 100));
                    }
                    case "KILL_STREAK_DAMAGE" -> {
                        KillStreak streak = combatKillStreaks.get(attacker.getUniqueId());
                        if (streak != null && System.currentTimeMillis() - streak.updated <= effect.integer("window-ms", 8000)) {
                            int stacks = Math.min(streak.kills, effect.integer("max-stacks", 5));
                            event.setDamage(current * (1 + stacks * effect.scaled("percent-per-stack", level, 2) / 100));
                        }
                    }
                    case "FLAT_BONUS_DAMAGE" -> event.setDamage(current + effect.scaled("amount", level, 0.5));
                    case "LIGHT_ARMOR_DAMAGE" -> {
                        long emptySlots = Arrays.stream(attacker.getInventory().getArmorContents())
                                .filter(item -> item == null || item.getType().isAir()).count();
                        if (emptySlots > 0) event.setDamage(current * (1 + emptySlots * effect.scaled("percent-per-slot", level, 2) / 100));
                    }
                }
            }
        });
    }

    private void processDefenseEnchants(EntityDamageByEntityEvent event, Player victim, Player attacker) {
        List<ItemStack> armor = new ArrayList<>(Arrays.asList(victim.getInventory().getArmorContents()));
        armor.add(victim.getInventory().getItemInOffHand());
        for (ItemStack item : armor) forEachProc(victim, item, "DEFEND", (definition, level) -> {
            for (EnchantDefinition.EffectDefinition effect : definition.effects()) {
                switch (effect.type()) {
                    case "CHEAT_DEATH" -> {
                        if (event.getFinalDamage() >= victim.getHealth()) {
                            event.setDamage(0); victim.setHealth(Math.max(1, effect.number("health", 1)));
                            victim.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,
                                    effect.integer("resistance-ticks", 40) + effect.integer("resistance-ticks-per-level", 0) * (level - 1),
                                    effect.integer("resistance-amplifier", 1), true, true, true));
                        }
                    }
                    case "RADIAL_KNOCKBACK" -> radialKnockback(victim, effect, level);
                    case "LARGE_HIT_REDUCTION" -> { if (event.getDamage() >= effect.number("minimum-damage", 8)) event.setDamage(event.getDamage() * (1 - effect.scaled("percent", level, 8) / 100)); }
                    case "STATIONARY_REDUCTION" -> { if (System.currentTimeMillis() - lastMoved.getOrDefault(victim.getUniqueId(), 0L) >= effect.integer("stationary-ms", 2000)) event.setDamage(event.getDamage() * (1 - effect.scaled("percent", level, 5) / 100)); }
                    case "PACIFIST_REDUCTION" -> { if (System.currentTimeMillis() - lastAttack.getOrDefault(victim.getUniqueId(), 0L) >= effect.integer("peace-ms", 10000)) event.setDamage(event.getDamage() * (1 - effect.scaled("percent", level, 8) / 100)); }
                    case "HEAL_LOWEST_ALLY" -> healLowestAlly(victim, effect, level);
                    case "LOW_HEALTH_REGEN" -> { if ((victim.getHealth() - event.getFinalDamage()) / maxHealth(victim) * 100 <= effect.number("threshold", 30)) victim.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, (int) Math.round(effect.scaled("duration-ticks", level, 60)), effect.integer("amplifier", 0), true, true, true)); }
                    case "SNEAK_REDUCTION" -> { if (victim.isSneaking()) event.setDamage(event.getDamage() * (1 - effect.scaled("percent", level, 5) / 100)); }
                    case "NEARBY_ALLY_REDUCTION" -> {
                        long allies = victim.getNearbyEntities(effect.number("radius", 6), effect.number("radius", 6), effect.number("radius", 6)).stream()
                                .filter(Player.class::isInstance).map(Player.class::cast).filter(other -> isAlly(victim, other)).limit(effect.integer("max-allies", 4)).count();
                        if (allies > 0) event.setDamage(event.getDamage() * (1 - allies * effect.scaled("percent-per-ally", level, 2) / 100));
                    }
                    case "PROJECTILE_REDUCTION" -> { if (event.getDamager() instanceof Projectile) event.setDamage(event.getDamage() * (1 - effect.scaled("percent", level, 5) / 100)); }
                    case "RETALIATE" -> {
                        if (attacker != null && !attacker.equals(victim)) {
                            syntheticDamage = true;
                            try { attacker.damage(effect.scaled("damage", level, 0.5), victim); }
                            finally { syntheticDamage = false; }
                        }
                    }
                }
            }
        });
    }

    private void applyKillEffects(Player killer, LivingEntity victim, List<ItemStack> drops, EnchantDefinition definition, int level) {
        for (EnchantDefinition.EffectDefinition effect : definition.effects()) {
            switch (effect.type()) {
                case "VICTIM_HEALTH_HEAL" -> heal(killer, Math.min(effect.number("max-heal", 8), maxHealth(victim) * effect.scaled("percent", level, 1) / 100));
                case "DUPLICATE_RANDOM_DROP" -> { if (!drops.isEmpty()) { ItemStack copy = drops.get(ThreadLocalRandom.current().nextInt(drops.size())).clone(); copy.setAmount(Math.max(1, effect.integer("amount", 1) + (int) Math.floor(effect.number("amount-per-level", 0) * Math.max(0, level - 1)))); drops.add(copy); } }
                case "AOE_ON_KILL" -> aoeDamage(killer, victim, effect, level);
                case "ELITE_SKILL_XP" -> { if (isElite(victim, effect)) skills.addXp(killer, effect.text("skill", "combat"), "ELITE_KILL", effect.scaled("amount", level, 25)); }
                case "MULTIKILL_HEAL" -> multikillHeal(killer, effect, level);
                case "KILL_ABSORPTION" -> killer.setAbsorptionAmount(Math.min(effect.scaled("max-absorption", level, 4),
                        killer.getAbsorptionAmount() + effect.scaled("amount", level, 0.5)));
            }
        }
    }

    private void forEachProc(Player player, ItemStack item, String trigger, ProcConsumer consumer) {
        for (var entry : enchants.get(item).entrySet()) {
            EnchantDefinition definition = configs.get().enchants().get(entry.getKey());
            if (definition == null || !definition.enabled() || !definition.trigger().equals(trigger)) continue;
            if (ThreadLocalRandom.current().nextDouble(100) >= definition.procChance(entry.getValue())) continue;
            if (!cooldowns.tryUse(player.getUniqueId(), definition.id(), definition.cooldownMs())) continue;
            consumer.accept(definition, entry.getValue());
            Bukkit.getPluginManager().callEvent(new CustomEnchantProcEvent(player, definition.id(), entry.getValue(), item));
        }
    }

    private double comboDamage(Player attacker, LivingEntity target, String enchant, int level, EnchantDefinition.EffectDefinition effect, double damage) {
        String key = attacker.getUniqueId() + ":" + target.getUniqueId() + ":" + enchant;
        long now = System.currentTimeMillis();
        Combo previous = combos.get(key);
        int stack = previous == null || now - previous.updated > effect.integer("reset-ms", 3000) ? 0 : previous.stacks + 1;
        int max = effect.integer("max-stacks", 3) + effect.integer("max-stacks-per-level", 0) * (level - 1);
        stack = Math.min(stack, max);
        combos.put(key, new Combo(stack, now));
        return damage * (1 + stack * effect.scaled("percent-per-stack", level, 2) / 100);
    }

    private double markDamage(Player attacker, LivingEntity target, String enchant, double damage, EnchantDefinition.EffectDefinition effect, int level) {
        String key = attacker.getUniqueId() + ":" + target.getUniqueId() + ":" + enchant;
        long now = System.currentTimeMillis();
        Mark mark = marks.get(key);
        int stacks = mark == null || mark.expires < now ? 1 : Math.min(effect.integer("max-stacks", 4), mark.stacks + 1);
        marks.put(key, new Mark(stacks, now + effect.integer("duration-ms", 5000)));
        return damage * (1 + Math.max(0, stacks - 1) * effect.scaled("percent-per-stack", level, 3) / 100);
    }

    private void delayedDamage(Player attacker, LivingEntity target, double damage, int ticks) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!target.isValid() || target.isDead()) return;
            syntheticDamage = true;
            try { target.damage(Math.max(0, damage), attacker); }
            finally { syntheticDamage = false; }
        }, Math.max(1, ticks));
    }

    private void gravityWell(Player attacker, LivingEntity target, EnchantDefinition.EffectDefinition effect, int level) {
        double radius = effect.scaled("radius", level, 3); double strength = effect.scaled("strength", level, 0.3);
        nearbyLiving(target, radius, attacker).stream().limit(effect.integer("max-targets", 10)).forEach(entity -> {
            Vector pull = target.getLocation().toVector().subtract(entity.getLocation().toVector()).normalize().multiply(strength);
            entity.setVelocity(entity.getVelocity().add(pull));
        });
    }

    private void ricochet(Player attacker, LivingEntity target, double damage, EnchantDefinition.EffectDefinition effect, int level) {
        nearbyLiving(target, effect.scaled("radius", level, 4), attacker).stream().filter(entity -> !entity.equals(target)).findFirst().ifPresent(next ->
                delayedDamage(attacker, next, damage * effect.scaled("percent", level, 25) / 100, effect.integer("delay-ticks", 2)));
    }

    private void radialKnockback(Player center, EnchantDefinition.EffectDefinition effect, int level) {
        double radius = effect.scaled("radius", level, 3); double strength = effect.scaled("strength", level, 0.6);
        nearbyLiving(center, radius, center).stream().limit(effect.integer("max-targets", 12)).forEach(entity -> {
            Vector direction = entity.getLocation().toVector().subtract(center.getLocation().toVector());
            if (direction.lengthSquared() > 0.001) entity.setVelocity(direction.normalize().multiply(strength).setY(0.25));
        });
    }

    private void healLowestAlly(Player player, EnchantDefinition.EffectDefinition effect, int level) {
        player.getNearbyEntities(effect.scaled("radius", level, 6), effect.scaled("radius", level, 6), effect.scaled("radius", level, 6)).stream()
                .filter(Player.class::isInstance).map(Player.class::cast).min(Comparator.comparingDouble(p -> p.getHealth() / maxHealth(p)))
                .ifPresent(ally -> heal(ally, effect.scaled("amount", level, 1)));
    }

    private void aoeDamage(Player killer, LivingEntity victim, EnchantDefinition.EffectDefinition effect, int level) {
        syntheticDamage = true;
        try { nearbyLiving(victim, effect.scaled("radius", level, 3), killer).stream().limit(effect.integer("max-targets", 10))
                .forEach(entity -> entity.damage(effect.scaled("damage", level, 2), killer)); }
        finally { syntheticDamage = false; }
    }

    private void multikillHeal(Player killer, EnchantDefinition.EffectDefinition effect, int level) {
        long now = System.currentTimeMillis(); KillStreak old = killStreaks.get(killer.getUniqueId());
        int kills = old == null || now - old.updated > effect.integer("window-ms", 5000) ? 1 : old.kills + 1;
        killStreaks.put(killer.getUniqueId(), new KillStreak(kills, now));
        if (kills >= effect.integer("kills", 3)) heal(killer, effect.scaled("amount", level, 2));
    }

    private void recordCombatKill(Player killer) {
        long now = System.currentTimeMillis();
        KillStreak old = combatKillStreaks.get(killer.getUniqueId());
        int kills = old == null || now - old.updated > 15_000 ? 1 : old.kills + 1;
        combatKillStreaks.put(killer.getUniqueId(), new KillStreak(kills, now));
    }

    private boolean isBehind(Player attacker, LivingEntity target, double threshold) {
        Vector facing = target.getLocation().getDirection().setY(0);
        Vector towardAttacker = attacker.getLocation().toVector().subtract(target.getLocation().toVector()).setY(0);
        if (facing.lengthSquared() < 0.001 || towardAttacker.lengthSquared() < 0.001) return false;
        return facing.normalize().dot(towardAttacker.normalize()) <= threshold;
    }

    private boolean isAirborne(Player player) {
        return player.getFallDistance() > 0.0f || Math.abs(player.getVelocity().getY()) > 0.08;
    }

    private boolean isAlly(Player first, Player second) {
        var team = first.getScoreboard().getEntryTeam(first.getName());
        return team != null && team.hasEntry(second.getName());
    }

    private void magnet(Player player, EnchantDefinition.EffectDefinition effect, int level) {
        double radius = effect.scaled("radius", level, 3);
        player.getNearbyEntities(radius, radius, radius).stream().filter(Item.class::isInstance).map(Item.class::cast)
                .limit(effect.integer("max-items", 30)).forEach(item -> {
                    Vector delta = player.getEyeLocation().toVector().subtract(item.getLocation().toVector());
                    if (delta.lengthSquared() > 0.1) item.setVelocity(delta.normalize().multiply(0.35));
                });
    }

    private boolean isElite(LivingEntity victim, EnchantDefinition.EffectDefinition effect) {
        return maxHealth(victim) >= effect.number("minimum-health", 40) || victim.getScoreboardTags().contains("incogrpg_elite") || victim instanceof Boss;
    }
    private int skillLevel(Player player, String id) { return data.getOrCreate(player.getUniqueId(), player.getName()).progress(id).level(); }
    private List<LivingEntity> nearbyLiving(LivingEntity center, double radius, Entity exclude) {
        return center.getNearbyEntities(radius, radius, radius).stream().filter(LivingEntity.class::isInstance).map(LivingEntity.class::cast)
                .filter(entity -> !entity.equals(exclude) && !entity.equals(center) && !(entity instanceof ArmorStand)).toList();
    }
    private void heal(Player player, double amount) { if (amount > 0) player.setHealth(Math.min(maxHealth(player), player.getHealth() * 1.0 + amount * (1 + stats.value(player, "CUSTOM_HEALING_POWER") / 100.0))); }
    private static double missingHealth(LivingEntity entity) { return (1 - entity.getHealth() / maxHealth(entity)) * 100.0; }
    private static double maxHealth(LivingEntity entity) { var instance = entity.getAttribute(Attribute.MAX_HEALTH); return instance == null ? Math.max(1, entity.getHealth()) : Math.max(1, instance.getValue()); }
    private static Player attacker(Entity damager) { if (damager instanceof Player p) return p; if (damager instanceof Projectile projectile) { ProjectileSource source = projectile.getShooter(); if (source instanceof Player p) return p; } return null; }
    private record Combo(int stacks, long updated) {}
    private record Mark(int stacks, long expires) {}
    private record KillStreak(int kills, long updated) {}
    @FunctionalInterface private interface ProcConsumer { void accept(EnchantDefinition definition, int level); }
}

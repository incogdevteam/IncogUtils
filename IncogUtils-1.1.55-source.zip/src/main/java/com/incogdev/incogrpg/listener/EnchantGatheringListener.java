package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.api.event.CustomEnchantProcEvent;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.EnchantDefinition;
import com.incogdev.incogrpg.service.CooldownService;
import com.incogdev.incogrpg.service.EnchantService;
import com.incogdev.incogrpg.service.SkillService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class EnchantGatheringListener implements Listener {
    private final ConfigManager configs;
    private final EnchantService enchants;
    private final CooldownService cooldowns;
    private final SkillService skills;
    private final Map<UUID, OreStreak> oreStreaks = new HashMap<>();
    private final Map<UUID, Set<ChunkKey>> surveyed = new HashMap<>();

    public EnchantGatheringListener(ConfigManager configs, EnchantService enchants, CooldownService cooldowns, SkillService skills) {
        this.configs = configs; this.enchants = enchants; this.cooldowns = cooldowns; this.skills = skills;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (configs.get().disabledWorld(player.getWorld().getName())) return;
        ItemStack tool = player.getInventory().getItemInMainHand();
        for (var entry : enchants.get(tool).entrySet()) {
            EnchantDefinition definition = configs.get().enchants().get(entry.getKey());
            if (!proc(player, definition, entry.getValue(), "BLOCK_BREAK")) continue;
            for (EnchantDefinition.EffectDefinition effect : definition.effects()) {
                switch (effect.type()) {
                    case "ORE_STREAK_DROPS" -> oreStreak(event, effect, entry.getValue());
                    case "SOURCE_XP_BURST" -> skills.awardSource(player, "BLOCK_BREAK", event.getBlock().getType().name(), effect.scaled("multiplier", entry.getValue(), 2));
                    case "FIRST_ORE_CHUNK_DROPS" -> firstOre(event, effect, entry.getValue());
                }
            }
            Bukkit.getPluginManager().callEvent(new CustomEnchantProcEvent(player, definition.id(), entry.getValue(), tool));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH || configs.get().disabledWorld(event.getPlayer().getWorld().getName())) return;
        ItemStack rod = event.getPlayer().getInventory().getItemInMainHand();
        for (var entry : enchants.get(rod).entrySet()) {
            EnchantDefinition definition = configs.get().enchants().get(entry.getKey());
            if (!proc(event.getPlayer(), definition, entry.getValue(), "FISH_CATCH")) continue;
            for (EnchantDefinition.EffectDefinition effect : definition.effects()) {
                if (effect.type().equals("RARE_CATCH_XP") && isRareCatch(event))
                    skills.addXp(event.getPlayer(), "fishing", "TROPHY_CATCH", effect.scaled("amount", entry.getValue(), 10));
            }
            Bukkit.getPluginManager().callEvent(new CustomEnchantProcEvent(event.getPlayer(), definition.id(), entry.getValue(), rod));
        }
    }

    private void oreStreak(BlockBreakEvent event, EnchantDefinition.EffectDefinition effect, int level) {
        if (!event.getBlock().getType().name().endsWith("_ORE")) { oreStreaks.remove(event.getPlayer().getUniqueId()); return; }
        long now = System.currentTimeMillis(); OreStreak old = oreStreaks.get(event.getPlayer().getUniqueId());
        int stacks = old == null || now - old.updated > effect.integer("reset-ms", 4000) ? 1 : old.stacks + 1;
        stacks = Math.min(stacks, effect.integer("max-stacks", 10));
        oreStreaks.put(event.getPlayer().getUniqueId(), new OreStreak(stacks, now));
        double chance = stacks * effect.scaled("chance-per-stack", level, 1.5);
        if (ThreadLocalRandom.current().nextDouble(100) < chance) duplicateDrops(event, 1);
    }

    private void firstOre(BlockBreakEvent event, EnchantDefinition.EffectDefinition effect, int level) {
        if (!event.getBlock().getType().name().endsWith("_ORE")) return;
        ChunkKey key = new ChunkKey(event.getBlock().getWorld().getUID(), event.getBlock().getChunk().getX(), event.getBlock().getChunk().getZ());
        if (!surveyed.computeIfAbsent(event.getPlayer().getUniqueId(), ignored -> new HashSet<>()).add(key)) return;
        if (ThreadLocalRandom.current().nextDouble(100) < effect.scaled("chance", level, 25)) duplicateDrops(event, 1);
    }

    private void duplicateDrops(BlockBreakEvent event, int copies) {
        ItemStack tool = event.getPlayer().getInventory().getItemInMainHand();
        event.getBlock().getDrops(tool, event.getPlayer()).forEach(drop -> {
            ItemStack extra = drop.clone(); extra.setAmount(Math.min(extra.getMaxStackSize(), extra.getAmount() * copies));
            event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), extra);
        });
    }

    private boolean proc(Player player, EnchantDefinition definition, int level, String trigger) {
        return definition != null && definition.enabled() && definition.trigger().equals(trigger)
                && ThreadLocalRandom.current().nextDouble(100) < definition.procChance(level)
                && cooldowns.tryUse(player.getUniqueId(), definition.id(), definition.cooldownMs());
    }

    private boolean isRareCatch(PlayerFishEvent event) {
        if (!(event.getCaught() instanceof Item item)) return true;
        Material type = item.getItemStack().getType();
        return type != Material.COD && type != Material.SALMON && type != Material.PUFFERFISH && type != Material.TROPICAL_FISH;
    }
    private record OreStreak(int stacks, long updated) {}
    private record ChunkKey(UUID world, int x, int z) {}
}

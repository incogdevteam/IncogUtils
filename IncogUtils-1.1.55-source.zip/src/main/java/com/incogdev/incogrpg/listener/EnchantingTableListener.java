package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.EnchantDefinition;
import com.incogdev.incogrpg.service.EnchantService;
import com.incogdev.incogrpg.util.Messages;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class EnchantingTableListener implements Listener {
    private final ConfigManager configs;
    private final EnchantService enchants;
    private final Messages messages;

    public EnchantingTableListener(ConfigManager configs, EnchantService enchants, Messages messages) {
        this.configs = configs;
        this.enchants = enchants;
        this.messages = messages;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEnchantBook(EnchantItemEvent event) {
        var core = configs.get().core();
        if (!core.getBoolean("enchanting.enchanting-table.enabled", true)) return;
        ItemStack item = event.getItem();
        if (item.getType() != Material.BOOK || !enchants.get(item).isEmpty()) return;

        List<EnchantDefinition> rolled = new ArrayList<>();
        for (String id : core.getStringList("enchanting.enchanting-table.eligible-enchants")) {
            EnchantDefinition definition = configs.get().enchants().get(id.toLowerCase(java.util.Locale.ROOT));
            if (!eligible(definition, core)) continue;
            double chance = core.getDouble("enchanting.enchanting-table.rarity-chances." + definition.rarity(), 0.0);
            if (chance > 0 && ThreadLocalRandom.current().nextDouble(100.0) < chance) rolled.add(definition);
        }
        if (rolled.isEmpty()) return;

        EnchantDefinition chosen = rolled.get(ThreadLocalRandom.current().nextInt(rolled.size()));
        int level = Math.min(chosen.maxLevel(), Math.max(1, event.getExpLevelCost()));
        if (enchants.apply(item, chosen, level, true) != EnchantService.ApplyResult.SUCCESS) return;

        ItemMeta meta = item.getItemMeta();
        meta.displayName(messages.raw("<white>Enchanted Book <dark_gray>• " + chosen.displayName() + " " + EnchantService.roman(level)));
        item.setItemMeta(meta);
    }

    private boolean eligible(EnchantDefinition definition, org.bukkit.configuration.file.YamlConfiguration core) {
        if (definition == null || !definition.enabled()) return false;
        String rarity = definition.rarity().toUpperCase(java.util.Locale.ROOT);
        return !rarity.equals("LEGENDARY") && !rarity.equals("MYTHIC")
                && core.getDouble("enchanting.enchanting-table.rarity-chances." + rarity, 0.0) > 0;
    }
}

package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.service.StatService;
import com.incogdev.incogrpg.service.EnchantService;
import com.incogdev.incogrpg.service.ReforgeService;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.plugin.Plugin;

public final class EquipmentListener implements Listener {
    private final Plugin plugin;
    private final StatService stats;
    private final EnchantService enchants;
    private final ReforgeService reforges;
    public EquipmentListener(Plugin plugin, StatService stats, EnchantService enchants, ReforgeService reforges) {
        this.plugin = plugin; this.stats = stats; this.enchants = enchants; this.reforges = reforges;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) { if (event.getWhoClicked() instanceof Player player) update(player); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onClose(InventoryCloseEvent event) { if (event.getPlayer() instanceof Player player) update(player); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHeld(PlayerItemHeldEvent event) { update(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent event) { update(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onBreak(PlayerItemBreakEvent event) { update(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) { update(event.getPlayer()); }

    private void update(Player player) { Bukkit.getScheduler().runTask(plugin, () -> {
        if (!player.isOnline()) return;
        for (var item : player.getInventory().getContents()) { enchants.migrate(item); reforges.migrate(item); }
        stats.recompute(player);
    }); }
}

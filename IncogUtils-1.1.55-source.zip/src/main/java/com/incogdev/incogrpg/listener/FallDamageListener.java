package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.IncogRpgPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * Restores normal fall events when another listener cancelled them earlier in the Bukkit event
 * pipeline. It is deliberately configurable per world for servers that keep a no-fall-damage hub.
 */
public final class FallDamageListener implements Listener {
    private final IncogRpgPlugin plugin;

    public FallDamageListener(IncogRpgPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onFall(EntityDamageEvent event) {
        if (!plugin.configs().get().core().getBoolean("fall-damage.enforce", true)
                || event.getCause() != EntityDamageEvent.DamageCause.FALL
                || !(event.getEntity() instanceof Player player)) return;
        boolean excluded = plugin.configs().get().core().getStringList("fall-damage.excluded-worlds").stream()
                .filter(world -> world != null && !world.isBlank())
                .anyMatch(world -> world.trim().equalsIgnoreCase(player.getWorld().getName()));
        if (!excluded) event.setCancelled(false);
    }
}

package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.integration.VaultEconomyBridge;
import com.incogdev.incogrpg.menu.MenuService;
import com.incogdev.incogrpg.menu.RpgMenuHolder;
import com.incogdev.incogrpg.model.CustomItemDefinition;
import com.incogdev.incogrpg.model.ReforgeDefinition;
import com.incogdev.incogrpg.model.SkillDefinition;
import com.incogdev.incogrpg.service.ReforgeService;
import com.incogdev.incogrpg.service.StatService;
import com.incogdev.incogrpg.service.AchievementService;
import com.incogdev.incogrpg.service.PetService;
import com.incogdev.incogrpg.service.AccessoryService;
import com.incogdev.incogrpg.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class MenuListener implements Listener {
    private final Plugin plugin;
    private final ConfigManager configs;
    private final MenuService menus;
    private final ReforgeService reforges;
    private final StatService stats;
    private final PlayerDataService data;
    private final AchievementService achievements;
    private final PetService pets;
    private final AccessoryService accessories;
    private final Messages messages;
    private final VaultEconomyBridge vault;
    private volatile boolean reforgeFailureLogged;

    public MenuListener(Plugin plugin, ConfigManager configs, MenuService menus, ReforgeService reforges,
                        StatService stats, PlayerDataService data, AchievementService achievements,
                        PetService pets, AccessoryService accessories, Messages messages, VaultEconomyBridge vault) {
        this.plugin = plugin; this.configs = configs; this.menus = menus; this.reforges = reforges;
        this.stats = stats; this.data = data; this.achievements = achievements; this.pets = pets;
        this.accessories = accessories; this.messages = messages; this.vault = vault;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof RpgMenuHolder holder) || !(event.getWhoClicked() instanceof Player player)) return;
        if (holder.type() == RpgMenuHolder.Type.REFORGE) { handleReforgeClick(event, player, holder); return; }
        if (holder.type() == RpgMenuHolder.Type.ACCESSORY_BAG) { handleAccessoryClick(event, player, holder); return; }
        event.setCancelled(true);
        int slot = event.getRawSlot();
        switch (holder.type()) {
            case MENU_HUB -> menus.handleMenuHubClick(player, holder.page(), slot);
            case PLAYER_SETTINGS -> menus.handlePlayerSettingsClick(player, slot);
            case ADMIN_SETTINGS -> menus.handleAdminSettingsClick(player, slot);
            case ENCHANTS -> {
                if (slot == 45) {
                    if (holder.page() > 0) menus.openEnchants(player, holder.page() - 1);
                    else menus.openMenuHub(player);
                }
                if (slot == 53) menus.openEnchants(player, holder.page() + 1);
            }
            case SKILLS -> handleSkills(player, holder, slot);
            case DAILY_REWARDS -> menus.handleDailyRewardsClick(player, holder.page(), slot);
            case SKILL_TREE -> handleSkillTree(player, holder, slot);
            case STATS -> handleStats(player, holder, slot);
            case ITEMS -> handleItems(player, holder, slot);
            case ACHIEVEMENTS -> handleAchievements(player, holder, slot);
            case PETS -> handlePets(player, holder, slot);
            case ITEM_DETAIL -> {
                if (slot == 40) menus.openItems(player, holder.page());
            }
            default -> { }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof RpgMenuHolder holder)) return;
        if (holder.type() != RpgMenuHolder.Type.REFORGE) { event.setCancelled(true); return; }
        // Drag distribution inside a custom inventory is client/server desync-prone. Players can
        // still insert with a normal click or shift-click, both handled transactionally below.
        if (event.getRawSlots().stream().anyMatch(slot -> slot < event.getView().getTopInventory().getSize()))
            event.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof RpgMenuHolder holder) || holder.type() != RpgMenuHolder.Type.REFORGE || !(event.getPlayer() instanceof Player player)) return;
        returnInput(player, event.getInventory());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) { recoverOpenReforgeInput(event.getPlayer()); }

    /** Called on quit, inventory close, and plugin shutdown. Safe to call repeatedly. */
    public void recoverOpenReforgeInput(Player player) {
        Inventory top = player.getOpenInventory().getTopInventory();
        if (!(top.getHolder() instanceof RpgMenuHolder holder)
                || holder.type() != RpgMenuHolder.Type.REFORGE) return;
        returnInput(player, top);
    }

    private void handleReforgeClick(InventoryClickEvent event, Player player, RpgMenuHolder holder) {
        Inventory top = event.getView().getTopInventory();
        if (!holder.context().equals(player.getUniqueId().toString())) {
            event.setCancelled(true);
            return;
        }
        if (event.getRawSlot() == 18) {
            event.setCancelled(true);
            returnInput(player, top);
            menus.openMenuHub(player);
            return;
        }
        if (event.getRawSlot() == MenuService.REFORGE_BUTTON_SLOT) {
            event.setCancelled(true);
            try { roll(player, top); }
            catch (LinkageError | RuntimeException error) { reforgeFailure(player, error); }
            return;
        }
        if (event.getRawSlot() >= 0 && event.getRawSlot() < top.getSize()) {
            event.setCancelled(true);
            if (event.getRawSlot() == MenuService.REFORGE_ITEM_SLOT) {
                if (event.isShiftClick()) returnInput(player, top);
                else if (event.isLeftClick() || event.isRightClick()) swapInputAndCursor(event, top);
                menus.updateReforgeButton(top);
            }
            return;
        }
        if (event.isShiftClick() && event.getClickedInventory() == player.getInventory()) {
            event.setCancelled(true);
            if (empty(top.getItem(MenuService.REFORGE_ITEM_SLOT)) && !empty(event.getCurrentItem())) {
                // Never share the same mutable ItemStack instance between two inventories.
                top.setItem(MenuService.REFORGE_ITEM_SLOT, event.getCurrentItem().clone());
                event.setCurrentItem(null);
            }
            menus.updateReforgeButton(top);
            return;
        }
        // A bottom-inventory double-click can otherwise collect matching stacks out of the custom
        // top inventory even though the clicked slot is not in it.
        if (event.getAction() == InventoryAction.COLLECT_TO_CURSOR) {
            event.setCancelled(true);
            return;
        }
        Bukkit.getScheduler().runTask(plugin, () -> menus.updateReforgeButton(top));
    }

    private void swapInputAndCursor(InventoryClickEvent event, Inventory top) {
        ItemStack input = top.getItem(MenuService.REFORGE_ITEM_SLOT);
        ItemStack cursor = event.getCursor();
        top.setItem(MenuService.REFORGE_ITEM_SLOT, empty(cursor) ? null : cursor.clone());
        event.setCursor(empty(input) ? null : input.clone());
    }

    private void returnInput(Player player, Inventory inventory) {
        ItemStack input = inventory.getItem(MenuService.REFORGE_ITEM_SLOT);
        if (empty(input)) return;
        ItemStack delivery = input.clone();
        try {
            Map<Integer, ItemStack> overflow = player.getInventory().addItem(delivery);
            inventory.setItem(MenuService.REFORGE_ITEM_SLOT, null);
            overflow.values().forEach(drop -> player.getWorld().dropItemNaturally(player.getLocation(), drop));
        } catch (RuntimeException error) {
            // A closing inventory cannot be trusted to retain escrow forever. Fall back to a world
            // drop and clear only after Bukkit confirms that the entity was spawned.
            try {
                player.getWorld().dropItemNaturally(player.getLocation(), delivery);
                inventory.setItem(MenuService.REFORGE_ITEM_SLOT, null);
            } catch (RuntimeException fallbackError) {
                // Keep the original in escrow if both delivery paths fail. Never clear first.
                error.addSuppressed(fallbackError);
            }
            if (!reforgeFailureLogged) {
                reforgeFailureLogged = true;
                plugin.getLogger().warning("Could not return a reforge-menu item to " + player.getName()
                        + "; inventory delivery failed and a safe world-drop fallback was attempted: "
                        + error.getClass().getSimpleName());
            }
        }
    }

    private void handleSkills(Player viewer, RpgMenuHolder holder, int slot) {
        Player target = online(holder.context());
        if (target == null) return;
        if (slot == 45) { menus.openMenuHub(viewer); return; }
        SkillDefinition definition = menus.skillAtSkillsMenuSlot(slot);
        if (definition != null) menus.openSkill(viewer, target, definition);
    }

    private void handleSkillTree(Player viewer, RpgMenuHolder holder, int slot) {
        String[] context = holder.context().split(":", 2);
        if (context.length != 2) return;
        Player target = online(context[0]);
        SkillDefinition definition = configs.get().skills().get(context[1]);
        if (target == null || definition == null) return;
        if (slot == 45) {
            if (holder.page() > 0) menus.openSkill(viewer, target, definition, holder.page() - 1);
            else menus.openSkills(viewer, target);
        }
        if (slot == 49) menus.openStats(viewer, target, 0);
        if (slot == 53) menus.openSkill(viewer, target, definition, holder.page() + 1);
    }

    private void handleStats(Player viewer, RpgMenuHolder holder, int slot) {
        Player target = online(holder.context());
        if (target == null) return;
        if (slot == 45) {
            if (holder.page() > 0) menus.openStats(viewer, target, holder.page() - 1);
            else menus.openMenuHub(viewer);
        }
        if (slot == 53) menus.openStats(viewer, target, holder.page() + 1);
    }

    private void handleItems(Player viewer, RpgMenuHolder holder, int slot) {
        if (slot == 45) {
            if (holder.page() > 0) menus.openItems(viewer, holder.page() - 1);
            else menus.openMenuHub(viewer);
            return;
        }
        if (slot == 53) { menus.openItems(viewer, holder.page() + 1); return; }
        int index = contentIndex(slot);
        if (index < 0) return;
        var definitions = menus.enabledItems();
        int position = holder.page() * MenuService.CONTENT.length + index;
        if (position < definitions.size()) menus.openItem(viewer, definitions.get(position), holder.page());
    }

    private void handleAchievements(Player viewer, RpgMenuHolder holder, int slot) {
        Player target = online(holder.context());
        if (target == null) return;
        if (slot == 45) {
            if (holder.page() > 0) menus.openAchievements(viewer, target, holder.page() - 1);
            else menus.openMenuHub(viewer);
        }
        if (slot == 53) menus.openAchievements(viewer, target, holder.page() + 1);
    }

    private void handlePets(Player player, RpgMenuHolder holder, int slot) {
        if (slot == 45) {
            if (holder.page() > 0) menus.openPets(player, holder.context(), holder.page() - 1);
            else menus.openMenuHub(player);
            return;
        }
        if (slot == 46) { menus.openPets(player, menus.adjacentPetSkillFilter(holder.context(), -1), 0); return; }
        if (slot == 47) { menus.openPets(player, "all", 0); return; }
        if (slot == 48) { menus.openPets(player, menus.adjacentPetSkillFilter(holder.context(), 1), 0); return; }
        if (slot == 49) { pets.dismiss(player); menus.openPets(player, holder.context(), holder.page()); return; }
        if (slot == 53) { menus.openPets(player, holder.context(), holder.page() + 1); return; }
        int index = contentIndex(slot);
        if (index < 0) return;
        var definitions = pets.definitions(holder.context());
        int position = holder.page() * MenuService.CONTENT.length + index;
        if (position >= definitions.size()) return;
        var definition = definitions.get(position);
        if (data.getOrCreate(player.getUniqueId(), player.getName()).activePetId().equals(definition.id())) pets.dismiss(player);
        else {
            PetService.SummonResult result = pets.summon(player, definition.id());
            if (result == PetService.SummonResult.DISABLED) messages.send(player, "pets-disabled");
            if (result == PetService.SummonResult.LOCKED) messages.send(player, "pet-locked", Map.of("pet", definition.displayName(),
                    "skill", definition.skill(), "level", definition.unlockSkillLevel()));
        }
        menus.openPets(player, holder.context(), holder.page());
    }

    private void handleAccessoryClick(InventoryClickEvent event, Player player, RpgMenuHolder holder) {
        Inventory top = event.getView().getTopInventory();
        if (!holder.context().equals(player.getUniqueId().toString())) { event.setCancelled(true); return; }
        int raw = event.getRawSlot();
        if (raw == 18) { event.setCancelled(true); menus.openMenuHub(player); return; }
        if (raw >= 0 && raw < top.getSize()) {
            event.setCancelled(true);
            int bagSlot = menus.accessoryIndex(raw);
            if (bagSlot < 0) return;
            ItemStack cursor = event.getCursor();
            ItemStack stored = accessories.get(player, bagSlot);
            if (empty(cursor)) {
                if (empty(stored)) return;
                accessories.set(player, bagSlot, null);
                event.setCursor(stored.clone());
                accessoryChanged(player, top);
                return;
            }
            AccessoryService.SetResult result = accessories.set(player, bagSlot, cursor.clone());
            if (result != AccessoryService.SetResult.SUCCESS) { accessoryError(player, result); return; }
            event.setCursor(empty(stored) ? null : stored.clone());
            accessoryChanged(player, top);
            return;
        }
        if (event.isShiftClick() && event.getClickedInventory() == player.getInventory()) {
            event.setCancelled(true);
            ItemStack current = event.getCurrentItem();
            if (empty(current)) return;
            int destination = -1;
            for (int slot = 0; slot < accessories.slots(); slot++) if (empty(accessories.get(player, slot))) { destination = slot; break; }
            if (destination < 0) { messages.send(player, "accessory-bag-full"); return; }
            AccessoryService.SetResult result = accessories.set(player, destination, current.clone());
            if (result != AccessoryService.SetResult.SUCCESS) { accessoryError(player, result); return; }
            event.setCurrentItem(null);
            accessoryChanged(player, top);
            return;
        }
        if (event.getAction() == InventoryAction.COLLECT_TO_CURSOR) event.setCancelled(true);
    }

    private void accessoryChanged(Player player, Inventory top) {
        stats.recompute(player);
        data.saveAsync(data.getOrCreate(player.getUniqueId(), player.getName()), false);
        menus.refreshAccessories(player, top);
    }

    private void accessoryError(Player player, AccessoryService.SetResult result) {
        switch (result) {
            case DISABLED -> messages.send(player, "accessories-disabled");
            case NOT_ACCESSORY -> messages.send(player, "accessory-invalid");
            case DUPLICATE -> messages.send(player, "accessory-duplicate");
            case ONE_AT_A_TIME -> messages.send(player, "accessory-one-at-a-time");
            default -> messages.send(player, "accessory-invalid");
        }
    }

    private Player online(String uuid) {
        try { return Bukkit.getPlayer(UUID.fromString(uuid)); }
        catch (IllegalArgumentException ignored) { return null; }
    }

    private static int contentIndex(int slot) {
        for (int i = 0; i < MenuService.CONTENT.length; i++) if (MenuService.CONTENT[i] == slot) return i;
        return -1;
    }

    private void roll(Player player, Inventory inventory) {
        ItemStack input = inventory.getItem(MenuService.REFORGE_ITEM_SLOT);
        if (input == null || input.getType().isAir()) { messages.send(player, "reforge-no-item"); return; }
        Optional<ReforgeDefinition> rolled = reforges.roll(input);
        if (rolled.isEmpty()) { messages.send(player, "reforge-no-options"); return; }
        ReforgeDefinition definition = rolled.get(); double cost = reforges.cost(input, definition);
        // Build the result on a clone. A failed apply can never corrupt or consume the escrowed input.
        ItemStack result = input.clone();
        if (!reforges.apply(result, definition)) { messages.send(player, "reforge-no-options"); return; }
        if (!charge(player, cost)) return;
        inventory.setItem(MenuService.REFORGE_ITEM_SLOT, result);
        stats.recompute(player);
        menus.updateReforgeButton(inventory);
        try { achievements.add(player, "REFORGES_APPLIED", definition.id(), 1); }
        catch (RuntimeException error) {
            if (!reforgeFailureLogged) {
                reforgeFailureLogged = true;
                plugin.getLogger().warning("The reforge succeeded, but achievement progress could not be recorded ("
                        + error.getClass().getSimpleName() + ").");
            }
        }
        messages.send(player, "reforge-success", Map.of("reforge", definition.displayName(), "cost", format(cost)));
        if (definition.rarity().equals("MYTHIC") && configs.get().reforgeSettings().announceMythic())
            Bukkit.broadcast(messages.raw("<gradient:#F472B6:#8B5CF6><bold>" + player.getName() + " rolled " + definition.displayName() + "!</bold></gradient>"));
    }

    private void reforgeFailure(Player player, Throwable error) {
        messages.send(player, "reforge-menu-error");
        if (reforgeFailureLogged) return;
        reforgeFailureLogged = true;
        plugin.getLogger().warning("A reforge-menu action failed safely; the input item was preserved ("
                + error.getClass().getSimpleName() + (error.getMessage() == null ? "" : ": " + error.getMessage()) + ").");
    }

    private static boolean empty(ItemStack item) { return item == null || item.getType().isAir(); }

    private boolean charge(Player player, double cost) {
        return switch (configs.get().reforgeSettings().costType()) {
            case "FREE" -> true;
            case "VAULT" -> {
                if (!vault.available() || !vault.charge(player, cost)) { messages.send(player, "reforge-insufficient-money", Map.of("cost", format(cost))); yield false; }
                yield true;
            }
            default -> {
                int levels = (int) Math.ceil(cost);
                if (player.getLevel() < levels) { messages.send(player, "reforge-insufficient-xp", Map.of("cost", levels)); yield false; }
                player.setLevel(player.getLevel() - levels); yield true;
            }
        };
    }
    private static String format(double value) { return String.format(java.util.Locale.US, "%.2f", value); }
}

package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.EnchantDefinition;
import com.incogdev.incogrpg.service.EnchantService;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class NaturalEnchantDropListener implements Listener {
    private final ConfigManager configs;
    private final EnchantService enchants;
    private final Map<UUID, Map<EntityType, Integer>> killsByPlayerAndMob = new HashMap<>();

    public NaturalEnchantDropListener(ConfigManager configs, EnchantService enchants) {
        this.configs = configs;
        this.enchants = enchants;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLoot(LootGenerateEvent event) {
        var core = configs.get().core();
        ConfigurationSection settings = core.getConfigurationSection("enchanting.natural-drops.mythic-loot");
        if (settings == null || !settings.getBoolean("enabled", false)) return;
        if (ThreadLocalRandom.current().nextDouble(100.0) >= settings.getDouble("chance", 1.0)) return;

        List<EnchantDefinition> candidates = definitions(settings.getStringList("enchants"), "MYTHIC");
        if (candidates.isEmpty()) return;
        EnchantDefinition chosen = candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
        event.getLoot().add(enchants.book(chosen, 1));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(EntityDeathEvent event) {
        if (event.getEntity().getKiller() == null) return;
        var core = configs.get().core();
        ConfigurationSection settings = core.getConfigurationSection("enchanting.natural-drops.legendary-mob");
        if (settings == null || !settings.getBoolean("enabled", false)) return;

        UUID playerId = event.getEntity().getKiller().getUniqueId();
        Map<EntityType, Integer> playerKills = killsByPlayerAndMob.computeIfAbsent(playerId, ignored -> new HashMap<>());
        int kills = playerKills.getOrDefault(event.getEntityType(), 0);
        double baseChance = settings.getDouble("base-chance", 0.01);
        double increment = settings.getDouble("increment-per-kill", 0.01);
        double maximum = settings.getDouble("max-chance", 5.0);
        ConfigurationSection routes = settings.getConfigurationSection("routes");
        if (routes == null) return;

        for (String id : routes.getKeys(false)) {
            ConfigurationSection route = routes.getConfigurationSection(id);
            if (route == null || !route.getStringList("entities").contains(event.getEntityType().name())) continue;
            EnchantDefinition definition = configs.get().enchants().get(id.toLowerCase(java.util.Locale.ROOT));
            if (definition == null || !definition.enabled() || !definition.rarity().equals("LEGENDARY")) continue;

            double chance = route.contains("fixed-chance")
                    ? route.getDouble("fixed-chance")
                    : Math.min(maximum, baseChance + kills * increment);
            if (ThreadLocalRandom.current().nextDouble(100.0) < chance) event.getDrops().add(enchants.book(definition, 1));
        }
        playerKills.put(event.getEntityType(), kills + 1);
    }

    private List<EnchantDefinition> definitions(List<String> ids, String rarity) {
        List<EnchantDefinition> result = new ArrayList<>();
        for (String id : ids) {
            EnchantDefinition definition = configs.get().enchants().get(id.toLowerCase(java.util.Locale.ROOT));
            if (definition != null && definition.enabled() && definition.rarity().equals(rarity)) result.add(definition);
        }
        return result;
    }
}

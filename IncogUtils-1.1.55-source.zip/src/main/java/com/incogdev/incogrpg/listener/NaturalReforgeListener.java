package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.ItemGroups;
import com.incogdev.incogrpg.model.ReforgeDefinition;
import com.incogdev.incogrpg.service.CustomItemService;
import com.incogdev.incogrpg.service.ReforgeService;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.ThreadLocalRandom;

/** Applies source-aware reforges to crafted equipment, mob equipment drops, and generated loot. */
public final class NaturalReforgeListener implements Listener {
    private static final String CRAFTING = "CRAFTING";
    private static final String MOB_DROP = "MOB_DROP";
    private static final String CHEST_LOOT = "CHEST_LOOT";

    private final ConfigManager configs;
    private final CustomItemService items;
    private final ReforgeService reforges;

    public NaturalReforgeListener(ConfigManager configs, CustomItemService items, ReforgeService reforges) {
        this.configs = configs;
        this.items = items;
        this.reforges = reforges;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        ConfigManager.NaturalSourceSettings settings = configs.get().naturalReforgeSettings().crafting();
        ItemStack current = event.getCurrentItem();
        ItemStack result = apply(current, CRAFTING, null, settings, CustomItemService.AcquisitionSource.RECIPE);
        if (result != current) event.setCurrentItem(result);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(EntityDeathEvent event) {
        ConfigManager.NaturalSourceSettings settings = configs.get().naturalReforgeSettings().mobDrops();
        if (settings.playerKillOnly() && event.getEntity().getKiller() == null) return;
        ListIterator<ItemStack> iterator = event.getDrops().listIterator();
        while (iterator.hasNext()) {
            ItemStack current = iterator.next();
            ItemStack result = apply(current, MOB_DROP, event.getEntityType(), settings,
                    CustomItemService.AcquisitionSource.MOB_DROP);
            if (result != current) iterator.set(result);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLoot(LootGenerateEvent event) {
        ConfigManager.NaturalSourceSettings settings = configs.get().naturalReforgeSettings().chestLoot();
        List<ItemStack> updated = new ArrayList<>(event.getLoot().size());
        for (ItemStack current : event.getLoot())
            updated.add(apply(current, CHEST_LOOT, null, settings, CustomItemService.AcquisitionSource.CHEST_LOOT));
        event.setLoot(updated);
    }

    private ItemStack apply(ItemStack current, String source, EntityType entityType,
                            ConfigManager.NaturalSourceSettings sourceSettings,
                            CustomItemService.AcquisitionSource acquisitionSource) {
        ConfigManager.NaturalReforgeSettings settings = configs.get().naturalReforgeSettings();
        if (!settings.enabled() || !sourceSettings.enabled() || current == null || current.getType().isAir()) return current;
        if (settings.equipmentOnly() && !ItemGroups.isEquipment(current.getType())) return current;
        var custom = items.definition(current);
        if (custom.isPresent() && (!sourceSettings.includeCustomItems() || !items.canAcquire(custom.get(), acquisitionSource)))
            return current;
        if (settings.preserveExistingReforges() && reforges.get(current).isPresent()) return current;
        if (ThreadLocalRandom.current().nextDouble(100) >= sourceSettings.chance()) return current;
        ReforgeDefinition definition = reforges.rollNatural(current, source, entityType).orElse(null);
        if (definition == null) return current;
        ItemStack result = current.clone();
        return reforges.apply(result, definition) ? result : current;
    }
}

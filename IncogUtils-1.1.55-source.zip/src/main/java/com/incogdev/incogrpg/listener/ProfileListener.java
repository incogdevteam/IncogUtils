package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.service.CooldownService;
import com.incogdev.incogrpg.service.StatService;
import com.incogdev.incogrpg.service.HudService;
import com.incogdev.incogrpg.service.AchievementService;
import com.incogdev.incogrpg.service.PetService;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

import java.sql.SQLException;

public final class ProfileListener implements Listener {
    private final Plugin plugin;
    private final PlayerDataService data;
    private final StatService stats;
    private final CooldownService cooldowns;
    private final HudService hud;
    private final AchievementService achievements;
    private final PetService pets;

    public ProfileListener(Plugin plugin, PlayerDataService data, StatService stats, CooldownService cooldowns,
                           HudService hud, AchievementService achievements) {
        this(plugin, data, stats, cooldowns, hud, achievements, null);
    }

    public ProfileListener(Plugin plugin, PlayerDataService data, StatService stats, CooldownService cooldowns,
                           HudService hud, AchievementService achievements, PetService pets) {
        this.plugin = plugin; this.data = data; this.stats = stats; this.cooldowns = cooldowns; this.hud = hud;
        this.achievements = achievements;
        this.pets = pets;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        try { data.load(event.getUniqueId(), event.getName()); }
        catch (SQLException ex) {
            plugin.getLogger().severe("Could not load " + event.getName() + "'s RPG profile: " + ex.getMessage());
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,
                    net.kyori.adventure.text.Component.text("Your RPG profile could not be loaded. Please try again."));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        data.getOrCreate(event.getPlayer().getUniqueId(), event.getPlayer().getName()).updateIdentity(event.getPlayer().getName());
        Bukkit.getScheduler().runTask(plugin, () -> {
            stats.recompute(event.getPlayer());
            achievements.bootstrap(event.getPlayer());
            if (pets != null) pets.bootstrap(event.getPlayer());
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        hud.clear(event.getPlayer());
        stats.clear(event.getPlayer());
        cooldowns.clear(event.getPlayer().getUniqueId());
        if (pets != null) pets.removeVisual(event.getPlayer());
        data.unload(event.getPlayer().getUniqueId());
    }
}

package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.CustomItemDefinition;
import com.incogdev.incogrpg.model.ReforgeDefinition;
import com.incogdev.incogrpg.service.CustomItemService;
import com.incogdev.incogrpg.service.ReforgeService;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;

/** Applies non-rollable and optional regular reforges through configured custom-item catalysts. */
public final class ReforgeStoneListener implements Listener {
    private final ConfigManager configs;
    private final CustomItemService items;
    private final ReforgeService reforges;

    public ReforgeStoneListener(ConfigManager configs, CustomItemService items, ReforgeService reforges) {
        this.configs = configs;
        this.items = items;
        this.reforges = reforges;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPrepare(PrepareAnvilEvent event) {
        AnvilInventory inventory = event.getInventory();
        ItemStack base = inventory.getFirstItem();
        ItemStack catalyst = inventory.getSecondItem();
        if (base == null || base.getType().isAir() || catalyst == null || catalyst.getType().isAir()) return;
        CustomItemDefinition item = items.definition(catalyst).orElse(null);
        if (item == null || item.appliesReforge().isBlank()) return;
        ReforgeDefinition definition = configs.get().reforges().get(item.appliesReforge());
        if (definition == null || !definition.enabled() || !definition.supports(base.getType())) {
            event.setResult(null);
            return;
        }
        if (reforges.get(base).map(ReforgeDefinition::id).filter(definition.id()::equals).isPresent()) {
            event.setResult(null);
            return;
        }
        ItemStack result = base.clone();
        if (!reforges.apply(result, definition)) {
            event.setResult(null);
            return;
        }
        int cost = Math.max(0, item.anvilLevelCost());
        event.setResult(result);
        event.getView().setRepairItemCountCost(1);
        event.getView().setMaximumRepairCost(Math.max(event.getView().getMaximumRepairCost(), cost + 1));
        event.getView().setRepairCost(cost);
    }
}

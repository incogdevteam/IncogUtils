package com.incogdev.incogrpg.listener;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.service.SkillService;
import com.incogdev.incogrpg.service.StatService;
import org.bukkit.Chunk;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Tameable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityBreedEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTameEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.SmithItemEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;

import java.util.*;

public final class SkillXpListener implements Listener {
    private final ConfigManager configs;
    private final SkillService skills;
    private final StatService stats;
    private final Set<BlockKey> placedBlocks = Collections.synchronizedSet(new LinkedHashSet<>());
    private final Map<UUID, Double> movement = new HashMap<>();
    private final Map<UUID, Long> lastMovementAward = new HashMap<>();
    private final Map<UUID, Set<ChunkKey>> explored = new HashMap<>();

    public SkillXpListener(ConfigManager configs, SkillService skills, StatService stats) {
        this.configs = configs; this.skills = skills; this.stats = stats;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (ignore(event.getPlayer())) return;
        if (configs.get().core().getBoolean("anti-exploit.track-player-placed-blocks", true)) remember(new BlockKey(event.getBlockPlaced()));
        skills.awardSource(event.getPlayer(), "BLOCK_PLACE", event.getBlockPlaced().getType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (ignore(event.getPlayer())) return;
        BlockKey key = new BlockKey(event.getBlock());
        if (placedBlocks.remove(key)) return;
        double multiplier = 1;
        if (event.getBlock().getBlockData() instanceof Ageable ageable && ageable.getAge() < ageable.getMaximumAge()) multiplier = 0;
        skills.awardSource(event.getPlayer(), "BLOCK_BREAK", event.getBlock().getType().name(), multiplier);
        applyFortune(event);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        EntityDamageEvent cause = event.getEntity().getLastDamageCause();
        Player petOwner = cause instanceof EntityDamageByEntityEvent petDamage && petDamage.getDamager() instanceof Tameable pet
                && pet.getOwner() instanceof Player owner ? owner : null;
        if (killer == null && petOwner == null) return;
        if (killer != null && ignore(killer)) return;
        boolean projectile = cause instanceof EntityDamageByEntityEvent damage && damage.getDamager() instanceof Projectile;
        if (killer != null) skills.awardSource(killer, projectile ? "PROJECTILE_KILL" : "ENTITY_KILL", event.getEntityType().name(), 1);
        if (petOwner != null && !ignore(petOwner)) skills.awardSource(petOwner, "PET_KILL", event.getEntityType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        Player attacker = attacker(event.getDamager());
        if (attacker != null && !ignore(attacker)) {
            String target = event.getDamager() instanceof Projectile ? "PROJECTILE" : "MELEE";
            skills.awardSource(attacker, "DAMAGE_DEALT", target, Math.min(event.getFinalDamage(), 50));
        }
        if (event.getEntity() instanceof Player victim && !ignore(victim))
            skills.awardSource(victim, "DAMAGE_TAKEN", event.getCause().name(), Math.min(event.getFinalDamage(), 50));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFall(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player && event.getCause() == EntityDamageEvent.DamageCause.FALL && !ignore(player)
                && event.getFinalDamage() < player.getHealth())
            skills.awardSource(player, "FALL_SURVIVED", "FALL", Math.min(event.getFinalDamage(), 30));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH || ignore(event.getPlayer())) return;
        String target = event.getCaught() == null ? "UNKNOWN" : event.getCaught().getType().name();
        skills.awardSource(event.getPlayer(), "FISH_CATCH", target, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEnchant(EnchantItemEvent event) {
        if (!ignore(event.getEnchanter())) skills.awardSource(event.getEnchanter(), "ENCHANT_ITEM", event.getItem().getType().name(), Math.max(1, event.getExpLevelCost()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (event.getWhoClicked() instanceof Player player && event.getRecipe() != null && !ignore(player)) {
            ItemStack result = event.getRecipe().getResult();
            skills.awardSource(player, "CRAFT_ITEM", result.getType().name(), Math.min(64, result.getAmount()));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSmith(SmithItemEvent event) {
        if (event.getWhoClicked() instanceof Player player && !ignore(player)) skills.awardSource(player, "SMITH_ITEM", "SMITHING", 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAnvil(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player && event.getInventory().getType() == InventoryType.ANVIL
                && event.getRawSlot() == 2 && event.getCurrentItem() != null && !ignore(player))
            skills.awardSource(player, "ANVIL_USE", event.getCurrentItem().getType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTame(EntityTameEvent event) {
        if (event.getOwner() instanceof Player player && !ignore(player)) skills.awardSource(player, "ENTITY_TAME", event.getEntityType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreed(EntityBreedEvent event) {
        if (event.getBreeder() instanceof Player player && !ignore(player)) skills.awardSource(player, "ENTITY_BREED", event.getEntityType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent event) {
        Material material = event.getItem().getType();
        if (!ignore(event.getPlayer()) && (material == Material.POTION || material == Material.MILK_BUCKET || material == Material.HONEY_BOTTLE))
            skills.awardSource(event.getPlayer(), "CONSUME_POTION", material.name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!event.hasChangedPosition() || ignore(event.getPlayer())) return;
        Player player = event.getPlayer();
        if (event.getFrom().getWorld() != event.getTo().getWorld()) return;
        double distance = Math.min(4, event.getFrom().distance(event.getTo()));
        movement.merge(player.getUniqueId(), distance, Double::sum);
        long now = System.currentTimeMillis();
        long interval = configs.get().core().getLong("anti-exploit.movement-xp-interval-ticks", 100) * 50L;
        double minimum = configs.get().core().getDouble("anti-exploit.movement-xp-minimum-distance", 12);
        double accumulated = movement.getOrDefault(player.getUniqueId(), 0.0);
        if (accumulated >= minimum && now - lastMovementAward.getOrDefault(player.getUniqueId(), 0L) >= interval) {
            skills.awardSource(player, "MOVEMENT", "FOOT", accumulated / minimum);
            movement.put(player.getUniqueId(), 0.0); lastMovementAward.put(player.getUniqueId(), now);
        }
        Chunk chunk = event.getTo().getChunk();
        ChunkKey key = new ChunkKey(chunk.getWorld().getUID(), chunk.getX(), chunk.getZ());
        if (explored.computeIfAbsent(player.getUniqueId(), ignored -> new HashSet<>()).add(key))
            skills.awardSource(player, "DISCOVER_CHUNK", chunk.getWorld().getEnvironment().name(), 1);
    }

    private void applyFortune(BlockBreakEvent event) {
        String material = event.getBlock().getType().name();
        double fortune;
        if (material.endsWith("_ORE")) fortune = stats.value(event.getPlayer(), "CUSTOM_MINING_FORTUNE");
        else if (material.endsWith("_LOG") || material.endsWith("_STEM") || material.equals("MANGROVE_ROOTS")) fortune = stats.value(event.getPlayer(), "CUSTOM_WOODCUTTING_FORTUNE");
        else if (isCrop(material)) fortune = stats.value(event.getPlayer(), "CUSTOM_FARMING_FORTUNE");
        else fortune = 0;
        if (fortune <= 0 || !event.isDropItems()) return;
        int guaranteed = (int) (fortune / 100.0);
        double remainder = fortune % 100.0;
        int copies = guaranteed + (Math.random() * 100 < remainder ? 1 : 0);
        if (copies <= 0) return;
        for (ItemStack drop : event.getBlock().getDrops(event.getPlayer().getInventory().getItemInMainHand(), event.getPlayer())) {
            ItemStack extra = drop.clone(); extra.setAmount(Math.min(extra.getMaxStackSize(), extra.getAmount() * copies));
            event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), extra);
        }
    }

    private static boolean isCrop(String material) {
        return Set.of("WHEAT", "CARROTS", "POTATOES", "BEETROOTS", "NETHER_WART", "COCOA", "MELON", "PUMPKIN",
                "SUGAR_CANE", "CACTUS", "BAMBOO", "SWEET_BERRY_BUSH").contains(material);
    }

    private boolean ignore(Player player) {
        return configs.get().disabledWorld(player.getWorld().getName()) ||
                (configs.get().core().getBoolean("anti-exploit.ignore-creative-mode", true) && player.getGameMode() == GameMode.CREATIVE);
    }
    private void remember(BlockKey key) {
        placedBlocks.add(key);
        int max = configs.get().core().getInt("anti-exploit.placed-block-cache-limit", 250000);
        synchronized (placedBlocks) { while (placedBlocks.size() > max) placedBlocks.remove(placedBlocks.iterator().next()); }
    }
    private static Player attacker(Entity damager) {
        if (damager instanceof Player player) return player;
        if (damager instanceof Projectile projectile) { ProjectileSource source = projectile.getShooter(); if (source instanceof Player player) return player; }
        return null;
    }
    private record BlockKey(UUID world, int x, int y, int z) { BlockKey(org.bukkit.block.Block b) { this(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ()); } }
    private record ChunkKey(UUID world, int x, int z) {}
}

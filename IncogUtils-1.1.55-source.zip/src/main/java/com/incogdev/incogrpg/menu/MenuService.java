package com.incogdev.incogrpg.menu;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.model.*;
import com.incogdev.incogrpg.service.CustomItemService;
import com.incogdev.incogrpg.service.AchievementService;
import com.incogdev.incogrpg.service.ReforgeService;
import com.incogdev.incogrpg.service.StatService;
import com.incogdev.incogrpg.service.PetService;
import com.incogdev.incogrpg.service.AccessoryService;
import com.incogdev.incogrpg.util.Messages;
import com.incogdev.incogutils.maintenance.MaintenanceManager;
import com.incogdev.incogutils.settings.PlayerSettingsManager;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import com.destroystokyo.paper.profile.ProfileProperty;

import java.nio.charset.StandardCharsets;
import java.util.*;

public final class MenuService { // IncogUtils menu presentation
    private static final List<String> SKILL_DISPLAY_ORDER = List.of(
            "combat", "mining", "woodcutting", "excavation", "farming", "archery", "defense");
    private static final List<String> DAILY_RANK_TABS = List.of("secret", "unknown", "ominous", "cryptic", "incog", "incog+");
    public static final int REFORGE_ITEM_SLOT = 11;
    public static final int REFORGE_BUTTON_SLOT = 15;
    public static final int[] CONTENT = {10,11,12,13,14,15,16,19,20,21,22,23,24,25,28,29,30,31,32,33,34,37,38,39,40,41,42,43};
    private final IncogRpgPlugin host;
    private final ConfigManager configs;
    private final PlayerDataService data;
    private final StatService stats;
    private final ReforgeService reforges;
    private final CustomItemService customItems;
    private final AchievementService achievements;
    private final PetService pets;
    private final AccessoryService accessories;
    private final Messages messages;

    public MenuService(IncogRpgPlugin host, ConfigManager configs, PlayerDataService data, StatService stats, ReforgeService reforges,
                       CustomItemService customItems, AchievementService achievements, PetService pets,
                       AccessoryService accessories, Messages messages) {
        this.host = host;
        this.configs = configs;
        this.data = data;
        this.stats = stats;
        this.reforges = reforges;
        this.customItems = customItems;
        this.achievements = achievements;
        this.pets = pets;
        this.accessories = accessories;
        this.messages = messages;
    }

    /** Opens the two-page navigation hub for every player-facing IncogUtils feature. */
    public void openMenuHub(Player player) { openMenuHub(player, 0); }

    public void openMenuHub(Player player, int requestedPage) {
        int page = Math.max(0, Math.min(1, requestedPage));
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.MENU_HUB, "", page);
        Inventory inv = Bukkit.createInventory(holder, 36, Component.text("Main Menu • " + (page + 1) + "/2"));
        holder.attach(inv);

        if (page == 0) populatePlayerHub(inv, player);
        else populateUtilityHub(inv, player);

        if (page > 0) inv.setItem(27, item(Material.ARROW, "<yellow>Player Menus", List.of(messages.raw("<gray>Return to RPG, claims, and economy menus."))));
        if (page < 1) inv.setItem(35, item(Material.ARROW, "<yellow>Utilities & Staff", List.of(messages.raw("<gray>Open the remaining IncogUtils tools."))));
        player.openInventory(inv);
    }

    /** Called by the shared menu listener after it has safely cancelled the inventory click. */
    public void handleMenuHubClick(Player player, int page, int slot) {
        if (slot == 27 && page > 0) { openMenuHub(player, page - 1); return; }
        if (slot == 35 && page < 1) { openMenuHub(player, page + 1); return; }
        if (page == 0) handlePlayerHubClick(player, slot);
        else handleUtilityHubClick(player, slot);
    }

    private void populatePlayerHub(Inventory inv, Player player) {
        hubButton(inv, player, 1, Material.EXPERIENCE_BOTTLE, "<gradient:#22D3EE:#A78BFA>Skills</gradient>", List.of("<gray>Skill levels, reward trees, and progress."), "incogrpg.use", featureAvailable(player, "rpg"));
        hubButton(inv, player, 2, Material.NETHER_STAR, "<gradient:#FDE047:#A78BFA>Stats</gradient>", List.of("<gray>Every active stat and its source breakdown."), "incogrpg.use", featureAvailable(player, "rpg"));
        hubButton(inv, player, 3, Material.TOTEM_OF_UNDYING, "<gradient:#FDE047:#F97316>Achievements</gradient>", List.of("<gray>Advancement tree, requirements, and rewards."), "incogrpg.use", featureAvailable(player, "rpg"));
        hubButton(inv, player, 4, Material.BONE, "<gradient:#F9A8D4:#A78BFA>Pet Stable</gradient>", List.of("<gray>Skill pets, bonuses, and skill filters."), "incogrpg.pets", featureAvailable(player, "pets"));
        hubButton(inv, player, 5, Material.BUNDLE, "<gradient:#FDE047:#22D3EE>Accessory Bag</gradient>", List.of("<gray>Equip your three skill relics."), "incogrpg.accessories", accessories.enabled() && featureAvailable(player, "rpg"));
        hubButton(inv, player, 6, Material.SMITHING_TABLE, "<gradient:#FDE047:#A78BFA>Reforge Station</gradient>", List.of("<gray>Roll or reroll equipment reforges."), "incogrpg.reforge", configs.get().reforgeSettings().enabled() && featureAvailable(player, "rpg"));
        hubButton(inv, player, 7, Material.NETHER_STAR, "<gradient:#F472B6:#22D3EE>Custom Item Codex</gradient>", List.of("<gray>Items, recipes, drops, and obtainment."), "incogrpg.use", featureAvailable(player, "rpg"));
        hubButton(inv, player, 10, Material.ENCHANTED_BOOK, "<gradient:#C084FC:#22D3EE>Enchant Codex</gradient>", List.of("<gray>Browse IncogRPG's unique enchantments."), "incogrpg.use", featureAvailable(player, "rpg"));
        hubButton(inv, player, 11, Material.BEACON, "<gradient:#A855F7:#EC4899>Claims</gradient>", List.of("<gray>Claim management, members, flags, and cores."), "incogclaims.use", host.claimsModuleAvailable() && featureAvailable(player, "claims"));
        hubButton(inv, player, 12, Material.DIAMOND_SWORD, "<gradient:#FB7185:#F97316>PVP Protection</gradient>", List.of("<gray>Toggle your personal PVP protection."), "incogclaims.use", host.claimsModuleAvailable() && featureAvailable(player, "pvp"));
        hubButton(inv, player, 13, Material.EMERALD, "<gradient:#4ADE80:#FDE047>Market</gradient>", List.of("<gray>Browse live prices and market categories."), "incogshop.market", host.economyModuleAvailable() && featureAvailable(player, "market"));
        hubButton(inv, player, 14, Material.HOPPER, "<gradient:#FDE047:#FB7185>Bulk Sell</gradient>", List.of("<gray>Sell eligible inventory items quickly."), "incogshop.sell", host.economyModuleAvailable() && featureAvailable(player, "market"));
        hubButton(inv, player, 15, Material.GOLD_INGOT, "<gradient:#FDE047:#F97316>Auction House</gradient>", List.of("<gray>Browse server auctions and claimed items."), "incogshop.auction", host.economyModuleAvailable() && featureAvailable(player, "auctions"));
        hubButton(inv, player, 16, Material.CHEST, "<gradient:#22D3EE:#4ADE80>Player Shops</gradient>", List.of("<gray>Open the player-shop command tools."), "incogshop.playershop", host.economyModuleAvailable() && featureAvailable(player, "player_shops"));
        hubButton(inv, player, 21, Material.COMPARATOR, "<gradient:#22D3EE:#A78BFA>Player Settings</gradient>", List.of("<gray>Choose your HUD and notification preferences."), "incogutils.settings", true);
        hubButton(inv, player, 22, Material.CLOCK, "<gradient:#FDE047:#22D3EE>Daily Rewards</gradient>", List.of("<gray>View your rank-based daily rewards."), "incogshop.daily", host.economyModuleAvailable());
        hubButton(inv, player, 23, Material.FIREWORK_STAR, "<gradient:#F472B6:#C084FC>UltraCosmetics</gradient>", List.of("<gray>Open cosmetic gadgets, pets, effects, and more."), "ultracosmetics.openmenu", ultraCosmeticsAvailable());
    }

    private void populateUtilityHub(Inventory inv, Player player) {
        hubButton(inv, player, 1, Material.EXPERIENCE_BOTTLE, "<gradient:#A78BFA:#22D3EE>XP Vault</gradient>", List.of("<gray>Deposit and withdraw stored experience."), "incogshop.xpvault", host.economyModuleAvailable() && featureAvailable(player, "market"));
        hubButton(inv, player, 2, Material.BARREL, "<gradient:#FDE047:#22D3EE>Overflow Stash</gradient>", List.of("<gray>Recover items saved by economy systems."), "incogshop.stash", host.economyModuleAvailable() && featureAvailable(player, "market"));
        hubButton(inv, player, 3, Material.ENCHANTING_TABLE, "<gradient:#C084FC:#F472B6>The Hex</gradient>", List.of("<gray>Upgrade the item held in your main hand."), "incogshop.hex", host.economyModuleAvailable() && featureAvailable(player, "hex"));
        hubButton(inv, player, 4, Material.ANVIL, "<gradient:#FF9D2E:#FF4D6D>ItemForge</gradient>", List.of("<gray>Create, edit, and manage ItemForge items."), "itemforge.admin", host.itemForgeModuleAvailable() && featureAvailable(player, "itemforge"));
        hubButton(inv, player, 5, Material.PLAYER_HEAD, "<gradient:#22D3EE:#A78BFA>Secure Trade</gradient>", List.of("<gray>Start a trade with <white>/trade <player></white>."), "incogshop.trade", host.economyModuleAvailable() && featureAvailable(player, "trading"));
        hubButton(inv, player, 6, Material.COMPARATOR, "<gradient:#FB7185:#FDE047>Macro Alerts</gradient>", List.of("<gray>Toggle staff alerts from AntiMacro."), "incogantimacro.alerts", host.antiMacroModuleAvailable() && featureAvailable(player, "antimacro"));
        hubButton(inv, player, 7, Material.REDSTONE, "<gradient:#F97316:#FDE047>Economy Admin</gradient>", List.of("<gray>Open the market administration GUI."), "incogshop.admin.gui", host.economyModuleAvailable() && featureAvailable(player, "market"));
        hubButton(inv, player, 10, Material.COMMAND_BLOCK, "<gradient:#FB7185:#A78BFA>AntiMacro Console</gradient>", List.of("<gray>View AntiMacro administration commands."), "incogantimacro.admin", host.antiMacroModuleAvailable() && featureAvailable(player, "antimacro"));
        hubButton(inv, player, 11, Material.CLOCK, "<gradient:#22D3EE:#FDE047>Reload IncogUtils</gradient>", List.of("<gray>Reload all IncogUtils modules safely."), "incogrpg.admin.reload", featureAvailable(player, "rpg"));
        hubButton(inv, player, 12, Material.REPEATER, "<gradient:#FB7185:#A78BFA>Admin Settings</gradient>", List.of("<gray>Enable or disable IncogUtils features."), "incogutils.settings.admin", true);
    }

    private void handlePlayerHubClick(Player player, int slot) {
        switch (slot) {
            case 1 -> openHubInternal(player, "rpg", "incogrpg.use", () -> openSkills(player, player));
            case 2 -> openHubInternal(player, "rpg", "incogrpg.use", () -> openStats(player, player, 0));
            case 3 -> openHubInternal(player, "rpg", "incogrpg.use", () -> openAchievements(player, player, 0));
            case 4 -> openHubInternal(player, "pets", "incogrpg.pets", () -> openPets(player, "all", 0));
            case 5 -> runHubCommand(player, "accessories", "incogrpg.accessories", accessories.enabled() && featureAvailable(player, "rpg"), "Accessory Bag");
            case 6 -> runHubCommand(player, "reforge", "incogrpg.reforge", configs.get().reforgeSettings().enabled() && featureAvailable(player, "rpg"), "Reforge Station");
            case 7 -> openHubInternal(player, "rpg", "incogrpg.use", () -> openItems(player, 0));
            case 10 -> openHubInternal(player, "rpg", "incogrpg.use", () -> openEnchants(player, 0));
            case 11 -> runHubCommand(player, "claims", "incogclaims.use", host.claimsModuleAvailable() && featureAvailable(player, "claims"), "Claims");
            case 12 -> runHubCommand(player, "pvp", "incogclaims.use", host.claimsModuleAvailable() && featureAvailable(player, "pvp"), "PVP Protection");
            case 13 -> runHubCommand(player, "market", "incogshop.market", host.economyModuleAvailable() && featureAvailable(player, "market"), "Market");
            case 14 -> runHubCommand(player, "sell", "incogshop.sell", host.economyModuleAvailable() && featureAvailable(player, "market"), "Bulk Sell");
            case 15 -> runHubCommand(player, "ah", "incogshop.auction", host.economyModuleAvailable() && featureAvailable(player, "auctions"), "Auction House");
            case 16 -> runHubCommand(player, "pshop list", "incogshop.playershop", host.economyModuleAvailable() && featureAvailable(player, "player_shops"), "Player Shops");
            case 21 -> openHubInternal(player, "incogutils.settings", () -> openPlayerSettings(player));
            case 22 -> openHubInternal(player, "incogshop.daily", () -> openDailyRewards(player, 0));
            case 23 -> runHubCommand(player, "uc menu", "ultracosmetics.openmenu", ultraCosmeticsAvailable(), "UltraCosmetics");
            default -> { }
        }
    }

    private void handleUtilityHubClick(Player player, int slot) {
        switch (slot) {
            case 1 -> runHubCommand(player, "xpvault", "incogshop.xpvault", host.economyModuleAvailable() && featureAvailable(player, "market"), "XP Vault");
            case 2 -> runHubCommand(player, "stash", "incogshop.stash", host.economyModuleAvailable() && featureAvailable(player, "market"), "Overflow Stash");
            case 3 -> runHubCommand(player, "hex", "incogshop.hex", host.economyModuleAvailable() && featureAvailable(player, "hex"), "The Hex");
            case 4 -> runHubCommand(player, "itemforge", "itemforge.admin", host.itemForgeModuleAvailable() && featureAvailable(player, "itemforge"), "ItemForge");
            case 5 -> runHubCommand(player, "trade", "incogshop.trade", host.economyModuleAvailable() && featureAvailable(player, "trading"), "Secure Trade");
            case 6 -> runHubCommand(player, "antimacro alerts", "incogantimacro.alerts", host.antiMacroModuleAvailable() && featureAvailable(player, "antimacro"), "Macro Alerts");
            case 7 -> runHubCommand(player, "marketadmin gui", "incogshop.admin.gui", host.economyModuleAvailable() && featureAvailable(player, "market"), "Economy Admin");
            case 10 -> runHubCommand(player, "antimacro", "incogantimacro.admin", host.antiMacroModuleAvailable() && featureAvailable(player, "antimacro"), "AntiMacro Console");
            case 11 -> runHubCommand(player, "reload", "incogrpg.admin.reload", featureAvailable(player, "rpg"), "Reload");
            case 12 -> openHubInternal(player, "incogutils.settings.admin", () -> openAdminSettings(player));
            default -> { }
        }
    }

    private void hubButton(Inventory inv, Player player, int slot, Material icon, String title, List<String> description,
                           String permission, boolean moduleAvailable) {
        boolean allowed = permission.isBlank() || player.hasPermission(permission);
        List<Component> lore = new ArrayList<>();
        description.forEach(line -> lore.add(messages.raw(line)));
        lore.add(Component.empty());
        if (!moduleAvailable) lore.add(messages.raw("<red>This module is disabled or unavailable."));
        else if (!allowed) lore.add(messages.raw("<red>Requires <white>" + permission));
        else lore.add(messages.raw("<yellow>Click to open"));
        inv.setItem(slot, item(moduleAvailable && allowed ? icon : Material.BARRIER,
                moduleAvailable && allowed ? title : "<red>Locked: </red>" + title, lore, true));
    }

    private void openHubInternal(Player player, String feature, String permission, Runnable action) {
        if (!featureAvailable(player, feature)) {
            player.sendMessage(host.featureSettings().message(feature));
            return;
        }
        if (!player.hasPermission(permission)) { messages.send(player, "no-permission"); return; }
        player.closeInventory();
        Bukkit.getScheduler().runTask(host, () -> { if (player.isOnline()) action.run(); });
    }

    private void openHubInternal(Player player, String permission, Runnable action) {
        if (!player.hasPermission(permission)) { messages.send(player, "no-permission"); return; }
        player.closeInventory();
        Bukkit.getScheduler().runTask(host, () -> { if (player.isOnline()) action.run(); });
    }

    private boolean featureAvailable(Player player, String feature) {
        return !host.featureSettings().blocked(player, feature);
    }

    private void runHubCommand(Player player, String command, String permission, boolean moduleAvailable, String feature) {
        if (!moduleAvailable) {
            player.sendMessage(messages.raw("<red>" + feature + " is currently disabled or unavailable."));
            return;
        }
        if (!player.hasPermission(permission)) { messages.send(player, "no-permission"); return; }
        player.closeInventory();
        Bukkit.getScheduler().runTask(host, () -> { if (player.isOnline()) player.performCommand(command); });
    }

    /** Optional integration: IncogUtils remains loadable when UltraCosmetics is absent. */
    private boolean ultraCosmeticsAvailable() {
        return Bukkit.getPluginManager().isPluginEnabled("UltraCosmetics");
    }

    public void openPlayerSettings(Player player) {
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.PLAYER_SETTINGS, player.getUniqueId().toString(), 0);
        Inventory inv = Bukkit.createInventory(holder, 36, Component.text("Player Settings"));
        holder.attach(inv);
        settingButton(inv, player, 11, Material.EXPERIENCE_BOTTLE, PlayerSettingsManager.Setting.SKILL_PROGRESS,
                "<gray>Show skill XP and progress on the action bar.");
        settingButton(inv, player, 12, Material.GOLDEN_APPLE, PlayerSettingsManager.Setting.HEALTH_DISPLAY,
                "<gray>Show numeric high-health on the action bar.");
        settingButton(inv, player, 13, Material.NETHER_STAR, PlayerSettingsManager.Setting.LEVEL_UP_NOTIFICATIONS,
                "<gray>Show chat and sound feedback when a skill levels up.");
        settingButton(inv, player, 14, Material.TOTEM_OF_UNDYING, PlayerSettingsManager.Setting.ACHIEVEMENT_NOTIFICATIONS,
                "<gray>Show your achievement chat, title, and sound notifications.");
        settingButton(inv, player, 15, Material.DIAMOND_SWORD, PlayerSettingsManager.Setting.PVP_STATUS_DISPLAY,
                "<gray>Show your current PVP status on the action bar.");
        inv.setItem(35, item(Material.BARRIER, "<yellow>Back to /menus", List.of(messages.raw("<gray>Return to the IncogUtils Menu Hub."))));
        player.openInventory(inv);
    }

    public void openDailyRewards(Player player, int requestedTab) {
        if (!host.economyModuleAvailable()) return;
        int tab = Math.max(0, Math.min(DAILY_RANK_TABS.size() - 1, requestedTab));
        String rank = DAILY_RANK_TABS.get(tab);
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.DAILY_REWARDS, rank, tab);
        Inventory inv = Bukkit.createInventory(holder, 54, Component.text("Daily Rewards"));
        holder.attach(inv);
        for (int i = 0; i < DAILY_RANK_TABS.size(); i++) {
            String id = DAILY_RANK_TABS.get(i);
            String label = host.economyModule().getConfig().getString("daily-rewards.rank-rewards." + id + ".display-name", id);
            inv.setItem(i, item(dailyRankIcon(id),
                    (i == tab ? "<gold>" : "<white>") + label,
                    List.of(messages.raw(i == tab ? "<yellow>Selected rank tab" : "<gray>Click to view this rank's rewards")), true));
        }
        int days = host.economyModule().dailyRewards().cycleDays();
        for (int day = 1; day <= Math.min(days, 27); day++) {
            String path = "daily-rewards.rank-rewards." + rank + ".rewards." + day;
            var section = host.economyModule().getConfig().getConfigurationSection(path);
            List<Component> lore = new ArrayList<>();
            if (section == null) {
                lore.add(messages.raw("<gray>No rank-specific reward configured"));
                lore.add(messages.raw("<dark_gray>The server fallback reward may apply"));
            } else {
                double money = section.getDouble("money", 0.0D);
                if (money > 0) lore.add(messages.raw("<green>Money: <white>" + host.economyModule().money(money)));
                for (String reward : section.getStringList("items")) lore.add(messages.raw("<gray>Item: <white>" + reward));
                if (!section.getStringList("commands").isEmpty()) lore.add(messages.raw("<gray>Bonus commands: <white>" + section.getStringList("commands").size()));
            }
            lore.add(Component.empty());
            lore.add(messages.raw("<yellow>Rank: <white>" + rank));
            inv.setItem(9 + day - 1, item(section == null ? Material.GRAY_DYE : Material.CHEST,
                    "<aqua>Day " + day, lore, section != null));
        }
        inv.setItem(45, item(Material.BARRIER, "<yellow>Back to Main Menu", List.of()));
        inv.setItem(53, item(Material.EMERALD, "<green>Claim Today's Reward", List.of(messages.raw("<gray>Claims the reward for your actual rank.")), true));
        player.openInventory(inv);
    }

    public void handleDailyRewardsClick(Player player, int tab, int slot) {
        if (slot >= 0 && slot < DAILY_RANK_TABS.size()) { openDailyRewards(player, slot); return; }
        if (slot == 45) { openMenuHub(player); return; }
        if (slot == 53) { player.closeInventory(); player.performCommand("daily claim"); }
    }

    private Material dailyRankIcon(String rank) {
        return switch (rank.toLowerCase(Locale.ROOT)) {
            case "secret" -> Material.BRICKS;
            case "unknown" -> Material.PRISMARINE;
            case "ominous" -> Material.GRASS_BLOCK;
            case "cryptic" -> Material.OAK_SIGN;
            case "incog" -> Material.REDSTONE;
            case "incog+" -> Material.BOOKSHELF;
            default -> Material.NAME_TAG;
        };
    }

    public void handlePlayerSettingsClick(Player player, int slot) {
        PlayerSettingsManager.Setting setting = switch (slot) {
            case 11 -> PlayerSettingsManager.Setting.SKILL_PROGRESS;
            case 12 -> PlayerSettingsManager.Setting.HEALTH_DISPLAY;
            case 13 -> PlayerSettingsManager.Setting.LEVEL_UP_NOTIFICATIONS;
            case 14 -> PlayerSettingsManager.Setting.ACHIEVEMENT_NOTIFICATIONS;
            case 15 -> PlayerSettingsManager.Setting.PVP_STATUS_DISPLAY;
            default -> null;
        };
        if (slot == 35) { openMenuHub(player); return; }
        if (setting == null) return;
        host.playerSettings().toggle(player, setting);
        host.hud().clear(player);
        openPlayerSettings(player);
    }

    public void openAdminSettings(Player player) {
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.ADMIN_SETTINGS, "", 0);
        Inventory inv = Bukkit.createInventory(holder, 54, messages.raw("<gradient:#FB7185:#A78BFA><bold>Admin Feature Settings</bold></gradient>"));
        holder.attach(inv);
        fill(inv);
        boolean global = host.featureSettings().globalEnabled();
        inv.setItem(4, toggleItem(Material.REDSTONE_TORCH, "All IncogUtils Features", global,
                "<gray>Master player-access switch. Protections and data stay loaded."));
        for (int index = 0; index < MaintenanceManager.FEATURES.size() && index < CONTENT.length; index++) {
            String feature = MaintenanceManager.FEATURES.get(index);
            inv.setItem(CONTENT[index], toggleItem(featureIcon(feature), MaintenanceManager.pretty(feature),
                    host.featureSettings().featureEnabled(feature), "<gray>Controls player access to this feature."));
        }
        inv.setItem(49, backButton());
        player.openInventory(inv);
    }

    public void handleAdminSettingsClick(Player player, int slot) {
        if (!player.hasPermission("incogutils.settings.admin")) { messages.send(player, "no-permission"); player.closeInventory(); return; }
        if (slot == 49) { openMenuHub(player, 1); return; }
        if (slot == 4) {
            host.featureSettings().setGlobalEnabled(!host.featureSettings().globalEnabled());
            openAdminSettings(player);
            return;
        }
        int index = contentIndex(slot);
        if (index < 0 || index >= MaintenanceManager.FEATURES.size()) return;
        String feature = MaintenanceManager.FEATURES.get(index);
        host.featureSettings().setFeatureEnabled(feature, !host.featureSettings().featureEnabled(feature));
        openAdminSettings(player);
    }

    private void settingButton(Inventory inv, Player player, int slot, Material icon,
                               PlayerSettingsManager.Setting setting, String description) {
        inv.setItem(slot, toggleItem(icon, setting.label(), host.playerSettings().enabled(player, setting), description));
    }

    private ItemStack toggleItem(Material icon, String label, boolean enabled, String description) {
        return item(enabled ? icon : Material.GRAY_DYE, (enabled ? "<green>" : "<red>") + label + ": "
                + (enabled ? "Enabled" : "Disabled"), List.of(messages.raw(description), Component.empty(),
                messages.raw("<yellow>Click to " + (enabled ? "disable" : "enable"))), true);
    }

    private ItemStack backButton() {
        return item(Material.ARROW, "<yellow>Back to /menus", List.of(messages.raw("<gray>Return to the IncogUtils Menu Hub.")));
    }

    private static Material featureIcon(String feature) {
        return switch (feature) {
            case "rpg" -> Material.DIAMOND_SWORD;
            case "pets" -> Material.BONE;
            case "economy" -> Material.EMERALD;
            case "market" -> Material.GOLD_INGOT;
            case "player_shops" -> Material.CHEST;
            case "daily_rewards" -> Material.CLOCK;
            case "auctions" -> Material.ANVIL;
            case "trading" -> Material.PLAYER_HEAD;
            case "shopping_district" -> Material.BRICKS;
            case "claims" -> Material.CRYING_OBSIDIAN;
            case "pvp" -> Material.IRON_SWORD;
            case "homes" -> Material.RED_BED;
            case "itemforge" -> Material.SMITHING_TABLE;
            case "antimacro" -> Material.COMPARATOR;
            case "vaults" -> Material.TRIAL_KEY;
            case "hex" -> Material.ENCHANTING_TABLE;
            default -> Material.LEVER;
        };
    }

    public void openSkills(Player viewer, Player target) {
        String title = configuredTitle("menus.skills-title", "<gradient:#22D3EE:#A78BFA><player>'s Skills</gradient>",
                Map.of("player", target.getName()));
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.SKILLS, target.getUniqueId().toString(), 0);
        Inventory inv = Bukkit.createInventory(holder, 54, messages.raw(title));
        holder.attach(inv);
        PlayerProfile profile = data.getOrCreate(target.getUniqueId(), target.getName());
        int index = 0;
        for (SkillDefinition def : enabledSkills()) {
            if (isCenteredSkill(def)) continue;
            if (index >= CONTENT.length) break;
            putSkillButton(inv, profile, def, CONTENT[index++]);
        }
        // Keep the three requested utility skills together in the center row.
        int centeredSlot = 30;
        for (SkillDefinition def : enabledSkills()) {
            if (isCenteredSkill(def)) putSkillButton(inv, profile, def, centeredSlot++);
        }
        inv.setItem(4, profileItem(target, profile));
        inv.setItem(45, item(Material.BARRIER, "<yellow>Back to the Main Menu", List.of()));
        viewer.openInventory(inv);
    }

    private boolean isCenteredSkill(SkillDefinition definition) {
        return switch (definition.id().toLowerCase(Locale.ROOT)) {
            case "smithing", "exploration", "building" -> true;
            default -> false;
        };
    }

    private void putSkillButton(Inventory inv, PlayerProfile profile, SkillDefinition def, int slot) {
        SkillProgress progress = profile.progress(def.id());
        double required = progress.level() >= def.maxLevel() ? 0 : def.xpRequired(progress.level());
        double percent = required <= 0 ? 1 : Math.max(0, Math.min(1, progress.xp() / required));
        List<Component> lore = new ArrayList<>();
        def.description().forEach(line -> lore.add(messages.raw("<gray>" + line)));
        lore.add(Component.empty());
        lore.add(messages.raw("<gray>Level <white>" + progress.level() + "</white><dark_gray>/</dark_gray><gray>" + def.maxLevel()));
        lore.add(messages.raw(progressBar(percent, 14)));
        lore.add(messages.raw(progress.level() >= def.maxLevel() ? "<gold><bold>MAX LEVEL</bold>" :
                "<gray>XP <white>" + number(progress.xp()) + "</white><dark_gray>/</dark_gray><gray>" + number(required)));
        nextMilestone(def, progress.level()).ifPresent(entry -> lore.add(messages.raw(
                "<gray>Next milestone <gold>Level " + entry.getKey() + "</gold>")));
        lore.add(Component.empty());
        lore.add(messages.raw("<yellow>Click to open the level tree"));
        inv.setItem(slot, item(def.icon(), def.displayName(), lore, progress.level() >= def.maxLevel()));
    }

    public void openPets(Player player, String requestedSkill, int requestedPage) {
        String skill = requestedSkill == null || requestedSkill.isBlank() ? "all" : requestedSkill.toLowerCase(Locale.ROOT);
        List<PetDefinition> definitions = pets.definitions(skill);
        int pages = Math.max(1, (int) Math.ceil(definitions.size() / (double) CONTENT.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        String title = configuredTitle("menus.pets-title", "<gradient:#F9A8D4:#A78BFA>Pets</gradient> <dark_gray>•</dark_gray> <page>/<pages>",
                Map.of("page", page + 1, "pages", pages));
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.PETS, skill, page);
        Inventory inv = Bukkit.createInventory(holder, 54, messages.raw(title));
        holder.attach(inv);
        fill(inv);
        PlayerProfile profile = data.getOrCreate(player.getUniqueId(), player.getName());
        for (int i = 0; i < CONTENT.length; i++) {
            int position = page * CONTENT.length + i;
            if (position >= definitions.size()) break;
            PetDefinition definition = definitions.get(position);
            PetProgress progress = profile.petProgress(definition.id());
            boolean unlocked = pets.unlocked(player, definition);
            boolean active = profile.activePetId().equals(definition.id());
            double required = progress.level() >= definition.maxLevel() ? 0 : definition.xpRequired(progress.level());
            List<Component> lore = new ArrayList<>();
            definition.description().forEach(line -> lore.add(messages.raw("<gray>" + line)));
            lore.add(Component.empty());
            lore.add(messages.raw("<gray>Linked skill <white>" + pretty(definition.skill())));
            lore.add(messages.raw("<gray>Rarity <white>" + pretty(definition.rarity())));
            if (!definition.requiredPermission().isBlank())
                lore.add(messages.raw("<gray>Availability <gold>Rank-exclusive</gold>"));
            if (!definition.specialModifier().isBlank()) {
                lore.add(Component.empty());
                lore.add(messages.raw("<gradient:#FDE047:#A78BFA><bold>Exclusive Modifier</bold></gradient>"));
                lore.add(messages.raw("<gold>✦ " + pretty(definition.specialModifier()) + "</gold> <gray>" + specialModifierText(definition, progress.level())));
            }
            lore.add(messages.raw("<gray>Pet level <white>" + progress.level() + "</white><dark_gray>/</dark_gray><gray>" + definition.maxLevel()));
            if (required > 0) {
                lore.add(messages.raw(progressBar(progress.xp() / required, 12)));
                lore.add(messages.raw("<gray>Pet XP <white>" + number(progress.xp()) + "</white><dark_gray>/</dark_gray><gray>" + number(required)));
            }
            lore.add(Component.empty());
            lore.add(messages.raw("<gradient:#22D3EE:#A78BFA><bold>Active Bonuses</bold></gradient>"));
            definition.baseStats().forEach((stat, amount) -> lore.add(messages.raw("<dark_gray>  •</dark_gray> <gray>" + pretty(stat) + " " + coloredSigned(amount + definition.perLevelStats().getOrDefault(stat, 0.0) * progress.level()))));
            definition.perLevelStats().entrySet().stream().filter(entry -> !definition.baseStats().containsKey(entry.getKey()))
                    .forEach(entry -> lore.add(messages.raw("<dark_gray>  •</dark_gray> <gray>" + pretty(entry.getKey()) + " " + coloredSigned(entry.getValue() * progress.level()))));
            lore.add(messages.raw("<dark_gray>  •</dark_gray> <gray>" + pretty(definition.skill()) + " XP <green>+" + number(definition.skillXpBonus(progress.level())) + "%"));
            lore.add(Component.empty());
            String lockReason = definition.requiredPermission().isBlank()
                    ? "<red>Locked — reach " + pretty(definition.skill()) + " level " + definition.unlockSkillLevel()
                    : "<red>Locked — requires the " + pretty(rankName(definition.requiredPermission())) + " rank";
            lore.add(messages.raw(active ? "<green><bold>ACTIVE — click to dismiss</bold>" : unlocked ? "<yellow>Click to summon" : lockReason));
            inv.setItem(CONTENT[i], petHead(definition, (active ? "<green>✓ </green>" : "") + definition.displayName(), lore, active));
        }
        inv.setItem(4, item(Material.BONE, "<gradient:#F9A8D4:#A78BFA>Pet Stable</gradient>", List.of(
                messages.raw(pets.enabled() ? "<gray>Unlocked <white>" + profile.petProgressSnapshot().size() + "</white><dark_gray>/</dark_gray><gray>" + configs.get().pets().size()
                        : "<red>Disabled in pets.yml"),
                messages.raw("<gray>Only the active pet grants stats and matching skill XP.")), pets.enabled()));
        inv.setItem(45, page > 0 ? item(Material.ARROW, "<yellow>Previous Page", List.of()) : backButton());
        String previousFilter = adjacentPetSkillFilter(skill, -1);
        String nextFilter = adjacentPetSkillFilter(skill, 1);
        inv.setItem(46, item(Material.ARROW, "<yellow>Previous Skill Filter",
                List.of(messages.raw("<gray>Switch to <white>" + petFilterName(previousFilter)))));
        inv.setItem(47, item(petFilterIcon(skill), "<gradient:#22D3EE:#A78BFA>Skill Filter: " + petFilterName(skill) + "</gradient>",
                List.of(messages.raw("<gray>Showing <white>" + definitions.size() + "</white><gray> pets."), Component.empty(),
                        messages.raw("<yellow>Click to show all skills")), !skill.equals("all")));
        inv.setItem(48, item(Material.ARROW, "<yellow>Next Skill Filter",
                List.of(messages.raw("<gray>Switch to <white>" + petFilterName(nextFilter)))));
        inv.setItem(49, item(Material.BARRIER, "<red>Dismiss Active Pet", List.of(messages.raw("<gray>Keep its levels and unlock status."))));
        if (page + 1 < pages) inv.setItem(53, item(Material.ARROW, "<yellow>Next Page", List.of()));
        player.openInventory(inv);
    }

    public void openAccessories(Player player) {
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.ACCESSORY_BAG, player.getUniqueId().toString(), 0);
        Inventory inv = Bukkit.createInventory(holder, 27, messages.raw(configuredTitle("menus.accessories-title",
                "<gradient:#FDE047:#22D3EE>Accessory Bag</gradient>", Map.of())));
        holder.attach(inv);
        refreshAccessories(player, inv);
        player.openInventory(inv);
    }

    public void refreshAccessories(Player player, Inventory inv) {
        fill(inv);
        inv.setItem(4, item(Material.BUNDLE, "<gradient:#FDE047:#22D3EE><bold>Skill Relic Bag</bold></gradient>", List.of(
                messages.raw("<gray>Place one configured skill relic in each slot."),
                messages.raw("<gray>All three contribute their stats, passive enchants, and reforges."),
                messages.raw("<dark_gray>Contents save across restarts.")), true));
        int[] guiSlots = accessoryGuiSlots();
        for (int index = 0; index < guiSlots.length; index++) {
            ItemStack stored = accessories.get(player, index);
            inv.setItem(guiSlots[index], stored == null || stored.getType().isAir() ? item(Material.LIGHT_GRAY_STAINED_GLASS_PANE,
                    "<gray>Relic Slot " + (index + 1), List.of(messages.raw("<dark_gray>Click a SKILL_RELIC here or shift-click it below."))) : stored.clone());
        }
        inv.setItem(18, backButton());
        inv.setItem(22, statsItem(player));
    }

    public int[] accessoryGuiSlots() {
        int count = accessories.slots();
        if (count == 1) return new int[]{13};
        if (count == 2) return new int[]{12, 14};
        if (count == 3) return new int[]{11, 13, 15};
        int[] slots = new int[count];
        int start = 13 - count / 2;
        for (int i = 0; i < count; i++) slots[i] = start + i;
        return slots;
    }

    public int accessoryIndex(int rawSlot) {
        int[] slots = accessoryGuiSlots();
        for (int i = 0; i < slots.length; i++) if (slots[i] == rawSlot) return i;
        return -1;
    }

    public void openSkill(Player viewer, Player target, SkillDefinition definition) { openSkill(viewer, target, definition, 0); }

    public void openSkill(Player viewer, Player target, SkillDefinition definition, int requestedPage) {
        int pages = Math.max(1, (int) Math.ceil(definition.maxLevel() / (double) CONTENT.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        String title = configuredTitle("menus.skill-tree-title", "<skill> <dark_gray>•</dark_gray> <page>/<pages>", Map.of(
                "skill", definition.displayName(), "page", page + 1, "pages", pages));
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.SKILL_TREE,
                target.getUniqueId() + ":" + definition.id(), page);
        Inventory inv = Bukkit.createInventory(holder, 54, messages.raw(title));
        holder.attach(inv);
        fill(inv);
        SkillProgress progress = data.getOrCreate(target.getUniqueId(), target.getName()).progress(definition.id());
        int start = page * CONTENT.length + 1;
        for (int i = 0; i < CONTENT.length; i++) {
            int level = start + i;
            if (level > definition.maxLevel()) break;
            SkillDefinition.Milestone milestone = definition.milestones().get(level);
            boolean unlocked = progress.level() >= level;
            boolean next = progress.level() + 1 == level;
            boolean isMilestone = milestone != null;
            Material material = levelNodeMaterial(milestone, unlocked, next);
            String status = unlocked ? "<green>UNLOCKED" : next ? "<yellow>IN PROGRESS" : "<gray>LOCKED";
            List<Component> lore = new ArrayList<>();
            lore.add(messages.raw("<gray>XP required <white>" + number(definition.xpRequired(level - 1))));
            if (next) {
                double needed = definition.xpRequired(level - 1);
                lore.add(messages.raw(progressBar(needed <= 0 ? 1 : progress.xp() / needed, 12)));
                lore.add(messages.raw("<gray>Current XP <white>" + number(progress.xp()) + "</white><dark_gray>/</dark_gray><gray>" + number(needed)));
            }
            lore.add(Component.empty());
            lore.add(messages.raw("<gradient:#22D3EE:#A78BFA><bold>Level Rewards</bold></gradient>"));
            if (definition.perLevelStats().isEmpty()) lore.add(messages.raw("<dark_gray>No per-level stat reward"));
            else definition.perLevelStats().forEach((stat, amount) -> lore.add(messages.raw(
                    "<dark_gray>  •</dark_gray> <gray>" + pretty(stat) + " " + coloredSigned(amount))));
            if (milestone != null) {
                milestone.stats().forEach((stat, amount) -> lore.add(messages.raw(
                        "<dark_gray>  ★</dark_gray> <gold>" + pretty(stat) + " " + coloredSigned(amount))));
                milestone.items().forEach((id, amount) -> customItems.definition(id).ifPresent(custom -> lore.add(messages.raw(
                        "<dark_gray>  ◆</dark_gray> <gold>" + amount + "× " + strip(custom.displayName())))));
                milestone.description().forEach(line -> lore.add(messages.raw("<dark_gray>  •</dark_gray> <gray>" + line)));
                if (!milestone.commands().isEmpty()) lore.add(messages.raw("<dark_gray>  • Admin command reward"));
            }
            lore.add(Component.empty());
            lore.add(messages.raw(status));
            inv.setItem(CONTENT[i], item(material, (isMilestone ? "<gold><bold>★ " : "<white>") + "Level " + level, lore, isMilestone || unlocked));
        }
        List<Component> summary = new ArrayList<>();
        summary.add(messages.raw("<gray>Viewing <white>" + target.getName()));
        summary.add(messages.raw("<gray>Current level <white>" + progress.level() + "</white><dark_gray>/</dark_gray><gray>" + definition.maxLevel()));
        summary.add(Component.empty());
        definition.perLevelStats().forEach((stat, amount) -> summary.add(messages.raw(
                "<gray>" + pretty(stat) + " total " + coloredSigned(amount * progress.level()))));
        inv.setItem(4, item(definition.icon(), definition.displayName(), summary, true));
        inv.setItem(45, item(Material.ARROW, page > 0 ? "<yellow>Previous Page" : "<yellow>Back to Skills", List.of()));
        inv.setItem(48, sourcesItem(definition));
        inv.setItem(49, statsItem(target));
        if (page + 1 < pages) inv.setItem(53, item(Material.ARROW, "<yellow>Next Page", List.of()));
        viewer.openInventory(inv);
    }

    public void openStats(Player viewer, Player target, int requestedPage) {
        StatBreakdown breakdown = stats.breakdown(target);
        List<Map.Entry<String, StatBreakdown.StatLine>> lines = breakdown.stats().entrySet().stream()
                .filter(entry -> Math.abs(entry.getValue().total()) > 0.000001)
                .sorted(Map.Entry.comparingByKey()).toList();
        int pages = Math.max(1, (int) Math.ceil(lines.size() / (double) CONTENT.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        String title = configuredTitle("menus.stats-title", "<gradient:#FDE047:#A78BFA><player>'s Stats</gradient> <dark_gray>•</dark_gray> <page>/<pages>",
                Map.of("player", target.getName(), "page", page + 1, "pages", pages));
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.STATS, target.getUniqueId().toString(), page);
        Inventory inv = Bukkit.createInventory(holder, 54, messages.raw(title));
        holder.attach(inv);
        fill(inv);
        for (int i = 0; i < CONTENT.length; i++) {
            int position = page * CONTENT.length + i;
            if (position >= lines.size()) break;
            var entry = lines.get(position);
            List<Component> lore = new ArrayList<>();
            lore.add(messages.raw("<gray>Total <white>" + signed(entry.getValue().total())));
            lore.add(Component.empty());
            lore.add(messages.raw("<gradient:#22D3EE:#A78BFA><bold>Distribution</bold></gradient>"));
            entry.getValue().sources().entrySet().stream()
                    .filter(source -> Math.abs(source.getValue()) > 0.000001)
                    .sorted((a, b) -> Double.compare(Math.abs(b.getValue()), Math.abs(a.getValue())))
                    .forEach(source -> lore.add(messages.raw("<dark_gray>  •</dark_gray> <gray>" + source.getKey() + " " + coloredSigned(source.getValue()))));
            inv.setItem(CONTENT[i], item(statIcon(entry.getKey()), "<gradient:#FDE047:#A78BFA>" + pretty(entry.getKey()) + "</gradient>", lore));
        }
        inv.setItem(4, item(Material.PLAYER_HEAD, "<gradient:#22D3EE:#A78BFA>" + target.getName() + "</gradient>",
                List.of(messages.raw("<gray>Every active stat and the exact"), messages.raw("<gray>skill, item, enchant, reforge, or base source."))));
        inv.setItem(45, page > 0 ? item(Material.ARROW, "<yellow>Previous Page", List.of()) : backButton());
        if (page + 1 < pages) inv.setItem(53, item(Material.ARROW, "<yellow>Next Page", List.of()));
        viewer.openInventory(inv);
    }

    public void openItems(Player player, int requestedPage) {
        List<CustomItemDefinition> definitions = enabledItems();
        int pages = Math.max(1, (int) Math.ceil(definitions.size() / (double) CONTENT.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        String title = configuredTitle("menus.items-title", "<gradient:#F472B6:#22D3EE>Custom Items</gradient> <dark_gray>•</dark_gray> <page>/<pages>",
                Map.of("page", page + 1, "pages", pages));
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.ITEMS, "", page);
        Inventory inv = Bukkit.createInventory(holder, 54, messages.raw(title));
        holder.attach(inv);
        fill(inv);
        for (int i = 0; i < CONTENT.length; i++) {
            int position = page * CONTENT.length + i;
            if (position >= definitions.size()) break;
            CustomItemDefinition def = definitions.get(position);
            ItemStack icon = customItems.create(def, 1);
            ItemMeta meta = icon.getItemMeta();
            List<Component> lore = new ArrayList<>(Optional.ofNullable(meta.lore()).orElse(List.of()));
            lore.add(Component.empty());
            lore.add(messages.raw("<yellow>Click for recipe, drops, and details"));
            meta.lore(lore);
            icon.setItemMeta(meta);
            inv.setItem(CONTENT[i], icon);
        }
        inv.setItem(4, item(Material.BOOK, "<gradient:#FDE047:#A78BFA>Item Codex</gradient>",
                List.of(messages.raw("<gray>Definitions, rewards, mob drops,"), messages.raw("<gray>recipes, stats, enchants, and reforges."))));
        inv.setItem(45, page > 0 ? item(Material.ARROW, "<yellow>Previous Page", List.of()) : backButton());
        if (page + 1 < pages) inv.setItem(53, item(Material.ARROW, "<yellow>Next Page", List.of()));
        player.openInventory(inv);
    }

    public void openItem(Player player, CustomItemDefinition definition, int returnPage) {
        String title = configuredTitle("menus.item-detail-title", "<dark_gray>Item: <item>", Map.of("item", definition.displayName()));
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.ITEM_DETAIL, definition.id(), returnPage);
        Inventory inv = Bukkit.createInventory(holder, 45, messages.raw(title));
        holder.attach(inv);
        fill(inv);
        inv.setItem(4, customItems.create(definition, 1));
        List<Component> obtaining = new ArrayList<>();
        if (definition.obtainment().isEmpty()) obtaining.add(messages.raw("<gray>Admin-only unless configured otherwise."));
        else definition.obtainment().forEach(line -> obtaining.add(messages.raw("<dark_gray>•</dark_gray> <gray>" + line)));
        inv.setItem(20, item(Material.COMPASS, "<gold><bold>How to Obtain</bold>", obtaining));
        List<Component> recipeLore = new ArrayList<>();
        if (definition.recipe() == null || !definition.recipe().enabled()) recipeLore.add(messages.raw("<gray>No crafting recipe is configured."));
        else {
            recipeLore.add(messages.raw("<gray>Shaped recipe <white>→ " + definition.recipe().amount() + " item(s)"));
            for (String row : definition.recipe().shape()) recipeLore.add(messages.raw("<dark_gray>[</dark_gray><white>" + row.replace(" ", "·") + "</white><dark_gray>]</dark_gray>"));
            definition.recipe().ingredients().forEach((key, material) -> recipeLore.add(messages.raw(
                    "<gray>" + key + " <dark_gray>=</dark_gray> <white>" + pretty(material.name()))));
        }
        inv.setItem(22, item(Material.CRAFTING_TABLE, "<gradient:#FDE047:#F97316>Crafting</gradient>", recipeLore));
        List<Component> dropLore = new ArrayList<>();
        if (definition.drops().isEmpty()) dropLore.add(messages.raw("<gray>No mob drop is configured."));
        else definition.drops().forEach(drop -> {
            dropLore.add(messages.raw("<gray>" + drop.entities().stream().map(type -> pretty(type.name())).sorted().toList()));
            dropLore.add(messages.raw("<dark_gray>  Chance:</dark_gray> <white>" + number(drop.chance()) + "% <dark_gray>•</dark_gray> <white>" + drop.minimum() + "-" + drop.maximum()));
            if (drop.lootingBonusPerLevel() > 0) dropLore.add(messages.raw("<dark_gray>  Looting:</dark_gray> <green>+" + number(drop.lootingBonusPerLevel()) + "%/level"));
        });
        inv.setItem(24, item(Material.ROTTEN_FLESH, "<gradient:#FB7185:#991B1B>Mob Drops</gradient>", dropLore));
        inv.setItem(40, item(Material.ARROW, "<yellow>Back to Item Codex", List.of()));
        player.openInventory(inv);
    }

    public void openEnchants(Player player, int requestedPage) {
        List<EnchantDefinition> definitions = configs.get().enchants().values().stream().filter(EnchantDefinition::enabled).toList();
        int pages = Math.max(1, (int) Math.ceil(definitions.size() / (double) CONTENT.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        String title = configuredTitle("menus.enchants-title", "<gradient:#C084FC:#22D3EE>Custom Enchants</gradient> <dark_gray>•</dark_gray> <page>/<pages>",
                Map.of("page", page + 1, "pages", pages));
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.ENCHANTS, "", page);
        Inventory inv = Bukkit.createInventory(holder, 54, messages.raw(title));
        holder.attach(inv);
        fill(inv);
        for (int i = 0; i < CONTENT.length; i++) {
            int position = page * CONTENT.length + i;
            if (position >= definitions.size()) break;
            EnchantDefinition def = definitions.get(position);
            List<Component> lore = new ArrayList<>();
            def.description().forEach(line -> lore.add(messages.raw("<gray>" + line)));
            lore.add(Component.empty());
            lore.add(messages.raw("<gray>Rarity " + CustomItemService.rarityLabel(def.rarity())));
            lore.add(messages.raw("<gray>Max level <white>" + def.maxLevel()));
            lore.add(messages.raw("<gray>Trigger <white>" + pretty(def.trigger())));
            lore.add(messages.raw("<gray>Items <white>" + String.join(", ", def.itemGroups().stream().map(MenuService::pretty).toList())));
            lore.add(Component.empty());
            lore.add(messages.raw("<gold><bold>How to Obtain</bold>"));
            lore.addAll(enchantAcquisitionLore(def));
            lore.add(Component.empty());
            lore.add(messages.raw("<aqua><bold>Bonus Increase by Level</bold></aqua>"));
            lore.addAll(enchantScalingLore(def));
            inv.setItem(CONTENT[i], item(Material.ENCHANTED_BOOK, def.displayName(), lore, true));
        }
        inv.setItem(4, item(Material.ENCHANTING_TABLE, "<gradient:#C084FC:#22D3EE>Enchant Codex</gradient>",
                List.of(messages.raw("<gray>Every enchant lists its configured bonus"), messages.raw("<gray>increase per enchant level, with its"),
                        messages.raw("<gray>level-one baseline for context."), messages.raw("<gray>IncogRPG enchants remain separate from ExcellentEnchants."))));
        inv.setItem(45, page > 0 ? item(Material.ARROW, "<yellow>Previous Page", List.of()) : backButton());
        if (page + 1 < pages) inv.setItem(53, item(Material.ARROW, "<yellow>Next Page", List.of()));
        player.openInventory(inv);
    }

    private List<Component> enchantAcquisitionLore(EnchantDefinition definition) {
        List<Component> lines = new ArrayList<>();
        var core = configs.get().core();
        String id = definition.id();
        String tablePath = "enchanting.enchanting-table";
        if (core.getBoolean(tablePath + ".enabled", false)
                && core.getStringList(tablePath + ".eligible-enchants").contains(id)) {
            double chance = core.getDouble(tablePath + ".rarity-chances." + definition.rarity(), 0.0);
            lines.add(messages.raw("<dark_gray>  •</dark_gray> <gray>Enchant a book at an enchanting table. Chance: <white>"
                    + number(chance) + "%</white> per table enchantment."));
        }

        String mythicPath = "enchanting.natural-drops.mythic-loot";
        if (core.getBoolean(mythicPath + ".enabled", false)
                && core.getStringList(mythicPath + ".enchants").contains(id)) {
            lines.add(messages.raw("<dark_gray>  •</dark_gray> <gray>Rare loot-table drop. Chance: <white>"
                    + number(core.getDouble(mythicPath + ".chance", 1.0)) + "%</white> per generated loot table."));
        }

        String legendaryPath = "enchanting.natural-drops.legendary-mob";
        var route = core.getConfigurationSection(legendaryPath + ".routes." + id);
        if (core.getBoolean(legendaryPath + ".enabled", false) && route != null) {
            String mobs = route.getStringList("entities").stream().map(MenuService::pretty).sorted().toList().stream().reduce((a, b) -> a + ", " + b).orElse("configured mobs");
            if (route.contains("fixed-chance")) {
                lines.add(messages.raw("<dark_gray>  •</dark_gray> <gray>Rare drop from <white>" + mobs
                        + "</white>. Fixed chance: <white>" + number(route.getDouble("fixed-chance")) + "%</white>."));
            } else {
                lines.add(messages.raw("<dark_gray>  •</dark_gray> <gray>Rare drop from <white>" + mobs
                        + "</white>. Starts at <white>" + number(core.getDouble(legendaryPath + ".base-chance", 0.01))
                        + "%</white>, increases per player kill, and caps at <white>"
                        + number(core.getDouble(legendaryPath + ".max-chance", 5.0)) + "%</white>."));
            }
        }

        configs.get().items().values().stream()
                .filter(item -> item.enabled() && item.enchants().containsKey(id))
                .forEach(item -> {
                    lines.add(messages.raw("<dark_gray>  •</dark_gray> <gray>Preloaded on <white>" + strip(item.displayName()) + "</white>."));
                    item.obtainment().stream()
                            .filter(text -> !text.toLowerCase(Locale.ROOT).contains("admin"))
                            .forEach(text -> lines.add(messages.raw("<dark_gray>    -</dark_gray> <gray>" + text)));
                });

        if (lines.isEmpty()) {
            lines.add(messages.raw("<dark_gray>  •</dark_gray> <gray>No normal player acquisition is configured."));
        }
        return lines;
    }

    /**
     * Reads the configured effect deltas instead of maintaining a second hard-coded
     * enchant table. Values such as max-percent-per-level become " +6% / enchant
     * level", while radius, amount, and duration values retain their raw units.
     * Proc chance is intentionally omitted: the catalog is about the effect bonus.
     */
    private List<Component> enchantScalingLore(EnchantDefinition definition) {
        List<Component> lines = new ArrayList<>();
        for (EnchantDefinition.EffectDefinition effect : definition.effects()) {
            effect.options().keySet().stream()
                    .filter(key -> key.endsWith("-per-level"))
                    .sorted()
                    .forEach(key -> {
                        String baseKey = key.substring(0, key.length() - "-per-level".length());
                        // The top-level proc chance is not an effect bonus. A field such
                        // as chance-per-stack is different: it is the effect's actual
                        // per-level bonus and should be displayed.
                        if (baseKey.equalsIgnoreCase("chance")) return;
                        double increase = effect.number(key, 0.0);
                        if (!Double.isFinite(increase) || Math.abs(increase) < 0.0000001) return;
                        double baseline = effect.number(baseKey, Double.NaN);
                        String lowerBaseKey = baseKey.toLowerCase(Locale.ROOT);
                        String unit = lowerBaseKey.contains("percent") || lowerBaseKey.startsWith("chance") ? "%" : "";
                        String baselineText = Double.isFinite(baseline)
                                ? " <dark_gray>(L1: " + number(baseline) + unit + ")</dark_gray>" : "";
                        lines.add(messages.raw("<dark_gray>  •</dark_gray> <gray>" + pretty(effect.type()) + " · "
                                + pretty(baseKey) + " <dark_gray>→</dark_gray> <green>" + signed(increase) + unit
                                + " / enchant level</green>" + baselineText));
                    });
        }
        if (lines.isEmpty()) lines.add(messages.raw("<dark_gray>  • No configured level-based bonus."));
        return lines;
    }

    public void openAchievements(Player viewer, Player target, int requestedPage) {
        PlayerProfile profile = data.getOrCreate(target.getUniqueId(), target.getName());
        List<AchievementDefinition> definitions = configs.get().achievements().values().stream()
                .filter(AchievementDefinition::enabled)
                .filter(def -> !def.hidden() || def.parent().isBlank() || profile.achievementCompleted(def.parent()) || profile.achievementCompleted(def.id()))
                .toList();
        int pages = Math.max(1, (int) Math.ceil(definitions.size() / (double) CONTENT.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        String title = configuredTitle("menus.achievements-title",
                "<gradient:#FDE047:#F97316><player>'s Achievements</gradient> <dark_gray>•</dark_gray> <page>/<pages>",
                Map.of("player", target.getName(), "page", page + 1, "pages", pages));
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.ACHIEVEMENTS, target.getUniqueId().toString(), page);
        Inventory inv = Bukkit.createInventory(holder, 54, messages.raw(title));
        holder.attach(inv);
        fill(inv);
        for (int i = 0; i < CONTENT.length; i++) {
            int position = page * CONTENT.length + i;
            if (position >= definitions.size()) break;
            AchievementDefinition def = definitions.get(position);
            boolean complete = profile.achievementCompleted(def.id());
            boolean parentLocked = !def.parent().isBlank() && !profile.achievementCompleted(def.parent());
            List<Component> lore = new ArrayList<>();
            def.description().forEach(line -> lore.add(messages.raw("<gray>" + line)));
            lore.add(Component.empty());
            lore.add(messages.raw("<gray>Frame <white>" + pretty(def.frame())));
            if (!def.parent().isBlank()) {
                AchievementDefinition parent = configs.get().achievements().get(def.parent());
                lore.add(messages.raw("<gray>Parent <white>" + (parent == null ? def.parent() : strip(parent.displayName()))));
            }
            lore.add(Component.empty());
            lore.add(messages.raw("<gradient:#22D3EE:#A78BFA><bold>Requirements</bold></gradient>"));
            for (AchievementDefinition.Requirement requirement : def.requirements()) {
                double current = achievements.progress(profile, requirement);
                lore.add(messages.raw("<dark_gray>  •</dark_gray> <gray>" + pretty(requirement.metric()) +
                        (requirement.target().equals("all") ? "" : " <white>" + pretty(requirement.target())) +
                        " <white>" + number(Math.min(current, requirement.amount())) + "</white><dark_gray>/</dark_gray><gray>" + number(requirement.amount())));
            }
            lore.add(messages.raw(progressBar(achievements.completionRatio(profile, def), 12)));
            lore.add(Component.empty());
            lore.add(messages.raw("<gradient:#FDE047:#F97316><bold>Rewards</bold></gradient>"));
            if (def.reward().items().isEmpty() && def.reward().skillXp().isEmpty() &&
                    def.reward().commands().isEmpty() && def.reward().messages().isEmpty())
                lore.add(messages.raw("<dark_gray>  • No configured reward"));
            def.reward().items().forEach((id, amount) -> customItems.definition(id).ifPresent(item ->
                    lore.add(messages.raw("<dark_gray>  ◆</dark_gray> <gold>" + amount + "× " + strip(item.displayName())))));
            def.reward().skillXp().forEach((id, amount) -> {
                SkillDefinition skill = configs.get().skills().get(id);
                lore.add(messages.raw("<dark_gray>  ✦</dark_gray> <aqua>" + number(amount) + " " +
                        (skill == null ? pretty(id) : strip(skill.displayName())) + " XP"));
            });
            if (!def.reward().commands().isEmpty()) lore.add(messages.raw("<dark_gray>  • Server command reward"));
            lore.add(Component.empty());
            lore.add(messages.raw(complete ? "<green><bold>COMPLETED</bold>" : parentLocked ? "<red>LOCKED BY PARENT" : "<yellow>IN PROGRESS"));
            Material icon = complete ? def.icon() : parentLocked ? Material.GRAY_DYE : def.icon();
            inv.setItem(CONTENT[i], item(icon, complete ? "<green>✓ </green>" + def.displayName() : def.displayName(), lore,
                    complete || def.frame().equals("CHALLENGE")));
        }
        inv.setItem(4, item(Material.TOTEM_OF_UNDYING, "<gradient:#FDE047:#F97316>Achievement Progress</gradient>",
                List.of(messages.raw("<gray>Completed <white>" + achievements.completed(profile) + "</white><dark_gray>/</dark_gray><gray>" +
                                configs.get().achievements().values().stream().filter(AchievementDefinition::enabled).count()),
                        messages.raw("<gray>Hidden branches appear after their parent unlocks.")), true));
        inv.setItem(45, page > 0 ? item(Material.ARROW, "<yellow>Previous Page", List.of()) : backButton());
        if (page + 1 < pages) inv.setItem(53, item(Material.ARROW, "<yellow>Next Page", List.of()));
        viewer.openInventory(inv);
    }

    public void openReforge(Player player) {
        RpgMenuHolder holder = new RpgMenuHolder(RpgMenuHolder.Type.REFORGE, player.getUniqueId().toString(), 0);
        Inventory inv = Bukkit.createInventory(holder, 27, messages.raw(configs.get().reforgeSettings().stationTitle()));
        holder.attach(inv);
        fill(inv);
        inv.setItem(REFORGE_ITEM_SLOT, null);
        inv.setItem(13, item(Material.AMETHYST_SHARD, "<gradient:#FDE047:#A78BFA>Reforge Forge</gradient>",
                List.of(messages.raw("<gray>Place compatible gear on the left."), messages.raw("<gray>Every roll adds a colored name prefix"),
                        messages.raw("<gray>and a configurable stat package."))));
        inv.setItem(18, backButton());
        updateReforgeButton(inv);
        player.openInventory(inv);
    }

    public void updateReforgeButton(Inventory inv) {
        ItemStack input = inv.getItem(REFORGE_ITEM_SLOT);
        if (input == null || input.getType().isAir()) {
            inv.setItem(REFORGE_BUTTON_SLOT, item(Material.ANVIL, "<gray>Insert an item",
                    List.of(messages.raw("<dark_gray>Place equipment in the left slot."))));
            return;
        }
        int options = reforges.compatible(input).size();
        double base = configs.get().reforgeSettings().baseCost() *
                (reforges.get(input).isPresent() ? configs.get().reforgeSettings().rerollCostMultiplier() : 1);
        inv.setItem(REFORGE_BUTTON_SLOT, item(options == 0 ? Material.BARRIER : Material.SMITHING_TABLE,
                options == 0 ? "<red>No Compatible Reforges" : "<gradient:#FDE047:#A78BFA><bold>Roll a Reforge</bold></gradient>",
                List.of(messages.raw("<gray>Possible outcomes <white>" + options),
                        messages.raw("<gray>Base cost <white>" + number(base)),
                        messages.raw("<gray>Name format <white>" + configs.get().reforgeSettings().nameFormat()),
                        Component.empty(), messages.raw("<yellow>Click to roll"))));
    }

    public List<SkillDefinition> enabledSkills() {
        return configs.get().skills().values().stream().filter(SkillDefinition::enabled)
                .sorted(Comparator.comparingInt(def -> {
                    int index = SKILL_DISPLAY_ORDER.indexOf(def.id().toLowerCase(Locale.ROOT));
                    return index < 0 ? SKILL_DISPLAY_ORDER.size() : index;
                })).toList();
    }

    public SkillDefinition skillAtSkillsMenuSlot(int slot) {
        if (slot >= 31 && slot <= 33) {
            return enabledSkills().stream().filter(this::isCenteredSkill).skip(slot - 31L).findFirst().orElse(null);
        }
        int index = contentIndex(slot);
        if (index < 0) return null;
        return enabledSkills().stream().filter(def -> !isCenteredSkill(def)).skip(index).findFirst().orElse(null);
    }
    public List<CustomItemDefinition> enabledItems() { return configs.get().items().values().stream().filter(CustomItemDefinition::enabled).toList(); }

    private static int contentIndex(int slot) {
        for (int index = 0; index < CONTENT.length; index++) if (CONTENT[index] == slot) return index;
        return -1;
    }

    /**
     * Returns the adjacent pet-menu filter. "all" is deliberately part of the cycle so players
     * can always return to the complete stable without needing to type a command.
     */
    public String adjacentPetSkillFilter(String currentSkill, int direction) {
        List<String> filters = new ArrayList<>();
        filters.add("all");
        pets.definitions("all").stream().map(PetDefinition::skill).distinct().forEach(filters::add);
        if (filters.size() == 1) return "all";
        int index = filters.indexOf(currentSkill == null ? "all" : currentSkill.toLowerCase(Locale.ROOT));
        if (index < 0) index = 0;
        return filters.get(Math.floorMod(index + direction, filters.size()));
    }

    private Material petFilterIcon(String skill) {
        if (skill == null || skill.equalsIgnoreCase("all")) return Material.COMPASS;
        SkillDefinition definition = configs.get().skills().get(skill.toLowerCase(Locale.ROOT));
        return definition == null ? Material.COMPASS : definition.icon();
    }

    private String petFilterName(String skill) {
        if (skill == null || skill.equalsIgnoreCase("all")) return "All Skills";
        SkillDefinition definition = configs.get().skills().get(skill.toLowerCase(Locale.ROOT));
        return definition == null ? pretty(skill) : definition.displayName();
    }

    private ItemStack profileItem(Player player, PlayerProfile profile) {
        ItemStack head = item(Material.PLAYER_HEAD, "<gradient:#22D3EE:#A78BFA>" + player.getName() + "</gradient>", List.of(
                messages.raw("<gray>Total skill level <white>" + profile.totalLevels()),
                messages.raw("<gray>Skills tracked <white>" + enabledSkills().size()), Component.empty(),
                messages.raw("<dark_gray>All rewards and caps are admin-configurable.")), true);
        if (head.getItemMeta() instanceof SkullMeta skull) {
            // Use the live player profile so Java and Bedrock skins render correctly
            // when a compatible skin bridge such as BedrockSkinManager is installed.
            skull.setOwningPlayer(player);
            head.setItemMeta(skull);
        }
        return head;
    }

    private ItemStack sourcesItem(SkillDefinition definition) {
        List<Component> lore = new ArrayList<>();
        definition.sources().forEach(source -> lore.add(messages.raw("<dark_gray>•</dark_gray> <gray>" + pretty(source.type()) +
                " <white>" + number(source.amount()) + " XP" + (source.targets().isEmpty() ? "" : " <dark_gray>(" + source.targetMode().toLowerCase(Locale.ROOT) + ")"))));
        return item(Material.EXPERIENCE_BOTTLE, "<gradient:#4ADE80:#22D3EE>How to Earn XP</gradient>", lore);
    }

    private ItemStack statsItem(Player player) {
        List<Component> lore = new ArrayList<>();
        stats.get(player).values().entrySet().stream().filter(entry -> Math.abs(entry.getValue()) > 0.0001)
                .sorted(Map.Entry.comparingByKey()).limit(12)
                .forEach(entry -> lore.add(messages.raw("<dark_gray>•</dark_gray> <gray>" + pretty(entry.getKey()) + " " + coloredSigned(entry.getValue()))));
        if (lore.isEmpty()) lore.add(messages.raw("<dark_gray>No active stats"));
        lore.add(Component.empty());
        lore.add(messages.raw("<yellow>Click for the full source distribution"));
        return item(Material.NETHER_STAR, "<gradient:#FDE047:#A78BFA>Combined Stats</gradient>", lore, true);
    }

    private Material levelNodeMaterial(SkillDefinition.Milestone milestone, boolean unlocked, boolean next) {
        if (milestone != null && !milestone.items().isEmpty()) {
            String id = milestone.items().keySet().iterator().next();
            Optional<CustomItemDefinition> item = customItems.definition(id);
            if (item.isPresent()) return item.get().material();
        }
        if (milestone != null) return Material.NETHER_STAR;
        if (unlocked) return Material.LIME_STAINED_GLASS_PANE;
        if (next) return Material.YELLOW_STAINED_GLASS_PANE;
        return Material.GRAY_STAINED_GLASS_PANE;
    }

    private Optional<Map.Entry<Integer, SkillDefinition.Milestone>> nextMilestone(SkillDefinition definition, int currentLevel) {
        return definition.milestones().entrySet().stream().filter(entry -> entry.getKey() > currentLevel).findFirst();
    }

    private String configuredTitle(String path, String fallback, Map<String, ?> replacements) {
        String title = configs.get().core().getString(path, fallback);
        for (var entry : replacements.entrySet()) title = title.replace("<" + entry.getKey() + ">", String.valueOf(entry.getValue()));
        return title;
    }

    public ItemStack item(Material material, String name, List<Component> lore) { return item(material, name, lore, false); }

    public ItemStack item(Material material, String name, List<Component> lore, boolean glint) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(messages.raw(name));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(glint);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        return item;
    }

    /** Builds a textured player skull for a pet entry, never requiring a resource pack. */
    private ItemStack petHead(PetDefinition definition, String name, List<Component> lore, boolean glint) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = head.getItemMeta();
        if (!(meta instanceof SkullMeta skull)) return item(definition.icon(), name, lore, glint);
        applyPetTexture(skull, definition);
        skull.displayName(messages.raw(name));
        skull.lore(lore);
        skull.setEnchantmentGlintOverride(glint);
        skull.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        head.setItemMeta(skull);
        return head;
    }

    private void applyPetTexture(SkullMeta skull, PetDefinition definition) {
        String texture = definition.headTexture().trim();
        try {
            if (!texture.isBlank()) {
                // Convenience: administrators may use either the normal base64
                // value from a head database or a textures.minecraft.net URL.
                if (texture.startsWith("http://") || texture.startsWith("https://")) {
                    String json = "{\"textures\":{\"SKIN\":{\"url\":\"" + texture.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}}}";
                    texture = Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
                }
                com.destroystokyo.paper.profile.PlayerProfile profile = Bukkit.createProfile(UUID.nameUUIDFromBytes(
                        ("incogutils:pet:" + definition.id()).getBytes(StandardCharsets.UTF_8)), "IncogPet");
                profile.setProperty(new ProfileProperty("textures", texture));
                skull.setPlayerProfile(profile);
                return;
            }
            // Do not rely on MHF_* account lookups. On many modern/offline-mode
            // servers those names resolve to an offline UUID with no skin, leaving a
            // Steve head in the menu. Each built-in pet model has an embedded Mojang
            // texture instead. Admin-provided head owners remain a last-resort option
            // for custom entity types, while an explicit head-texture always wins.
            String builtInTexture = defaultPetHeadTexture(definition.entityType());
            if (!builtInTexture.isBlank()) {
                com.destroystokyo.paper.profile.PlayerProfile profile = Bukkit.createProfile(UUID.nameUUIDFromBytes(
                        ("incogutils:pet-model:" + definition.entityType()).getBytes(StandardCharsets.UTF_8)), "IncogPet");
                profile.setProperty(new ProfileProperty("textures", builtInTexture));
                skull.setPlayerProfile(profile);
                return;
            }
            String owner = definition.headOwner();
            if (!owner.isBlank()) skull.setOwningPlayer(Bukkit.getOfflinePlayer(owner));
        } catch (RuntimeException ignored) {
            // A malformed admin texture must not prevent the whole pets menu opening.
        }
    }

    /**
     * Texture values are permanent Mojang texture properties, not player names, so
     * these heads render consistently for every viewer. Every entity in the bundled
     * pet catalog is represented here; custom pets can still supply head-texture.
     */
    private static String defaultPetHeadTexture(EntityType type) {
        return switch (type) {
            case BAT -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNjY4MWE3MmRhNzI2M2NhOWFlZjA2NjU0MmVjY2E3YTE4MGM0MGUzMjhjMDQ2M2ZjYjExNGNiM2I4MzA1NzU1MiJ9fX0=";
            case WOLF -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNjlkMWQzMTEzZWM0M2FjMjk2MWRkNTlmMjgxNzVmYjQ3MTg4NzNjNmM0NDhkZmNhODcyMjMxN2Q2NyJ9fX0=";
            case CAT -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGVkM2RiYWUzZDNhZmJkMWZiNDJkN2Q3YzE2MjE5MjJmYWI1NmZhNGNhNTc0OTViYmNkNGFiOWI3YjI3ZDUifX19";
            case FOX -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvODFjYmJlZDlmYzg0MzM0ODBiODIxNTYxMmNlMDVlYzFmNjhiYTQ4YWJlM2QxMmEwZmEwNjhhZGJkMGQwZmRjMiJ9fX0=";
            case BEE -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDQyMGM5YzQzZTA5NTg4MGRjZDJlMjgxYzgxZjQ3YjE2M2I0NzhmNThhNTg0YmI2MWY5M2U2ZTEwYTE1NWYzMSJ9fX0=";
            case RABBIT -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMTE3YmZmYzE5NzJhY2Q3ZjNiNGE4ZjQzYjViNmM3NTM0Njk1YjhmZDYyNjc3ZTAzMDZiMjgzMTU3NGIifX19";
            case PARROT -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNGQ0ODJhNjVkMDA0YmNlYjcxNDEzNDk2MzY5MTE2MzBkZmZiYTY4ZmYyMWI4ZDUxZDkxNzc4NTBmOTQ0YzZmZiJ9fX0=";
            case ALLAY -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZDJhMjJmMjE3MjhlZmYxNzZlNzhkNGNjMTg3MDI4M2I5YTc5OTMwMmJhYThhZjkxN2ZlZTM3OGRkYzQ5OTJjNyJ9fX0=";
            case IRON_GOLEM -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZTEzZjM0MjI3MjgzNzk2YmMwMTcyNDRjYjQ2NTU3ZDY0YmQ1NjJmYTlkYWIwZTEyYWY1ZDIzYWQ2OTljZjY5NyJ9fX0=";
            case SNOW_GOLEM -> "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYTEwYmY1NmU4ODI1NjA4ODllMDQyZDAxN2U4YjRjMDM5YjM1YTNhODRlNzE5N2M3ZjMzM2ViMjhkMDlkNDAyNSJ9fX0=";
            default -> "";
        };
    }

    private static String rankName(String permission) {
        int separator = permission.lastIndexOf('.');
        return separator >= 0 ? permission.substring(separator + 1) : permission;
    }

    private static String specialModifierText(PetDefinition definition, int level) {
        double value = definition.specialModifierValue(level);
        return switch (definition.specialModifier()) {
            case "CINDERBITE" -> number(value) + "% chance to briefly ignite a melee target";
            case "COMET_DASH" -> "sprinting hits grant " + number(value / 20.0) + "s of Speed I";
            case "AEGIS_WARD" -> "absorbs " + number(value) + " damage";
            case "STARLIGHT_GRACE" -> "low-health hits grant " + number(value) + " absorption hearts";
            case "ROYAL_BOUNTY" -> "hostile kills grant " + number(value) + " bonus XP";
            default -> pretty(definition.specialModifier());
        };
    }

    private void fill(Inventory inv) {
        if (!configs.get().core().getBoolean("menus.fill-empty-slots", true)) return;
        Material filler = Material.matchMaterial(configs.get().core().getString("menus.filler-material", "BLACK_STAINED_GLASS_PANE"));
        if (filler == null) filler = Material.BLACK_STAINED_GLASS_PANE;
        ItemStack pane = item(filler, " ", List.of());
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
    }

    public static String pretty(String value) {
        StringJoiner joiner = new StringJoiner(" ");
        for (String part : value.replace("CUSTOM_", "").toLowerCase(Locale.ROOT).split("_"))
            if (!part.isEmpty()) joiner.add(Character.toUpperCase(part.charAt(0)) + part.substring(1));
        return joiner.toString();
    }
    private static String strip(String value) { return value.replaceAll("<[^>]+>", ""); }
    private static String coloredSigned(double value) { return (value >= 0 ? "<green>+" : "<red>") + number(value); }
    private static String signed(double value) { return (value >= 0 ? "+" : "") + number(value); }
    private static String number(double value) {
        return value == Math.rint(value) ? String.format(Locale.US, "%,.0f", value) : String.format(Locale.US, "%,.2f", value);
    }
    private static String progressBar(double progress, int segments) {
        int filled = (int) Math.round(Math.max(0, Math.min(1, progress)) * segments);
        return "<gradient:#22D3EE:#8B5CF6>" + "▰".repeat(filled) + "</gradient><dark_gray>" + "▱".repeat(segments - filled) + "</dark_gray>";
    }
    private static Material statIcon(String stat) {
        return switch (stat.replace("CUSTOM_", "")) {
            case "MAX_HEALTH", "HEALING_POWER", "LIFESTEAL" -> Material.GOLDEN_APPLE;
            case "ATTACK_DAMAGE", "PROJECTILE_DAMAGE", "PET_DAMAGE" -> Material.NETHERITE_SWORD;
            case "ARMOR", "ARMOR_TOUGHNESS", "KNOCKBACK_RESISTANCE" -> Material.NETHERITE_CHESTPLATE;
            case "MOVEMENT_SPEED", "SNEAKING_SPEED", "JUMP_STRENGTH" -> Material.FEATHER;
            case "CRIT_CHANCE", "CRIT_DAMAGE" -> Material.TARGET;
            case "MINING_FORTUNE", "MINING_EFFICIENCY", "BLOCK_BREAK_SPEED" -> Material.DIAMOND_PICKAXE;
            case "FARMING_FORTUNE" -> Material.GOLDEN_HOE;
            case "FISHING_FORTUNE" -> Material.FISHING_ROD;
            case "WOODCUTTING_FORTUNE" -> Material.DIAMOND_AXE;
            case "XP_GAIN" -> Material.EXPERIENCE_BOTTLE;
            case "LUCK" -> Material.EMERALD;
            default -> Material.PRISMARINE_CRYSTALS;
        };
    }
}

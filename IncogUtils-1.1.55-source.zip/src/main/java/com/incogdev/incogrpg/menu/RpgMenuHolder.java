package com.incogdev.incogrpg.menu;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

public final class RpgMenuHolder implements InventoryHolder {
    private final Type type;
    private final String context;
    private final int page;
    private Inventory inventory;

    public RpgMenuHolder(Type type, String context, int page) { this.type = type; this.context = context; this.page = page; }
    public void attach(Inventory inventory) { this.inventory = inventory; }
    public Type type() { return type; }
    public String context() { return context; }
    public int page() { return page; }
    @Override public @NotNull Inventory getInventory() { return inventory; }
    public enum Type { MENU_HUB, PLAYER_SETTINGS, ADMIN_SETTINGS, SKILLS, SKILL_TREE, STATS, ITEMS, ITEM_DETAIL, ENCHANTS, ACHIEVEMENTS, PETS, ACCESSORY_BAG, REFORGE, DAILY_REWARDS }
}

package com.incogdev.incogrpg.model;

import org.bukkit.Material;

import java.util.List;
import java.util.Map;

/** A completely configuration-backed achievement and its advancement-style rewards. */
public record AchievementDefinition(
        String id,
        String displayName,
        List<String> description,
        Material icon,
        String frame,
        boolean enabled,
        boolean hidden,
        boolean announce,
        String parent,
        List<Requirement> requirements,
        Reward reward
) {
    public AchievementDefinition {
        description = List.copyOf(description);
        requirements = List.copyOf(requirements);
    }

    public record Requirement(String metric, String target, double amount) {
        public String progressKey() { return metric + ":" + target; }
    }

    public record Reward(
            Map<String, Integer> items,
            Map<String, Double> skillXp,
            List<String> commands,
            List<String> messages
    ) {
        public Reward {
            items = Map.copyOf(items);
            skillXp = Map.copyOf(skillXp);
            commands = List.copyOf(commands);
            messages = List.copyOf(messages);
        }
    }
}

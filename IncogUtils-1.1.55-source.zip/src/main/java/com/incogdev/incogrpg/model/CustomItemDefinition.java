package com.incogdev.incogrpg.model;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;

import java.util.List;
import java.util.Map;
import java.util.Set;

public record CustomItemDefinition(
        String id,
        String displayName,
        List<String> description,
        Material material,
        String rarity,
        String category,
        boolean enabled,
        boolean glint,
        boolean unbreakable,
        int customModelData,
        Map<String, Double> stats,
        Map<String, Integer> enchants,
        String reforge,
        String appliesReforge,
        int anvilLevelCost,
        List<String> obtainment,
        boolean milestoneExclusive,
        RecipeDefinition recipe,
        List<DropDefinition> drops
) {
    public record RecipeDefinition(boolean enabled, List<String> shape, Map<Character, Material> ingredients, int amount) {}
    public record DropDefinition(Set<EntityType> entities, double chance, int minimum, int maximum,
                                 double lootingBonusPerLevel, boolean playerKillOnly) {}
}

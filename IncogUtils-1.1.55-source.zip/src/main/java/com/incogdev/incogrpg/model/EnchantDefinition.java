package com.incogdev.incogrpg.model;

import org.bukkit.Material;

import java.util.List;
import java.util.Map;
import java.util.Set;

public record EnchantDefinition(
        String id,
        String displayName,
        List<String> description,
        String rarity,
        boolean enabled,
        int maxLevel,
        Set<String> itemGroups,
        Set<String> conflicts,
        String trigger,
        double baseChance,
        double chancePerLevel,
        long cooldownMs,
        List<EffectDefinition> effects
) {
    public double procChance(int level) {
        return Math.max(0.0, Math.min(100.0, baseChance + chancePerLevel * Math.max(0, level - 1)));
    }

    public boolean supports(Material material) {
        return itemGroups.stream().anyMatch(group -> ItemGroups.matches(group, material));
    }

    public record EffectDefinition(String type, Map<String, Object> options) {
        public double number(String key, double fallback) {
            Object value = options.get(key);
            if (value instanceof Number n) return n.doubleValue();
            if (value != null) {
                try { return Double.parseDouble(value.toString()); } catch (NumberFormatException ignored) {}
            }
            return fallback;
        }

        public int integer(String key, int fallback) {
            return (int) Math.round(number(key, fallback));
        }

        public boolean bool(String key, boolean fallback) {
            Object value = options.get(key);
            return value == null ? fallback : Boolean.parseBoolean(value.toString());
        }

        public String text(String key, String fallback) {
            Object value = options.get(key);
            return value == null ? fallback : value.toString();
        }

        public double scaled(String key, int level, double fallback) {
            return number(key, fallback) + number(key + "-per-level", 0.0) * Math.max(0, level - 1);
        }
    }
}

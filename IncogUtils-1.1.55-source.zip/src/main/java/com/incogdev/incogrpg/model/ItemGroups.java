package com.incogdev.incogrpg.model;

import org.bukkit.Material;

import java.util.Locale;

public final class ItemGroups {
    private ItemGroups() {}

    public static boolean matches(String rawGroup, Material material) {
        String group = rawGroup.toUpperCase(Locale.ROOT);
        String name = material.name();
        if (group.equals("UNIVERSAL")) return !material.isAir() && material.isItem();
        if (group.equals("ARMOR")) return isArmor(name);
        if (group.equals("WEAPONS")) return name.endsWith("_SWORD") || name.endsWith("_AXE") || name.equals("MACE") || name.equals("TRIDENT");
        if (group.equals("TOOLS")) return name.endsWith("_PICKAXE") || name.endsWith("_AXE") || name.endsWith("_SHOVEL") || name.endsWith("_HOE") || name.equals("SHEARS");
        if (group.equals("SWORDS")) return name.endsWith("_SWORD");
        if (group.equals("AXES")) return name.endsWith("_AXE");
        if (group.equals("PICKAXES")) return name.endsWith("_PICKAXE");
        if (group.equals("SHOVELS")) return name.endsWith("_SHOVEL");
        if (group.equals("HOES")) return name.endsWith("_HOE");
        if (group.equals("BOWS")) return name.equals("BOW") || name.equals("CROSSBOW");
        if (group.equals("HELMETS")) return name.endsWith("_HELMET") || name.equals("TURTLE_HELMET");
        if (group.equals("CHESTPLATES")) return name.endsWith("_CHESTPLATE") || name.equals("ELYTRA");
        if (group.equals("LEGGINGS")) return name.endsWith("_LEGGINGS");
        if (group.equals("BOOTS")) return name.endsWith("_BOOTS");
        if (group.equals("FISHING_RODS")) return name.equals("FISHING_ROD");
        if (group.equals("TRIDENTS")) return name.equals("TRIDENT");
        if (group.equals("SHIELDS")) return name.equals("SHIELD");
        return name.equals(group);
    }

    public static boolean isEquipment(Material material) {
        String name = material.name();
        return isArmor(name) || name.endsWith("_SWORD") || name.endsWith("_AXE")
                || name.endsWith("_PICKAXE") || name.endsWith("_SHOVEL") || name.endsWith("_HOE")
                || name.equals("MACE") || name.equals("TRIDENT") || name.equals("BOW")
                || name.equals("CROSSBOW") || name.equals("FISHING_ROD") || name.equals("SHIELD")
                || name.equals("SHEARS");
    }

    private static boolean isArmor(String name) {
        return name.endsWith("_HELMET") || name.endsWith("_CHESTPLATE") || name.endsWith("_LEGGINGS")
                || name.endsWith("_BOOTS") || name.equals("TURTLE_HELMET") || name.equals("ELYTRA");
    }
}

package com.incogdev.incogrpg.model;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;

import java.util.List;
import java.util.Map;

public record PetDefinition(
        String id,
        String displayName,
        List<String> description,
        String skill,
        Material icon,
        EntityType entityType,
        String headTexture,
        String headOwner,
        String rarity,
        boolean enabled,
        boolean autoUnlock,
        String requiredPermission,
        String specialModifier,
        double specialModifierBase,
        double specialModifierPerLevel,
        long specialModifierCooldownMs,
        int maxLevel,
        int unlockSkillLevel,
        double xpBase,
        double xpMultiplier,
        double xpExponent,
        Map<String, Double> baseStats,
        Map<String, Double> perLevelStats,
        double skillXpBonusBase,
        double skillXpBonusPerLevel
) {
    public double xpRequired(int level) {
        if (level < 0 || level >= maxLevel) return 0;
        return Math.max(1, xpBase * xpMultiplier * Math.pow(level + 1.0, xpExponent));
    }

    public double skillXpBonus(int level) {
        return Math.max(0, skillXpBonusBase + skillXpBonusPerLevel * Math.max(0, level));
    }

    public double specialModifierValue(int level) {
        return Math.max(0, specialModifierBase + specialModifierPerLevel * Math.max(0, level));
    }
}

package com.incogdev.incogrpg.model;

public record PetProgress(int level, double xp) {
    public PetProgress {
        level = Math.max(0, level);
        xp = Math.max(0, Double.isFinite(xp) ? xp : 0);
    }
}

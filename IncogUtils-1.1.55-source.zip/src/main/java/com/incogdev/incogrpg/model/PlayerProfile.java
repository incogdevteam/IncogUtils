package com.incogdev.incogrpg.model;

import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class PlayerProfile {
    private final UUID uuid;
    private String lastKnownName;
    private final Map<String, SkillProgress> skills = new HashMap<>();
    private final Map<String, Double> achievementProgress = new HashMap<>();
    private final Map<String, Long> completedAchievements = new HashMap<>();
    private final Map<String, PetProgress> pets = new HashMap<>();
    private final Map<Integer, ItemStack> accessories = new HashMap<>();
    private String activePetId = "";
    private long lastSeen;
    private long revision;
    private long savedRevision;

    public PlayerProfile(UUID uuid, String lastKnownName) {
        this.uuid = uuid;
        this.lastKnownName = lastKnownName;
        this.lastSeen = System.currentTimeMillis();
    }

    public UUID uuid() { return uuid; }
    public synchronized String lastKnownName() { return lastKnownName; }
    public synchronized long lastSeen() { return lastSeen; }
    public synchronized boolean dirty() { return revision != savedRevision; }
    public synchronized long revision() { return revision; }

    public synchronized SkillProgress progress(String skillId) {
        return skills.getOrDefault(skillId, new SkillProgress(0, 0));
    }

    public synchronized void setProgress(String skillId, SkillProgress progress) {
        skills.put(skillId, progress);
        revision++;
    }

    public synchronized int totalLevels() {
        return skills.values().stream().mapToInt(SkillProgress::level).sum();
    }

    public synchronized Map<String, SkillProgress> snapshot() {
        return Map.copyOf(skills);
    }

    public synchronized double achievementProgress(String key) {
        return achievementProgress.getOrDefault(key, 0.0);
    }

    public synchronized void setAchievementProgress(String key, double value) {
        achievementProgress.put(key, Math.max(0, value));
        revision++;
    }

    public synchronized double addAchievementProgress(String key, double amount) {
        double updated = Math.max(0, achievementProgress.getOrDefault(key, 0.0) + amount);
        achievementProgress.put(key, updated);
        revision++;
        return updated;
    }

    public synchronized boolean achievementCompleted(String achievementId) {
        return completedAchievements.containsKey(achievementId);
    }

    public synchronized boolean completeAchievement(String achievementId, long completedAt) {
        if (completedAchievements.putIfAbsent(achievementId, completedAt) != null) return false;
        revision++;
        return true;
    }

    public synchronized boolean revokeAchievement(String achievementId) {
        if (completedAchievements.remove(achievementId) == null) return false;
        revision++;
        return true;
    }

    public synchronized void resetAchievements() {
        achievementProgress.clear();
        completedAchievements.clear();
        revision++;
    }

    public synchronized Map<String, Double> achievementProgressSnapshot() {
        return Map.copyOf(achievementProgress);
    }

    public synchronized Map<String, Long> completedAchievementsSnapshot() {
        return Map.copyOf(completedAchievements);
    }

    public synchronized boolean petUnlocked(String petId) { return pets.containsKey(petId); }
    public synchronized PetProgress petProgress(String petId) { return pets.getOrDefault(petId, new PetProgress(0, 0)); }
    public synchronized boolean unlockPet(String petId) {
        if (pets.putIfAbsent(petId, new PetProgress(0, 0)) != null) return false;
        revision++;
        return true;
    }
    public synchronized boolean lockPet(String petId) {
        if (pets.remove(petId) == null) return false;
        if (activePetId.equals(petId)) activePetId = "";
        revision++;
        return true;
    }
    public synchronized void setPetProgress(String petId, PetProgress progress) {
        pets.put(petId, progress);
        revision++;
    }
    public synchronized Map<String, PetProgress> petProgressSnapshot() { return Map.copyOf(pets); }
    public synchronized String activePetId() { return activePetId; }
    public synchronized void setActivePetId(String petId) {
        String normalized = petId == null ? "" : petId;
        if (activePetId.equals(normalized)) return;
        activePetId = normalized;
        revision++;
    }

    public synchronized ItemStack accessory(int slot) {
        ItemStack item = accessories.get(slot);
        return item == null ? null : item.clone();
    }

    public synchronized void setAccessory(int slot, ItemStack item) {
        if (item == null || item.getType().isAir()) accessories.remove(slot);
        else accessories.put(slot, item.clone());
        revision++;
    }

    public synchronized Map<Integer, ItemStack> accessorySnapshot() {
        Map<Integer, ItemStack> snapshot = new HashMap<>();
        accessories.forEach((slot, item) -> snapshot.put(slot, item.clone()));
        return Map.copyOf(snapshot);
    }

    public synchronized void updateIdentity(String name) {
        this.lastKnownName = name;
        this.lastSeen = System.currentTimeMillis();
        revision++;
    }

    public synchronized void markClean() { this.savedRevision = revision; }
    public synchronized void markClean(long savedAtRevision) { this.savedRevision = Math.max(savedRevision, Math.min(savedAtRevision, revision)); }

    public synchronized void reset() {
        skills.clear();
        revision++;
    }
}

package com.incogdev.incogrpg.model;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;

import java.util.List;
import java.util.Map;
import java.util.Set;

public record ReforgeDefinition(
        String id,
        String displayName,
        List<String> description,
        String rarity,
        boolean enabled,
        boolean rollEnabled,
        double weight,
        double naturalWeight,
        double costMultiplier,
        Set<String> itemGroups,
        Set<String> naturalSources,
        Set<EntityType> naturalEntities,
        Map<String, Double> stats
) {
    public boolean supports(Material material) {
        return itemGroups.stream().anyMatch(group -> ItemGroups.matches(group, material));
    }


    public boolean supportsNaturalSource(String source, EntityType entityType) {
        if (!naturalSources.contains(source.toUpperCase(java.util.Locale.ROOT))) return false;
        return entityType == null || naturalEntities.isEmpty() || naturalEntities.contains(entityType);
    }
}

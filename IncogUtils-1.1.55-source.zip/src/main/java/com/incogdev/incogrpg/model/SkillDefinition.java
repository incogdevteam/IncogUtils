package com.incogdev.incogrpg.model;

import org.bukkit.Material;

import java.util.List;
import java.util.Map;
import java.util.Set;

public record SkillDefinition(
        String id,
        String displayName,
        List<String> description,
        Material icon,
        boolean enabled,
        int maxLevel,
        double curveBase,
        double curveMultiplier,
        double curveExponent,
        List<XpSourceDefinition> sources,
        Map<String, Double> perLevelStats,
        Map<Integer, Milestone> milestones
) {
    public double xpRequired(int currentLevel) {
        if (currentLevel < 0) throw new IllegalArgumentException("currentLevel must be >= 0");
        return Math.max(1.0, curveBase * curveMultiplier * Math.pow(currentLevel + 1.0, curveExponent));
    }

    public record XpSourceDefinition(String type, double amount, Set<String> targets, String targetMode) {
        public boolean matches(String target) {
            if (targets.isEmpty()) return true;
            String normalized = target.toUpperCase(java.util.Locale.ROOT);
            return switch (targetMode) {
                case "PREFIX" -> targets.stream().anyMatch(normalized::startsWith);
                case "SUFFIX" -> targets.stream().anyMatch(normalized::endsWith);
                case "CONTAINS" -> targets.stream().anyMatch(normalized::contains);
                default -> targets.contains(normalized);
            };
        }
    }

    public record Milestone(
            Map<String, Double> stats,
            Map<String, Integer> items,
            List<String> description,
            List<String> commands,
            List<String> messages
    ) {}
}

package com.incogdev.incogrpg.model;

public record SkillProgress(int level, double xp) {
    public SkillProgress {
        if (level < 0) throw new IllegalArgumentException("level must be >= 0");
        if (!Double.isFinite(xp) || xp < 0) throw new IllegalArgumentException("xp must be finite and >= 0");
    }
}

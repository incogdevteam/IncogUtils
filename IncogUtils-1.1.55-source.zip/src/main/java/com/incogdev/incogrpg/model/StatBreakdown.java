package com.incogdev.incogrpg.model;

import java.util.Map;

public record StatBreakdown(Map<String, StatLine> stats) {
    public StatLine get(String stat) {
        return stats.getOrDefault(stat.toUpperCase(java.util.Locale.ROOT), new StatLine(0, Map.of()));
    }

    public record StatLine(double total, Map<String, Double> sources) {}
}

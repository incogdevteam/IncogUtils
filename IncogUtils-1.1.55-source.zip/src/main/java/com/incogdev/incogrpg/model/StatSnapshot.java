package com.incogdev.incogrpg.model;

import java.util.Map;

public record StatSnapshot(Map<String, Double> values) {
    public static final StatSnapshot EMPTY = new StatSnapshot(Map.of());
    public double get(String stat) { return values.getOrDefault(stat.toUpperCase(java.util.Locale.ROOT), 0.0); }
}

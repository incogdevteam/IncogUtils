package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.model.CustomItemDefinition;
import com.incogdev.incogrpg.model.PlayerProfile;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/** Persistent virtual equipment slots restricted to configured custom-item categories. */
public final class AccessoryService {
    private final ConfigManager configs;
    private final PlayerDataService data;
    private final CustomItemService customItems;

    public AccessoryService(ConfigManager configs, PlayerDataService data, CustomItemService customItems) {
        this.configs = configs;
        this.data = data;
        this.customItems = customItems;
    }

    public boolean enabled() { return configs.get().accessorySettings().enabled(); }
    public int slots() { return configs.get().accessorySettings().slots(); }

    public Optional<CustomItemDefinition> definition(ItemStack item) {
        return customItems.definition(item).filter(definition -> definition.enabled()
                && (configs.get().accessorySettings().allowedCategories().contains(definition.category().toUpperCase(Locale.ROOT))
                || (configs.get().accessorySettings().includeMilestoneRewards() && definition.milestoneExclusive())));
    }

    public boolean accepts(ItemStack item) { return definition(item).isPresent(); }

    public List<ItemStack> items(Player player) {
        if (!enabled()) return List.of();
        PlayerProfile profile = profile(player);
        List<ItemStack> result = new ArrayList<>();
        for (int slot = 0; slot < slots(); slot++) {
            ItemStack item = profile.accessory(slot);
            if (accepts(item)) result.add(item);
        }
        return List.copyOf(result);
    }

    public ItemStack get(Player player, int slot) {
        return validSlot(slot) ? profile(player).accessory(slot) : null;
    }

    public SetResult set(Player player, int slot, ItemStack item) {
        if (!enabled()) return SetResult.DISABLED;
        if (!validSlot(slot)) return SetResult.INVALID_SLOT;
        if (item != null && !item.getType().isAir()) {
            if (item.getAmount() != 1) return SetResult.ONE_AT_A_TIME;
            CustomItemDefinition incoming = definition(item).orElse(null);
            if (incoming == null) return SetResult.NOT_ACCESSORY;
            if (!configs.get().accessorySettings().allowDuplicates()) {
                PlayerProfile profile = profile(player);
                for (int other = 0; other < slots(); other++) {
                    if (other == slot) continue;
                    CustomItemDefinition existing = definition(profile.accessory(other)).orElse(null);
                    if (existing != null && existing.id().equals(incoming.id())) return SetResult.DUPLICATE;
                }
            }
        }
        profile(player).setAccessory(slot, item);
        return SetResult.SUCCESS;
    }

    public boolean validSlot(int slot) { return slot >= 0 && slot < slots(); }
    private PlayerProfile profile(Player player) { return data.getOrCreate(player.getUniqueId(), player.getName()); }

    public enum SetResult { SUCCESS, DISABLED, INVALID_SLOT, NOT_ACCESSORY, DUPLICATE, ONE_AT_A_TIME }
}

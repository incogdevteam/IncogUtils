package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.api.event.AchievementUnlockEvent;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.model.AchievementDefinition;
import com.incogdev.incogrpg.model.PlayerProfile;
import com.incogdev.incogrpg.model.SkillDefinition;
import com.incogdev.incogrpg.util.Messages;
import com.incogdev.incogutils.settings.PlayerSettingsManager;
import net.kyori.adventure.title.Title;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.*;

/** Tracks arbitrary configured metrics and turns them into persistent advancement-style unlocks. */
public final class AchievementService {
    public static final Set<String> BUILT_IN_METRICS = Set.of(
            "SKILL_LEVEL", "TOTAL_SKILL_LEVEL", "SKILL_XP_EARNED", "BLOCKS_BROKEN", "MOBS_KILLED",
            "PLAYERS_KILLED", "DAMAGE_DEALT", "ITEMS_CRAFTED", "FISH_CAUGHT", "REFORGES_APPLIED",
            "ENCHANT_PROCS", "CUSTOM_ITEMS_OBTAINED", "ACHIEVEMENTS_COMPLETED");

    private final IncogRpgPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataService data;
    private final CustomItemService items;
    private final Messages messages;
    private final PlayerSettingsManager playerSettings;
    private SkillService skills;

    public AchievementService(IncogRpgPlugin plugin, ConfigManager configs, PlayerDataService data,
                              CustomItemService items, Messages messages, PlayerSettingsManager playerSettings) {
        this.plugin = plugin;
        this.configs = configs;
        this.data = data;
        this.items = items;
        this.messages = messages;
        this.playerSettings = playerSettings;
    }

    public void setSkillService(SkillService skills) { this.skills = skills; }

    public void bootstrap(Player player) {
        if (!enabled()) return;
        PlayerProfile profile = data.getOrCreate(player.getUniqueId(), player.getName());
        for (SkillDefinition skill : configs.get().skills().values()) {
            profile.setAchievementProgress(key("SKILL_LEVEL", skill.id()), profile.progress(skill.id()).level());
        }
        profile.setAchievementProgress(key("TOTAL_SKILL_LEVEL", "all"), profile.totalLevels());
        profile.setAchievementProgress(key("ACHIEVEMENTS_COMPLETED", "all"), profile.completedAchievementsSnapshot().size());
        evaluate(player, profile, false);
    }

    public void add(Player player, String metric, String target, double amount) {
        if (!enabled() || amount <= 0 || !Double.isFinite(amount)) return;
        PlayerProfile profile = data.getOrCreate(player.getUniqueId(), player.getName());
        String normalizedMetric = normalizeMetric(metric);
        String normalizedTarget = normalizeTarget(target);
        profile.addAchievementProgress(key(normalizedMetric, normalizedTarget), amount);
        if (!normalizedTarget.equals("all")) profile.addAchievementProgress(key(normalizedMetric, "all"), amount);
        evaluate(player, profile, true);
    }

    public void set(Player player, String metric, String target, double value) {
        if (!enabled() || !Double.isFinite(value)) return;
        PlayerProfile profile = data.getOrCreate(player.getUniqueId(), player.getName());
        profile.setAchievementProgress(key(metric, target), value);
        evaluate(player, profile, true);
    }

    public boolean grant(Player player, String achievementId, boolean rewards) {
        AchievementDefinition definition = definition(achievementId).orElse(null);
        if (definition == null) return false;
        PlayerProfile profile = data.getOrCreate(player.getUniqueId(), player.getName());
        if (!profile.completeAchievement(definition.id(), System.currentTimeMillis())) return false;
        if (rewards) reward(player, definition);
        updateCompletedMetric(profile);
        notifyUnlock(player, definition);
        Bukkit.getPluginManager().callEvent(new AchievementUnlockEvent(player, definition.id(), true));
        evaluate(player, profile, true);
        return true;
    }

    public boolean revoke(Player player, String achievementId) {
        PlayerProfile profile = data.getOrCreate(player.getUniqueId(), player.getName());
        boolean changed = profile.revokeAchievement(normalizeTarget(achievementId));
        if (changed) updateCompletedMetric(profile);
        return changed;
    }

    public void reset(Player player) {
        PlayerProfile profile = data.getOrCreate(player.getUniqueId(), player.getName());
        profile.resetAchievements();
        bootstrap(player);
    }

    public Optional<AchievementDefinition> definition(String id) {
        return Optional.ofNullable(configs.get().achievements().get(normalizeTarget(id)));
    }

    public double progress(PlayerProfile profile, AchievementDefinition.Requirement requirement) {
        return profile.achievementProgress(requirement.progressKey());
    }

    public double completionRatio(PlayerProfile profile, AchievementDefinition definition) {
        return definition.requirements().stream().mapToDouble(requirement ->
                Math.min(1.0, progress(profile, requirement) / requirement.amount())).average().orElse(0);
    }

    public int completed(PlayerProfile profile) { return profile.completedAchievementsSnapshot().size(); }

    private void evaluate(Player player, PlayerProfile profile, boolean notify) {
        boolean unlocked;
        boolean anyUnlocked = false;
        do {
            unlocked = false;
            for (AchievementDefinition definition : configs.get().achievements().values()) {
                if (!definition.enabled() || profile.achievementCompleted(definition.id())) continue;
                if (!definition.parent().isBlank() && !profile.achievementCompleted(definition.parent())) continue;
                if (definition.requirements().stream().anyMatch(requirement -> progress(profile, requirement) + 0.000001 < requirement.amount())) continue;
                if (!profile.completeAchievement(definition.id(), System.currentTimeMillis())) continue;
                reward(player, definition);
                updateCompletedMetric(profile);
                if (notify) notifyUnlock(player, definition);
                Bukkit.getPluginManager().callEvent(new AchievementUnlockEvent(player, definition.id(), false));
                unlocked = true;
                anyUnlocked = true;
            }
        } while (unlocked);
        if (anyUnlocked && configs.get().core().getBoolean("achievements.save-on-unlock", true)) data.saveAsync(profile, false);
    }

    private void reward(Player player, AchievementDefinition definition) {
        definition.reward().items().forEach((itemId, amount) -> items.definition(itemId)
                .ifPresent(item -> items.give(player, item, amount, CustomItemService.AcquisitionSource.ACHIEVEMENT)));
        if (skills != null) definition.reward().skillXp().forEach((skillId, amount) ->
                skills.addXp(player, skillId, "ACHIEVEMENT", amount));
        definition.reward().messages().forEach(line -> player.sendMessage(messages.raw(replace(line, player, definition))));
        definition.reward().commands().forEach(command -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                replace(command, player, definition)));
    }

    private void notifyUnlock(Player player, AchievementDefinition definition) {
        Component achievementName = messages.raw(definition.displayName())
                .hoverEvent(HoverEvent.showText(acquisitionHover(definition)));
        if (playerSettings.enabled(player, PlayerSettingsManager.Setting.ACHIEVEMENT_NOTIFICATIONS)) {
            messages.send(player, "achievement-unlocked", Map.of("frame", pretty(definition.frame())),
                    Map.of("achievement", achievementName));
            if (configs.get().core().getBoolean("achievements.notification.title-enabled", true)) {
                long fadeIn = configs.get().core().getLong("achievements.notification.fade-in-ms", 250);
                long stay = configs.get().core().getLong("achievements.notification.stay-ms", 2500);
                long fadeOut = configs.get().core().getLong("achievements.notification.fade-out-ms", 500);
                player.showTitle(Title.title(messages.raw("<gradient:#FDE047:#F97316><bold>Achievement Unlocked!</bold></gradient>"),
                        messages.raw(definition.displayName()), Title.Times.times(Duration.ofMillis(fadeIn), Duration.ofMillis(stay), Duration.ofMillis(fadeOut))));
            }
            String sound = configs.get().core().getString("achievements.notification.sound", "ui.toast.challenge_complete");
            if (!sound.isBlank()) try { player.playSound(player.getLocation(), sound, 0.85f, definition.frame().equals("CHALLENGE") ? 0.9f : 1.15f); }
            catch (IllegalArgumentException ignored) { }
        }
        if (definition.announce() && configs.get().core().getBoolean("achievements.announce-enabled", true))
            Bukkit.broadcast(messages.component("achievement-announcement", Map.of("player", player.getName()),
                    Map.of("achievement", achievementName)));
    }

    private Component acquisitionHover(AchievementDefinition definition) {
        Component hover = messages.raw("<gradient:#FDE047:#F97316><bold>How to Obtain</bold></gradient>");
        for (String line : definition.description())
            hover = hover.append(Component.newline()).append(messages.raw("<gray>" + line));
        if (!definition.parent().isBlank()) {
            AchievementDefinition parent = configs.get().achievements().get(definition.parent());
            hover = hover.append(Component.newline()).append(messages.raw("<dark_gray>Parent:</dark_gray> <white>" +
                    plain(parent == null ? definition.parent() : parent.displayName())));
        }
        hover = hover.append(Component.newline()).append(Component.newline())
                .append(messages.raw("<aqua><bold>Requirements</bold>"));
        for (AchievementDefinition.Requirement requirement : definition.requirements()) {
            String target = requirement.target().equals("all") ? "" : " " + pretty(requirement.target());
            hover = hover.append(Component.newline()).append(messages.raw("<dark_gray>•</dark_gray> <gray>" +
                    pretty(requirement.metric()) + target + " <white>" + number(requirement.amount())));
        }
        hover = hover.append(Component.newline()).append(Component.newline())
                .append(messages.raw("<yellow>Open <white>/achievements</white> for live progress."));
        return hover;
    }

    private void updateCompletedMetric(PlayerProfile profile) {
        profile.setAchievementProgress(key("ACHIEVEMENTS_COMPLETED", "all"), profile.completedAchievementsSnapshot().size());
    }

    private boolean enabled() { return configs.get().core().getBoolean("achievements.enabled", true); }
    public static String key(String metric, String target) { return normalizeMetric(metric) + ":" + normalizeTarget(target); }
    private static String normalizeMetric(String metric) { return metric.toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_'); }
    private static String normalizeTarget(String target) {
        if (target == null || target.isBlank() || target.equals("*")) return "all";
        return target.toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
    }
    private static String replace(String text, Player player, AchievementDefinition definition) {
        return text.replace("<player>", player.getName()).replace("<uuid>", player.getUniqueId().toString())
                .replace("<achievement>", definition.id()).replace("<achievement_name>", definition.displayName());
    }
    private static String pretty(String value) {
        String normalized = value.toLowerCase(Locale.ROOT).replace('_', ' ');
        return Character.toUpperCase(normalized.charAt(0)) + normalized.substring(1);
    }
    private static String plain(String value) { return value.replaceAll("<[^>]+>", "").trim(); }
    private static String number(double value) {
        return value == Math.rint(value) ? String.format(Locale.US, "%,.0f", value)
                : String.format(Locale.US, "%,.2f", value);
    }
}

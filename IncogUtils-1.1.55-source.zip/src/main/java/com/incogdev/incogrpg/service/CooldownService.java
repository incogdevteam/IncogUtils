package com.incogdev.incogrpg.service;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CooldownService {
    private final Map<String, Long> cooldowns = new ConcurrentHashMap<>();

    public boolean tryUse(UUID player, String id, long durationMs) {
        if (durationMs <= 0) return true;
        long now = System.currentTimeMillis();
        String key = player + ":" + id;
        Long previous = cooldowns.putIfAbsent(key, now + durationMs);
        if (previous == null) return true;
        if (previous <= now) return cooldowns.replace(key, previous, now + durationMs);
        return false;
    }

    public void clear(UUID player) { cooldowns.keySet().removeIf(key -> key.startsWith(player + ":")); }
    public void prune() {
        long now = System.currentTimeMillis();
        cooldowns.entrySet().removeIf(entry -> entry.getValue() <= now);
    }
}

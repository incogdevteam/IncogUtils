package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.CustomItemDefinition;
import com.incogdev.incogrpg.model.EnchantDefinition;
import com.incogdev.incogrpg.model.ReforgeDefinition;
import com.incogdev.incogrpg.util.Messages;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

/** Builds, identifies, gives, and registers recipes for every items.yml definition. */
public final class CustomItemService {
    public enum AcquisitionSource { SKILL_MILESTONE, ACHIEVEMENT, RECIPE, MOB_DROP, CHEST_LOOT, ADMIN, API }
    private final IncogRpgPlugin plugin;
    private final ConfigManager configs;
    private final Messages messages;
    private final EnchantService enchants;
    private final ReforgeService reforges;
    private final NamespacedKey itemIdKey;
    private final Set<NamespacedKey> registeredRecipes = new HashSet<>();

    public CustomItemService(IncogRpgPlugin plugin, ConfigManager configs, Messages messages,
                             EnchantService enchants, ReforgeService reforges) {
        this.plugin = plugin;
        this.configs = configs;
        this.messages = messages;
        this.enchants = enchants;
        this.reforges = reforges;
        this.itemIdKey = new NamespacedKey(plugin, "custom_item_id");
    }

    public Optional<CustomItemDefinition> definition(String id) {
        if (id == null) return Optional.empty();
        return Optional.ofNullable(configs.get().items().get(normalize(id)));
    }

    public Optional<CustomItemDefinition> definition(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return Optional.empty();
        String id = item.getItemMeta().getPersistentDataContainer().get(itemIdKey, PersistentDataType.STRING);
        return Optional.ofNullable(id == null ? null : configs.get().items().get(id));
    }

    public ItemStack create(CustomItemDefinition definition, int requestedAmount) {
        int amount = Math.max(1, Math.min(definition.material().getMaxStackSize(), requestedAmount));
        ItemStack result = new ItemStack(definition.material(), amount);
        ItemMeta meta = result.getItemMeta();
        meta.displayName(messages.raw(definition.displayName()));
        List<Component> lore = new ArrayList<>();
        lore.add(messages.raw(rarityLabel(definition.rarity()) + " <dark_gray>•</dark_gray> <gray>" + pretty(definition.category())));
        lore.add(Component.empty());
        definition.description().forEach(line -> lore.add(messages.raw("<gray>" + line)));
        if (!definition.stats().isEmpty()) {
            lore.add(Component.empty());
            lore.add(messages.raw("<gradient:#22D3EE:#A78BFA><bold>Item Stats</bold></gradient>"));
            definition.stats().forEach((stat, value) -> lore.add(messages.raw(
                    "<dark_gray>  •</dark_gray> <gray>" + pretty(stat) + " " + (value >= 0 ? "<green>+" : "<red>") + number(value))));
        }
        if (!definition.appliesReforge().isBlank()) {
            ReforgeDefinition applied = configs.get().reforges().get(definition.appliesReforge());
            if (applied != null) {
                lore.add(Component.empty());
                lore.add(messages.raw("<gradient:#FDE047:#A78BFA><bold>Reforge Stone</bold></gradient>"));
                lore.add(messages.raw("<gray>Applies " + applied.displayName() + "<gray> in an anvil."));
                lore.add(messages.raw("<gray>Level cost <white>" + definition.anvilLevelCost()));
                lore.add(messages.raw("<dark_gray>The stone is consumed on use."));
            }
        }
        if (!definition.obtainment().isEmpty()) {
            lore.add(Component.empty());
            lore.add(messages.raw("<gold><bold>How to Obtain</bold>"));
            definition.obtainment().forEach(line -> lore.add(messages.raw("<dark_gray>  •</dark_gray> <gray>" + line)));
        }
        lore.add(Component.empty());
        lore.add(messages.raw("<dark_gray>Item ID: " + definition.id()));
        meta.lore(lore);
        meta.setUnbreakable(definition.unbreakable());
        meta.setEnchantmentGlintOverride(definition.glint());
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        if (definition.customModelData() > 0) {
            var model = meta.getCustomModelDataComponent();
            model.setFloats(List.of((float) definition.customModelData()));
            meta.setCustomModelDataComponent(model);
        }
        meta.getPersistentDataContainer().set(itemIdKey, PersistentDataType.STRING, definition.id());
        result.setItemMeta(meta);

        definition.enchants().forEach((id, level) -> {
            EnchantDefinition enchant = configs.get().enchants().get(id);
            if (enchant != null) enchants.apply(result, enchant, Math.min(level, enchant.maxLevel()), true);
        });
        if (!definition.reforge().isBlank()) {
            ReforgeDefinition reforge = configs.get().reforges().get(definition.reforge());
            if (reforge != null) reforges.apply(result, reforge);
        }
        return result;
    }

    public Optional<ItemStack> create(String id, int amount) {
        return definition(id).filter(CustomItemDefinition::enabled).map(def -> create(def, amount));
    }

    public void give(Player player, CustomItemDefinition definition, int amount) {
        give(player, definition, amount, AcquisitionSource.ADMIN);
    }

    public boolean give(Player player, CustomItemDefinition definition, int amount, AcquisitionSource source) {
        if (!canAcquire(definition, source)) return false;
        int remaining = Math.max(1, amount);
        while (remaining > 0) {
            int batch = Math.min(definition.material().getMaxStackSize(), remaining);
            Map<Integer, ItemStack> overflow = player.getInventory().addItem(create(definition, batch));
            overflow.values().forEach(drop -> player.getWorld().dropItemNaturally(player.getLocation(), drop));
            remaining -= batch;
        }
        return true;
    }

    public boolean canAcquire(CustomItemDefinition definition, AcquisitionSource source) {
        return !definition.milestoneExclusive() || source == AcquisitionSource.SKILL_MILESTONE
                || source == AcquisitionSource.ADMIN || source == AcquisitionSource.API;
    }

    public void refresh(ItemStack item) {
        Optional<CustomItemDefinition> current = definition(item);
        if (current.isEmpty()) return;
        int amount = item.getAmount();
        ItemStack replacement = create(current.get(), amount);
        item.setType(replacement.getType());
        item.setAmount(replacement.getAmount());
        item.setItemMeta(replacement.getItemMeta());
    }

    public int reloadRecipes() {
        registeredRecipes.forEach(Bukkit::removeRecipe);
        registeredRecipes.clear();
        int added = 0;
        for (CustomItemDefinition definition : configs.get().items().values()) {
            CustomItemDefinition.RecipeDefinition recipeDefinition = definition.recipe();
            if (!definition.enabled() || recipeDefinition == null || !recipeDefinition.enabled()) continue;
            if (!canAcquire(definition, AcquisitionSource.RECIPE)) continue;
            NamespacedKey key = new NamespacedKey(plugin, "item_" + definition.id());
            Bukkit.removeRecipe(key);
            ItemStack output = create(definition, recipeDefinition.amount());
            ShapedRecipe recipe = new ShapedRecipe(key, output).shape(recipeDefinition.shape().toArray(String[]::new));
            recipeDefinition.ingredients().forEach(recipe::setIngredient);
            if (Bukkit.addRecipe(recipe)) {
                registeredRecipes.add(key);
                added++;
            } else plugin.getLogger().warning("Could not register custom item recipe " + definition.id());
        }
        return added;
    }

    public NamespacedKey itemIdKey() { return itemIdKey; }

    public static String rarityLabel(String rarity) {
        return switch (rarity.toUpperCase(Locale.ROOT)) {
            case "UNCOMMON" -> "<green><bold>UNCOMMON</bold>";
            case "RARE" -> "<aqua><bold>RARE</bold>";
            case "EPIC" -> "<light_purple><bold>EPIC</bold>";
            case "LEGENDARY" -> "<gold><bold>LEGENDARY</bold>";
            case "MYTHIC" -> "<gradient:#F472B6:#8B5CF6><bold>MYTHIC</bold></gradient>";
            default -> "<white><bold>COMMON</bold>";
        };
    }

    private static String normalize(String id) { return id.toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_'); }
    private static String pretty(String value) {
        StringJoiner result = new StringJoiner(" ");
        for (String part : value.replace("CUSTOM_", "").toLowerCase(Locale.ROOT).split("_"))
            if (!part.isEmpty()) result.add(Character.toUpperCase(part.charAt(0)) + part.substring(1));
        return result.toString();
    }
    private static String number(double value) {
        return value == Math.rint(value) ? String.format(Locale.US, "%,.0f", value) : String.format(Locale.US, "%,.2f", value);
    }
}

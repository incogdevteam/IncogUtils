package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.EnchantDefinition;
import com.incogdev.incogrpg.util.Messages;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public final class EnchantService {
    private static final String LORE_MARKER = "incogrpg:enchant";
    private final ConfigManager configs;
    private final Messages messages;
    private final NamespacedKey key;
    private final NamespacedKey loreLinesKey;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public EnchantService(IncogRpgPlugin plugin, ConfigManager configs, Messages messages) {
        this.configs = configs; this.messages = messages; this.key = new NamespacedKey(plugin, "custom_enchants");
        this.loreLinesKey = new NamespacedKey(plugin, "enchant_lore_lines");
    }

    public Map<String, Integer> get(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return Map.of();
        String raw = item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (raw == null || raw.isBlank()) return Map.of();
        Map<String, Integer> result = new TreeMap<>();
        for (String part : raw.split(",")) {
            String[] pair = part.split(":", 2);
            if (pair.length == 2) {
                try { result.put(pair[0], Integer.parseInt(pair[1])); } catch (NumberFormatException ignored) {}
            }
        }
        return Map.copyOf(result);
    }

    public ApplyResult apply(ItemStack item, EnchantDefinition definition, int level, boolean unsafe) {
        if (item == null || item.getType().isAir()) return ApplyResult.INCOMPATIBLE;
        if (!unsafe && !definition.supports(item.getType())) return ApplyResult.INCOMPATIBLE;
        if (level < 1 || level > definition.maxLevel()) return ApplyResult.INVALID_LEVEL;
        Map<String, Integer> current = new TreeMap<>(get(item));
        if (!unsafe && !configs.get().core().getBoolean("enchanting.allow-conflicting-enchants", false)) {
            // Counterpart enchants are alternatives. Applying the new choice removes
            // every configured counterpart first, so an item can never retain both
            // halves of a mutually exclusive pair. The reverse-direction check keeps
            // older/custom YAML safe even when only one side lists the conflict.
            Set<String> replacements = new LinkedHashSet<>();
            for (String conflict : definition.conflicts()) if (current.containsKey(conflict)) replacements.add(conflict);
            for (String existing : current.keySet()) {
                EnchantDefinition other = configs.get().enchants().get(existing);
                if (other != null && other.conflicts().contains(definition.id())) replacements.add(existing);
            }
            replacements.forEach(current::remove);
        }
        int max = configs.get().core().getInt("enchanting.max-custom-enchants-per-item", 8);
        if (!current.containsKey(definition.id()) && current.size() >= max) return ApplyResult.LIMIT;
        current.put(definition.id(), level);
        write(item, current);
        return ApplyResult.SUCCESS;
    }

    public boolean remove(ItemStack item, String id) {
        Map<String, Integer> current = new TreeMap<>(get(item));
        if (current.remove(id) == null) return false;
        write(item, current);
        return true;
    }

    public void clear(ItemStack item) { write(item, Map.of()); }

    public ItemStack book(EnchantDefinition definition, int level) {
        ItemStack item = new ItemStack(Material.ENCHANTED_BOOK);
        apply(item, definition, level, true);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(messages.raw("<white>Enchanted Book <dark_gray>• " + definition.displayName() + " " + roman(level)));
        item.setItemMeta(meta);
        return item;
    }

    private void write(ItemStack item, Map<String, Integer> values) {
        ItemMeta meta = item.getItemMeta();
        if (values.isEmpty()) meta.getPersistentDataContainer().remove(key);
        else meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, values.entrySet().stream()
                .map(entry -> entry.getKey() + ":" + entry.getValue()).reduce((a, b) -> a + "," + b).orElse(""));
        if (configs.get().core().getBoolean("enchanting.show-lore", true)) {
            List<Component> lore = new ArrayList<>(Optional.ofNullable(meta.lore()).orElse(List.of()));
            boolean removedLegacy = lore.removeIf(this::isLegacyLine);
            Integer count = meta.getPersistentDataContainer().get(loreLinesKey, PersistentDataType.INTEGER);
            if (!removedLegacy && count != null) for (int i = 0; i < count && !lore.isEmpty(); i++) lore.remove(lore.size() - 1);
            meta.getPersistentDataContainer().remove(loreLinesKey);
            if (!values.isEmpty()) {
                lore.add(messages.raw(configs.get().core().getString("enchanting.lore-header", "<dark_gray>Custom Enchantments")));
                values.forEach((id, level) -> {
                    EnchantDefinition definition = configs.get().enchants().get(id);
                    if (definition != null) lore.add(messages.raw("<gray>• " + definition.displayName() + " <white>" + roman(level)));
                });
                meta.getPersistentDataContainer().set(loreLinesKey, PersistentDataType.INTEGER, 1 + values.size());
            }
            meta.lore(lore.isEmpty() ? null : lore);
        }
        item.setItemMeta(meta);
    }

    public void migrate(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();
        boolean hasData = meta.getPersistentDataContainer().has(key);
        boolean legacy = Optional.ofNullable(meta.lore()).orElse(List.of()).stream().anyMatch(this::isLegacyLine);
        if (legacy || (hasData && !meta.getPersistentDataContainer().has(loreLinesKey))) write(item, get(item));
    }

    public static String roman(int number) {
        if (number <= 0) return String.valueOf(number);
        String[] thousands = {"", "M", "MM", "MMM"};
        String[] hundreds = {"", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM"};
        String[] tens = {"", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"};
        String[] ones = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"};
        if (number >= 4000) return String.valueOf(number);
        return thousands[number / 1000] + hundreds[number % 1000 / 100] + tens[number % 100 / 10] + ones[number % 10];
    }

    private boolean isLegacyLine(Component line) {
        return LORE_MARKER.equals(line.insertion()) || mini.serialize(line).contains(LORE_MARKER);
    }

    public enum ApplyResult { SUCCESS, INCOMPATIBLE, INVALID_LEVEL, LIMIT, CONFLICT }
}

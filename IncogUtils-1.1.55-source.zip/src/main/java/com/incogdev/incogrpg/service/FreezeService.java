package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.util.Messages;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Persistent moderation freezes. A freeze prevents movement and gameplay input without
 * preventing chat, so staff can still speak with the player being investigated.
 */
public final class FreezeService implements Listener {
    public record FreezeRecord(String playerName, String frozenBy, String reason, long frozenAt) { }

    private final IncogRpgPlugin plugin;
    private final ConfigManager configs;
    private final Messages messages;
    private final File file;
    private final Map<UUID, FreezeRecord> frozen = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastNotice = new ConcurrentHashMap<>();

    public FreezeService(IncogRpgPlugin plugin, ConfigManager configs, Messages messages) {
        this.plugin = plugin;
        this.configs = configs;
        this.messages = messages;
        this.file = new File(plugin.getDataFolder(), "frozen-players.yml");
    }

    public void load() {
        frozen.clear();
        if (!persist() || !file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        var root = yaml.getConfigurationSection("frozen");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                String path = "frozen." + key;
                frozen.put(uuid, new FreezeRecord(
                        yaml.getString(path + ".player-name", "Unknown"),
                        yaml.getString(path + ".frozen-by", "Console"),
                        yaml.getString(path + ".reason", "Under staff review"),
                        yaml.getLong(path + ".frozen-at", System.currentTimeMillis())
                ));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Ignoring invalid UUID in frozen-players.yml: " + key);
            }
        }
    }

    public void save() {
        if (!persist()) return;
        YamlConfiguration yaml = new YamlConfiguration();
        frozen.forEach((uuid, record) -> {
            String path = "frozen." + uuid;
            yaml.set(path + ".player-name", record.playerName());
            yaml.set(path + ".frozen-by", record.frozenBy());
            yaml.set(path + ".reason", record.reason());
            yaml.set(path + ".frozen-at", record.frozenAt());
        });
        try {
            yaml.save(file);
        } catch (IOException exception) {
            plugin.getLogger().warning("Could not save frozen-player records: " + exception.getMessage());
        }
    }

    public boolean enabled() { return configs.get().core().getBoolean("freeze.enabled", true); }
    public boolean frozen(UUID uuid) { return enabled() && frozen.containsKey(uuid); }
    public boolean frozen(Player player) { return frozen(player.getUniqueId()) && !player.hasPermission("incogutils.freeze.bypass"); }
    public Optional<FreezeRecord> record(UUID uuid) { return Optional.ofNullable(frozen.get(uuid)); }
    public List<Map.Entry<UUID, FreezeRecord>> records() {
        return frozen.entrySet().stream().sorted(Comparator.comparing(entry -> entry.getValue().playerName(), String.CASE_INSENSITIVE_ORDER)).toList();
    }

    public boolean freeze(Player target, String frozenBy, String reason) {
        if (!enabled() || target.hasPermission("incogutils.freeze.bypass")) return false;
        frozen.put(target.getUniqueId(), new FreezeRecord(target.getName(), frozenBy, cleanReason(reason), System.currentTimeMillis()));
        save();
        tellFrozen(target);
        return true;
    }

    public Optional<FreezeRecord> unfreeze(UUID uuid) {
        FreezeRecord removed = frozen.remove(uuid);
        lastNotice.remove(uuid);
        if (removed != null) save();
        return Optional.ofNullable(removed);
    }

    public Optional<Map.Entry<UUID, FreezeRecord>> findByName(String name) {
        if (name == null) return Optional.empty();
        return frozen.entrySet().stream().filter(entry -> entry.getValue().playerName().equalsIgnoreCase(name)).findFirst();
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!frozen(player) || event.getTo() == null) return;
        Location from = event.getFrom();
        Location to = event.getTo();
        if (samePosition(from, to)) return; // Allow head movement so staff can still communicate naturally.
        event.setTo(new Location(from.getWorld(), from.getX(), from.getY(), from.getZ(), to.getYaw(), to.getPitch()));
        notice(player);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) { if (block(event.getPlayer())) event.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent event) { if (block(event.getPlayer())) event.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) { if (block(event.getPlayer())) event.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) { if (block(event.getPlayer())) event.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) { if (block(event.getPlayer())) event.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) { if (block(event.getPlayer())) event.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) { if (block(event.getPlayer())) event.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent event) { if (block(event.getPlayer())) event.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent event) { if (block(event.getPlayer())) event.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player && block(player)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        Player attacker = attackingPlayer(event.getDamager());
        if (attacker != null && block(attacker)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBow(EntityShootBowEvent event) {
        if (event.getEntity() instanceof Player player && block(player)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!frozen(player) || allowedCommand(event.getMessage())) return;
        event.setCancelled(true);
        notice(player);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (frozen(event.getPlayer())) tellFrozen(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) { lastNotice.remove(event.getPlayer().getUniqueId()); }

    private boolean block(Player player) {
        if (!frozen(player)) return false;
        notice(player);
        return true;
    }

    private void notice(Player player) {
        long now = System.currentTimeMillis();
        long delay = Math.max(250L, configs.get().core().getLong("freeze.actionbar-interval-ms", 1250L));
        if (now - lastNotice.getOrDefault(player.getUniqueId(), 0L) < delay) return;
        lastNotice.put(player.getUniqueId(), now);
        player.sendActionBar(messages.raw(message("freeze.messages.actionbar", "<red><bold>FROZEN</bold> <gray>You may not move or interact while staff review your account.")));
    }

    private void tellFrozen(Player player) {
        FreezeRecord record = frozen.get(player.getUniqueId());
        if (record == null) return;
        player.sendMessage(messages.raw(message("freeze.messages.frozen", "<red><bold>You have been frozen by <white><staff></white>.</bold>", Map.of("staff", record.frozenBy()))));
        if (!record.reason().isBlank()) player.sendMessage(messages.raw(message("freeze.messages.reason", "<gray>Reason: <white><reason>", Map.of("reason", record.reason()))));
        player.sendMessage(messages.raw(message("freeze.messages.instructions", "<yellow>Please remain online and respond to staff in chat.")));
    }

    private boolean allowedCommand(String raw) {
        if (!configs.get().core().getBoolean("freeze.block-commands", true)) return true;
        String command = raw == null ? "" : raw.stripLeading();
        if (command.startsWith("/")) command = command.substring(1);
        if (command.isBlank()) return false;
        String root = command.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        return configs.get().core().getStringList("freeze.allowed-command-roots").stream()
                .map(value -> value.toLowerCase(Locale.ROOT).replaceFirst("^/", ""))
                .anyMatch(root::equals);
    }

    private boolean persist() { return configs.get().core().getBoolean("freeze.persist-across-restarts", true); }
    private static boolean samePosition(Location first, Location second) {
        return first.getWorld().equals(second.getWorld())
                && Double.compare(first.getX(), second.getX()) == 0
                && Double.compare(first.getY(), second.getY()) == 0
                && Double.compare(first.getZ(), second.getZ()) == 0;
    }

    private static Player attackingPlayer(Entity entity) {
        if (entity instanceof Player player) return player;
        if (entity instanceof org.bukkit.entity.Projectile projectile && projectile.getShooter() instanceof Player player) return player;
        return null;
    }

    private static String cleanReason(String reason) { return reason == null ? "" : reason.strip(); }
    private String message(String path, String fallback) { return configs.get().core().getString(path, fallback); }
    private String message(String path, String fallback, Map<String, String> replacements) {
        String value = message(path, fallback);
        for (Map.Entry<String, String> entry : replacements.entrySet()) value = value.replace("<" + entry.getKey() + ">", entry.getValue());
        return value;
    }
}

package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.util.Messages;
import com.incogdev.incogutils.settings.PlayerSettingsManager;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Keeps skill XP, numeric health, and the periodic PVP reminder together on the vanilla action bar. */
public final class HudService {
    private final com.incogdev.incogrpg.IncogRpgPlugin host;
    private final ConfigManager configs;
    private final Messages messages;
    private final PlayerSettingsManager settings;
    private final Map<UUID, TimedNotice> xpNotices = new ConcurrentHashMap<>();
    private final Map<UUID, Long> pvpStatusVisibleUntil = new ConcurrentHashMap<>();
    private final Map<UUID, Long> nextPvpStatusAt = new ConcurrentHashMap<>();
    private final Map<UUID, PreviousHealthScale> previousHealthScales = new ConcurrentHashMap<>();
    private final Set<UUID> renderedActionBars = ConcurrentHashMap.newKeySet();

    public HudService(com.incogdev.incogrpg.IncogRpgPlugin host, ConfigManager configs, Messages messages, PlayerSettingsManager settings) {
        this.host = host;
        this.configs = configs;
        this.messages = messages;
        this.settings = settings;
    }

    /** Progress remains in the signature for compatibility with the former boss-bar HUD. */
    public void notify(Player player, Component component, double progress) {
        if (!configs.get().core().getBoolean("hud.enabled", true)
                || !configs.get().core().getBoolean("hud.xp.enabled", true)
                || !settings.enabled(player, PlayerSettingsManager.Setting.SKILL_PROGRESS)) return;
        long holdTicks = Math.max(1, configs.get().core().getLong("hud.xp.hold-ticks",
                configs.get().core().getLong("hud.notification-hold-ticks", 40)));
        xpNotices.put(player.getUniqueId(), new TimedNotice(component, System.currentTimeMillis() + holdTicks * 50L));
        render(player, System.currentTimeMillis());
    }

    public void tick() {
        long now = System.currentTimeMillis();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!configs.get().core().getBoolean("hud.enabled", true)) {
                clear(player);
                continue;
            }
            updateVisualHeartScale(player);
            render(player, now);
        }
        xpNotices.entrySet().removeIf(entry -> entry.getValue().expiresAt() <= now || Bukkit.getPlayer(entry.getKey()) == null);
        pvpStatusVisibleUntil.keySet().removeIf(uuid -> Bukkit.getPlayer(uuid) == null);
        nextPvpStatusAt.keySet().removeIf(uuid -> Bukkit.getPlayer(uuid) == null);
        previousHealthScales.keySet().removeIf(uuid -> Bukkit.getPlayer(uuid) == null);
        renderedActionBars.removeIf(uuid -> Bukkit.getPlayer(uuid) == null);
    }

    public void clear(Player player) {
        xpNotices.remove(player.getUniqueId());
        pvpStatusVisibleUntil.remove(player.getUniqueId());
        nextPvpStatusAt.remove(player.getUniqueId());
        if (renderedActionBars.remove(player.getUniqueId())) player.sendActionBar(Component.empty());
        restoreVisualHeartScale(player);
    }

    private void render(Player player, long now) {
        TimedNotice xp = xpNotices.get(player.getUniqueId());
        if (xp != null && (xp.expiresAt() <= now
                || !configs.get().core().getBoolean("hud.xp.enabled", true)
                || !settings.enabled(player, PlayerSettingsManager.Setting.SKILL_PROGRESS))) {
            xpNotices.remove(player.getUniqueId(), xp);
            xp = null;
        }
        Component health = health(player);
        Component display = null;
        if (xp != null) display = xp.component();
        if (health != null) display = display == null ? health
                : display.append(messages.raw(" <dark_gray>│</dark_gray> ")).append(health);
        Component pvp = pvpStatus(player, now);
        if (pvp != null) display = display == null ? pvp
                : display.append(messages.raw(" <dark_gray>│</dark_gray> ")).append(pvp);

        if (display != null) {
            player.sendActionBar(display);
            renderedActionBars.add(player.getUniqueId());
        } else if (renderedActionBars.remove(player.getUniqueId())) {
            player.sendActionBar(Component.empty());
        }
    }

    private Component health(Player player) {
        if (!configs.get().core().getBoolean("hud.health.enabled", true)
                || !settings.enabled(player, PlayerSettingsManager.Setting.HEALTH_DISPLAY)) return null;
        var maxHealthAttribute = Registry.ATTRIBUTE.get(NamespacedKey.minecraft("max_health"));
        AttributeInstance instance = maxHealthAttribute == null ? null : player.getAttribute(maxHealthAttribute);
        if (instance == null) return null;
        double maximum = instance.getValue();
        double vanilla = configs.get().core().getDouble("hud.health.vanilla-max-health", 20.0);
        if (configs.get().core().getBoolean("hud.health.only-non-vanilla-max-health", true)
                && Math.abs(maximum - vanilla) < 0.0001) return null;
        double absorption = Math.max(0, player.getAbsorptionAmount());
        String absorptionText = absorption <= 0 ? "" : configs.get().core()
                .getString("hud.health.absorption-format", " <gold>+<absorption>❤</gold>")
                .replace("<absorption>", number(absorption));
        String format = configs.get().core().getString("hud.health.format",
                "<red>❤</red> <white><health></white><dark_gray>/</dark_gray><gray><max_health></gray><absorption>");
        return messages.raw(format.replace("<health>", number(player.getHealth()))
                .replace("<max_health>", number(maximum)).replace("<absorption>", absorptionText));
    }

    private Component pvpStatus(Player player, long now) {
        if (!settings.enabled(player, PlayerSettingsManager.Setting.PVP_STATUS_DISPLAY)
                || !host.claimsModuleAvailable()) {
            pvpStatusVisibleUntil.remove(player.getUniqueId());
            nextPvpStatusAt.remove(player.getUniqueId());
            return null;
        }
        UUID uuid = player.getUniqueId();
        long visibleUntil = pvpStatusVisibleUntil.getOrDefault(uuid, 0L);
        if (now >= visibleUntil) {
            long nextDisplay = nextPvpStatusAt.getOrDefault(uuid, 0L);
            if (now < nextDisplay) return null;
            long displayMillis = Math.max(1L, configs.get().core().getLong("hud.pvp-status.display-seconds", 5L)) * 1000L;
            long reminderMillis = Math.max(1L, configs.get().core().getLong("hud.pvp-status.reminder-minutes", 3L)) * 60_000L;
            pvpStatusVisibleUntil.put(uuid, now + displayMillis);
            nextPvpStatusAt.put(uuid, now + reminderMillis);
        }
        boolean enabled = host.claimsModule().getPvpManager().isEnabled(player.getUniqueId());
        return messages.raw(enabled ? "<gray>PVP:</gray> <green>ON</green>" : "<gray>PVP:</gray> <red>OFF</red>");
    }

    private void updateVisualHeartScale(Player player) {
        if (!configs.get().core().getBoolean("hud.health.enabled", true)
                || !configs.get().core().getBoolean("hud.health.limit-vanilla-hearts", true)
                || !settings.enabled(player, PlayerSettingsManager.Setting.HEALTH_DISPLAY)) {
            restoreVisualHeartScale(player);
            return;
        }
        previousHealthScales.computeIfAbsent(player.getUniqueId(), ignored ->
                new PreviousHealthScale(player.isHealthScaled(), player.getHealthScale()));
        double visibleHearts = Math.max(1.0, Math.min(100.0,
                configs.get().core().getDouble("hud.health.visible-hearts", 10.0)));
        double scale = visibleHearts * 2.0;
        if (!player.isHealthScaled()) player.setHealthScaled(true);
        if (Math.abs(player.getHealthScale() - scale) > 0.0001) player.setHealthScale(scale);
    }

    private void restoreVisualHeartScale(Player player) {
        PreviousHealthScale previous = previousHealthScales.remove(player.getUniqueId());
        if (previous == null) return;
        if (previous.scaled()) {
            player.setHealthScaled(true);
            player.setHealthScale(previous.scale());
        } else player.setHealthScaled(false);
    }

    private static String number(double value) {
        return value == Math.rint(value) ? String.format(Locale.US, "%.0f", value) : String.format(Locale.US, "%.1f", value);
    }

    private record TimedNotice(Component component, long expiresAt) {}
    private record PreviousHealthScale(boolean scaled, double scale) {}
}

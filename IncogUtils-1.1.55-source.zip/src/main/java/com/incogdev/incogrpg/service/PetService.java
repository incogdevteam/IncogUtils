package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.model.PetDefinition;
import com.incogdev.incogrpg.model.PetProgress;
import com.incogdev.incogrpg.model.PlayerProfile;
import com.incogdev.incogrpg.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

/** Persistent, skill-linked RPG pets. The entire service is inert while pets.yml settings.enabled is false. */
public final class PetService implements Listener {
    public enum SummonResult { SUCCESS, DISABLED, UNKNOWN, LOCKED }

    private final org.bukkit.plugin.Plugin plugin;
    private final ConfigManager configs;
    private final PlayerDataService data;
    private final Messages messages;
    private final Map<UUID, Entity> visuals = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Long>> modifierCooldowns = new ConcurrentHashMap<>();
    private Consumer<Player> statUpdater = ignored -> {};
    private volatile boolean visualFailureLogged;

    public PetService(org.bukkit.plugin.Plugin plugin, ConfigManager configs, PlayerDataService data, Messages messages) {
        this.plugin = plugin;
        this.configs = configs;
        this.data = data;
        this.messages = messages;
    }

    public void setStatUpdater(Consumer<Player> updater) { this.statUpdater = updater; }
    public boolean enabled() { return configs.get().petSettings().enabled(); }
    public Optional<PetDefinition> definition(String id) {
        if (id == null) return Optional.empty();
        return Optional.ofNullable(configs.get().pets().get(normalize(id)));
    }
    public List<PetDefinition> definitions(String skill) {
        String normalized = skill == null ? "all" : normalize(skill);
        return configs.get().pets().values().stream().filter(PetDefinition::enabled)
                .filter(pet -> normalized.equals("all") || pet.skill().equals(normalized)).toList();
    }

    public void bootstrap(Player player) {
        if (!enabled()) { removeVisual(player); return; }
        refreshUnlocks(player, false);
        PlayerProfile profile = profile(player);
        PetDefinition active = definition(profile.activePetId()).filter(PetDefinition::enabled).orElse(null);
        if (active == null || !unlocked(player, active)) {
            profile.setActivePetId("");
            removeVisual(player);
            return;
        }
        spawnVisual(player, active);
        statUpdater.accept(player);
    }

    public int refreshUnlocks(Player player, boolean notify) {
        if (!enabled() || !configs.get().petSettings().autoUnlockFromSkillLevel()) return 0;
        PlayerProfile profile = profile(player);
        int unlocked = 0;
        for (PetDefinition definition : configs.get().pets().values()) {
            if (!definition.enabled() || !definition.autoUnlock()
                    || profile.progress(definition.skill()).level() < definition.unlockSkillLevel()) continue;
            if (!profile.unlockPet(definition.id())) continue;
            unlocked++;
            if (notify) messages.send(player, "pet-unlocked", Map.of("pet", definition.displayName(),
                    "skill", definition.skill(), "level", definition.unlockSkillLevel()));
        }
        return unlocked;
    }

    public void addXp(Player player, String skillId, double awardedSkillXp) {
        if (!enabled() || awardedSkillXp <= 0) return;
        PlayerProfile profile = profile(player);
        PetDefinition definition = definition(profile.activePetId()).orElse(null);
        if (definition == null || !definition.enabled() || !definition.skill().equals(normalize(skillId))) return;
        PetProgress before = profile.petProgress(definition.id());
        int level = before.level();
        double gained = awardedSkillXp * configs.get().petSettings().activePetXpShare();
        double xp = before.xp() + gained;
        while (level < definition.maxLevel() && xp >= definition.xpRequired(level)) {
            xp -= definition.xpRequired(level);
            level++;
        }
        if (level >= definition.maxLevel()) xp = 0;
        profile.setPetProgress(definition.id(), new PetProgress(level, xp));
        if (level > before.level()) {
            messages.send(player, "pet-level-up", Map.of("pet", definition.displayName(), "level", level));
            statUpdater.accept(player);
        }
    }

    public double skillXpBonus(Player player, String skillId) {
        if (!enabled()) return 0;
        PlayerProfile profile = profile(player);
        PetDefinition definition = definition(profile.activePetId()).orElse(null);
        if (definition == null || !definition.skill().equals(normalize(skillId))) return 0;
        return definition.skillXpBonus(profile.petProgress(definition.id()).level());
    }

    public Map<String, Double> statBonuses(Player player) {
        if (!enabled()) return Map.of();
        PlayerProfile profile = profile(player);
        PetDefinition definition = definition(profile.activePetId()).orElse(null);
        if (definition == null || !unlocked(player, definition)) return Map.of();
        int level = profile.petProgress(definition.id()).level();
        Map<String, Double> values = new LinkedHashMap<>(definition.baseStats());
        definition.perLevelStats().forEach((stat, amount) -> values.merge(stat, amount * level, Double::sum));
        return Map.copyOf(values);
    }

    public Optional<PetDefinition> active(Player player) {
        if (!enabled()) return Optional.empty();
        return definition(profile(player).activePetId());
    }

    public SummonResult summon(Player player, String requestedId) {
        if (!enabled()) return SummonResult.DISABLED;
        PetDefinition definition = definition(requestedId).filter(PetDefinition::enabled).orElse(null);
        if (definition == null) return SummonResult.UNKNOWN;
        PlayerProfile profile = profile(player);
        if (!unlocked(player, definition)) return SummonResult.LOCKED;
        profile.setActivePetId(definition.id());
        spawnVisual(player, definition);
        statUpdater.accept(player);
        messages.send(player, "pet-summoned", Map.of("pet", definition.displayName()));
        return SummonResult.SUCCESS;
    }

    public void dismiss(Player player) {
        profile(player).setActivePetId("");
        removeVisual(player);
        statUpdater.accept(player);
        messages.send(player, "pet-dismissed");
    }

    public boolean unlock(Player player, String petId) {
        PetDefinition definition = definition(petId).orElse(null);
        return definition != null && definition.requiredPermission().isBlank() && profile(player).unlockPet(definition.id());
    }

    public boolean lock(Player player, String petId) {
        PetDefinition definition = definition(petId).orElse(null);
        if (definition == null) return false;
        boolean changed = profile(player).lockPet(definition.id());
        if (changed && profile(player).activePetId().isBlank()) {
            removeVisual(player);
            statUpdater.accept(player);
        }
        return changed;
    }

    public void setProgress(Player player, String petId, int requestedLevel, double requestedXp) {
        PetDefinition definition = definition(petId).orElseThrow(() -> new IllegalArgumentException("Unknown pet " + petId));
        int level = Math.max(0, Math.min(definition.maxLevel(), requestedLevel));
        double xp = level >= definition.maxLevel() ? 0 : Math.max(0, Math.min(requestedXp, Math.nextDown(definition.xpRequired(level))));
        PlayerProfile profile = profile(player);
        profile.unlockPet(definition.id());
        profile.setPetProgress(definition.id(), new PetProgress(level, xp));
        statUpdater.accept(player);
    }

    /** True when a player owns a normal pet or currently holds its rank permission. */
    public boolean unlocked(Player player, PetDefinition definition) {
        if (definition == null || !definition.enabled()) return false;
        if (!definition.requiredPermission().isBlank()) return player.hasPermission(definition.requiredPermission());
        return profile(player).petUnlocked(definition.id());
    }

    public void tick() {
        if (!enabled() || !configs.get().petSettings().visualsEnabled()) {
            visuals.forEach((uuid, entity) -> entity.remove());
            visuals.clear();
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            PetDefinition definition = active(player).orElse(null);
            if (definition == null) { removeVisual(player); continue; }
            Entity entity = visuals.get(player.getUniqueId());
            if (entity == null || !entity.isValid()) {
                spawnVisual(player, definition);
                continue;
            }
            Location target = player.getLocation().clone();
            if (target.getDirection().lengthSquared() > 0)
                target.subtract(target.getDirection().normalize().multiply(configs.get().petSettings().followDistance()));
            target.add(0, 0.25, 0);
            if (!entity.getWorld().equals(player.getWorld()) || entity.getLocation().distanceSquared(target) >
                    configs.get().petSettings().teleportDistance() * configs.get().petSettings().teleportDistance()
                    || entity.getLocation().distanceSquared(target) > 1.0) entity.teleport(target);
        }
    }

    public void removeVisual(Player player) {
        Entity entity = visuals.remove(player.getUniqueId());
        if (entity != null) entity.remove();
    }

    public void shutdown() {
        visuals.values().forEach(Entity::remove);
        visuals.clear();
        modifierCooldowns.clear();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (visuals.values().stream().anyMatch(entity -> entity.getUniqueId().equals(event.getEntity().getUniqueId())))
            event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTarget(EntityTargetLivingEntityEvent event) {
        if (event.getTarget() != null && visuals.values().stream()
                .anyMatch(entity -> entity.getUniqueId().equals(event.getTarget().getUniqueId()))) event.setCancelled(true);
    }

    /** Small effects reserved for configured store-rank pets. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onRankPetMelee(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        PetDefinition pet = activeRankPet(player);
        if (pet == null) return;
        int level = profile(player).petProgress(pet.id()).level();
        double value = pet.specialModifierValue(level);
        switch (pet.specialModifier()) {
            case "CINDERBITE" -> {
                if (event.getEntity() instanceof LivingEntity target && chance(value))
                    target.setFireTicks(Math.max(target.getFireTicks(), 24));
            }
            case "COMET_DASH" -> {
                if (player.isSprinting() && consumeModifierCooldown(player, pet))
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,
                            Math.max(20, (int) Math.round(value)), 0, true, false, true));
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onRankPetDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        PetDefinition pet = activeRankPet(player);
        if (pet == null) return;
        int level = profile(player).petProgress(pet.id()).level();
        double value = pet.specialModifierValue(level);
        switch (pet.specialModifier()) {
            case "AEGIS_WARD" -> {
                if (consumeModifierCooldown(player, pet)) event.setDamage(Math.max(0, event.getDamage() - value));
            }
            case "STARLIGHT_GRACE" -> {
                double afterHit = player.getHealth() - event.getFinalDamage();
                if (afterHit > 0 && afterHit / Math.max(1, player.getMaxHealth()) <= 0.25 && consumeModifierCooldown(player, pet)) {
                    player.setAbsorptionAmount(Math.max(player.getAbsorptionAmount(), value * 2.0));
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (player.isOnline()) player.setAbsorptionAmount(0);
                    }, 60L);
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onRankPetKill(EntityDeathEvent event) {
        if (!(event.getEntity() instanceof Monster) || !(event.getEntity().getKiller() instanceof Player player)) return;
        PetDefinition pet = activeRankPet(player);
        if (pet == null || !pet.specialModifier().equals("ROYAL_BOUNTY")) return;
        int level = profile(player).petProgress(pet.id()).level();
        event.setDroppedExp(event.getDroppedExp() + Math.max(1, (int) Math.floor(pet.specialModifierValue(level))));
    }

    private PetDefinition activeRankPet(Player player) {
        PetDefinition pet = active(player).orElse(null);
        return pet != null && !pet.specialModifier().isBlank() && unlocked(player, pet) ? pet : null;
    }

    private boolean consumeModifierCooldown(Player player, PetDefinition pet) {
        if (pet.specialModifierCooldownMs() <= 0) return true;
        long now = System.currentTimeMillis();
        Map<String, Long> cooldowns = modifierCooldowns.computeIfAbsent(player.getUniqueId(), ignored -> new ConcurrentHashMap<>());
        long readyAt = cooldowns.getOrDefault(pet.specialModifier(), 0L);
        if (readyAt > now) return false;
        cooldowns.put(pet.specialModifier(), now + pet.specialModifierCooldownMs());
        return true;
    }

    private static boolean chance(double percent) {
        return percent > 0 && ThreadLocalRandom.current().nextDouble(100.0) < percent;
    }

    private void spawnVisual(Player player, PetDefinition definition) {
        removeVisual(player);
        if (!configs.get().petSettings().visualsEnabled()) return;
        try {
            Entity entity = player.getWorld().spawnEntity(player.getLocation(), definition.entityType());
            entity.setInvulnerable(true);
            entity.setSilent(true);
            entity.setGlowing(configs.get().petSettings().glowing());
            entity.setGravity(false);
            entity.setPersistent(false);
            entity.customName(messages.raw(definition.displayName()));
            entity.setCustomNameVisible(configs.get().petSettings().showName());
            if (entity instanceof LivingEntity living) {
                living.setAI(false);
                living.setCollidable(false);
                living.setCanPickupItems(false);
            }
            if (entity instanceof Mob mob) mob.setRemoveWhenFarAway(false);
            visuals.put(player.getUniqueId(), entity);
        } catch (RuntimeException error) {
            if (!visualFailureLogged) {
                visualFailureLogged = true;
                plugin.getLogger().warning("Could not spawn a configured pet visual (" + error.getClass().getSimpleName()
                        + "). Pet bonuses and progression remain active.");
            }
        }
    }

    private PlayerProfile profile(Player player) { return data.getOrCreate(player.getUniqueId(), player.getName()); }
    private static String normalize(String value) {
        return value.toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
    }
}

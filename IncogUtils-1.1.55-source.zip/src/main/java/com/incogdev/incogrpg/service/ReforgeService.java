package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.model.ReforgeDefinition;
import com.incogdev.incogrpg.util.Messages;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class ReforgeService {
    private static final String LORE_MARKER = "incogrpg:reforge";
    private final ConfigManager configs;
    private final Messages messages;
    private final NamespacedKey key;
    private final NamespacedKey loreLinesKey;
    private final NamespacedKey originalNameKey;
    private final NamespacedKey originalNameCustomKey;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public ReforgeService(IncogRpgPlugin plugin, ConfigManager configs, Messages messages) {
        this.configs = configs; this.messages = messages; this.key = new NamespacedKey(plugin, "reforge");
        this.loreLinesKey = new NamespacedKey(plugin, "reforge_lore_lines");
        this.originalNameKey = new NamespacedKey(plugin, "reforge_original_name");
        this.originalNameCustomKey = new NamespacedKey(plugin, "reforge_original_name_custom");
    }

    public Optional<ReforgeDefinition> get(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return Optional.empty();
        String id = item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
        return Optional.ofNullable(id == null ? null : configs.get().reforges().get(id));
    }

    public List<ReforgeDefinition> compatible(ItemStack item) {
        if (item == null || item.getType().isAir()) return List.of();
        String current = get(item).map(ReforgeDefinition::id).orElse("");
        boolean allowSame = configs.get().reforgeSettings().allowSame();
        return configs.get().reforges().values().stream().filter(ReforgeDefinition::enabled)
                .filter(ReforgeDefinition::rollEnabled)
                .filter(def -> def.supports(item.getType())).filter(def -> allowSame || !def.id().equals(current)).toList();
    }

    public Optional<ReforgeDefinition> roll(ItemStack item) {
        List<ReforgeDefinition> options = compatible(item);
        double total = options.stream().mapToDouble(ReforgeDefinition::weight).sum();
        if (total <= 0) return Optional.empty();
        double selected = ThreadLocalRandom.current().nextDouble(total);
        for (ReforgeDefinition option : options) {
            selected -= option.weight();
            if (selected <= 0) return Optional.of(option);
        }
        return Optional.of(options.get(options.size() - 1));
    }

    public Optional<ReforgeDefinition> rollNatural(ItemStack item, String source, org.bukkit.entity.EntityType entityType) {
        List<ReforgeDefinition> options = configs.get().reforges().values().stream()
                .filter(ReforgeDefinition::enabled)
                .filter(definition -> definition.supports(item.getType()))
                .filter(definition -> definition.supportsNaturalSource(source, entityType))
                .toList();
        double total = options.stream().mapToDouble(ReforgeDefinition::naturalWeight).sum();
        if (total <= 0) return Optional.empty();
        double selected = ThreadLocalRandom.current().nextDouble(total);
        for (ReforgeDefinition option : options) {
            selected -= option.naturalWeight();
            if (selected <= 0) return Optional.of(option);
        }
        return Optional.of(options.get(options.size() - 1));
    }

    public boolean apply(ItemStack item, ReforgeDefinition definition) {
        return apply(item, definition, false);
    }

    /** Applies a definition, optionally bypassing its configured item groups for explicit admin use. */
    public boolean apply(ItemStack item, ReforgeDefinition definition, boolean force) {
        if (item == null || item.getType().isAir() || definition == null
                || (!force && !definition.supports(item.getType()))) return false;
        ItemMeta meta = item.getItemMeta();
        boolean alreadyReforged = meta.getPersistentDataContainer().has(key);
        stripOwnedLore(meta);
        if (!alreadyReforged || !meta.getPersistentDataContainer().has(originalNameKey)) rememberOriginalName(item, meta);
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, definition.id());
        List<Component> lore = new ArrayList<>(Optional.ofNullable(meta.lore()).orElse(List.of()));
        String format = configs.get().reforgeSettings().loreFormat().replace("<reforge>", definition.displayName());
        lore.add(0, messages.raw(format));
        definition.stats().forEach((stat, value) -> lore.add(1, messages.raw(
                "<dark_gray>  " + pretty(stat) + ": " + (value >= 0 ? "<green>+" : "<red>") + trim(value))));
        meta.getPersistentDataContainer().set(loreLinesKey, PersistentDataType.INTEGER, 1 + definition.stats().size());
        applyPrefix(item, meta, definition);
        meta.lore(lore);
        item.setItemMeta(meta);
        return true;
    }

    public boolean remove(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        if (!meta.getPersistentDataContainer().has(key)) return false;
        meta.getPersistentDataContainer().remove(key);
        stripOwnedLore(meta);
        restoreOriginalName(meta);
        item.setItemMeta(meta);
        return true;
    }

    public void migrate(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();
        String id = meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (id == null) return;
        boolean legacy = Optional.ofNullable(meta.lore()).orElse(List.of()).stream().anyMatch(this::isLegacyLine)
                || !meta.getPersistentDataContainer().has(loreLinesKey)
                || !meta.getPersistentDataContainer().has(originalNameKey);
        ReforgeDefinition definition = configs.get().reforges().get(id);
        if (legacy && definition != null) apply(item, definition);
    }

    public double cost(ItemStack item, ReforgeDefinition selected) {
        double base = configs.get().reforgeSettings().baseCost() * selected.costMultiplier();
        if (get(item).isPresent()) base *= configs.get().reforgeSettings().rerollCostMultiplier();
        return Math.max(0, base);
    }

    private void stripOwnedLore(ItemMeta meta) {
        List<Component> lore = new ArrayList<>(Optional.ofNullable(meta.lore()).orElse(List.of()));
        boolean removedLegacy = lore.removeIf(this::isLegacyLine);
        Integer count = meta.getPersistentDataContainer().get(loreLinesKey, PersistentDataType.INTEGER);
        if (!removedLegacy && count != null) {
            for (int i = 0; i < count && !lore.isEmpty(); i++) lore.remove(0);
        }
        meta.getPersistentDataContainer().remove(loreLinesKey);
        meta.lore(lore.isEmpty() ? null : lore);
    }

    private void rememberOriginalName(ItemStack item, ItemMeta meta) {
        boolean custom = meta.hasDisplayName();
        String original = custom && meta.displayName() != null ? mini.serialize(meta.displayName()) : "<white>" + pretty(item.getType().name());
        meta.getPersistentDataContainer().set(originalNameKey, PersistentDataType.STRING, original);
        meta.getPersistentDataContainer().set(originalNameCustomKey, PersistentDataType.BYTE, (byte) (custom ? 1 : 0));
    }

    private void applyPrefix(ItemStack item, ItemMeta meta, ReforgeDefinition definition) {
        String original = meta.getPersistentDataContainer().get(originalNameKey, PersistentDataType.STRING);
        if (original == null) original = "<white>" + pretty(item.getType().name());
        boolean keepCustom = configs.get().reforgeSettings().preserveOriginalName();
        Byte wasCustom = meta.getPersistentDataContainer().get(originalNameCustomKey, PersistentDataType.BYTE);
        String itemName = keepCustom || wasCustom == null || wasCustom == 0 ? original : "<white>" + pretty(item.getType().name());
        String name = configs.get().reforgeSettings().nameFormat()
                .replace("<reforge>", definition.displayName()).replace("<item>", itemName);
        meta.displayName(messages.raw(name));
    }

    private void restoreOriginalName(ItemMeta meta) {
        String original = meta.getPersistentDataContainer().get(originalNameKey, PersistentDataType.STRING);
        Byte wasCustom = meta.getPersistentDataContainer().get(originalNameCustomKey, PersistentDataType.BYTE);
        if (original != null && wasCustom != null && wasCustom == 1) meta.displayName(mini.deserialize(original));
        else meta.displayName(null);
        meta.getPersistentDataContainer().remove(originalNameKey);
        meta.getPersistentDataContainer().remove(originalNameCustomKey);
    }

    private boolean isLegacyLine(Component line) {
        return LORE_MARKER.equals(line.insertion()) || mini.serialize(line).contains(LORE_MARKER);
    }

    private static String pretty(String value) {
        String[] parts = value.replace("CUSTOM_", "").toLowerCase(Locale.ROOT).split("_");
        StringJoiner joiner = new StringJoiner(" ");
        for (String part : parts) joiner.add(Character.toUpperCase(part.charAt(0)) + part.substring(1));
        return joiner.toString();
    }
    private static String trim(double value) { return value == Math.rint(value) ? String.valueOf((long) value) : String.format(Locale.US, "%.3f", value).replaceAll("0+$", "").replaceAll("\\.$", ""); }
}

package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.api.event.SkillLevelUpEvent;
import com.incogdev.incogrpg.api.event.SkillXpGainEvent;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.model.PlayerProfile;
import com.incogdev.incogrpg.model.SkillDefinition;
import com.incogdev.incogrpg.model.SkillProgress;
import com.incogdev.incogrpg.util.Messages;
import com.incogdev.incogutils.settings.PlayerSettingsManager;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.ToDoubleFunction;

public final class SkillService {
    private final IncogRpgPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataService data;
    private final Messages messages;
    private final CustomItemService items;
    private final HudService hud;
    private final PetService pets;
    private final Map<UUID, Long> actionBarThrottle = new ConcurrentHashMap<>();
    private ToDoubleFunction<Player> xpBonusProvider = ignored -> 0.0;
    private java.util.function.Consumer<Player> statUpdater = ignored -> {};

    public SkillService(IncogRpgPlugin plugin, ConfigManager configs, PlayerDataService data, Messages messages,
                        CustomItemService items, HudService hud, PetService pets) {
        this.plugin = plugin; this.configs = configs; this.data = data; this.messages = messages;
        this.items = items; this.hud = hud; this.pets = pets;
    }

    public void setXpBonusProvider(ToDoubleFunction<Player> provider) { this.xpBonusProvider = provider; }
    public void setStatUpdater(java.util.function.Consumer<Player> updater) { this.statUpdater = updater; }

    public double awardSource(Player player, String sourceType, String target, double sourceMultiplier) {
        if (configs.get().disabledWorld(player.getWorld().getName())) return 0;
        double total = 0;
        for (SkillDefinition definition : configs.get().skills().values()) {
            if (!definition.enabled()) continue;
            for (SkillDefinition.XpSourceDefinition source : definition.sources()) {
                if (source.type().equalsIgnoreCase(sourceType) && source.matches(target)) {
                    double amount = source.amount() * Math.max(0, sourceMultiplier);
                    addXp(player, definition.id(), sourceType, amount);
                    total += amount;
                }
            }
        }
        return total;
    }

    public AddResult addXp(Player player, String skillId, String source, double rawAmount) {
        SkillDefinition definition = configs.get().skills().get(normalize(skillId));
        if (definition == null || !definition.enabled() || rawAmount <= 0) return AddResult.NONE;
        double global = Math.max(0, configs.get().core().getDouble("progression.xp-multiplier", 1.0));
        double bonus = Math.max(-100, xpBonusProvider.applyAsDouble(player));
        double petBonus = Math.max(0, pets.skillXpBonus(player, definition.id()));
        double amount = rawAmount * global * (1.0 + bonus / 100.0) * (1.0 + petBonus / 100.0);
        SkillXpGainEvent event = new SkillXpGainEvent(player, definition.id(), source, amount);
        Bukkit.getPluginManager().callEvent(event);
        if (event.isCancelled() || event.getAmount() <= 0) return AddResult.NONE;

        PlayerProfile profile = data.getOrCreate(player.getUniqueId(), player.getName());
        SkillProgress before = profile.progress(definition.id());
        int level = before.level();
        double xp = before.xp() + event.getAmount();
        int oldLevel = level;
        boolean totalCapHit = false;
        while (level < definition.maxLevel() && xp >= definition.xpRequired(level)) {
            int totalCap = configs.get().totalLevelCap();
            boolean bypass = player.hasPermission(configs.get().core().getString(
                    "progression.bypass-total-cap-permission", "incogrpg.bypass.skillcap"));
            if (totalCap > 0 && profile.totalLevels() + (level - oldLevel) >= totalCap && !bypass) {
                xp = Math.min(xp, Math.max(0, definition.xpRequired(level) - 0.0001));
                totalCapHit = true;
                break;
            }
            xp -= definition.xpRequired(level);
            level++;
        }
        if (level >= definition.maxLevel()) xp = 0;
        profile.setProgress(definition.id(), new SkillProgress(level, Math.max(0, xp)));
        pets.addXp(player, definition.id(), event.getAmount());

        if (level > oldLevel) {
            for (int gained = oldLevel + 1; gained <= level; gained++) processLevel(player, definition, gained);
            Bukkit.getPluginManager().callEvent(new SkillLevelUpEvent(player, definition.id(), oldLevel, level));
            statUpdater.accept(player);
            pets.refreshUnlocks(player, true);
            if (configs.get().core().getBoolean("persistence.save-on-level-up", true)) data.saveAsync(profile, false);
        }
        showActionBar(player, definition, event.getAmount(), level, xp);
        if (totalCapHit) messages.send(player, "total-cap-reached", Map.of("cap", configs.get().totalLevelCap()));
        return new AddResult(event.getAmount(), oldLevel, level, xp, totalCapHit);
    }

    public void setProgress(PlayerProfile profile, String skillId, int level, double xp) {
        SkillDefinition definition = configs.get().skills().get(normalize(skillId));
        if (definition == null) throw new IllegalArgumentException("Unknown skill " + skillId);
        int safeLevel = Math.min(Math.max(0, level), definition.maxLevel());
        double safeXp = safeLevel >= definition.maxLevel() ? 0 : Math.min(Math.max(0, xp), Math.nextDown(definition.xpRequired(safeLevel)));
        profile.setProgress(definition.id(), new SkillProgress(safeLevel, safeXp));
    }

    public SkillProgress setTotalXp(PlayerProfile profile, String skillId, double totalXp) {
        SkillDefinition definition = configs.get().skills().get(normalize(skillId));
        if (definition == null) throw new IllegalArgumentException("Unknown skill " + skillId);
        SkillProgress progress = progressForTotalXp(definition, totalXp);
        profile.setProgress(definition.id(), progress);
        return progress;
    }

    public static double totalXp(SkillDefinition definition, SkillProgress progress) {
        double total = Math.max(0, progress.xp());
        int completedLevels = Math.min(Math.max(0, progress.level()), definition.maxLevel());
        for (int level = 0; level < completedLevels; level++) total += definition.xpRequired(level);
        return total;
    }

    public static SkillProgress progressForTotalXp(SkillDefinition definition, double requestedTotal) {
        double remaining = Math.max(0, Double.isFinite(requestedTotal) ? requestedTotal : 0);
        int level = 0;
        while (level < definition.maxLevel()) {
            double required = definition.xpRequired(level);
            if (remaining < required) break;
            remaining -= required;
            level++;
        }
        return new SkillProgress(level, level >= definition.maxLevel() ? 0 : remaining);
    }

    private void processLevel(Player player, SkillDefinition definition, int level) {
        if (configs.get().core().getBoolean("progression.announce-level-ups", true)
                && plugin.playerSettings().enabled(player, PlayerSettingsManager.Setting.LEVEL_UP_NOTIFICATIONS)) {
            player.sendMessage(messages.component("skill-level-up", Map.of("skill", definition.displayName(), "level", level)));
            String soundName = configs.get().core().getString("progression.level-up-sound", "ui.toast.challenge_complete");
            try { player.playSound(player.getLocation(), soundName, 0.8f, 1.1f); }
            catch (Exception ignored) {}
        }
        SkillDefinition.Milestone milestone = definition.milestones().get(level);
        if (milestone == null) return;
        milestone.items().forEach((itemId, amount) -> items.definition(itemId).ifPresent(item -> {
            items.give(player, item, amount, CustomItemService.AcquisitionSource.SKILL_MILESTONE);
            messages.send(player, "milestone-item-reward", Map.of("amount", amount, "item", item.displayName()));
        }));
        milestone.messages().forEach(line -> player.sendMessage(messages.raw(line)));
        milestone.commands().forEach(command -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command
                .replace("<player>", player.getName()).replace("<uuid>", player.getUniqueId().toString())
                .replace("<skill>", definition.id()).replace("<level>", String.valueOf(level))));
    }

    private void showActionBar(Player player, SkillDefinition definition, double gained, int level, double xp) {
        if (!configs.get().core().getBoolean("progression.action-bar-xp", true)) return;
        long now = System.currentTimeMillis();
        long throttle = configs.get().core().getLong("progression.action-bar-throttle-ms", 500);
        Long previous = actionBarThrottle.put(player.getUniqueId(), now);
        if (previous != null && now - previous < throttle) return;
        double required = level >= definition.maxLevel() ? 0 : definition.xpRequired(level);
        int segments = Math.max(5, Math.min(30, configs.get().core().getInt("progression.action-bar-progress-segments", 10)));
        double progress = required <= 0 ? 1.0 : Math.max(0, Math.min(1, xp / required));
        Component bar = messages.component("skill-xp-actionbar", Map.of(
                "skill", definition.displayName(), "skill_color", "", "xp", format(gained),
                "current", format(xp), "required", required <= 0 ? "MAX" : format(required),
                "progress_bar", progressBar(progress, segments)));
        hud.notify(player, bar, progress);
    }

    private static String progressBar(double progress, int segments) {
        int filled = (int) Math.round(progress * segments);
        return "<gradient:#22D3EE:#8B5CF6>" + "▰".repeat(filled) + "</gradient><dark_gray>" + "▱".repeat(segments - filled) + "</dark_gray>";
    }

    public Optional<SkillDefinition> definition(String id) { return Optional.ofNullable(configs.get().skills().get(normalize(id))); }
    private static String normalize(String id) { return id.toLowerCase(Locale.ROOT).replace('-', '_'); }
    private static String format(double value) { return value >= 1000 ? String.format(Locale.US, "%,.0f", value) : String.format(Locale.US, "%.1f", value); }
    public record AddResult(double added, int oldLevel, int newLevel, double remainingXp, boolean totalCapHit) {
        public static final AddResult NONE = new AddResult(0, 0, 0, 0, false);
        public boolean leveledUp() { return newLevel > oldLevel; }
    }
}

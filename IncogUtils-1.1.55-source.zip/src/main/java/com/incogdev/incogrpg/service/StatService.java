package com.incogdev.incogrpg.service;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogrpg.data.PlayerDataService;
import com.incogdev.incogrpg.model.*;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class StatService {
    private final IncogRpgPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataService data;
    private final ReforgeService reforges;
    private final EnchantService enchants;
    private final CustomItemService items;
    private final PetService pets;
    private final AccessoryService accessories;
    private final Map<UUID, StatSnapshot> snapshots = new ConcurrentHashMap<>();
    private final Map<UUID, StatBreakdown> breakdowns = new ConcurrentHashMap<>();
    private final Map<UUID, Set<Attribute>> appliedAttributes = new ConcurrentHashMap<>();
    private volatile boolean attributeApplicationDisabled;
    private volatile boolean attributeFailureLogged;

    public StatService(IncogRpgPlugin plugin, ConfigManager configs, PlayerDataService data,
                       ReforgeService reforges, EnchantService enchants, CustomItemService items, PetService pets,
                       AccessoryService accessories) {
        this.plugin = plugin; this.configs = configs; this.data = data; this.reforges = reforges; this.enchants = enchants;
        this.items = items; this.pets = pets; this.accessories = accessories;
    }

    public StatSnapshot recompute(Player player) {
        Map<String, Double> values = new LinkedHashMap<>();
        Map<String, Map<String, Double>> sources = new LinkedHashMap<>();
        ConfigurationValues.copy(configs.get().core().getConfigurationSection("stats.base"), values, sources);
        PlayerProfile profile = data.getOrCreate(player.getUniqueId(), player.getName());
        for (SkillDefinition definition : configs.get().skills().values()) {
            int level = profile.progress(definition.id()).level();
            String skillSource = "Skill • " + plain(definition.displayName());
            definition.perLevelStats().forEach((stat, amount) -> merge(values, sources, stat, amount * level, skillSource));
            definition.milestones().forEach((milestoneLevel, milestone) -> {
                if (level >= milestoneLevel) milestone.stats().forEach((stat, amount) ->
                        merge(values, sources, stat, amount, skillSource + " milestone " + milestoneLevel));
            });
        }
        pets.active(player).ifPresent(pet -> pets.statBonuses(player).forEach((stat, amount) ->
                merge(values, sources, stat, amount, "Pet • " + plain(pet.displayName()))));
        List<ItemStack> equipped = new ArrayList<>();
        equipped.add(player.getInventory().getItemInMainHand());
        equipped.add(player.getInventory().getItemInOffHand());
        equipped.addAll(Arrays.asList(player.getInventory().getArmorContents()));
        equipped.addAll(accessories.items(player));
        for (int index = 0; index < equipped.size(); index++) {
            ItemStack item = equipped.get(index);
            Map<String, Integer> itemEnchants = enchants.get(item);
            for (var entry : itemEnchants.entrySet()) {
                EnchantDefinition definition = configs.get().enchants().get(entry.getKey());
                if (definition == null) continue;
                boolean active = definition.trigger().equals("PASSIVE") || (index == 0 && definition.trigger().equals("HELD_PASSIVE"));
                if (!active) continue;
                String enchantSource = "Enchant • " + plain(definition.displayName());
                for (EnchantDefinition.EffectDefinition effect : definition.effects()) {
                    if (effect.type().equals("ATTRIBUTE")) merge(values, sources, effect.text("attribute", ""), effect.scaled("amount", entry.getValue(), 0), enchantSource);
                    if (effect.type().equals("CUSTOM_STAT")) merge(values, sources, effect.text("stat", ""), effect.scaled("amount", entry.getValue(), 0), enchantSource);
                    if (effect.type().equals("SKILL_SCALE_ATTRIBUTE")) {
                        int skillLevel = profile.progress(effect.text("skill", "exploration")).level();
                        double amount = effect.scaled("amount-per-skill-level", entry.getValue(), 0) * skillLevel;
                        merge(values, sources, effect.text("attribute", "MOVEMENT_SPEED"), Math.min(effect.number("max-amount", amount), amount), enchantSource);
                    }
                }
            }
        }
        for (ItemStack item : equipped) {
            items.definition(item).ifPresent(definition -> definition.stats().forEach((stat, amount) ->
                    merge(values, sources, stat, amount, "Item • " + plain(definition.displayName()))));
        }
        double reforgeMultiplier = 1.0 + values.getOrDefault("CUSTOM_REFORGE_POWER", 0.0) / 100.0;
        for (ItemStack item : equipped) {
            reforges.get(item).ifPresent(reforge -> reforge.stats().forEach((stat, amount) ->
                    merge(values, sources, stat, amount * reforgeMultiplier, "Reforge • " + plain(reforge.displayName()))));
        }
        var caps = configs.get().core().getConfigurationSection("stats.caps");
        if (caps != null) caps.getKeys(false).forEach(stat -> {
            String id = stat.toUpperCase(Locale.ROOT);
            Double value = values.get(id);
            double cap = caps.getDouble(stat);
            if (value != null && value > cap) merge(values, sources, id, cap - value, "Configured cap");
        });
        StatSnapshot snapshot = new StatSnapshot(Map.copyOf(values));
        snapshots.put(player.getUniqueId(), snapshot);
        Map<String, StatBreakdown.StatLine> lines = new LinkedHashMap<>();
        values.forEach((stat, total) -> lines.put(stat, new StatBreakdown.StatLine(total,
                Map.copyOf(sources.getOrDefault(stat, Map.of())))));
        breakdowns.put(player.getUniqueId(), new StatBreakdown(Map.copyOf(lines)));
        applyAttributesSafely(player, snapshot);
        return snapshot;
    }

    public StatSnapshot get(Player player) {
        StatSnapshot snapshot = snapshots.get(player.getUniqueId());
        return snapshot == null ? recompute(player) : snapshot;
    }
    public double value(Player player, String stat) { return get(player).get(stat); }
    public StatBreakdown breakdown(Player player) {
        if (!breakdowns.containsKey(player.getUniqueId())) recompute(player);
        return breakdowns.getOrDefault(player.getUniqueId(), new StatBreakdown(Map.of()));
    }

    public void clear(Player player) {
        try {
            removeModifiers(player, appliedAttributes.remove(player.getUniqueId()));
        } catch (LinkageError | RuntimeException error) {
            if (!handleAttributeFailure(error)) throw error;
        }
        snapshots.remove(player.getUniqueId());
        breakdowns.remove(player.getUniqueId());
    }

    /** Re-enables attribute writes after an administrator reloads configuration. */
    public void resetAttributeCircuitBreaker() {
        attributeApplicationDisabled = false;
        attributeFailureLogged = false;
    }

    private void applyAttributesSafely(Player player, StatSnapshot snapshot) {
        if (!configs.get().core().getBoolean("stats.attribute-application.enabled", true)
                || attributeApplicationDisabled) return;
        try {
            applyAttributes(player, snapshot);
        } catch (LinkageError | RuntimeException error) {
            if (!handleAttributeFailure(error)) throw error;
        }
    }

    /**
     * Attribute APIs have changed binary signatures between Paper development builds. Never let a
     * compatibility failure escape into Bukkit's scheduler unless an administrator explicitly asks
     * for THROW behavior; otherwise one concise warning replaces thousands of repeated stack traces.
     */
    private boolean handleAttributeFailure(Throwable error) {
        String policy = configs.get().core().getString("stats.attribute-application.failure-policy", "DISABLE")
                .trim().toUpperCase(Locale.ROOT);
        if (policy.equals("THROW")) return false;
        if (!attributeFailureLogged && configs.get().core().getBoolean(
                "stats.attribute-application.log-first-failure", true)) {
            attributeFailureLogged = true;
            String detail = error.getMessage() == null || error.getMessage().isBlank()
                    ? error.getClass().getSimpleName()
                    : error.getClass().getSimpleName() + ": " + error.getMessage();
            plugin.getLogger().warning("Vanilla attribute application failed (" + detail + "). "
                    + (policy.equals("SUPPRESS")
                    ? "Further failures will be suppressed without stack traces."
                    : "Attribute application is disabled until /incogrpg reload or restart; custom stat calculations remain available."));
        }
        if (!policy.equals("SUPPRESS")) attributeApplicationDisabled = true;
        return true;
    }

    private void applyAttributes(Player player, StatSnapshot snapshot) {
        removeModifiers(player, appliedAttributes.get(player.getUniqueId()));
        Set<Attribute> applied = new HashSet<>();
        snapshot.values().forEach((stat, amount) -> {
            if (stat.startsWith("CUSTOM_") || Math.abs(amount) < 0.0000001) return;
            Attribute attribute = attribute(stat);
            if (attribute == null) return;
            AttributeInstance instance = player.getAttribute(attribute);
            if (instance == null) return;
            NamespacedKey key = modifierKey(stat);
            // Attribute modifiers can survive a hot reload/player serialization while the in-memory
            // appliedAttributes index cannot. Always remove the exact key before re-adding it so two
            // queued equipment recomputations are idempotent instead of throwing "already applied".
            instance.getModifiers().stream().filter(modifier -> modifier.getKey().equals(key))
                    .toList().forEach(instance::removeModifier);
            instance.addModifier(new AttributeModifier(key, boundedAttributeAmount(stat, amount), AttributeModifier.Operation.ADD_NUMBER));
            applied.add(attribute);
        });
        appliedAttributes.put(player.getUniqueId(), Set.copyOf(applied));
        Attribute maxHealth = attribute("MAX_HEALTH");
        AttributeInstance health = maxHealth == null ? null : player.getAttribute(maxHealth);
        if (health != null && player.getHealth() > health.getValue()) player.setHealth(Math.max(0.1, health.getValue()));
    }

    /**
     * IncogUtils grants fall protection through negative fall-damage modifiers. Never let a
     * combined progression/item/relic modifier reach -1.0, because that would make fall damage
     * zero regardless of drop height. A configured positive minimum keeps the rewards useful
     * while preserving meaningful damage from extreme falls.
     */
    private double boundedAttributeAmount(String stat, double amount) {
        if (!"FALL_DAMAGE_MULTIPLIER".equalsIgnoreCase(stat)) return amount;
        double minimumMultiplier = configs.get().core().getDouble("fall-damage.minimum-multiplier", 0.15D);
        minimumMultiplier = Math.max(0.01D, Math.min(1.0D, minimumMultiplier));
        return Math.max(amount, minimumMultiplier - 1.0D);
    }

    private void removeModifiers(Player player, Set<Attribute> attributes) {
        if (attributes == null) return;
        for (Attribute attribute : attributes) {
            AttributeInstance instance = player.getAttribute(attribute);
            if (instance == null) continue;
            instance.getModifiers().stream().filter(modifier -> modifier.getKey().namespace().equals(plugin.getName().toLowerCase(Locale.ROOT)))
                    .filter(modifier -> modifier.getKey().value().startsWith("stat_"))
                    .toList().forEach(instance::removeModifier);
        }
    }

    private Attribute attribute(String stat) {
        if (stat == null || stat.isBlank()) return null;
        return Registry.ATTRIBUTE.get(NamespacedKey.minecraft(stat.toLowerCase(Locale.ROOT)));
    }

    private NamespacedKey modifierKey(String stat) {
        return new NamespacedKey(plugin, "stat_" + stat.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_./-]", "_"));
    }

    private static void merge(Map<String, Double> values, Map<String, Map<String, Double>> sources,
                              String stat, double amount, String source) {
        if (stat == null || stat.isBlank() || !Double.isFinite(amount)) return;
        String id = stat.toUpperCase(Locale.ROOT);
        values.merge(id, amount, Double::sum);
        sources.computeIfAbsent(id, ignored -> new LinkedHashMap<>()).merge(source, amount, Double::sum);
    }

    private static String plain(String miniMessage) {
        return miniMessage.replaceAll("<[^>]+>", "").trim();
    }

    private static final class ConfigurationValues {
        static void copy(org.bukkit.configuration.ConfigurationSection section, Map<String, Double> target,
                         Map<String, Map<String, Double>> sources) {
            if (section == null) return;
            section.getKeys(false).forEach(key -> merge(target, sources, key, section.getDouble(key), "Base"));
        }
    }
}

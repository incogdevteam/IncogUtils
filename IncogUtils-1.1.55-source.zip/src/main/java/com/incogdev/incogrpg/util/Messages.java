package com.incogdev.incogrpg.util;

import com.incogdev.incogrpg.config.ConfigManager;
import com.incogdev.incogutils.branding.Branding;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;

import java.util.Map;

public final class Messages {
    private final ConfigManager configs;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public Messages(ConfigManager configs) { this.configs = configs; }

    public Component component(String key, Map<String, ?> replacements) {
        String raw = configs.get().messages().getString(key, "<red>Missing message: " + key);
        for (Map.Entry<String, ?> entry : replacements.entrySet()) {
            String placeholder = entry.getKey();
            raw = raw.replace("<" + placeholder + ">", String.valueOf(entry.getValue()))
                    .replace("</" + placeholder + ">", "");
        }
        return mini.deserialize(raw);
    }

    public Component component(String key, Map<String, ?> replacements, Map<String, Component> components) {
        String raw = configs.get().messages().getString(key, "<red>Missing message: " + key);
        for (Map.Entry<String, ?> entry : replacements.entrySet()) {
            if (components.containsKey(entry.getKey())) continue;
            raw = raw.replace("<" + entry.getKey() + ">", String.valueOf(entry.getValue()))
                    .replace("</" + entry.getKey() + ">", "");
        }
        TagResolver.Builder resolver = TagResolver.builder();
        for (Map.Entry<String, Component> entry : components.entrySet()) {
            raw = raw.replace("</" + entry.getKey() + ">", "");
            resolver.resolver(Placeholder.component(entry.getKey(), entry.getValue()));
        }
        return mini.deserialize(raw, resolver.build());
    }

    public Component raw(String miniMessage) { return mini.deserialize(miniMessage); }

    public void send(CommandSender sender, String key) { send(sender, key, Map.of()); }

    public void send(CommandSender sender, String key, Map<String, ?> replacements) {
        Component prefix = mini.deserialize(Branding.miniConfigured(configs.get().messages().getString("prefix", ""), "RPG"));
        sender.sendMessage(prefix.append(component(key, replacements)));
    }

    public void send(CommandSender sender, String key, Map<String, ?> replacements,
                     Map<String, Component> components) {
        Component prefix = mini.deserialize(Branding.miniConfigured(configs.get().messages().getString("prefix", ""), "RPG"));
        sender.sendMessage(prefix.append(component(key, replacements, components)));
    }
}

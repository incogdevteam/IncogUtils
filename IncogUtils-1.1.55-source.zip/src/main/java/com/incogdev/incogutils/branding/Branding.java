package com.incogdev.incogutils.branding;

import java.util.Locale;

/** Shared chat branding used by every bundled IncogUtils feature. */
public final class Branding {
    private Branding() {}

    public static String legacyPrefix(String feature) {
        return "§8[§b§lIncogUtils§r §7• §f" + feature + "§8] §7» §r";
    }

    public static String miniPrefix(String feature) {
        return "<dark_gray>[</dark_gray><aqua><bold>IncogUtils</bold></aqua> <gray>•</gray> <white>"
                + feature + "</white><dark_gray>]</dark_gray> <gray>»</gray> ";
    }

    /**
     * Upgrades known legacy defaults while preserving an administrator's genuinely custom prefix.
     */
    public static String legacyConfigured(String configured, String feature) {
        if (configured == null || configured.isBlank() || isLegacyBrand(configured)) return legacyPrefix(feature);
        return color(configured);
    }

    public static String miniConfigured(String configured, String feature) {
        if (configured == null || configured.isBlank() || isLegacyBrand(configured)) return miniPrefix(feature);
        return configured;
    }

    private static boolean isLegacyBrand(String configured) {
        String plain = configured.replaceAll("<[^>]+>", "")
                .replaceAll("(?i)[&§][0-9A-FK-ORX]", "")
                .toLowerCase(Locale.ROOT);
        return plain.contains("incogrpg") || plain.contains("incog-rpg")
                || plain.contains("incogecon") || plain.contains("incog-shop")
                || plain.contains("incog-claims") || plain.contains("incog claims")
                || plain.contains("incog-homes") || plain.contains("incog homes")
                || plain.contains("incog-antimacro") || plain.contains("antimacro")
                || plain.contains("itemforge") || plain.contains("incogvaults");
    }

    private static String color(String value) { return value.replace('&', '§'); }
}

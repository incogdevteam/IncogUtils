package com.incogdev.incogutils.maintenance;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogutils.branding.Branding;
import org.bukkit.command.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.*;

public final class MaintenanceCommand implements TabExecutor {
    private final IncogRpgPlugin plugin; private final MaintenanceManager manager;
    public MaintenanceCommand(IncogRpgPlugin plugin, MaintenanceManager manager) { this.plugin = plugin; this.manager = manager; }

    @Override public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.isOp() && !sender.hasPermission("incogutils.maintenance.admin")) { message(sender, "§cYou do not have permission."); return true; }
        if (args.length == 0 || args[0].equalsIgnoreCase("status") || args[0].equalsIgnoreCase("list")) { status(sender); return true; }
        if (args[0].equalsIgnoreCase("on") || args[0].equalsIgnoreCase("off")) {
            boolean on = args[0].equalsIgnoreCase("on"); String reason = args.length > 1 ? String.join(" ", Arrays.copyOfRange(args, 1, args.length)) : null;
            manager.setGlobal(on, reason); message(sender, "§aGlobal maintenance " + (on ? "enabled" : "disabled") + "."); return true;
        }
        if (args[0].equalsIgnoreCase("feature")) {
            if (args.length < 3) { message(sender, "§eUsage: /incogmaintenance feature <feature> <on|off> [reason]"); return true; }
            String feature = MaintenanceManager.normalize(args[1]); boolean on;
            if (args[2].equalsIgnoreCase("on")) on = true; else if (args[2].equalsIgnoreCase("off")) on = false; else { message(sender, "§cUse on or off."); return true; }
            String reason = args.length > 3 ? String.join(" ", Arrays.copyOfRange(args, 3, args.length)) : null;
            if (!manager.setFeature(feature, on, reason)) { message(sender, "§cUnknown feature. Use /incogmaintenance list."); return true; }
            message(sender, "§a" + MaintenanceManager.pretty(feature) + " maintenance " + (on ? "enabled" : "disabled") + "."); return true;
        }
        message(sender, "§e/incogmaintenance <status|on|off|feature>"); return true;
    }
    private static void message(CommandSender sender, String message) { sender.sendMessage(Branding.legacyPrefix("Maintenance") + message); }

    private void status(CommandSender sender) {
        sender.sendMessage("§8§m---------------- §6IncogUtils Maintenance §8§m----------------");
        sender.sendMessage("§7Global: " + (manager.globalEnabled() ? "§cON §7- §f" + manager.globalReason() : "§aOFF"));
        for (String f : MaintenanceManager.FEATURES) sender.sendMessage("§7- §f" + MaintenanceManager.pretty(f) + ": " + (manager.featureEnabled(f) ? "§cON §7- §f" + manager.featureReason(f) : "§aOFF"));
    }

    @Override public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) return filter(List.of("status","on","off","feature","list"), args[0]);
        if (args.length == 2 && args[0].equalsIgnoreCase("feature")) return filter(MaintenanceManager.FEATURES, args[1]);
        if (args.length == 3 && args[0].equalsIgnoreCase("feature")) return filter(List.of("on","off"), args[2]);
        return List.of();
    }
    private static List<String> filter(List<String> src, String p) { String q=p.toLowerCase(Locale.ROOT); return src.stream().filter(s->s.startsWith(q)).toList(); }
}

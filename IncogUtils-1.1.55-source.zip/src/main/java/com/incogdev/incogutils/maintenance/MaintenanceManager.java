package com.incogdev.incogutils.maintenance;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogutils.branding.Branding;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class MaintenanceManager {
    public static final List<String> FEATURES = List.of(
            "rpg", "pets", "economy", "market", "player_shops", "daily_rewards",
            "auctions", "trading", "shopping_district", "claims", "pvp", "homes",
            "itemforge", "antimacro", "vaults", "hex"
    );

    private final IncogRpgPlugin plugin;
    private final File file;
    private final Set<String> enabledFeatures = new HashSet<>();
    private final Map<String, String> featureReasons = new HashMap<>();
    private boolean global;
    private String globalReason = "IncogUtils is currently under maintenance.";

    public MaintenanceManager(IncogRpgPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "maintenance.yml");
    }

    public void load() {
        enabledFeatures.clear(); featureReasons.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        global = y.getBoolean("global.enabled", false);
        globalReason = y.getString("global.reason", "IncogUtils is currently under maintenance.");
        for (String feature : FEATURES) {
            if (y.getBoolean("features." + feature + ".enabled", false)) enabledFeatures.add(feature);
            featureReasons.put(feature, y.getString("features." + feature + ".reason", pretty(feature) + " is currently under maintenance."));
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("global.enabled", global); y.set("global.reason", globalReason);
        for (String feature : FEATURES) {
            y.set("features." + feature + ".enabled", enabledFeatures.contains(feature));
            y.set("features." + feature + ".reason", featureReasons.getOrDefault(feature, pretty(feature) + " is currently under maintenance."));
        }
        try { y.save(file); } catch (IOException e) { plugin.getLogger().warning("Could not save maintenance.yml: " + e.getMessage()); }
    }

    public boolean globalEnabled() { return global; }
    public boolean featureEnabled(String feature) { return enabledFeatures.contains(normalize(feature)); }
    public String globalReason() { return globalReason; }
    public String featureReason(String feature) { String f = normalize(feature); return featureReasons.getOrDefault(f, pretty(f) + " is currently under maintenance."); }

    public void setGlobal(boolean enabled, String reason) {
        global = enabled;
        if (reason != null && !reason.isBlank()) globalReason = reason;
        save();
        if (enabled) closePlayerInventories();
    }

    public boolean setFeature(String feature, boolean enabled, String reason) {
        String f = normalize(feature);
        if (!FEATURES.contains(f)) return false;
        if (enabled) enabledFeatures.add(f); else enabledFeatures.remove(f);
        if (reason != null && !reason.isBlank()) featureReasons.put(f, reason);
        save();
        if (enabled) closePlayerInventories();
        return true;
    }

    public boolean blocked(CommandSender sender, String feature) {
        if (!(sender instanceof Player player)) return false;
        return blocked(player, feature);
    }

    public boolean blocked(Player player, String feature) {
        if (player == null || player.hasPermission("incogutils.maintenance.bypass")) return false;
        return global || enabledFeatures.contains(normalize(feature));
    }

    public String message(String feature) {
        return Branding.legacyPrefix("Maintenance") + "§c" + (global ? globalReason : featureReason(feature));
    }

    public static String normalize(String feature) { return feature == null ? "" : feature.trim().toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_'); }
    public static String pretty(String feature) {
        String[] words = normalize(feature).split("_"); StringBuilder out = new StringBuilder();
        for (String w : words) { if (w.isEmpty()) continue; if (!out.isEmpty()) out.append(' '); out.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)); }
        return out.toString();
    }

    private void closePlayerInventories() {
        plugin.getServer().getOnlinePlayers().stream().filter(p -> !p.hasPermission("incogutils.maintenance.bypass")).forEach(Player::closeInventory);
    }
}

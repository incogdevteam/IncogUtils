package com.incogdev.incogutils.module;

import com.incogdev.incogrpg.IncogRpgPlugin;
import org.bukkit.Server;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.logging.Logger;

/**
 * Lightweight plugin-like context for an IncogUtils feature module.
 *
 * <p>Paper permits exactly one {@code JavaPlugin} instance per JAR. The legacy
 * projects therefore use this context instead of trying to construct multiple
 * JavaPlugin subclasses. It keeps each module's files isolated while delegating
 * server, command, scheduler and listener ownership to the IncogUtils host.</p>
 */
public abstract class ModuleContext {
    private final IncogRpgPlugin host;
    private final String moduleId;
    private final File dataFolder;
    private FileConfiguration config;

    protected ModuleContext(IncogRpgPlugin host, String moduleId, String... legacyFolderNames) {
        this.host = host;
        this.moduleId = moduleId;
        this.dataFolder = new File(host.getDataFolder(), moduleId);
        migrateLegacyFolder(legacyFolderNames);
    }

    public final IncogRpgPlugin host() { return host; }
    public final Server getServer() { return host.getServer(); }
    public final Logger getLogger() { return host.getLogger(); }
    public final File getDataFolder() { return dataFolder; }
    public final PluginCommand getCommand(String name) { return host.getCommand(name); }
    public final boolean isEnabled() { return host.isEnabled(); }

    public final FileConfiguration getConfig() {
        if (config == null) reloadConfig();
        return config;
    }

    public final void saveDefaultConfig() {
        File file = new File(dataFolder, "config.yml");
        if (!file.exists()) saveResource("config.yml", false);
        reloadConfig();
    }

    public final void reloadConfig() {
        File file = new File(dataFolder, "config.yml");
        config = YamlConfiguration.loadConfiguration(file);
        try (InputStream stream = host.getResource(resourcePath("config.yml"))) {
            if (stream != null) {
                FileConfiguration defaults = YamlConfiguration.loadConfiguration(
                        new java.io.InputStreamReader(stream, java.nio.charset.StandardCharsets.UTF_8));
                config.setDefaults(defaults);
                config.options().copyDefaults(true);
            }
        } catch (IOException exception) {
            getLogger().warning("Could not load defaults for " + moduleId + ": " + exception.getMessage());
        }
    }

    public final void saveConfig() {
        try {
            Files.createDirectories(dataFolder.toPath());
            getConfig().save(new File(dataFolder, "config.yml"));
        } catch (IOException exception) {
            getLogger().severe("Could not save " + moduleId + "/config.yml: " + exception.getMessage());
        }
    }

    public final void saveResource(String path, boolean replace) {
        File target = new File(dataFolder, path);
        if (target.exists() && !replace) return;
        try (InputStream stream = host.getResource(resourcePath(path))) {
            if (stream == null) throw new IllegalArgumentException("Missing embedded module resource: " + path);
            Path parent = target.toPath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.copy(stream, target.toPath(), replace
                    ? new StandardCopyOption[]{StandardCopyOption.REPLACE_EXISTING}
                    : new StandardCopyOption[0]);
        } catch (IOException exception) {
            throw new IllegalStateException("Could not save " + moduleId + "/" + path, exception);
        }
    }

    private String resourcePath(String path) {
        return "modules/" + moduleId + "/" + path.replace('\\', '/');
    }

    private void migrateLegacyFolder(String... legacyNames) {
        if (dataFolder.exists()) return;
        File pluginsFolder = host.getDataFolder().getParentFile();
        if (pluginsFolder == null) return;
        for (String name : legacyNames) {
            Path source = new File(pluginsFolder, name).toPath();
            if (!Files.isDirectory(source)) continue;
            try {
                Files.createDirectories(dataFolder.toPath());
                try (var paths = Files.walk(source)) {
                    paths.forEach(from -> {
                        try {
                            Path relative = source.relativize(from);
                            Path to = dataFolder.toPath().resolve(relative);
                            if (Files.isDirectory(from)) Files.createDirectories(to);
                            else if (!Files.exists(to)) Files.copy(from, to, StandardCopyOption.COPY_ATTRIBUTES);
                        } catch (IOException exception) {
                            getLogger().warning("Could not migrate " + from + ": " + exception.getMessage());
                        }
                    });
                }
                getLogger().info("Imported legacy " + name + " data into IncogUtils/" + moduleId + ".");
                return;
            } catch (IOException exception) {
                getLogger().warning("Could not import legacy " + name + " data: " + exception.getMessage());
            }
        }
    }
}

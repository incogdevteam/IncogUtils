package com.incogdev.incogutils.settings;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Applies admin feature switches to commands without disabling defensive listeners. */
public final class FeatureAccessListener implements Listener {
    private static final Map<String, String> COMMANDS = new HashMap<>();
    static {
        map("rpg", "skills","skill","stats","items","enchants","achievements","accessories","reforge","menus","menu","incogmenus","incogutils","iu","incogrpg","irpg","reload","iureload","incogreload","rpgreload","freeze","freezeplayer");
        map("pets", "pets","pet");
        map("antimacro", "antimacro","am","amacro","macroguard","verify");
        map("claims", "claims","claim","incogclaims"); map("pvp", "pvp");
        map("itemforge", "itemforge","iforge");
        map("market", "market","shop","sell","stash","xpvault","xpbank","weeklystock","infinitestock","weeklymarket","globalrestock","marketrestock","restockall","marketadmin","sellwand","shoplog","transactionlog","shoplogs");
        map("daily_rewards", "daily","dailyreward","dailyrewards","rewards");
        map("player_shops", "pshop"); map("auctions", "ah","auctionhouse","auction"); map("trading", "trade");
        map("shopping_district", "shopdistrict","sdistrict","shoppingdistrict","shopplot"); map("hex", "hex","thehex");
        map("homes", "sethome","forcesethome","home","delhome","homes","homeadmin");
        map("vaults", "incogvaults","regenkey","vaultregenkey","vrkey");
        map("economy", "pay","balance","bal");
    }

    private final FeatureSettingsManager manager;
    public FeatureAccessListener(FeatureSettingsManager manager) { this.manager = manager; }
    private static void map(String feature, String... labels) { for (String label : labels) COMMANDS.put(label, feature); }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        String raw = event.getMessage().substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
        int colon = raw.indexOf(':'); if (colon >= 0) raw = raw.substring(colon + 1);
        if (raw.equals("settings") || raw.equals("preferences") || raw.equals("adminsettings") || raw.equals("featuresettings")) return;
        String feature = COMMANDS.get(raw);
        if (feature == null || !manager.blocked(event.getPlayer(), feature)) return;
        event.setCancelled(true);
        event.getPlayer().sendMessage(manager.message(manager.globalEnabled() ? feature : ""));
    }
}

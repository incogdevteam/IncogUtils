package com.incogdev.incogutils.settings;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogutils.branding.Branding;
import com.incogdev.incogutils.maintenance.MaintenanceManager;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Runtime-safe feature switches: player entry is blocked, while protection and persistence stay active. */
public final class FeatureSettingsManager {
    private final IncogRpgPlugin plugin;
    private final File file;
    private final Map<String, Boolean> enabled = new HashMap<>();
    private boolean globalEnabled = true;

    public FeatureSettingsManager(IncogRpgPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "feature-settings.yml");
    }

    public void load() {
        enabled.clear();
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        globalEnabled = yaml.getBoolean("global-enabled", true);
        for (String feature : MaintenanceManager.FEATURES)
            enabled.put(feature, yaml.getBoolean("features." + feature + ".enabled", true));
        if (!file.exists()) save();
    }

    public boolean globalEnabled() { return globalEnabled; }
    public boolean featureEnabled(String feature) { return enabled.getOrDefault(normalize(feature), true); }

    public void setGlobalEnabled(boolean value) {
        globalEnabled = value;
        save();
        if (!value) closePlayerInventories();
    }

    public boolean setFeatureEnabled(String feature, boolean value) {
        String normalized = normalize(feature);
        if (!MaintenanceManager.FEATURES.contains(normalized)) return false;
        enabled.put(normalized, value);
        save();
        if (!value) closePlayerInventories();
        return true;
    }

    public boolean blocked(CommandSender sender, String feature) {
        return sender instanceof Player player && blocked(player, feature);
    }

    public boolean blocked(Player player, String feature) {
        if (player == null || player.hasPermission("incogutils.features.bypass")) return false;
        String normalized = normalize(feature);
        return !globalEnabled || !featureEnabled(normalized) || !featureEnabled(parent(normalized));
    }

    public String message(String feature) {
        if (!globalEnabled) return Branding.legacyPrefix("Settings") + "§cIncogUtils is currently disabled by an administrator.";
        return Branding.legacyPrefix("Settings") + "§c" + MaintenanceManager.pretty(feature)
                + " is currently disabled by an administrator.";
    }

    public static String parent(String feature) {
        return switch (normalize(feature)) {
            case "market", "daily_rewards", "player_shops", "auctions", "trading", "shopping_district", "hex" -> "economy";
            default -> normalize(feature);
        };
    }

    private void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("global-enabled", globalEnabled);
        for (String feature : MaintenanceManager.FEATURES)
            yaml.set("features." + feature + ".enabled", featureEnabled(feature));
        try { yaml.save(file); }
        catch (IOException error) { plugin.getLogger().warning("Could not save feature-settings.yml: " + error.getMessage()); }
    }

    private void closePlayerInventories() {
        plugin.getServer().getOnlinePlayers().stream()
                .filter(player -> !player.hasPermission("incogutils.features.bypass"))
                .forEach(Player::closeInventory);
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
    }
}

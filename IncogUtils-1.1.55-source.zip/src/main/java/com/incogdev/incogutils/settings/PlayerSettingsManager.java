package com.incogdev.incogutils.settings;

import com.incogdev.incogrpg.IncogRpgPlugin;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Persistent, opt-out preferences for player-facing notifications and HUD elements. */
public final class PlayerSettingsManager {
    public enum Setting {
        SKILL_PROGRESS("skill-progress-action-bar", "Skill Progress", true),
        HEALTH_DISPLAY("health-action-bar", "Health Display", true),
        LEVEL_UP_NOTIFICATIONS("level-up-notifications", "Level-Up Notifications", true),
        ACHIEVEMENT_NOTIFICATIONS("achievement-notifications", "Achievement Notifications", true),
        PVP_STATUS_DISPLAY("pvp-status-action-bar", "PVP Status", true);

        private final String path;
        private final String label;
        private final boolean fallback;

        Setting(String path, String label, boolean fallback) {
            this.path = path; this.label = label; this.fallback = fallback;
        }

        public String path() { return path; }
        public String label() { return label; }
        public boolean fallback() { return fallback; }
    }

    private final IncogRpgPlugin plugin;
    private final File file;
    private final Map<UUID, EnumMap<Setting, Boolean>> values = new java.util.HashMap<>();

    public PlayerSettingsManager(IncogRpgPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "player-settings.yml");
    }

    public synchronized void load() {
        values.clear();
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        var players = yaml.getConfigurationSection("players");
        if (players == null) return;
        for (String rawUuid : players.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(rawUuid);
                EnumMap<Setting, Boolean> playerValues = new EnumMap<>(Setting.class);
                for (Setting setting : Setting.values()) {
                    String path = "players." + rawUuid + "." + setting.path();
                    if (yaml.contains(path)) playerValues.put(setting, yaml.getBoolean(path));
                }
                if (!playerValues.isEmpty()) values.put(uuid, playerValues);
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Ignored invalid UUID in player-settings.yml: " + rawUuid);
            }
        }
    }

    public boolean enabled(Player player, Setting setting) { return enabled(player.getUniqueId(), setting); }

    public synchronized boolean enabled(UUID uuid, Setting setting) {
        Boolean configured = values.getOrDefault(uuid, new EnumMap<>(Setting.class)).get(setting);
        return configured != null ? configured : defaultValue(setting);
    }

    public synchronized boolean toggle(Player player, Setting setting) {
        boolean next = !enabled(player, setting);
        values.computeIfAbsent(player.getUniqueId(), ignored -> new EnumMap<>(Setting.class)).put(setting, next);
        save(player);
        return next;
    }

    private boolean defaultValue(Setting setting) {
        return plugin.configs().get().core().getBoolean("player-settings.defaults." + setting.path(), setting.fallback());
    }

    private void save(Player changedPlayer) {
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        String root = "players." + changedPlayer.getUniqueId();
        yaml.set(root + ".last-known-name", changedPlayer.getName());
        EnumMap<Setting, Boolean> playerValues = values.get(changedPlayer.getUniqueId());
        for (Setting setting : Setting.values()) {
            Boolean value = playerValues == null ? null : playerValues.get(setting);
            yaml.set(root + "." + setting.path(), value);
        }
        try { yaml.save(file); }
        catch (IOException error) { plugin.getLogger().warning("Could not save player-settings.yml: " + error.getMessage()); }
    }

    public static Setting byPath(String value) {
        if (value == null) return null;
        String normalized = value.toLowerCase(Locale.ROOT).replace('_', '-');
        for (Setting setting : Setting.values()) if (setting.path().equals(normalized)) return setting;
        return null;
    }
}

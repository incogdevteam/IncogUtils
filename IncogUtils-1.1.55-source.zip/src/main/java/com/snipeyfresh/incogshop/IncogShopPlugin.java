package com.snipeyfresh.incogshop;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogutils.module.ModuleContext;
import com.incogdev.incogutils.branding.Branding;
import com.snipeyfresh.incogshop.auction.AuctionManager;
import com.snipeyfresh.incogshop.command.*;
import com.snipeyfresh.incogshop.economy.WalletManager;
import com.snipeyfresh.incogshop.economy.RankPerkManager;
import com.snipeyfresh.incogshop.history.PriceHistoryManager;
import com.snipeyfresh.incogshop.history.TransactionLogManager;
import com.snipeyfresh.incogshop.discord.DiscordPriceBridge;
import com.snipeyfresh.incogshop.gui.AuctionGui;
import com.snipeyfresh.incogshop.gui.SellGui;
import com.snipeyfresh.incogshop.gui.ShopGui;
import com.snipeyfresh.incogshop.listener.*;
import com.snipeyfresh.incogshop.market.DailyMarketFluxManager;
import com.snipeyfresh.incogshop.market.MarketManager;
import com.snipeyfresh.incogshop.market.WeeklyInfiniteStockManager;
import com.snipeyfresh.incogshop.daily.DailyRewardsManager;
import com.snipeyfresh.incogshop.daily.DailyRewardsAdminGui;
import com.snipeyfresh.incogshop.order.MarketOrderManager;
import com.snipeyfresh.incogshop.shop.ShopManager;
import com.snipeyfresh.incogshop.shop.OwnerShopHologramManager;
import com.snipeyfresh.incogshop.shopping.ShoppingDistrictManager;
import com.snipeyfresh.incogshop.shopping.MultiverseInventoriesBridge;
import com.snipeyfresh.incogshop.sellwand.SellWandCommand;
import com.snipeyfresh.incogshop.sellwand.SellWandListener;
import com.snipeyfresh.incogshop.sellwand.SellWandManager;
import com.snipeyfresh.incogshop.trade.TradeCommand;
import com.snipeyfresh.incogshop.trade.TradeManager;
import com.snipeyfresh.incogshop.gui.TradeGui;
import com.snipeyfresh.incogshop.util.Text;
import com.snipeyfresh.incogshop.util.AsyncIoManager;
import com.snipeyfresh.incogshop.stash.StashManager;
import com.snipeyfresh.incogshop.xp.XpVaultManager;
import com.snipeyfresh.incogshop.gui.StashGui;
import com.snipeyfresh.incogshop.gui.XpVaultGui;
import com.snipeyfresh.incogshop.gui.AdminSetupGui;
import com.snipeyfresh.incogshop.custom.CustomCategoryManager;
import com.snipeyfresh.incogshop.custom.GuiLayoutManager;
import com.snipeyfresh.incogshop.gui.LayoutEditorGui;
import com.snipeyfresh.incogshop.platform.BedrockInputManager;
import com.snipeyfresh.incogshop.hex.HexManager;
import com.snipeyfresh.incogshop.hex.HexCommand;
import com.snipeyfresh.incogshop.gui.HexGui;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.util.Objects;
import java.util.List;
import java.util.Map;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public final class IncogShopPlugin extends ModuleContext {
    private AsyncIoManager io;
    private WalletManager wallets;
    private RankPerkManager rankPerks;
    private MarketManager market;
    private DailyMarketFluxManager dailyMarketFlux;
    private WeeklyInfiniteStockManager weeklyInfiniteStock;
    private DailyRewardsManager dailyRewards;
    private DailyRewardsAdminGui dailyRewardsAdmin;
    private ShopManager shops;
    private OwnerShopHologramManager ownerShopHolograms;
    private ShoppingDistrictManager shoppingDistrict;
    private MultiverseInventoriesBridge multiverseInventories;
    private SellWandManager sellWands;
    private TradeManager trades;
    private TradeGui tradeGui;
    private AuctionManager auctions;
    private MarketOrderManager orders;
    private PriceHistoryManager history;
    private TransactionLogManager transactionLog;
    private DiscordPriceBridge discordPriceBridge;
    private ShopGui gui;
    private SellGui sellGui;
    private AuctionGui auctionGui;
    private com.snipeyfresh.incogshop.gui.OrderBookGui orderGui;
    private CustomCategoryManager customCategories;
    private GuiLayoutManager layouts;
    private LayoutEditorGui layoutEditor;
    private StashManager stash;
    private StashGui stashGui;
    private XpVaultManager xpVault;
    private XpVaultGui xpVaultGui;
    private AdminSetupGui adminSetupGui;
    private BedrockInputManager bedrockInputs;
    private HexManager hex;
    private HexGui hexGui;
    private int autosavePhase;

    public IncogShopPlugin(IncogRpgPlugin host) {
        super(host, "economy", "IncogEcon", "Incog-Shop");
    }

    public void enable() {
        saveDefaultConfig();
        migrateShoppingDistrictWorldPolicy();
        migrateShoppingDistrictLazyIslandDefaults();
        migrateLegacySellWandMaterial();
        migrateLegacyDefaultRankPerks();
        io = new AsyncIoManager(this);
        transactionLog = new TransactionLogManager(this);
        wallets = new WalletManager(this);
        wallets.load();
        if (!wallets.ready()) {
            getLogger().severe("IncogEcon requires a working Vault economy provider in VAULT mode. Disabling to protect player balances.");
            return;
        }
        rankPerks = new RankPerkManager(this);

        market = new MarketManager(this);
        dailyMarketFlux = new DailyMarketFluxManager(this);
        weeklyInfiniteStock = new WeeklyInfiniteStockManager(this);
        dailyRewards = new DailyRewardsManager(this);
        dailyRewardsAdmin = new DailyRewardsAdminGui(this);
        customCategories = new CustomCategoryManager(this);
        layouts = new GuiLayoutManager(this);
        shops = new ShopManager(this);
        shoppingDistrict = new ShoppingDistrictManager(this);
        multiverseInventories = new MultiverseInventoriesBridge(this);
        ownerShopHolograms = new OwnerShopHologramManager(this);
        sellWands = new SellWandManager(this);
        trades = new TradeManager(this);
        tradeGui = new TradeGui(this);
        auctions = new AuctionManager(this);
        orders = new MarketOrderManager(this);
        gui = new ShopGui(this);
        sellGui = new SellGui(this);
        auctionGui = new AuctionGui(this);
        orderGui = new com.snipeyfresh.incogshop.gui.OrderBookGui(this);
        layoutEditor = new LayoutEditorGui(this);
        stash = new StashManager(this);
        stashGui = new StashGui(this);
        xpVault = new XpVaultManager(this);
        xpVaultGui = new XpVaultGui(this);
        adminSetupGui = new AdminSetupGui(this);
        bedrockInputs = new BedrockInputManager(this);
        hex = new HexManager(this);
        hexGui = new HexGui(this);
        hex.logDetectedIntegrations();

        market.load();
        dailyMarketFlux.load();
        weeklyInfiniteStock.load();
        dailyRewards.load();
        customCategories.load();
        layouts.load();
        stash.load();
        xpVault.load();
        shoppingDistrict.enable();
        multiverseInventories.scheduleSync();
        shops.load();
        ownerShopHolograms.refresh();
        auctions.load();
        orders.load();

        history = new PriceHistoryManager(this);
        history.load();
        history.captureChangedPrices();

        discordPriceBridge = new DiscordPriceBridge(this);
        discordPriceBridge.start();
        for (Player player : Bukkit.getOnlinePlayers()) wallets.touch(player.getUniqueId(), player.getName());

        MarketCommand marketCommand = new MarketCommand(this);
        PluginCommand marketPluginCommand = Objects.requireNonNull(getCommand("market"));
        marketPluginCommand.setExecutor(marketCommand); marketPluginCommand.setTabCompleter(marketCommand);
        Objects.requireNonNull(getCommand("sell")).setExecutor(new SellCommand(this));
        Objects.requireNonNull(getCommand("shoplog")).setExecutor(new ShopLogCommand(this));
        Objects.requireNonNull(getCommand("stash")).setExecutor(new StashCommand(this));
        Objects.requireNonNull(getCommand("xpvault")).setExecutor(new XpVaultCommand(this));
        Objects.requireNonNull(getCommand("hex")).setExecutor(new HexCommand(this));
        Objects.requireNonNull(getCommand("globalrestock")).setExecutor(new GlobalRestockCommand(this));
        Objects.requireNonNull(getCommand("weeklystock")).setExecutor(new WeeklyInfiniteStockCommand(this));
        Objects.requireNonNull(getCommand("daily")).setExecutor(new DailyRewardsCommand(this));

        SellWandCommand sellWandCommand = new SellWandCommand(this);
        PluginCommand sellWandPluginCommand = Objects.requireNonNull(getCommand("sellwand"));
        sellWandPluginCommand.setExecutor(sellWandCommand);
        sellWandPluginCommand.setTabCompleter(sellWandCommand);

        TradeCommand tradeCommand = new TradeCommand(this);
        PluginCommand tradePluginCommand = Objects.requireNonNull(getCommand("trade"));
        tradePluginCommand.setExecutor(tradeCommand);
        tradePluginCommand.setTabCompleter(tradeCommand);

        PlayerShopCommand pshop = new PlayerShopCommand(this);
        PluginCommand pshopCommand = Objects.requireNonNull(getCommand("pshop"));
        pshopCommand.setExecutor(pshop); pshopCommand.setTabCompleter(pshop);

        ShoppingDistrictCommand shoppingDistrictCommand = new ShoppingDistrictCommand(this);
        PluginCommand shoppingDistrictPluginCommand = Objects.requireNonNull(getCommand("shopdistrict"));
        shoppingDistrictPluginCommand.setExecutor(shoppingDistrictCommand);
        shoppingDistrictPluginCommand.setTabCompleter(shoppingDistrictCommand);

        AuctionCommand auction = new AuctionCommand(this);
        PluginCommand auctionCommand = Objects.requireNonNull(getCommand("ah"));
        auctionCommand.setExecutor(auction); auctionCommand.setTabCompleter(auction);

        AdminCommand admin = new AdminCommand(this);
        PluginCommand adminCommand = Objects.requireNonNull(getCommand("marketadmin"));
        adminCommand.setExecutor(admin); adminCommand.setTabCompleter(admin);

        getServer().getPluginManager().registerEvents(new GuiListener(this), host());
        getServer().getPluginManager().registerEvents(new LayoutEditorListener(this), host());
        getServer().getPluginManager().registerEvents(new AdminSetupListener(this), host());
        getServer().getPluginManager().registerEvents(new SellGuiListener(this), host());
        getServer().getPluginManager().registerEvents(new StashGuiListener(this), host());
        getServer().getPluginManager().registerEvents(new StashOverflowListener(this), host());
        getServer().getPluginManager().registerEvents(new XpVaultGuiListener(this), host());
        getServer().getPluginManager().registerEvents(new AuctionGuiListener(this), host());
        getServer().getPluginManager().registerEvents(new OrderGuiListener(this), host());
        getServer().getPluginManager().registerEvents(new ShopProtectionListener(this), host());
        getServer().getPluginManager().registerEvents(new ShoppingDistrictListener(this), host());
        getServer().getPluginManager().registerEvents(new SellWandListener(this), host());
        getServer().getPluginManager().registerEvents(new TradeListener(this), host());
        getServer().getPluginManager().registerEvents(new PlayerListener(this), host());
        getServer().getPluginManager().registerEvents(new HexListener(this), host());
        getServer().getPluginManager().registerEvents(dailyRewardsAdmin, host());

        getServer().getScheduler().runTaskTimer(host(), () -> {
            market.decayDemand();
        }, 20L * 60, 20L * 60);

        long historyTicks = Math.max(20L * 60L,
                getConfig().getLong("discord-price-check.history-resolution-minutes", 5) * 20L * 60L);
        getServer().getScheduler().runTaskTimer(host(), history::captureChangedPrices, historyTicks, historyTicks);
        getServer().getScheduler().runTaskTimer(host(), history::pruneAndRewrite, 20L * 60L * 60L, 20L * 60L * 60L);
        getServer().getScheduler().runTaskTimer(host(), auctions::settleExpired, 20L * 30, 20L * 30);
        getServer().getScheduler().runTaskTimer(host(), trades::expireRequests, 20L, 20L);
        getServer().getScheduler().runTaskTimer(host(), market::checkScheduledRestock, 20L * 60L, 20L * 60L);
        getServer().getScheduler().runTaskTimer(host(), dailyMarketFlux::tick, 20L, 20L);
        getServer().getScheduler().runTaskTimer(host(), weeklyInfiniteStock::tick, 20L, 20L);
        // Spread the autosave work across the configured autosave window instead
        // of serializing every IncogEcon data file on the exact same server tick.
        long saveCycleTicks = Math.max(20L * 8L, getConfig().getLong("saving.autosave-seconds", 60) * 20L);
        long saveSliceTicks = Math.max(20L, saveCycleTicks / 8L);
        getServer().getScheduler().runTaskTimer(host(), this::autosaveSlice, saveSliceTicks, saveSliceTicks);

        if (bedrockInputs.available()) {
            getLogger().info("Bedrock native input bridge: " + bedrockInputs.status() + ".");
        } else {
            getLogger().warning("No Geyser/Floodgate API is visible on this backend. Bedrock native text forms are unavailable; "
                    + "install Geyser-Spigot here or Floodgate on this backend if Bedrock players use IncogEcon text-entry features.");
        }
        getLogger().info("IncogEcon 1.9.2 by SnipeyFresh enabled. Economy provider: " + wallets.providerName() + ". Tradable materials: " + market.tradableMaterials().size() + ".");
    }

    /**
     * Replaces only the original two-tier VIP/MVP defaults with Incog's six
     * current rank tiers. Any administrator-created tier list is left intact.
     */
    private void migrateLegacyDefaultRankPerks() {
        boolean changed = false;
        if (isLegacyDefaultTierList("rank-perks.buy-discounts", "incogshop.discount.")) {
            getConfig().set("rank-perks.buy-discounts", incogRankTiers("incogshop.discount."));
            changed = true;
        }
        if (isLegacyDefaultTierList("rank-perks.sell-bonuses", "incogshop.sellbonus.")) {
            getConfig().set("rank-perks.sell-bonuses", incogRankTiers("incogshop.sellbonus."));
            changed = true;
        }
        if (changed) {
            saveConfig();
            getLogger().info("Migrated the default market rank perks to Secret, Unknown, Ominous, Cryptic, Incog, and Incog+.");
        }
    }

    /**
     * Legacy Sell Wands used Blaze Rods, which invited accidental Blaze Powder
     * crafting. Migrate only the old default once; intentionally customized
     * materials are preserved for administrators who choose to keep them.
     */
    private void migrateLegacySellWandMaterial() {
        if (getConfig().getBoolean("sell-wands.material-migration-complete", false)) return;
        String material = getConfig().getString("sell-wands.material", "STICK");
        boolean migrated = material != null && material.trim().equalsIgnoreCase("BLAZE_ROD");
        if (migrated) getConfig().set("sell-wands.material", "STICK");
        getConfig().set("sell-wands.material-migration-complete", true);
        saveConfig();
        if (migrated) {
            getLogger().info("Migrated the legacy Sell Wand material from BLAZE_ROD to STICK. Existing tagged wands remain protected.");
        }
    }

    /** Existing module configs are preserved, so migrate the requested no-PvP policy once. */
    private void migrateShoppingDistrictWorldPolicy() {
        // Read the stored file without defaults: ModuleContext exposes embedded
        // defaults in memory, which would otherwise make an absent migration
        // marker look as though it had already run on an upgraded server.
        File storedFile = new File(getDataFolder(), "config.yml");
        int version = YamlConfiguration.loadConfiguration(storedFile)
                .getInt("shopping-district.protection.policy-migration-version", 0);
        if (version >= 1) return;
        getConfig().set("shopping-district.protection.allow-pvp", false);
        getConfig().set("shopping-district.protection.policy-migration-version", 1);
        saveConfig();
        getLogger().info("Disabled PvP in the Shopping District and installed the protected-world policy.");
    }

    /** Updates only the former 25x25/50x50 defaults; custom district sizing is preserved. */
    private void migrateShoppingDistrictLazyIslandDefaults() {
        File storedFile = new File(getDataFolder(), "config.yml");
        YamlConfiguration stored = YamlConfiguration.loadConfiguration(storedFile);
        int version = stored.getInt("shopping-district.generation.lazy-islands-migration-version", 0);
        if (version >= 1) return;

        boolean changed = false;
        int legacyMaximum = stored.getInt("shopping-district.plots.max-size", 50);
        if (legacyMaximum == 50 && stored.getInt("shopping-district.plots.starter-size", 25) == 25) {
            getConfig().set("shopping-district.plots.starter-size", 40);
            changed = true;
        }
        if (legacyMaximum == 50) {
            getConfig().set("shopping-district.plots.max-size", 100);
            changed = true;
        }
        if (!stored.contains("shopping-district.plots.base-max-size")) {
            getConfig().set("shopping-district.plots.base-max-size", 50);
            changed = true;
        }
        getConfig().set("shopping-district.generation.lazy-islands-migration-version", 1);
        saveConfig();
        if (changed) {
            getLogger().info("Updated legacy Shopping District defaults to 40x40 starter, 50x50 base cap, and 100x100 rank cap.");
        }
    }

    private boolean isLegacyDefaultTierList(String path, String permissionPrefix) {
        List<Map<?, ?>> tiers = getConfig().getMapList(path);
        return tiers.size() == 2
                && containsTier(tiers, permissionPrefix + "vip", 10.0)
                && containsTier(tiers, permissionPrefix + "mvp", 15.0);
    }

    private boolean containsTier(List<Map<?, ?>> tiers, String permission, double percent) {
        return tiers.stream().anyMatch(tier -> permission.equalsIgnoreCase(String.valueOf(tier.get("permission")))
                && tier.get("percent") instanceof Number number
                && Double.compare(number.doubleValue(), percent) == 0);
    }

    private List<Map<String, Object>> incogRankTiers(String permissionPrefix) {
        return List.of(
                rankTier(permissionPrefix + "secret", 5.0),
                rankTier(permissionPrefix + "unknown", 10.0),
                rankTier(permissionPrefix + "ominous", 15.0),
                rankTier(permissionPrefix + "cryptic", 20.0),
                rankTier(permissionPrefix + "incog", 25.0),
                rankTier(permissionPrefix + "incog+", 30.0)
        );
    }

    private Map<String, Object> rankTier(String permission, double percent) {
        return Map.of("permission", permission, "percent", percent);
    }

    public void disable() {
        if (trades != null) trades.shutdown();
        if (discordPriceBridge != null) discordPriceBridge.stop();
        if (history != null) history.pruneAndRewrite();
        saveAllData();
        if (ownerShopHolograms != null) ownerShopHolograms.clear();
        if (shoppingDistrict != null) shoppingDistrict.disable();
        if (io != null) io.shutdownAndFlush(15_000L);
    }

    public AsyncIoManager io() { return io; }
    public WalletManager wallets() { return wallets; }
    public RankPerkManager rankPerks() { return rankPerks; }
    public MarketManager market() { return market; }
    public DailyMarketFluxManager dailyMarketFlux() { return dailyMarketFlux; }
    public WeeklyInfiniteStockManager weeklyInfiniteStock() { return weeklyInfiniteStock; }
    public DailyRewardsManager dailyRewards() { return dailyRewards; }
    public DailyRewardsAdminGui dailyRewardsAdmin() { return dailyRewardsAdmin; }
    public ShopManager shops() { return shops; }
    public OwnerShopHologramManager ownerShopHolograms() { return ownerShopHolograms; }
    public ShoppingDistrictManager shoppingDistrict() { return shoppingDistrict; }
    public SellWandManager sellWands() { return sellWands; }
    public TradeManager trades() { return trades; }
    public TradeGui tradeGui() { return tradeGui; }
    public AuctionManager auctions() { return auctions; }
    public MarketOrderManager orders() { return orders; }
    public PriceHistoryManager history() { return history; }
    public TransactionLogManager transactionLog() { return transactionLog; }
    public DiscordPriceBridge discordPriceBridge() { return discordPriceBridge; }
    public ShopGui gui() { return gui; }
    public SellGui sellGui() { return sellGui; }
    public AuctionGui auctionGui() { return auctionGui; }
    public com.snipeyfresh.incogshop.gui.OrderBookGui orderGui() { return orderGui; }
    public CustomCategoryManager customCategories() { return customCategories; }
    public GuiLayoutManager layouts() { return layouts; }
    public LayoutEditorGui layoutEditor() { return layoutEditor; }
    public StashManager stash() { return stash; }
    public StashGui stashGui() { return stashGui; }
    public XpVaultManager xpVault() { return xpVault; }
    public XpVaultGui xpVaultGui() { return xpVaultGui; }
    public AdminSetupGui adminSetupGui() { return adminSetupGui; }
    public BedrockInputManager bedrockInputs() { return bedrockInputs; }
    public HexManager hex() { return hex; }
    public HexGui hexGui() { return hexGui; }

    public String prefix() { return Branding.legacyConfigured(getConfig().getString("messages.prefix", ""), "Shop"); }
    public String money(double amount) { return getConfig().getString("economy.currency-symbol", "$") + String.format("%,.2f", amount); }

    private void migrateLegacyDataFolder() {
        Path current = getDataFolder().toPath();
        Path parent = current.getParent();
        if (parent == null) return;

        // The old plugin name used plugins/Incog-Shop. Keep that literal name
        // here so existing installations migrate cleanly after the rename.
        Path legacy = parent.resolve("Incog-Shop");
        Path marker = current.resolve(".incogecon-migrated");

        if (!Files.isDirectory(legacy) || Files.exists(marker)) return;

        try {
            Files.createDirectories(current);
            try (var paths = Files.walk(legacy)) {
                paths.forEach(source -> {
                    try {
                        Path relative = legacy.relativize(source);
                        Path target = current.resolve(relative);
                        if (Files.isDirectory(source)) {
                            Files.createDirectories(target);
                        } else if (!Files.exists(target)) {
                            Path targetParent = target.getParent();
                            if (targetParent != null) Files.createDirectories(targetParent);
                            Files.copy(source, target, StandardCopyOption.COPY_ATTRIBUTES);
                        }
                    } catch (IOException ex) {
                        getLogger().warning("Could not migrate legacy Incog-Shop data file: " + ex.getMessage());
                    }
                });
            }

            Files.writeString(marker,
                    "Migrated missing data from plugins/Incog-Shop to plugins/IncogEcon.\n");
            getLogger().info("Migrated existing Incog-Shop data into plugins/IncogEcon. "
                    + "The old Incog-Shop folder was left untouched as a backup.");
        } catch (IOException ex) {
            getLogger().severe("Failed to migrate legacy Incog-Shop data: " + ex.getMessage());
        }
    }

    private void autosaveSlice() {
        switch (autosavePhase++ & 7) {
            case 0 -> { if (market != null) market.save(); }
            case 1 -> { if (auctions != null) auctions.save(); }
            case 2 -> { if (orders != null) orders.save(); }
            case 3 -> {
                if (shops != null) shops.save();
                if (shoppingDistrict != null) shoppingDistrict.save();
            }
            case 4 -> { if (stash != null) stash.save(); }
            case 5 -> { if (xpVault != null) xpVault.save(); }
            case 6 -> { if (customCategories != null) customCategories.save(); }
            case 7 -> {
                if (wallets != null) wallets.save();
                if (dailyMarketFlux != null) dailyMarketFlux.save();
                if (weeklyInfiniteStock != null) weeklyInfiniteStock.save();
                if (dailyRewards != null) dailyRewards.save();
            }
        }
    }

    public void saveAllData() {
        if (wallets != null) wallets.save();
        if (market != null) market.save();
        if (dailyMarketFlux != null) dailyMarketFlux.save();
        if (weeklyInfiniteStock != null) weeklyInfiniteStock.save();
        if (dailyRewards != null) dailyRewards.save();
        if (shops != null) shops.save();
        if (shoppingDistrict != null) shoppingDistrict.save();
        if (auctions != null) auctions.save();
        if (orders != null) orders.save();
        if (customCategories != null) customCategories.save();
        if (stash != null) stash.save();
        if (xpVault != null) xpVault.save();
    }

    public void reloadAll() {
        if (trades != null) trades.shutdown();
        if (discordPriceBridge != null) discordPriceBridge.stop();
        saveAllData();
        if (io != null) io.flush(10_000L);
        if (ownerShopHolograms != null) ownerShopHolograms.clear();
        reloadConfig();
        wallets.load();
        market.load();
        if (dailyMarketFlux != null) dailyMarketFlux.reload();
        if (weeklyInfiniteStock != null) weeklyInfiniteStock.reload();
        if (dailyRewards != null) dailyRewards.reload();
        customCategories.load();
        layouts.load();
        stash.load();
        xpVault.load();
        if (shoppingDistrict != null) shoppingDistrict.reload();
        if (multiverseInventories != null) multiverseInventories.scheduleSync();
        shops.load();
        if (ownerShopHolograms != null) ownerShopHolograms.refresh();
        auctions.load();
        orders.load();

        if (history == null) history = new PriceHistoryManager(this);
        history.load();
        history.captureChangedPrices();

        discordPriceBridge = new DiscordPriceBridge(this);
        discordPriceBridge.start();
        for (Player player : Bukkit.getOnlinePlayers()) wallets.touch(player.getUniqueId(), player.getName());
    }
}

package com.snipeyfresh.incogshop.command;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/** /daily [claim|status] */
public final class DailyRewardsCommand implements CommandExecutor {
    private final IncogShopPlugin plugin;
    public DailyRewardsCommand(IncogShopPlugin plugin) { this.plugin = plugin; }
    @Override public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage(plugin.prefix() + "§cThis command is available in-game only."); return true; }
        if (args.length == 1 && args[0].equalsIgnoreCase("admin")) {
            if (!player.hasPermission("incogshop.daily.admin")) { player.sendMessage(plugin.prefix() + "§cYou do not have permission to edit Daily Rewards."); return true; }
            plugin.dailyRewardsAdmin().openRankOverview(player); return true;
        }
        if (args.length > 1 || (args.length == 1 && !args[0].equalsIgnoreCase("claim") && !args[0].equalsIgnoreCase("status"))) { player.sendMessage(plugin.prefix() + "§eUsage: /daily [claim|status|admin]"); return true; }
        if (args.length == 0 || args[0].equalsIgnoreCase("claim")) { player.sendMessage(plugin.prefix() + plugin.dailyRewards().claim(player)); return true; }
        var status = plugin.dailyRewards().status(player);
        if (!status.enabled()) { player.sendMessage(plugin.prefix() + "§eDaily Rewards are currently disabled."); return true; }
        player.sendMessage(plugin.prefix() + "§6Daily Rewards: " + (status.claimable() ? "§aReady to claim!" : "§eAlready claimed today."));
        player.sendMessage(plugin.prefix() + "§7Current streak: §f" + status.streak() + " §7| Next reward: §fDay " + status.nextDay());
        player.sendMessage(plugin.prefix() + "§7Claim interval: §fEvery " + status.intervalDays() + " day(s) §7| Reset: §fMidnight " + status.resetZone());
        return true;
    }
}

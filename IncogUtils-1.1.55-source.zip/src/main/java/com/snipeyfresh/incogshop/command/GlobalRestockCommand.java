package com.snipeyfresh.incogshop.command;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

/** Restores every market entry to market.initial-stock without retuning prices. */
public final class GlobalRestockCommand implements CommandExecutor {
    private final IncogShopPlugin plugin;

    public GlobalRestockCommand(IncogShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("incogshop.admin.globalrestock")) {
            sender.sendMessage(plugin.prefix() + "§cNo permission: incogshop.admin.globalrestock");
            return true;
        }
        if (args.length > 0) {
            sender.sendMessage(plugin.prefix() + "§eUsage: /globalrestock");
            return true;
        }

        long maximum = Math.max(1L, plugin.getConfig().getLong("market.maximum-stock-per-material", 1_000_000L));
        long defaultStock = Math.max(0L, Math.min(maximum, plugin.getConfig().getLong("market.initial-stock", 1000L)));
        int changed = plugin.market().resetAllStock(sender.getName());
        sender.sendMessage(plugin.prefix() + "§aGlobal restock complete. §f" + changed
                + " §amarket material(s) were restored to §f" + defaultStock + "§a stock.");
        return true;
    }
}

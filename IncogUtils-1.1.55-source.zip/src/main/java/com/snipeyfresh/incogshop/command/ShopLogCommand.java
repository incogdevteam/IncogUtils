package com.snipeyfresh.incogshop.command;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.history.TransactionLogManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

public final class ShopLogCommand implements CommandExecutor {
    private static final int PAGE_SIZE = 8;
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("MM/dd HH:mm").withZone(ZoneId.systemDefault());
    private final IncogShopPlugin plugin;

    public ShopLogCommand(IncogShopPlugin plugin) { this.plugin = plugin; }

    @Override public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("incogshop.logs")) { sender.sendMessage(plugin.prefix() + "§cYou do not have permission to view transaction logs."); return true; }
        String player = args.length >= 1 && !args[0].equalsIgnoreCase("all") ? args[0] : null;
        int page = 1;
        if (args.length >= 2) try { page = Math.max(1, Integer.parseInt(args[1])); } catch (NumberFormatException ignored) {}
        int need = page * PAGE_SIZE + 1;
        List<TransactionLogManager.Entry> entries = plugin.transactionLog().find(player, need);
        int start = (page - 1) * PAGE_SIZE;
        sender.sendMessage("§8§m-----------------------------------------------------");
        sender.sendMessage("§6§lSHOP TRANSACTIONS §8• §7" + (player == null ? "All players" : player) + " §8• §7Page " + page);
        if (start >= entries.size()) {
            sender.sendMessage("§7No transactions found" + (player == null ? "." : " for §f" + player + "§7."));
        } else {
            int end = Math.min(start + PAGE_SIZE, entries.size());
            for (int i = start; i < end; i++) {
                var e = entries.get(i);
                String buyer = e.buyerName() == null ? "SERVER" : e.buyerName();
                String seller = e.sellerName() == null ? "SERVER" : e.sellerName();
                sender.sendMessage("§8[§7" + TIME.format(e.time()) + "§8] §e" + e.type() + " §f" + e.amount() + "x " + e.item());
                sender.sendMessage("  §7Buyer: §f" + buyer + " §8• §7Seller: §f" + seller + " §8• §a" + plugin.money(e.total()) + " §8(§7" + plugin.money(e.unitPrice()) + "/ea§8) §8• §7" + e.source());
            }
            if (entries.size() > end) sender.sendMessage("§7More results: §f/shoplog " + (player == null ? "all" : player) + " " + (page + 1));
        }
        sender.sendMessage("§8§m-----------------------------------------------------");
        return true;
    }
}

package com.snipeyfresh.incogshop.command;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.shopping.ShopPlot;
import com.snipeyfresh.incogshop.shopping.ShoppingDistrictManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Player and staff commands for the protected procedural shopping district. */
public final class ShoppingDistrictCommand implements TabExecutor {
    private final IncogShopPlugin plugin;

    public ShoppingDistrictCommand(IncogShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        ShoppingDistrictManager district = plugin.shoppingDistrict();
        if (district == null || !district.enabled()) {
            player.sendMessage(plugin.prefix() + "§cThe Shopping District is currently disabled.");
            return true;
        }
        if (!player.hasPermission("incogshop.shoppingdistrict")) {
            noPermission(player);
            return true;
        }
        if (args.length == 0) {
            help(player);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "home", "plot", "shop" -> home(player, args);
            case "spawn", "hub", "explore" -> spawn(player);
            case "visit", "teleport", "tp" -> visit(player, args);
            case "list", "shops" -> list(player, args);
            case "info" -> info(player, args);
            case "buy", "new", "purchase" -> buy(player, args);
            case "sell" -> sell(player, args);
            case "rename", "name" -> rename(player, args);
            case "find", "search", "item" -> find(player, args);
            case "expand", "upgrade" -> expand(player, args);
            case "help", "?" -> help(player);
            case "admin" -> admin(player, args);
            default -> help(player);
        }
        return true;
    }

    private void home(Player player, String[] args) {
        ShoppingDistrictManager district = plugin.shoppingDistrict();
        var result = district.ensureStarterPlot(player);
        if (!result.success()) {
            player.sendMessage(plugin.prefix() + "§c" + result.message());
            return;
        }
        ShopPlot plot = args.length >= 2 ? district.resolveOwnedPlot(player.getUniqueId(), join(args, 1)).orElse(null) : result.plot();
        if (plot == null) {
            player.sendMessage(plugin.prefix() + "§cYou do not have a plot with that name or number.");
            return;
        }
        if (!district.teleport(player, plot)) {
            player.sendMessage(plugin.prefix() + "§cTeleport was blocked or failed.");
            return;
        }
        player.sendMessage(plugin.prefix() + "§aTeleported to your plot §f" + plot.displayName() + "§a.");
        player.sendMessage(plugin.prefix() + "§7Build inside your plot, place a chest or barrel, hold the item to sell, then use §f/pshop create <price>§7.");
    }

    private void spawn(Player player) {
        if (!player.hasPermission("incogshop.shoppingdistrict.visit")) {
            noPermission(player);
            return;
        }
        if (!districtTeleport(player, plugin.shoppingDistrict().spawn())) {
            player.sendMessage(plugin.prefix() + "§cTeleport was blocked or failed.");
            return;
        }
        player.sendMessage(plugin.prefix() + "§aTeleported to the Shopping District hub.");
    }

    private void visit(Player player, String[] args) {
        if (!player.hasPermission("incogshop.shoppingdistrict.visit")) {
            noPermission(player);
            return;
        }
        if (args.length < 2) {
            player.sendMessage(plugin.prefix() + "§eUsage: /shopdistrict visit <player> [plot-name|number]");
            return;
        }
        String ownerName = args[1];
        List<ShopPlot> matches = plotsForPlayer(ownerName);
        if (matches.isEmpty()) {
            player.sendMessage(plugin.prefix() + "§cThat player does not have a Shopping District plot.");
            return;
        }
        ShopPlot plot = selectPlot(matches, join(args, 2));
        if (plot == null) {
            player.sendMessage(plugin.prefix() + "§cThat player does not have a plot with that name or number.");
            return;
        }
        if (!plugin.shoppingDistrict().teleport(player, plot)) {
            player.sendMessage(plugin.prefix() + "§cTeleport was blocked or failed.");
            return;
        }
        player.sendMessage(plugin.prefix() + "§aTeleported to §f" + plot.ownerName() + "§a's plot §f" + plot.displayName() + "§a.");
    }

    private void list(Player player, String[] args) {
        List<ShopPlot> plots;
        if (args.length >= 2) {
            String name = args[1];
            plots = plotsForPlayer(name);
        } else {
            plots = plugin.shoppingDistrict().plots(player.getUniqueId());
        }
        if (plots.isEmpty()) {
            player.sendMessage(plugin.prefix() + "§7No Shopping District plots found.");
            return;
        }
        player.sendMessage(plugin.prefix() + "§6Shopping District plots (§f" + plots.size() + "§6):");
        for (int i = 0; i < plots.size(); i++) {
            player.sendMessage("§e" + (i + 1) + ". " + plugin.shoppingDistrict().describe(plots.get(i)));
        }
        if (args.length >= 2) {
            player.sendMessage("§7Visit one with §f/shopdistrict visit <player> [plot-name|number]§7.");
        } else {
            player.sendMessage("§7Open one with §f/shopdistrict home [plot-name|number]§7.");
        }
    }

    private void info(Player player, String[] args) {
        ShopPlot plot = null;
        if (args.length >= 2) {
            String selector = join(args, 1);
            plot = plugin.shoppingDistrict().resolveOwnedPlot(player.getUniqueId(), selector).orElse(null);
            if (plot == null) try {
                plot = plugin.shoppingDistrict().find(java.util.UUID.fromString(selector)).orElse(null);
            } catch (IllegalArgumentException ignored) {
                plot = plugin.shoppingDistrict().all().stream()
                        .filter(candidate -> candidate.ownerName().equalsIgnoreCase(selector))
                        .findFirst().orElse(null);
            }
        }
        if (plot == null) plot = plugin.shoppingDistrict().plotAt(player.getLocation()).orElse(null);
        if (plot == null) plot = plugin.shoppingDistrict().primary(player.getUniqueId()).orElse(null);
        if (plot == null) {
            player.sendMessage(plugin.prefix() + "§cNo plot was found. Use /shopdistrict home first.");
            return;
        }
        player.sendMessage(plugin.prefix() + "§6Plot information");
        player.sendMessage(plugin.shoppingDistrict().describe(plot));
        int max = plugin.shoppingDistrict().purchasableMaxSize(player);
        player.sendMessage("§7Expansion: §f" + plot.size() + "x" + plot.size() + "§7 → your paid limit §f" + max + "x" + max);
        player.sendMessage("§7Next expansion: §f" + plugin.money(plugin.shoppingDistrict().expansionPrice(plot.expansions(), 1)));
        player.sendMessage("§7New plot price: §f" + plugin.money(plugin.shoppingDistrict().plotPrice(plugin.shoppingDistrict().plots(plot.owner()).size())));
    }

    private void rename(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(plugin.prefix() + "§eUsage: /shopdistrict rename [current|plot-number] <new-name...>");
            return;
        }
        ShopPlot plot = selectedOrCurrent(player, args[1]);
        int nameStart = 1;
        if (args[1].equalsIgnoreCase("current") || isPositiveInteger(args[1])) {
            nameStart = 2;
        }
        if (nameStart >= args.length) {
            player.sendMessage(plugin.prefix() + "§eUsage: /shopdistrict rename [current|plot-number] <new-name...>");
            return;
        }
        if (plot == null) {
            player.sendMessage(plugin.prefix() + "§cYou do not have that plot.");
            return;
        }
        var result = plugin.shoppingDistrict().renamePlot(player, plot, join(args, nameStart));
        player.sendMessage(plugin.prefix() + (result.success() ? "§a" : "§c") + result.message());
    }

    private void buy(Player player, String[] args) {
        String layout = args.length >= 2 ? args[1] : "flat";
        ShoppingDistrictManager.PlotResult result = plugin.shoppingDistrict().buyPlot(player, layout);
        player.sendMessage(plugin.prefix() + (result.success() ? "§a" : "§c") + result.message());
        if (result.success() && result.plot() != null && plugin.shoppingDistrict().teleport(player, result.plot())) {
            player.sendMessage(plugin.prefix() + "§7Your new plot §f" + result.plot().displayName() + "§7 is ready.");
        }
    }

    private void find(Player player, String[] args) {
        String query = args.length >= 2 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "";
        if (query.isBlank()) { player.sendMessage(plugin.prefix() + "§eUsage: /shopdistrict find <item>"); return; }
        List<com.snipeyfresh.incogshop.shop.PlayerShop> shops = plugin.shops().all().stream()
                .filter(s -> s.item().getType().name().equalsIgnoreCase(query.replace(' ', '_'))).toList();
        if (shops.isEmpty()) { player.sendMessage(plugin.prefix() + "§cNo shops currently sell that item."); return; }
        int index = args.length >= 3 ? Math.max(1, integer(args[2], 1)) - 1 : 0;
        if (index >= shops.size()) { player.sendMessage(plugin.prefix() + "§cOnly " + shops.size() + " matching shop(s) were found."); return; }
        var shop = shops.get(index);
        var plot = plugin.shoppingDistrict().plotAt(shop.location()).or(() -> plugin.shoppingDistrict().primary(shop.owner()));
        if (plot.isEmpty() || !plugin.shoppingDistrict().teleport(player, plot.get())) { player.sendMessage(plugin.prefix() + "§cThat shop cannot be reached right now."); return; }
        player.sendMessage(plugin.prefix() + "§aTeleported to §f" + shop.ownerName() + "§a's shop selling §f" + query + "§a for " + plugin.money(shop.price()) + ".");
    }

    private void expand(Player player, String[] args) {
        Integer target = null;
        int selectorStart = 1;
        if (args.length == 2 && args[1].equalsIgnoreCase("current")) {
            selectorStart = 2;
        } else if (args.length == 2 && isPositiveInteger(args[1])
                && integer(args[1], 0) <= plugin.shoppingDistrict().plots(player.getUniqueId()).size()) {
            // A lone small number is much more likely to be a plot list number
            // than an invalid request to shrink a 40x40 starter plot.
            selectorStart = 1;
        } else if (args.length >= 2 && isPositiveInteger(args[1])) {
            target = integer(args[1], -1);
            selectorStart = 2;
        }
        ShopPlot plot = args.length == 2 && args[1].equalsIgnoreCase("current")
                ? currentOwnedOrPrimary(player)
                : selectorStart < args.length
                ? plugin.shoppingDistrict().resolveOwnedPlot(player.getUniqueId(), join(args, selectorStart)).orElse(null)
                : currentOwnedOrPrimary(player);
        if (plot == null) {
            player.sendMessage(plugin.prefix() + "§cYou do not have a plot with that name or number.");
            return;
        }
        ShoppingDistrictManager.PlotResult result = plugin.shoppingDistrict().expand(player, plot, target);
        player.sendMessage(plugin.prefix() + (result.success() ? "§a" : "§c") + result.message());
    }

    private void sell(Player player, String[] args) {
        ShopPlot plot = args.length >= 2
                ? plugin.shoppingDistrict().resolveOwnedPlot(player.getUniqueId(), join(args, 1)).orElse(null)
                : currentOwnedOrPrimary(player);
        if (plot == null) {
            player.sendMessage(plugin.prefix() + "§cYou do not have a plot with that name or number.");
            return;
        }
        var result = plugin.shoppingDistrict().sellPlot(player, plot, false);
        player.sendMessage(plugin.prefix() + (result.success() ? "§a" : "§c") + result.message());
    }

    private void admin(Player player, String[] args) {
        if (!player.hasPermission("incogshop.shoppingdistrict.admin")) {
            noPermission(player);
            return;
        }
        if (args.length < 2) {
            player.sendMessage(plugin.prefix() + "§e/shopdistrict admin <reload|save|allocate <player>|tp <player> [plot]|forcesell <player> [plot]>");
            return;
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                plugin.reloadConfig();
                plugin.shoppingDistrict().reload();
                if (plugin.ownerShopHolograms() != null) plugin.ownerShopHolograms().refresh();
                player.sendMessage(plugin.prefix() + "§aShopping District configuration reloaded.");
            }
            case "save" -> {
                plugin.shoppingDistrict().save();
                player.sendMessage(plugin.prefix() + "§aShopping District data saved.");
            }
            case "allocate" -> {
                if (args.length < 3) {
                    player.sendMessage(plugin.prefix() + "§eUsage: /shopdistrict admin allocate <player>");
                    return;
                }
                Player target = Bukkit.getPlayerExact(args[2]);
                if (target == null) {
                    player.sendMessage(plugin.prefix() + "§cThat player must be online for allocation.");
                    return;
                }
                var result = plugin.shoppingDistrict().ensureStarterPlot(target);
                player.sendMessage(plugin.prefix() + (result.success() ? "§a" : "§c") + result.message());
            }
            case "tp", "teleport" -> {
                if (args.length < 3) {
                    player.sendMessage(plugin.prefix() + "§eUsage: /shopdistrict admin tp <player> [plot-name|number]");
                    return;
                }
                List<ShopPlot> plots = plotsForPlayer(args[2]);
                if (plots.isEmpty()) {
                    player.sendMessage(plugin.prefix() + "§cNo plot found for that player.");
                    return;
                }
                ShopPlot plot = selectPlot(plots, join(args, 3));
                if (plot == null) {
                    player.sendMessage(plugin.prefix() + "§cNo matching plot found.");
                    return;
                }
                if (plugin.shoppingDistrict().teleport(player, plot)) {
                    player.sendMessage(plugin.prefix() + "§aTeleported to §f" + plot.ownerName() + "§a's plot §f" + plot.displayName() + "§a.");
                }
            }
            case "forcesell", "sell" -> {
                if (args.length < 3) { player.sendMessage(plugin.prefix() + "§eUsage: /shopdistrict admin forcesell <player> [plot-name|number]"); return; }
                List<ShopPlot> plots = plotsForPlayer(args[2]);
                ShopPlot plot = selectPlot(plots, join(args, 3));
                if (plot == null) { player.sendMessage(plugin.prefix() + "§cNo matching plot found."); return; }
                var result = plugin.shoppingDistrict().sellPlot(player, plot, true);
                player.sendMessage(plugin.prefix() + (result.success() ? "§a" : "§c") + result.message());
            }
            default -> player.sendMessage(plugin.prefix() + "§e/shopdistrict admin <reload|save|allocate <player>|tp <player> [plot]|forcesell <player> [plot]>");
        }
    }

    private boolean districtTeleport(Player player, org.bukkit.Location location) {
        if (location == null) return false;
        return player.teleport(location);
    }

    private void help(Player player) {
        player.sendMessage(plugin.prefix() + "§6Shopping District");
        player.sendMessage("§f/shopdistrict home [plot-name|number] §7— teleport to one of your plots");
        player.sendMessage("§f/shopdistrict expand [size] [plot-name|number] §7— expand one of your plots");
        player.sendMessage("§f/shopdistrict buy [template-id] §7— buy an additional plot");
        player.sendMessage("§f/shopdistrict rename [current|plot-number] <name...> §7— name a plot");
        player.sendMessage("§f/shopdistrict sell [plot-name|number] §7— sell one of your plots");
        player.sendMessage("§f/shopdistrict find <item> §7— find and visit shops selling an item");
        player.sendMessage("§f/shopdistrict visit <player> [plot-name|number] §7— visit another player's shop");
        player.sendMessage("§f/shopdistrict list [player] §7— list your plots or another player's plots");
        player.sendMessage("§f/shopdistrict info [plot-name|number] §7— show plot size, limits, and prices");
        player.sendMessage("§7To sell items: build a chest/barrel in your plot, hold the item, then use §f/pshop create <price>§7.");
        player.sendMessage("§7The district protects roads, plots, containers, redstone, entities, explosions, and dropped items from visitors.");
    }

    private void noPermission(Player player) {
        player.sendMessage(plugin.prefix() + "§cYou do not have permission to use the Shopping District.");
    }

    private static int integer(String value, int fallback) {
        try { return Integer.parseInt(value); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    private ShopPlot currentOwnedOrPrimary(Player player) {
        return plugin.shoppingDistrict().plotAt(player.getLocation())
                .filter(plot -> plot.owner().equals(player.getUniqueId()))
                .or(() -> plugin.shoppingDistrict().primary(player.getUniqueId()))
                .orElse(null);
    }

    /** For rename, a name without a selector applies to the current/primary plot. */
    private ShopPlot selectedOrCurrent(Player player, String firstArgument) {
        if (firstArgument != null && (firstArgument.equalsIgnoreCase("current") || isPositiveInteger(firstArgument))) {
            return firstArgument.equalsIgnoreCase("current")
                    ? currentOwnedOrPrimary(player)
                    : plugin.shoppingDistrict().resolveOwnedPlot(player.getUniqueId(), firstArgument).orElse(null);
        }
        return currentOwnedOrPrimary(player);
    }

    private List<ShopPlot> plotsForPlayer(String playerName) {
        Player online = Bukkit.getPlayerExact(playerName);
        if (online != null) {
            List<ShopPlot> owned = plugin.shoppingDistrict().plots(online.getUniqueId());
            if (!owned.isEmpty()) return owned;
        }
        return plugin.shoppingDistrict().all().stream()
                .filter(plot -> plot.ownerName().equalsIgnoreCase(playerName))
                .sorted(java.util.Comparator.comparingLong(ShopPlot::createdAt))
                .toList();
    }

    /** Resolves public plots by the stable list number or display name. */
    private static ShopPlot selectPlot(List<ShopPlot> plots, String selector) {
        if (plots == null || plots.isEmpty()) return null;
        String value = selector == null ? "" : selector.trim();
        if (value.isBlank()) return plots.get(0);
        if (isPositiveInteger(value)) {
            int index = integer(value, 0) - 1;
            return index >= 0 && index < plots.size() ? plots.get(index) : null;
        }
        return plots.stream().filter(plot -> plot.displayName().equalsIgnoreCase(value)).findFirst().orElse(null);
    }

    private static boolean isPositiveInteger(String value) {
        return integer(value, 0) > 0;
    }

    private static String join(String[] args, int start) {
        return args == null || start >= args.length ? "" : String.join(" ", java.util.Arrays.copyOfRange(args, start, args.length));
    }

    private static String shortId(ShopPlot plot) {
        return plot.id().toString().substring(0, 8);
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) return filter(List.of("home", "spawn", "explore", "visit", "list", "info", "buy", "rename", "sell", "expand", "help", "admin"), args[0]);
        if (args.length == 2 && (args[0].equalsIgnoreCase("buy") || args[0].equalsIgnoreCase("new") || args[0].equalsIgnoreCase("purchase")))
            return filter(new ArrayList<>(plugin.shoppingDistrict().settings().templates().keySet()), args[1]);
        if (args.length == 2 && (args[0].equalsIgnoreCase("home") || args[0].equalsIgnoreCase("sell") || args[0].equalsIgnoreCase("info") || args[0].equalsIgnoreCase("expand"))) {
            return filter(ownPlotSelectors(sender), args[1]);
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("rename") || args[0].equalsIgnoreCase("name"))) {
            List<String> selectors = new ArrayList<>();
            selectors.add("current");
            selectors.addAll(ownPlotSelectors(sender));
            return filter(selectors, args[1]);
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("visit") || args[0].equalsIgnoreCase("list"))) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("visit")) return filter(plotSelectors(plotsForPlayer(args[1])), args[2]);
        if (args.length == 3 && args[0].equalsIgnoreCase("expand") && isPositiveInteger(args[1])) {
            return filter(ownPlotSelectors(sender), args[2]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("admin")) return filter(List.of("reload", "save", "allocate", "tp", "forcesell"), args[1]);
        if (args.length == 3 && args[0].equalsIgnoreCase("admin") && (args[1].equalsIgnoreCase("allocate") || args[1].equalsIgnoreCase("tp") || args[1].equalsIgnoreCase("forcesell"))) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[2]);
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("admin") && (args[1].equalsIgnoreCase("tp") || args[1].equalsIgnoreCase("forcesell"))) {
            return filter(plotSelectors(plotsForPlayer(args[2])), args[3]);
        }
        return List.of();
    }

    private List<String> ownPlotSelectors(CommandSender sender) {
        if (!(sender instanceof Player player)) return List.of();
        return plotSelectors(plugin.shoppingDistrict().plots(player.getUniqueId()));
    }

    private static List<String> plotSelectors(List<ShopPlot> plots) {
        List<String> values = new ArrayList<>();
        for (int index = 0; index < plots.size(); index++) {
            values.add(Integer.toString(index + 1));
            values.add(plots.get(index).displayName());
        }
        return values;
    }

    private static List<String> filter(List<String> values, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        List<String> output = new ArrayList<>();
        for (String value : values) if (value.toLowerCase(Locale.ROOT).startsWith(lower)) output.add(value);
        return output;
    }
}

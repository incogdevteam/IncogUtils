package com.snipeyfresh.incogshop.command;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.time.Duration;
import java.time.Instant;

/** Shows a player's weekly-event eligibility without requiring them to find a GUI slot. */
public final class WeeklyInfiniteStockCommand implements CommandExecutor {
    private final IncogShopPlugin plugin;

    public WeeklyInfiniteStockCommand(IncogShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.prefix() + "§cThis command is available in-game only.");
            return true;
        }
        if (args.length > 0) {
            player.sendMessage(plugin.prefix() + "§eUsage: /weeklystock");
            return true;
        }
        if (plugin.weeklyInfiniteStock() == null) {
            player.sendMessage(plugin.prefix() + "§cWeekly Infinite Stock is unavailable while the market module is loading.");
            return true;
        }

        var status = plugin.weeklyInfiniteStock().statusFor(player);
        if (!status.enabled()) {
            player.sendMessage(plugin.prefix() + "§eWeekly Infinite Stock is currently disabled.");
            return true;
        }

        int limit = plugin.weeklyInfiniteStock().itemLimitFor(player);
        if (limit <= 0) {
            player.sendMessage(plugin.prefix() + "§7Weekly Infinite Stock: §cLocked");
            player.sendMessage(plugin.prefix() + "§7Requires the Cryptic, Incog, or Incog+ LuckPerms rank.");
            player.sendMessage(plugin.prefix() + "§7Next event: §f" + remaining(Duration.between(Instant.now(), status.eventStart())));
            return true;
        }

        player.sendMessage(plugin.prefix() + "§dWeekly Infinite Stock: " + (status.active() ? "§aActive" : "§eUpcoming"));
        player.sendMessage(plugin.prefix() + "§7Your access: §f" + limit + " selected item" + (limit == 1 ? "" : "s"));
        player.sendMessage(plugin.prefix() + "§7" + (status.active() ? "Ends in: §f" + remaining(Duration.between(Instant.now(), status.eventEnd()))
                : "Begins in: §f" + remaining(Duration.between(Instant.now(), status.eventStart()))));
        if (status.selectionsRevealed() && !status.playerItems().isEmpty()) {
            player.sendMessage(plugin.prefix() + "§dYour item" + (status.playerItems().size() == 1 ? ": §f" : "s: §f")
                    + String.join(", ", status.playerItems().stream().map(material -> material.name().toLowerCase().replace('_', ' ')).toList()));
        } else if (!status.active()) {
            player.sendMessage(plugin.prefix() + "§7The draw is revealed in: §f" + remaining(Duration.between(Instant.now(), status.selectionAt())));
        }
        return true;
    }

    private static String remaining(Duration duration) {
        long seconds = Math.max(0L, duration.getSeconds());
        return (seconds / 3600L) + "h " + ((seconds % 3600L) / 60L) + "m " + (seconds % 60L) + "s";
    }
}

package com.snipeyfresh.incogshop.daily;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Inventory editor backed by economy/config.yml, with chat prompts for text-only values. */
public final class DailyRewardsAdminGui implements Listener {
    private enum Prompt { ADD_RANK, MONEY, COMMAND, INTERVAL, CYCLE }
    private record Pending(Prompt type, String rank, int day) { }

    private static final class Holder implements InventoryHolder {
        private final String mode;
        private final String rank;
        private final int day;
        private Inventory inventory;

        private Holder(String mode, String rank, int day) {
            this.mode = mode;
            this.rank = rank;
            this.day = day;
        }
        private void attach(Inventory inventory) { this.inventory = inventory; }
        @Override public @NotNull Inventory getInventory() { return inventory; }
    }

    private final IncogShopPlugin plugin;
    private final DailyRewardsManager rewards;
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();

    public DailyRewardsAdminGui(IncogShopPlugin plugin) {
        this.plugin = plugin;
        this.rewards = plugin.dailyRewards();
    }

    public void openRankOverview(Player player) {
        Holder holder = new Holder("overview", null, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, Component.text("Daily Rewards • Rank Editor")); holder.attach(inv);
        inv.setItem(4, item(Material.CLOCK, "§6Daily Rewards Ranks", List.of("§7Click a rank to edit its day-by-day rewards.", "§7The Base Rewards apply when no rank matches.")));
        inv.setItem(45, item(Material.LIME_DYE, "§aAdd LuckPerms Rank", List.of("§7Click, then type the exact LuckPerms group name in chat.", "§8Type cancel to stop.")));
        inv.setItem(46, item(Material.CLOCK, "§eClaim interval: " + rewards.claimIntervalDays() + " day(s)", List.of("§7Click to change how often players can claim.", "§7Examples: 1 = daily, 7 = weekly.")));
        inv.setItem(47, item(Material.RECOVERY_COMPASS, "§eStreak length: " + rewards.cycleDays() + " day(s)", List.of("§7Click to choose the reward cycle length.", "§7Minimum: 1 day", "§7Maximum: 30 days")));
        inv.setItem(49, item(Material.PAPER, "§fBase Rewards", List.of("§7Fallback rewards for players without a configured rank.", "§7You can configure every day in the streak.")));
        inv.setItem(53, item(Material.ARROW, "§e§lBack to Menus", List.of("§7Return to the IncogUtils menu hub.")));
        int slot = 10;
        for (String rank : rewards.rankIds()) {
            if (slot >= 44) break;
            inv.setItem(slot++, item(Material.NAME_TAG, "§b" + rewards.rankName(rank), List.of("§7LuckPerms group: §f" + plugin.getConfig().getString("daily-rewards.rank-rewards." + rank + ".luckperms-group", rank), "§7Click to edit all " + rewards.cycleDays() + " days.")));
        }
        player.openInventory(inv);
    }

    private static final int[] DAY_SLOTS = {
            10,11,12,13,14,15,16,
            19,20,21,22,23,24,25,
            28,29,30,31,32,33,34,
            37,38,39,40,41,42,43,
            46,47
    };

    private void openEditor(Player player, String rank) {
        String title = rank == null ? "Daily Rewards • Base" : "Daily Rewards • " + rewards.rankName(rank);
        Holder holder = new Holder("days", rank, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, Component.text(title)); holder.attach(inv);

        for (int day = 1; day <= rewards.cycleDays() && day <= DAY_SLOTS.length; day++) {
            var section = plugin.getConfig().getConfigurationSection(rewards.rewardPath(rank, day));
            Material icon = Material.CHEST;
            List<String> items = rewards.itemRewards(rank, day);
            if (!items.isEmpty()) icon = Material.matchMaterial(items.getFirst().split(" ")[0]);
            if (icon == null) icon = Material.CHEST;
            int commands = rewards.commandRewards(rank, day).size();
            double money = section == null ? 0D : section.getDouble("money", 0D);
            String configured = section == null ? "§8Not explicitly configured" : "§aConfigured";
            inv.setItem(DAY_SLOTS[day - 1], item(icon, "§eDay " + day, List.of(
                    configured,
                    "§7Items: §f" + items.size(),
                    "§7Money: §f" + money,
                    "§7Commands: §f" + commands,
                    "§eClick to edit all rewards")));
        }

        inv.setItem(49, item(Material.ARROW, "§eBack", List.of("§7Return to rank list.")));
        inv.setItem(50, item(Material.CLOCK, "§6" + rewards.cycleDays() + "-Day Streak", List.of("§7Every active day can have multiple rewards.", "§7Change the streak length from the previous menu.")));
        if (rank != null) inv.setItem(53, item(Material.BARRIER, "§cDelete Rank", List.of("§7Shift-right click to delete this rank configuration.")));
        player.openInventory(inv);
    }

    private void openDayEditor(Player player, String rank, int day) {
        Holder holder = new Holder("day", rank, day);
        Inventory inv = Bukkit.createInventory(holder, 54, Component.text("Daily Rewards • Day " + day)); holder.attach(inv);
        List<String> entries = rewards.itemRewards(rank, day);
        for (int i = 0; i < Math.min(entries.size(), 45); i++) {
            String entry = entries.get(i);
            String[] parts = entry.split("\\s+", 2);
            Material material = Material.matchMaterial(parts[0]);
            if (material == null) material = Material.BARRIER;
            int amount = 1;
            if (parts.length > 1) try { amount = Math.max(1, Math.min(material.getMaxStackSize(), Integer.parseInt(parts[1]))); } catch (NumberFormatException ignored) { }
            ItemStack stack = new ItemStack(material, amount);
            ItemMeta meta = stack.getItemMeta();
            List<Component> lore = List.of(Component.text("§cClick to remove this item reward."));
            meta.lore(lore); stack.setItemMeta(meta);
            inv.setItem(i, stack);
        }
        var section = plugin.getConfig().getConfigurationSection(rewards.rewardPath(rank, day));
        double money = section == null ? 0D : section.getDouble("money", 0D);
        List<String> commands = rewards.commandRewards(rank, day);
        inv.setItem(45, item(Material.LIME_DYE, "§aAdd Held Item", List.of("§7Adds the item stack in your main hand.", "§7You can add multiple item rewards.")));
        inv.setItem(46, item(Material.GOLD_INGOT, "§6Money: §f" + money, List.of("§7Click to set this day's money reward.")));
        inv.setItem(47, item(Material.COMMAND_BLOCK, "§bConsole Commands: §f" + commands.size(), List.of("§7Left click: add another command", "§7Right click: clear all commands", "§8Commands all run when this day is claimed.")));
        inv.setItem(48, item(Material.PAPER, "§fReward Summary", List.of("§7Item stacks: §f" + entries.size(), "§7Money: §f" + money, "§7Commands: §f" + commands.size())));
        inv.setItem(49, item(Material.ARROW, "§eBack", List.of("§7Return to the day list.")));
        inv.setItem(53, item(Material.BARRIER, "§cClear Entire Day", List.of("§7Shift-right click to remove every reward", "§7configured for Day " + day + ".")));
        player.openInventory(inv);
    }

    private int dayForSlot(int slot) {
        for (int i = 0; i < DAY_SLOTS.length; i++) if (DAY_SLOTS[i] == slot) return i + 1;
        return -1;
    }

    @EventHandler public void click(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !(event.getInventory().getHolder() instanceof Holder holder)) return;
        event.setCancelled(true);
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return;

        if (holder.mode.equals("overview")) {
            if (slot == 53) { player.performCommand("menus"); return; }
            if (slot == 45) { prompt(player, new Pending(Prompt.ADD_RANK, null, 0), "§eType the LuckPerms group name for the new reward tier, or §ccancel§e."); return; }
            if (slot == 46) { prompt(player, new Pending(Prompt.INTERVAL, null, 0), "§eType the claim interval in days: §f1 §e= daily, §f7 §e= weekly."); return; }
            if (slot == 47) { prompt(player, new Pending(Prompt.CYCLE, null, 0), "§eType the streak length in days (§f1-30§e), or §ccancel§e."); return; }
            if (slot == 49) { openEditor(player, null); return; }
            int index = slot - 10;
            List<String> ranks = rewards.rankIds();
            if (index >= 0 && index < ranks.size()) openEditor(player, ranks.get(index));
            return;
        }

        if (holder.mode.equals("days")) {
            String rank = holder.rank;
            if (slot == 49) { openRankOverview(player); return; }
            if (slot == 53 && rank != null && event.isShiftClick() && event.isRightClick()) {
                rewards.removeRank(rank);
                player.sendMessage(plugin.prefix() + "§aDeleted daily-reward rank §f" + rank + "§a.");
                openRankOverview(player);
                return;
            }
            int day = dayForSlot(slot);
            if (day >= 1 && day <= rewards.cycleDays()) openDayEditor(player, rank, day);
            return;
        }

        if (!holder.mode.equals("day")) return;
        String rank = holder.rank;
        int day = holder.day;
        if (slot < 45) {
            List<String> items = rewards.itemRewards(rank, day);
            if (slot < items.size()) {
                rewards.removeItemReward(rank, day, slot);
                player.sendMessage(plugin.prefix() + "§aRemoved that item reward from Day §f" + day + "§a.");
                openDayEditor(player, rank, day);
            }
            return;
        }
        if (slot == 45) {
            ItemStack held = player.getInventory().getItemInMainHand();
            if (held.getType().isAir()) { player.sendMessage(plugin.prefix() + "§cHold the item stack you want to add first."); return; }
            if (rewards.itemRewards(rank, day).size() >= 45) { player.sendMessage(plugin.prefix() + "§cThis day already has the maximum of 45 item rewards."); return; }
            rewards.addItemReward(rank, day, held);
            player.sendMessage(plugin.prefix() + "§aAdded §f" + held.getAmount() + "x " + held.getType().name() + " §ato Day §f" + day + "§a.");
            openDayEditor(player, rank, day);
            return;
        }
        if (slot == 46) { prompt(player, new Pending(Prompt.MONEY, rank, day), "§eType the money reward for Day " + day + ", or §c0§e."); return; }
        if (slot == 47) {
            if (event.isRightClick()) {
                rewards.clearCommandRewards(rank, day);
                player.sendMessage(plugin.prefix() + "§aCleared all console commands for Day §f" + day + "§a.");
                openDayEditor(player, rank, day);
            } else {
                prompt(player, new Pending(Prompt.COMMAND, rank, day), "§eType another console command for Day " + day + " (without /), or §ccancel§e.");
            }
            return;
        }
        if (slot == 49) { openEditor(player, rank); return; }
        if (slot == 53 && event.isShiftClick() && event.isRightClick()) {
            rewards.clearReward(rank, day);
            player.sendMessage(plugin.prefix() + "§aCleared every reward configured for Day §f" + day + "§a.");
            openDayEditor(player, rank, day);
        }
    }

    private void prompt(Player player, Pending next, String message) {
        player.closeInventory();
        pending.put(player.getUniqueId(), next);
        player.sendMessage(plugin.prefix() + message);
    }

    @EventHandler public void chat(AsyncChatEvent event) {
        Pending next = pending.remove(event.getPlayer().getUniqueId());
        if (next == null) return;
        event.setCancelled(true);
        String input = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        Bukkit.getScheduler().runTask(plugin.host(), () -> {
            Player player = event.getPlayer();
            if (input.equalsIgnoreCase("cancel")) { player.sendMessage(plugin.prefix() + "§7Daily Rewards edit cancelled."); return; }
            try {
                if (next.type() == Prompt.ADD_RANK) {
                    rewards.addRank(input);
                    player.sendMessage(plugin.prefix() + "§aAdded rank §f" + input + "§a. Click it to set its rewards.");
                    openRankOverview(player);
                } else if (next.type() == Prompt.MONEY) {
                    rewards.setMoneyReward(next.rank(), next.day(), Double.parseDouble(input));
                    openDayEditor(player, next.rank(), next.day());
                } else if (next.type() == Prompt.INTERVAL) {
                    rewards.setClaimIntervalDays(Integer.parseInt(input));
                    player.sendMessage(plugin.prefix() + "§aDaily Rewards now claim every §f" + rewards.claimIntervalDays() + " §aday(s).");
                    openRankOverview(player);
                } else if (next.type() == Prompt.CYCLE) {
                    rewards.setCycleDays(Integer.parseInt(input));
                    player.sendMessage(plugin.prefix() + "§aDaily Reward streak length is now §f" + rewards.cycleDays() + " §adays.");
                    openRankOverview(player);
                } else {
                    rewards.addCommandReward(next.rank(), next.day(), input.startsWith("/") ? input.substring(1) : input);
                    player.sendMessage(plugin.prefix() + "§aAdded console command to Day §f" + next.day() + "§a.");
                    openDayEditor(player, next.rank(), next.day());
                }
            } catch (Exception ex) {
                player.sendMessage(plugin.prefix() + "§cInvalid value: " + ex.getMessage());
            }
        });
    }

    private ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Component.text(name));
        meta.lore(lore.stream().map(Component::text).toList());
        stack.setItemMeta(meta);
        return stack;
    }
}

package com.snipeyfresh.incogshop.daily;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.query.QueryOptions;

import java.io.File;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Persistent, calendar-day reward streaks. All rewards are configured, never hard-coded. */
public final class DailyRewardsManager {
    /** A calendar month is represented as a 30-claim reward cycle. */
    private static final int MAX_CYCLE_DAYS = 30;
    public record Status(boolean enabled, boolean claimable, int nextDay, int streak, String lastClaim, String resetZone, int intervalDays) { }

    private static final String PATH = "daily-rewards";
    private final IncogShopPlugin plugin;
    private final File file;
    private YamlConfiguration data;

    public DailyRewardsManager(IncogShopPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "daily-rewards.yml");
        this.data = new YamlConfiguration();
    }

    public void load() { data = YamlConfiguration.loadConfiguration(file); }
    public void reload() { load(); }
    public void save() { plugin.io().writeTextAtomic(file.toPath(), data.saveToString(), "daily-rewards.yml"); }
    public boolean enabled() { return plugin.getConfig().getBoolean(PATH + ".enabled", true); }

    public Status status(Player player) {
        ZoneId zone = zone();
        LocalDate today = LocalDate.now(zone);
        String path = "players." + player.getUniqueId();
        LocalDate last = parse(data.getString(path + ".last-claim", ""));
        int cycleDays = cycleDays();
        int streak = Math.max(0, Math.min(cycleDays, data.getInt(path + ".streak", 0)));
        int interval = claimIntervalDays();
        boolean claimable = last == null || !last.plusDays(interval).isAfter(today);
        int next = claimable ? (last != null && last.equals(today.minusDays(interval)) ? (streak % cycleDays) + 1 : 1) : Math.max(1, streak);
        return new Status(enabled(), claimable, next, streak, last == null ? "Never" : last.toString(), zone.getId(), interval);
    }

    public String claim(Player player) {
        Status status = status(player);
        if (!status.enabled()) return "§cDaily Rewards are currently disabled.";
        if (!status.claimable()) return "§eYou already claimed. Your next reward is available after " + status.intervalDays() + " day(s).";
        int day = Math.min(status.nextDay(), cycleDays());
        ConfigurationSection reward = rewardSection(player, day);
        if (reward == null) return "§cDaily reward " + day + " is not configured. Ask an admin to fix daily-rewards.rewards.";

        double money = Math.max(0.0D, reward.getDouble("money", 0.0D));
        if (money > 0.0D) plugin.wallets().deposit(player.getUniqueId(), money);
        for (String raw : reward.getStringList("items")) giveItem(player, raw);
        for (String command : reward.getStringList("commands")) {
            String expanded = command.replace("{player}", player.getName()).replace("{uuid}", player.getUniqueId().toString()).replace("{day}", String.valueOf(day));
            plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), expanded.startsWith("/") ? expanded.substring(1) : expanded);
        }
        String path = "players." + player.getUniqueId();
        data.set(path + ".last-claim", LocalDate.now(zone()).toString());
        data.set(path + ".streak", day);
        data.set(path + ".last-name", player.getName());
        save();
        String name = reward.getString("name", "Day " + day).replace('&', '§');
        return "§aClaimed §f" + name + "§a! Your daily streak is now §f" + day + "§a/" + cycleDays() + ".";
    }

    /** The matching configured rank wins by priority; root rewards remain the safe fallback. */
    public ConfigurationSection rewardSection(Player player, int day) {
        String rank = selectedRank(player);
        ConfigurationSection custom = rank == null ? null : plugin.getConfig().getConfigurationSection(PATH + ".rank-rewards." + rank + ".rewards." + day);
        if (custom != null) return custom;
        ConfigurationSection base = plugin.getConfig().getConfigurationSection(PATH + ".rewards." + day);
        if (base != null) return base;

        // Upgraded servers may still only have the old seven-day default list.
        // Reuse that pattern until an admin deliberately configures Day 8-30.
        int fallback = ((Math.max(1, day) - 1) % 7) + 1;
        ConfigurationSection rankedFallback = rank == null ? null
                : plugin.getConfig().getConfigurationSection(PATH + ".rank-rewards." + rank + ".rewards." + fallback);
        return rankedFallback != null ? rankedFallback : plugin.getConfig().getConfigurationSection(PATH + ".rewards." + fallback);
    }

    public List<String> rankIds() {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection(PATH + ".rank-rewards");
        if (section == null) return List.of();
        return section.getKeys(false).stream().sorted().toList();
    }
    public String rankName(String id) { return plugin.getConfig().getString(PATH + ".rank-rewards." + id + ".display-name", id); }
    /** Returns the configured reward rank currently selected for a player, or "default". */
    public String selectedRankId(Player player) {
        String selected = selectedRank(player);
        return selected == null ? "default" : selected;
    }
    public int cycleDays() { return Math.max(1, Math.min(MAX_CYCLE_DAYS, plugin.getConfig().getInt(PATH + ".cycle-days", MAX_CYCLE_DAYS))); }
    public void setCycleDays(int days) {
        plugin.getConfig().set(PATH + ".cycle-days", Math.max(1, Math.min(MAX_CYCLE_DAYS, days)));
        plugin.saveConfig();
    }
    public int claimIntervalDays() { return Math.max(1, Math.min(365, plugin.getConfig().getInt(PATH + ".claim-interval-days", 1))); }
    public void setClaimIntervalDays(int days) { plugin.getConfig().set(PATH + ".claim-interval-days", Math.max(1, Math.min(365, days))); plugin.saveConfig(); }
    public void addRank(String id) {
        String clean = id.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_+-]", "");
        if (clean.isBlank()) throw new IllegalArgumentException("Use letters, numbers, _, +, or - only.");
        String root = PATH + ".rank-rewards." + clean;
        plugin.getConfig().set(root + ".display-name", clean);
        plugin.getConfig().set(root + ".luckperms-group", clean);
        plugin.getConfig().set(root + ".priority", defaultPriority(clean));
        plugin.saveConfig();
    }
    public void removeRank(String id) { plugin.getConfig().set(PATH + ".rank-rewards." + id, null); plugin.saveConfig(); }
    public List<String> itemRewards(String rank, int day) {
        return List.copyOf(plugin.getConfig().getStringList(rewardPath(rank, day) + ".items"));
    }
    public void setItemReward(String rank, int day, ItemStack stack) {
        plugin.getConfig().set(rewardPath(rank, day) + ".items", List.of(itemEntry(stack)));
        plugin.saveConfig();
    }
    public void addItemReward(String rank, int day, ItemStack stack) {
        List<String> items = new java.util.ArrayList<>(itemRewards(rank, day));
        items.add(itemEntry(stack));
        plugin.getConfig().set(rewardPath(rank, day) + ".items", items);
        plugin.saveConfig();
    }
    public void removeItemReward(String rank, int day, int index) {
        List<String> items = new java.util.ArrayList<>(itemRewards(rank, day));
        if (index >= 0 && index < items.size()) items.remove(index);
        plugin.getConfig().set(rewardPath(rank, day) + ".items", items);
        plugin.saveConfig();
    }
    public void setMoneyReward(String rank, int day, double money) { plugin.getConfig().set(rewardPath(rank, day) + ".money", Math.max(0D, money)); plugin.saveConfig(); }
    public List<String> commandRewards(String rank, int day) {
        return List.copyOf(plugin.getConfig().getStringList(rewardPath(rank, day) + ".commands"));
    }
    public void setCommandReward(String rank, int day, String command) { plugin.getConfig().set(rewardPath(rank, day) + ".commands", command.isBlank() ? List.of() : List.of(command)); plugin.saveConfig(); }
    public void addCommandReward(String rank, int day, String command) {
        if (command == null || command.isBlank()) return;
        List<String> commands = new java.util.ArrayList<>(commandRewards(rank, day));
        commands.add(command);
        plugin.getConfig().set(rewardPath(rank, day) + ".commands", commands);
        plugin.saveConfig();
    }
    public void clearCommandRewards(String rank, int day) {
        plugin.getConfig().set(rewardPath(rank, day) + ".commands", List.of());
        plugin.saveConfig();
    }
    public void clearReward(String rank, int day) { plugin.getConfig().set(rewardPath(rank, day), null); plugin.saveConfig(); }
    public String rewardPath(String rank, int day) { return rank == null ? PATH + ".rewards." + day : PATH + ".rank-rewards." + rank + ".rewards." + day; }

    private String selectedRank(Player player) {
        return rankIds().stream().filter(id -> matches(player, id))
                .max(Comparator.comparingInt(id -> plugin.getConfig().getInt(PATH + ".rank-rewards." + id + ".priority", 0))).orElse(null);
    }
    private int defaultPriority(String rank) {
        return switch (rank) {
            case "secret" -> 10;
            case "unknown" -> 20;
            case "ominous" -> 30;
            case "cryptic" -> 40;
            case "incog" -> 50;
            case "incog+", "incogplus" -> 60;
            default -> rankIds().size() + 1;
        };
    }
    private boolean matches(Player player, String id) {
        String root = PATH + ".rank-rewards." + id;
        String permission = plugin.getConfig().getString(root + ".permission", "").trim();
        if (!permission.isBlank() && player.hasPermission(permission)) return true;
        String group = plugin.getConfig().getString(root + ".luckperms-group", id).trim();
        if (group.isBlank()) return false;
        try {
            var user = LuckPermsProvider.get().getPlayerAdapter(Player.class).getUser(player);
            return user.getInheritedGroups(QueryOptions.defaultContextualOptions()).stream()
                    .anyMatch(current -> current.getName().equalsIgnoreCase(group));
        } catch (IllegalStateException unavailable) { return false; }
    }


    private static String itemEntry(ItemStack stack) {
        int amount = Math.max(1, stack.getAmount());
        return stack.getType().name() + " " + amount;
    }

    private void giveItem(Player player, String entry) {
        String[] parts = entry.trim().split("\\s+", 2);
        Material material = Material.matchMaterial(parts[0].toUpperCase(java.util.Locale.ROOT));
        if (material == null || !material.isItem()) { plugin.getLogger().warning("Ignored invalid Daily Rewards item: " + entry); return; }
        int amount = 1;
        if (parts.length == 2) try { amount = Math.max(1, Math.min(material.getMaxStackSize() * 64, Integer.parseInt(parts[1]))); } catch (NumberFormatException ignored) { }
        while (amount > 0) {
            int stack = Math.min(amount, material.getMaxStackSize());
            var overflow = player.getInventory().addItem(new ItemStack(material, stack));
            overflow.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
            amount -= stack;
        }
    }

    private ZoneId zone() { try { return ZoneId.of(plugin.getConfig().getString(PATH + ".zone-id", "America/New_York")); } catch (Exception ignored) { return ZoneId.systemDefault(); } }
    private static LocalDate parse(String raw) { try { return raw == null || raw.isBlank() ? null : LocalDate.parse(raw); } catch (Exception ignored) { return null; } }
}

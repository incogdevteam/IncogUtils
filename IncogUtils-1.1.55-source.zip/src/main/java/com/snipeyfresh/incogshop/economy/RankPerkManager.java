package com.snipeyfresh.incogshop.economy;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Resolves non-stacking market perks from ordinary Bukkit permissions.
 *
 * LuckPerms (and any other permission provider) can grant the configured nodes
 * to groups without IncogEcon taking a hard dependency on that provider. When a
 * player has multiple matching nodes, only the highest percentage is used.
 */
public final class RankPerkManager {
    public record Tier(String permission, double percent) { }

    private final IncogShopPlugin plugin;

    public RankPerkManager(IncogShopPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("rank-perks.enabled", true);
    }

    public double buyDiscountPercent(Player player) {
        if (!enabled() || player == null) return 0.0;
        double maximum = clamp(plugin.getConfig().getDouble("rank-perks.maximum-buy-discount-percent", 95.0), 0.0, 100.0);
        return Math.min(maximum, highest(player, tiers("rank-perks.buy-discounts")));
    }

    public double sellBonusPercent(Player player) {
        if (!enabled() || player == null) return 0.0;
        double maximum = Math.max(0.0, plugin.getConfig().getDouble("rank-perks.maximum-sell-bonus-percent", 100.0));
        return Math.min(maximum, highest(player, tiers("rank-perks.sell-bonuses")));
    }

    public double discountedBuyPrice(Player player, double price) {
        return WalletManager.round(Math.max(0.0, price) * (1.0 - buyDiscountPercent(player) / 100.0));
    }

    public double boostedSellPrice(Player player, double price) {
        return WalletManager.round(Math.max(0.0, price) * (1.0 + sellBonusPercent(player) / 100.0));
    }

    public List<Tier> buyDiscountTiers() {
        return tiers("rank-perks.buy-discounts");
    }

    public List<Tier> sellBonusTiers() {
        return tiers("rank-perks.sell-bonuses");
    }

    private double highest(Player player, List<Tier> tiers) {
        double highest = 0.0;
        for (Tier tier : tiers) {
            if (player.hasPermission(tier.permission())) highest = Math.max(highest, tier.percent());
        }
        return highest;
    }

    private List<Tier> tiers(String path) {
        List<Tier> tiers = new ArrayList<>();
        for (Map<?, ?> raw : plugin.getConfig().getMapList(path)) {
            Object permissionValue = raw.get("permission");
            Object percentValue = raw.get("percent");
            if (permissionValue == null || percentValue == null) continue;

            String permission = permissionValue.toString().trim().toLowerCase(Locale.ROOT);
            if (permission.isBlank()) continue;

            double percent;
            if (percentValue instanceof Number number) percent = number.doubleValue();
            else {
                try { percent = Double.parseDouble(percentValue.toString()); }
                catch (NumberFormatException ignored) { continue; }
            }
            if (!Double.isFinite(percent) || percent <= 0.0) continue;
            tiers.add(new Tier(permission, percent));
        }
        tiers.sort(Comparator.comparingDouble(Tier::percent).reversed().thenComparing(Tier::permission));
        return List.copyOf(tiers);
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}

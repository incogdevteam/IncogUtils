package com.snipeyfresh.incogshop.gui;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.hex.HexManager.BookChoice;
import com.snipeyfresh.incogshop.hex.HexManager.EnchantChoice;
import com.snipeyfresh.incogshop.util.Text;
import com.snipeyfresh.incogshop.xp.XpVaultManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public final class HexGui {
    public static final int[] CONTENT_SLOTS = {
            9,10,11,12,13,14,15,16,17,
            18,19,20,21,22,23,24,25,26,
            27,28,29,30,31,32,33,34,35,
            36,37,38,39,40,41,42,43,44
    };

    private final IncogShopPlugin plugin;
    private final NamespacedKey enchantKey;
    private final NamespacedKey bookSlotKey;

    public HexGui(IncogShopPlugin plugin) {
        this.plugin = plugin;
        this.enchantKey = new NamespacedKey(plugin.host(), "hex_enchant");
        this.bookSlotKey = new NamespacedKey(plugin.host(), "hex_book_slot");
    }

    public record MainHolder() implements InventoryHolder { @Override public Inventory getInventory() { return null; } }
    public record EnchantHolder(int page) implements InventoryHolder { @Override public Inventory getInventory() { return null; } }
    public record BookHolder(int page) implements InventoryHolder { @Override public Inventory getInventory() { return null; } }
    public record IntegrationHolder() implements InventoryHolder { @Override public Inventory getInventory() { return null; } }
    public record UpgradeHolder() implements InventoryHolder { @Override public Inventory getInventory() { return null; } }

    public NamespacedKey enchantKey() { return enchantKey; }
    public NamespacedKey bookSlotKey() { return bookSlotKey; }

    public void openMain(Player player) {
        ItemStack target = plugin.hex().target(player);
        if (target == null) {
            player.closeInventory();
            player.sendMessage(plugin.prefix() + "§cYour held item changed. Hold the item you want and reopen /hex.");
            return;
        }

        Inventory inv = Bukkit.createInventory(new MainHolder(), 54, Text.color("&8IncogEcon &7• &5The Hex"));
        frame(inv);
        inv.setItem(4, named(Material.AMETHYST_SHARD, "&5&lTHE HEX", List.of(
                "&7One place to refine your item.",
                "&7Designed for Java and Bedrock players.",
                "", "&8Target stays safely in your main hand.")));
        inv.setItem(13, target.clone());

        inv.setItem(20, named(Material.ENCHANTING_TABLE, "&dEnchantments", List.of(
                "&7Purchase applicable vanilla and custom", "&7enchantments one level at a time.", "",
                "&7Uses: &6coins &7+ &aexperience", "&eClick to view")));
        inv.setItem(22, named(Material.ENCHANTED_BOOK, "&bEnchanted Books", List.of(
                "&7Apply compatible enchanted books", "&7already in your inventory.", "",
                "&aSupports ExcellentEnchants, Bukkit,", "&aand IncogRPG books safely.", "&eClick to view")));
        boolean reforgeAvailable = plugin.hex().reforgeAvailable();
        String reforgeProvider = plugin.hex().reforgeProviderName();
        inv.setItem(24, named(Material.ANVIL, "&6Reforges", List.of(
                reforgeAvailable ? "&a" + reforgeProvider + " reforge service detected." : "&8No supported reforge service detected.",
                "&7If installed, The Hex opens the", "&7plugin's own reforge menu so its", "&7rules remain authoritative.", "",
                reforgeAvailable ? "&eClick to open Reforges" : "&8Unavailable")));

        inv.setItem(29, named(Material.NETHERITE_CHESTPLATE, "&aItem Upgrades", List.of(
                plugin.hex().pluginEnabled("EcoArmor") ? "&aEcoArmor detected." : "&8EcoArmor not detected.",
                "&7View safe integration options for", "&7plugin-owned armor/item upgrades.", "",
                "&eClick to view")));
        inv.setItem(31, named(Material.NETHER_STAR, "&ePlugin Compatibility", compatibilityLore()));
        inv.setItem(33, named(Material.CLOCK, "&bRefresh Item", List.of(
                "&7Refresh the Hex's target snapshot.", "&7Use this after returning from an", "&7external upgrade menu.", "", "&eClick to refresh")));

        inv.setItem(48, named(Material.EXPERIENCE_BOTTLE, "&aExperience: &f" + XpVaultManager.totalExperience(player) + " XP", List.of()));
        inv.setItem(50, named(Material.GOLD_INGOT, "&6Balance: &f" + plugin.money(plugin.wallets().get(player.getUniqueId())), List.of()));
        inv.setItem(49, named(Material.ARROW, "&e&lBack to Menus", List.of("&7Return to the IncogUtils menu hub.")));
        player.openInventory(inv);
    }

    public void openEnchantments(Player player, int requestedPage) {
        if (plugin.hex().target(player) == null) { openMain(player); return; }
        List<EnchantChoice> choices = plugin.hex().enchantments(player);
        int pages = Math.max(1, (int)Math.ceil(choices.size() / (double)CONTENT_SLOTS.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        Inventory inv = Bukkit.createInventory(new EnchantHolder(page), 54,
                Text.color("&8The Hex &7• &dEnchantments &7(" + (page + 1) + "/" + pages + ")"));
        frame(inv);

        int start = page * CONTENT_SLOTS.length;
        for (int i = 0; i < CONTENT_SLOTS.length && start + i < choices.size(); i++) {
            EnchantChoice choice = choices.get(start + i);
            String name = choice.displayName();
            List<String> lore = new ArrayList<>();
            lore.add("&8Provider: " + choice.source());
            lore.add("&7Current: &f" + (choice.currentLevel() <= 0 ? "None" : choice.currentLevel()));
            lore.add("&7Next: &a" + choice.nextLevel());
            lore.add("");
            lore.add("&7Coin cost: &6" + plugin.money(choice.moneyCost()));
            lore.add("&7XP cost: &a" + choice.xpCost() + " XP");
            lore.add("");
            lore.add("&eClick to apply");
            ItemStack icon = named(Material.ENCHANTED_BOOK, "&d" + name, lore);
            ItemMeta meta = icon.getItemMeta();
            if (meta != null) {
                meta.getPersistentDataContainer().set(enchantKey, PersistentDataType.STRING, choice.id());
                icon.setItemMeta(meta);
            }
            inv.setItem(CONTENT_SLOTS[i], icon);
        }

        inv.setItem(45, named(Material.ARROW, "&ePrevious", page > 0 ? List.of("&7Previous page") : List.of("&8First page")));
        inv.setItem(49, named(Material.ARROW, "&eBack to The Hex", List.of()));
        inv.setItem(53, named(Material.ARROW, "&eNext", page + 1 < pages ? List.of("&7Next page") : List.of("&8Last page")));
        player.openInventory(inv);
    }

    public void openBooks(Player player, int requestedPage) {
        if (plugin.hex().target(player) == null) { openMain(player); return; }
        List<BookChoice> books = plugin.hex().books(player);
        int pages = Math.max(1, (int)Math.ceil(books.size() / (double)CONTENT_SLOTS.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        Inventory inv = Bukkit.createInventory(new BookHolder(page), 54,
                Text.color("&8The Hex &7• &bYour Books &7(" + (page + 1) + "/" + pages + ")"));
        frame(inv);

        if (books.isEmpty()) {
            inv.setItem(22, named(Material.BOOK, "&7No compatible enchanted books", List.of(
                    "&7Put enchanted books in your inventory", "&7and reopen this page.", "",
                    "&8Supported: Bukkit-registered enchants,", "&8ExcellentEnchants, and IncogRPG.")));
        } else {
            int start = page * CONTENT_SLOTS.length;
            for (int i = 0; i < CONTENT_SLOTS.length && start + i < books.size(); i++) {
                BookChoice choice = books.get(start + i);
                ItemStack icon = choice.book().clone();
                ItemMeta meta = icon.getItemMeta();
                if (meta != null) {
                    List<String> lore = meta.hasLore() && meta.getLore() != null
                            ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
                    lore.add("");
                    lore.add(Text.color("&eClick to apply through The Hex"));
                    meta.setLore(lore);
                    meta.getPersistentDataContainer().set(bookSlotKey, PersistentDataType.INTEGER, choice.inventorySlot());
                    icon.setItemMeta(meta);
                }
                inv.setItem(CONTENT_SLOTS[i], icon);
            }
        }
        inv.setItem(45, named(Material.ARROW, "&ePrevious", page > 0 ? List.of("&7Previous page") : List.of("&8First page")));
        inv.setItem(49, named(Material.ARROW, "&eBack to The Hex", List.of()));
        inv.setItem(53, named(Material.ARROW, "&eNext", page + 1 < pages ? List.of("&7Next page") : List.of("&8Last page")));
        player.openInventory(inv);
    }


    public void openItemUpgrades(Player player) {
        if (plugin.hex().target(player) == null) { openMain(player); return; }
        Inventory inv = Bukkit.createInventory(new UpgradeHolder(), 54, Text.color("&8The Hex &7• &aItem Upgrades"));
        frame(inv);

        inv.setItem(13, plugin.hex().target(player).clone());
        inv.setItem(20, status(Material.END_CRYSTAL, "&aEcoArmor Upgrade Crystals", plugin.hex().pluginEnabled("EcoArmor"),
                "EcoArmor owns tier validation and", "crystal consumption. Hex preserves its", "metadata and does not bypass those rules.",
                plugin.hex().pluginEnabled("EcoArmor") ? "Click for safe handoff instructions." : ""));
        inv.setItem(22, status(Material.PRISMARINE_SHARD, "&bEcoArmor Advancement Shards", plugin.hex().pluginEnabled("EcoArmor"),
                "Advancement shards remain handled", "by EcoArmor's normal inventory action.",
                plugin.hex().pluginEnabled("EcoArmor") ? "Click for safe handoff instructions." : ""));
        inv.setItem(24, status(Material.ANVIL, "&6Reforge Upgrades", plugin.hex().reforgeAvailable(),
                plugin.hex().reforgeAvailable() ? "Click to open " + plugin.hex().reforgeProviderName() + "'s real" : "No supported reforge service detected.",
                plugin.hex().reforgeAvailable() ? "reforge menu without rewriting data." : "IncogRPG or Reforges is required."));
        inv.setItem(30, named(Material.ENCHANTED_BOOK, "&dEnchant-based Upgrades", List.of(
                "&7Use Hex Enchantments or Your Books.",
                "&7High-level standard Bukkit books are",
                "&7kept at their stored level.", "",
                "&eClick to view enchantments")));
        inv.setItem(32, named(Material.SHIELD, "&eWhy Hex Doesn't Fake Plugin Upgrades", List.of(
                "&7Synthetic clicks can bypass another",
                "&7plugin's costs, requirements, or item",
                "&7validation. Hex deliberately hands",
                "&7those actions back to their owner.")));
        inv.setItem(49, named(Material.ARROW, "&eBack to The Hex", List.of()));
        player.openInventory(inv);
    }

    public void openIntegrations(Player player) {
        Inventory inv = Bukkit.createInventory(new IntegrationHolder(), 54, Text.color("&8The Hex &7• &eCompatibility"));
        frame(inv);
        inv.setItem(10, status(Material.ENDER_EYE, "&aGeyser / Floodgate", plugin.bedrockInputs().available(),
                "Native Bedrock forms remain available", "for IncogEcon text-entry features."));
        inv.setItem(12, status(Material.DIAMOND_CHESTPLATE, "&aEcoArmor", plugin.hex().pluginEnabled("EcoArmor"),
                "Hex preserves custom ItemMeta/PDC.", "EcoArmor owns its tier/crystal rules."));
        inv.setItem(14, status(Material.BOOK, "&bExcellentEnchants", plugin.hex().excellentEnchantsAvailable(),
                "Registered enchants, provider names,", "levels, conflicts, and charges are preserved."));
        inv.setItem(16, status(Material.ANVIL, "&dReforges", plugin.hex().reforgeAvailable(),
                plugin.hex().reforgeAvailable() ? plugin.hex().reforgeProviderName() + " is connected through its" : "IncogRPG/Reforges was not detected.",
                plugin.hex().reforgeAvailable() ? "real command and service contract." : "The reforge action is unavailable."));
        inv.setItem(28, status(Material.NETHER_STAR, "&bEco / libreforge", plugin.hex().pluginEnabled("eco") || plugin.hex().pluginEnabled("libreforge"),
                "Their custom metadata is preserved.", "Hex never rebuilds custom ItemStacks."));
        inv.setItem(30, status(Material.DIAMOND_SWORD, "&dCustom Incog Items", true,
                "Custom names, lore, model data, PDC,", "attributes, and plugin tags are retained."));
        inv.setItem(32, status(Material.ENCHANTED_BOOK, "&dIncogRPG Enchants", plugin.hex().incogRpgAvailable(),
                "Uses the registered IncogRpgApi service", "and IncogRPG's own validation/writer."));
        inv.setItem(34, status(Material.SHIELD, "&aProtection / Utility Plugins", true,
                "Hex performs no world edits, fake", "clicks, packets, or NMS mutations."));
        inv.setItem(49, named(Material.ARROW, "&eBack to The Hex", List.of()));
        player.openInventory(inv);
    }

    private ItemStack status(Material material, String name, boolean detected, String... lines) {
        List<String> lore = new ArrayList<>();
        lore.add(detected ? "&aDetected / Compatible" : "&8Not detected on this server");
        lore.add("");
        for (String line : lines) {
            if (line != null && !line.isBlank()) lore.add("&7" + line);
        }
        return named(material, name, lore);
    }

    private List<String> compatibilityLore() {
        return List.of(
                "&7The Hex uses Bukkit-registered enchants", "&7and provider-owned compatibility APIs.", "",
                "&7It preserves custom ItemMeta, PDC,", "&7lore, attributes, model data and tags.", "",
                "&7It does not fake another plugin's", "&7inventory events or internal upgrades.", "", "&eClick for detected integrations");
    }

    public static ItemStack named(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(name));
            List<String> colored = new ArrayList<>();
            for (String line : lore) colored.add(Text.color(line));
            meta.setLore(colored);
            item.setItemMeta(meta);
        }
        return item;
    }

    private static void frame(Inventory inv) {
        ItemStack pane = named(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < inv.getSize(); i++) {
            int row = i / 9;
            int col = i % 9;
            if (row == 0 || row == 5 || col == 0 || col == 8) inv.setItem(i, pane);
        }
    }
}

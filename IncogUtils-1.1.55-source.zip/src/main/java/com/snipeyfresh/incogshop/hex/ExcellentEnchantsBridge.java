package com.snipeyfresh.incogshop.hex;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.util.Text;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.lang.reflect.Method;

/** Optional, reflection-only bridge for ExcellentEnchants charge metadata and names. */
final class ExcellentEnchantsBridge {
    private final IncogShopPlugin plugin;
    private boolean warned;

    ExcellentEnchantsBridge(IncogShopPlugin plugin) {
        this.plugin = plugin;
    }

    boolean available() {
        return plugin.getServer().getPluginManager().isPluginEnabled("ExcellentEnchants");
    }

    String displayName(Enchantment enchantment) {
        if (!available() || enchantment == null) return null;
        try {
            ClassLoader loader = excellentClassLoader();
            Class<?> registry = Class.forName(
                    "su.nightexpress.excellentenchants.enchantment.EnchantRegistry", true, loader);
            Method getByBukkit = registry.getMethod("getByBukkit", Enchantment.class);
            Object custom = getByBukkit.invoke(null, enchantment);
            if (custom == null) return null;
            Object value = custom.getClass().getMethod("getDisplayName").invoke(custom);
            return value == null ? null : Text.renderMiniMessage(value.toString());
        } catch (ReflectiveOperationException | LinkageError ex) {
            warnOnce("could not read ExcellentEnchants display names", ex);
            return null;
        }
    }

    void restoreCharges(ItemStack item, Enchantment enchantment, int level) {
        if (!available() || item == null || enchantment == null) return;
        try {
            Class<?> utils = Class.forName(
                    "su.nightexpress.excellentenchants.EnchantsUtils", true, excellentClassLoader());
            utils.getMethod("restoreCharges", ItemStack.class, Enchantment.class, int.class)
                    .invoke(null, item, enchantment, level);
        } catch (ReflectiveOperationException | LinkageError ex) {
            warnOnce("could not initialize ExcellentEnchants charge metadata", ex);
        }
    }

    private ClassLoader excellentClassLoader() {
        var excellent = plugin.getServer().getPluginManager().getPlugin("ExcellentEnchants");
        return excellent == null ? plugin.getClass().getClassLoader() : excellent.getClass().getClassLoader();
    }

    private void warnOnce(String action, Throwable error) {
        if (warned) return;
        warned = true;
        plugin.getLogger().warning("The Hex " + action + ": " + error.getClass().getSimpleName()
                + ": " + error.getMessage() + ". Bukkit enchant compatibility remains enabled.");
    }
}

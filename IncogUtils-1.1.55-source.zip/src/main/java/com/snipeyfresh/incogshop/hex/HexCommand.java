package com.snipeyfresh.incogshop.hex;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public final class HexCommand implements CommandExecutor {
    private final IncogShopPlugin plugin;

    public HexCommand(IncogShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("The Hex can only be opened by a player.");
            return true;
        }
        if (!plugin.hex().enabled()) {
            player.sendMessage(plugin.prefix() + "§cThe Hex is currently disabled.");
            return true;
        }
        if (!player.hasPermission("incogshop.hex")) {
            player.sendMessage(plugin.prefix() + "§cYou do not have permission to use The Hex.");
            return true;
        }
        if (!plugin.hex().begin(player)) {
            player.sendMessage(plugin.prefix() + "§eHold the item you want to upgrade in your main hand, then run §f/hex§e.");
            return true;
        }
        plugin.hexGui().openMain(player);
        return true;
    }
}

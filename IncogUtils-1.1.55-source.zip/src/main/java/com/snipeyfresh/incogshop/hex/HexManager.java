package com.snipeyfresh.incogshop.hex;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.util.Text;
import com.snipeyfresh.incogshop.xp.XpVaultManager;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.command.PluginCommand;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Metadata-preserving backend for The Hex and its optional enchant/reforge bridges. */
public final class HexManager {
    private static final String BUKKIT_PREFIX = "bukkit:";
    private static final String INCOG_RPG_PREFIX = "incogrpg:";

    private final IncogShopPlugin plugin;
    private final Map<UUID, Session> sessions = new LinkedHashMap<>();
    private final ExcellentEnchantsBridge excellentEnchants;
    private final IncogRpgBridge incogRpg;

    public HexManager(IncogShopPlugin plugin) {
        this.plugin = plugin;
        this.excellentEnchants = new ExcellentEnchantsBridge(plugin);
        this.incogRpg = new IncogRpgBridge(plugin);
    }

    public record Session(int heldSlot, ItemStack snapshot) { }
    public record EnchantChoice(String id, String displayName, String source, int currentLevel, int nextLevel,
                                double moneyCost, long xpCost) { }
    public record BookChoice(int inventorySlot, ItemStack book, int enchantCount) { }
    public record ApplyResult(boolean success, int applied, int skipped, String message) { }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("hex.enabled", true);
    }

    public boolean begin(Player player) {
        ItemStack target = player.getInventory().getItemInMainHand();
        if (target == null || target.getType().isAir()) return false;
        sessions.put(player.getUniqueId(), new Session(player.getInventory().getHeldItemSlot(), target.clone()));
        return true;
    }

    public void end(Player player) {
        if (player != null) sessions.remove(player.getUniqueId());
    }

    public Session session(Player player) {
        return player == null ? null : sessions.get(player.getUniqueId());
    }

    public ItemStack target(Player player) {
        Session session = session(player);
        if (session == null) return null;
        if (player.getInventory().getHeldItemSlot() != session.heldSlot()) return null;
        ItemStack current = player.getInventory().getItem(session.heldSlot());
        if (current == null || current.getType().isAir()) return null;
        if (current.getAmount() != session.snapshot().getAmount() || !current.isSimilar(session.snapshot())) return null;
        return current;
    }

    public boolean refresh(Player player) {
        Session session = session(player);
        if (session == null) return begin(player);
        ItemStack current = player.getInventory().getItem(session.heldSlot());
        if (current == null || current.getType().isAir()) return false;
        sessions.put(player.getUniqueId(), new Session(session.heldSlot(), current.clone()));
        return true;
    }

    private void updateSnapshot(Player player, ItemStack updated) {
        Session session = session(player);
        if (session != null) sessions.put(player.getUniqueId(), new Session(session.heldSlot(), updated.clone()));
    }

    /** Returns every applicable Bukkit-registered enchant plus IncogRPG's API-backed enchants. */
    public List<EnchantChoice> enchantments(Player player) {
        ItemStack target = target(player);
        if (target == null) return List.of();
        ItemMeta meta = target.getItemMeta();
        if (meta == null) return List.of();

        List<EnchantChoice> out = new ArrayList<>();
        for (Enchantment enchantment : Registry.ENCHANTMENT) {
            if (!registeredEnchantAllowed(enchantment)) continue;
            if (!safeCanEnchant(enchantment, target)) continue;
            if (!plugin.getConfig().getBoolean("hex.enchantments.allow-curses", false)
                    && safeIsCursed(enchantment)) continue;

            int current = meta.getEnchantLevel(enchantment);
            int max = configuredMaxLevel(enchantment);
            if (current >= max || hasConflict(meta, enchantment)) continue;
            int next = Math.max(safeStartLevel(enchantment), current + 1);
            if (next > max) continue;
            out.add(new EnchantChoice(
                    bukkitId(enchantment), displayName(enchantment), enchantment.getKey().getNamespace(),
                    current, next, moneyCost(enchantment, next), xpCost(enchantment, next)));
        }

        if (plugin.getConfig().getBoolean("hex.enchantments.include-incogrpg", true) && incogRpg.available()) {
            Map<String, Integer> current = incogRpg.enchants(target);
            for (IncogRpgBridge.Definition definition : incogRpg.definitions(target)) {
                int oldLevel = current.getOrDefault(definition.id(), 0);
                int max = configuredIncogRpgMax(definition);
                int next = Math.max(1, oldLevel + 1);
                if (next > max) continue;
                String id = INCOG_RPG_PREFIX + definition.id();
                out.add(new EnchantChoice(id, definition.displayName(), "IncogRPG", oldLevel, next,
                        moneyCost("incogrpg", definition.id(), next),
                        xpCost("incogrpg", definition.id(), next)));
            }
        }

        out.sort(Comparator.comparing(EnchantChoice::displayName, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(EnchantChoice::id));
        return List.copyOf(out);
    }

    public ApplyResult purchaseEnchant(Player player, String enchantId) {
        if (!enabled()) return new ApplyResult(false, 0, 0, "The Hex is disabled.");
        if (enchantId == null || enchantId.isBlank()) {
            return new ApplyResult(false, 0, 0, "That enchantment is no longer available.");
        }
        if (enchantId.startsWith(BUKKIT_PREFIX)) return purchaseBukkitEnchant(player, enchantId);
        if (enchantId.startsWith(INCOG_RPG_PREFIX)) return purchaseIncogRpgEnchant(player, enchantId);
        return new ApplyResult(false, 0, 0, "That enchantment provider is no longer available.");
    }

    /** Kept for source compatibility with older Hex integrations. */
    public ApplyResult purchaseEnchant(Player player, Enchantment enchantment) {
        return enchantment == null
                ? new ApplyResult(false, 0, 0, "That enchantment is no longer available.")
                : purchaseEnchant(player, bukkitId(enchantment));
    }

    private ApplyResult purchaseBukkitEnchant(Player player, String enchantId) {
        ItemStack current = target(player);
        if (current == null) return new ApplyResult(false, 0, 0, "Your Hex item changed. Reopen /hex.");
        NamespacedKey key = NamespacedKey.fromString(enchantId.substring(BUKKIT_PREFIX.length()));
        Enchantment enchantment = key == null ? null : Registry.ENCHANTMENT.get(key);
        if (enchantment == null || !registeredEnchantAllowed(enchantment)) {
            return new ApplyResult(false, 0, 0, "That registered enchantment is no longer available.");
        }
        if (!safeCanEnchant(enchantment, current)) {
            return new ApplyResult(false, 0, 0, "That enchantment cannot be applied to this item.");
        }

        ItemMeta meta = current.getItemMeta();
        if (meta == null) return new ApplyResult(false, 0, 0, "This item cannot be enchanted.");
        if (hasConflict(meta, enchantment)) {
            return new ApplyResult(false, 0, 0, "That enchantment conflicts with one already on the item.");
        }
        int oldLevel = meta.getEnchantLevel(enchantment);
        int max = configuredMaxLevel(enchantment);
        int next = Math.max(safeStartLevel(enchantment), oldLevel + 1);
        if (next > max) return new ApplyResult(false, 0, 0, "That enchantment is already at its Hex maximum.");

        ItemStack updated = current.clone();
        if (!addRegisteredEnchant(updated, enchantment, next)) {
            return new ApplyResult(false, 0, 0, "The enchantment provider rejected that upgrade.");
        }
        return chargeAndCommit(player, updated, enchantId, displayName(enchantment), oldLevel, next,
                moneyCost(enchantment, next), xpCost(enchantment, next));
    }

    private ApplyResult purchaseIncogRpgEnchant(Player player, String enchantId) {
        ItemStack current = target(player);
        if (current == null) return new ApplyResult(false, 0, 0, "Your Hex item changed. Reopen /hex.");
        if (!incogRpg.available()) return new ApplyResult(false, 0, 0, "IncogRPG is no longer available.");
        String id = enchantId.substring(INCOG_RPG_PREFIX.length());
        IncogRpgBridge.Definition definition = incogRpg.definition(id);
        if (definition == null || !incogRpg.supports(id, current.getType())) {
            return new ApplyResult(false, 0, 0, "That IncogRPG enchantment cannot be applied to this item.");
        }

        int oldLevel = incogRpg.enchants(current).getOrDefault(id, 0);
        int max = configuredIncogRpgMax(definition);
        int next = Math.max(1, oldLevel + 1);
        if (next > max) return new ApplyResult(false, 0, 0, "That enchantment is already at its Hex maximum.");

        ItemStack updated = current.clone();
        IncogRpgBridge.ApplyOutcome outcome = incogRpg.apply(updated, id, next, false);
        if (outcome != IncogRpgBridge.ApplyOutcome.SUCCESS) {
            String reason = switch (outcome) {
                case INCOMPATIBLE -> "That IncogRPG enchantment does not support this item.";
                case CONFLICT -> "That IncogRPG enchantment conflicts with one already on the item.";
                case LIMIT -> "This item has reached IncogRPG's custom-enchantment limit.";
                case INVALID_LEVEL -> "IncogRPG rejected that enchantment level.";
                case ERROR, SUCCESS -> "IncogRPG rejected that enchantment upgrade.";
            };
            return new ApplyResult(false, 0, 0, reason);
        }
        return chargeAndCommit(player, updated, enchantId, definition.displayName(), oldLevel, next,
                moneyCost("incogrpg", id, next), xpCost("incogrpg", id, next));
    }

    private ApplyResult chargeAndCommit(Player player, ItemStack updated, String auditId, String displayName,
                                        int oldLevel, int nextLevel, double money, long xp) {
        if (plugin.wallets().get(player.getUniqueId()) + 1e-9 < money) {
            return new ApplyResult(false, 0, 0, "You need " + plugin.money(money) + ".");
        }
        long currentXp = XpVaultManager.totalExperience(player);
        if (currentXp < xp) return new ApplyResult(false, 0, 0, "You need " + xp + " experience points.");
        if (money > 0 && !plugin.wallets().withdraw(player.getUniqueId(), money)) {
            return new ApplyResult(false, 0, 0, "The economy provider rejected the payment.");
        }
        if (xp > 0) XpVaultManager.setTotalExperience(player, currentXp - xp);

        Session session = session(player);
        if (session == null || target(player) == null) {
            if (money > 0) plugin.wallets().deposit(player.getUniqueId(), money);
            if (xp > 0) XpVaultManager.setTotalExperience(player, currentXp);
            return new ApplyResult(false, 0, 0, "Your Hex session expired. No payment was kept.");
        }
        player.getInventory().setItem(session.heldSlot(), updated);
        updateSnapshot(player, updated);
        plugin.market().audit("HEX_ENCHANT", player.getUniqueId(), player.getName(), auditId,
                nextLevel, money, "xp=" + xp + ";from=" + oldLevel);
        return new ApplyResult(true, 1, 0, displayName + " upgraded to level " + nextLevel + ".");
    }

    public List<BookChoice> books(Player player) {
        List<BookChoice> out = new ArrayList<>();
        Session session = session(player);
        for (int slot = 0; slot < 36; slot++) {
            if (session != null && slot == session.heldSlot()) continue;
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack == null || stack.getType() != Material.ENCHANTED_BOOK) continue;
            int count = extractBookEnchants(stack).size() + incogRpg.enchants(stack).size();
            if (count > 0) out.add(new BookChoice(slot, stack.clone(), count));
        }
        return List.copyOf(out);
    }

    public ApplyResult applyBook(Player player, int inventorySlot) {
        ItemStack target = target(player);
        Session session = session(player);
        if (target == null || session == null) {
            return new ApplyResult(false, 0, 0, "Your Hex item changed. Reopen /hex.");
        }
        if (inventorySlot < 0 || inventorySlot >= 36 || inventorySlot == session.heldSlot()) {
            return new ApplyResult(false, 0, 0, "That book is no longer available.");
        }

        ItemStack book = player.getInventory().getItem(inventorySlot);
        if (book == null || book.getType() != Material.ENCHANTED_BOOK) {
            return new ApplyResult(false, 0, 0, "That book is no longer in your inventory.");
        }
        Map<Enchantment, Integer> bukkitEnchants = extractBookEnchants(book);
        Map<String, Integer> incogEnchants = incogRpg.enchants(book);
        if (bukkitEnchants.isEmpty() && incogEnchants.isEmpty()) {
            return new ApplyResult(false, 0, 0,
                    "That book's enchantment provider is not connected to The Hex.");
        }

        ItemStack updated = target.clone();
        boolean allowUnsafeTargets = plugin.getConfig().getBoolean("hex.books.allow-unsafe-targets", false);
        int applied = 0;
        int skipped = 0;

        for (Map.Entry<Enchantment, Integer> entry : bukkitEnchants.entrySet()) {
            Enchantment enchantment = entry.getKey();
            int level = Math.max(1, entry.getValue());
            if (!registeredEnchantAllowed(enchantment)) { skipped++; continue; }
            if (!allowUnsafeTargets && !safeCanEnchant(enchantment, updated)) { skipped++; continue; }
            ItemMeta meta = updated.getItemMeta();
            if (meta == null || hasConflict(meta, enchantment)) { skipped++; continue; }
            if (level <= meta.getEnchantLevel(enchantment)) { skipped++; continue; }
            if (addRegisteredEnchant(updated, enchantment, level)) applied++;
            else skipped++;
        }

        for (Map.Entry<String, Integer> entry : incogEnchants.entrySet()) {
            int existing = incogRpg.enchants(updated).getOrDefault(entry.getKey(), 0);
            int level = Math.max(1, entry.getValue());
            if (level <= existing) { skipped++; continue; }
            IncogRpgBridge.ApplyOutcome outcome = incogRpg.apply(updated, entry.getKey(), level, allowUnsafeTargets);
            if (outcome == IncogRpgBridge.ApplyOutcome.SUCCESS) applied++;
            else skipped++;
        }

        if (applied <= 0) {
            return new ApplyResult(false, 0, skipped, "None of that book's enchantments can upgrade this item.");
        }
        if (target(player) == null) {
            return new ApplyResult(false, 0, skipped, "Your Hex item changed before the book could be applied.");
        }

        consumeOne(player, inventorySlot, book);
        player.getInventory().setItem(session.heldSlot(), updated);
        updateSnapshot(player, updated);
        plugin.market().audit("HEX_BOOK", player.getUniqueId(), player.getName(), updated.getType().name(),
                applied, 0.0, "bookSlot=" + inventorySlot + ";skipped=" + skipped);
        return new ApplyResult(true, applied, skipped,
                "Applied " + applied + " enchantment" + (applied == 1 ? "" : "s")
                        + (skipped > 0 ? " (skipped " + skipped + ")." : "."));
    }

    private static void consumeOne(Player player, int inventorySlot, ItemStack book) {
        if (book.getAmount() <= 1) player.getInventory().setItem(inventorySlot, null);
        else {
            ItemStack reduced = book.clone();
            reduced.setAmount(book.getAmount() - 1);
            player.getInventory().setItem(inventorySlot, reduced);
        }
    }

    private Map<Enchantment, Integer> extractBookEnchants(ItemStack book) {
        Map<Enchantment, Integer> result = new LinkedHashMap<>();
        ItemMeta meta = book.getItemMeta();
        if (meta instanceof EnchantmentStorageMeta storage) result.putAll(storage.getStoredEnchants());
        for (Map.Entry<Enchantment, Integer> entry : book.getEnchantments().entrySet()) {
            result.merge(entry.getKey(), entry.getValue(), Math::max);
        }
        return result;
    }

    private boolean addRegisteredEnchant(ItemStack item, Enchantment enchantment, int level) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.addEnchant(enchantment, level, true)) return false;
        item.setItemMeta(meta);
        excellentEnchants.restoreCharges(item, enchantment, level);
        return true;
    }

    private boolean hasConflict(ItemMeta meta, Enchantment candidate) {
        for (Enchantment existing : meta.getEnchants().keySet()) {
            if (existing.equals(candidate)) continue;
            try {
                if (candidate.conflictsWith(existing) || existing.conflictsWith(candidate)) return true;
            } catch (Throwable ignored) {
                return true;
            }
        }
        return false;
    }

    private boolean registeredEnchantAllowed(Enchantment enchantment) {
        if (enchantment == null) return false;
        String namespace = enchantment.getKey().getNamespace().toLowerCase(Locale.ROOT);
        if (!"minecraft".equals(namespace)
                && !plugin.getConfig().getBoolean("hex.enchantments.include-registered-custom", true)) return false;
        return plugin.getConfig().getStringList("hex.enchantments.excluded-namespaces").stream()
                .map(value -> value.toLowerCase(Locale.ROOT)).noneMatch(namespace::equals);
    }

    private static boolean safeCanEnchant(Enchantment enchantment, ItemStack item) {
        try { return enchantment.canEnchantItem(item); }
        catch (Throwable ignored) { return false; }
    }

    private static boolean safeIsCursed(Enchantment enchantment) {
        try { return enchantment.isCursed(); }
        catch (Throwable ignored) { return false; }
    }

    private static int safeStartLevel(Enchantment enchantment) {
        try { return Math.max(1, enchantment.getStartLevel()); }
        catch (Throwable ignored) { return 1; }
    }

    public int configuredMaxLevel(Enchantment enchantment) {
        int start = safeStartLevel(enchantment);
        int nativeMax;
        try { nativeMax = Math.max(start, enchantment.getMaxLevel()); }
        catch (Throwable ignored) { nativeMax = start; }
        return configuredMaxLevel(enchantment.getKey().getNamespace(), enchantment.getKey().getKey(), nativeMax, start);
    }

    private int configuredIncogRpgMax(IncogRpgBridge.Definition definition) {
        int configured = configuredMaxLevel("incogrpg", definition.id(), definition.maxLevel(), 1);
        return Math.min(definition.maxLevel(), configured);
    }

    private int configuredMaxLevel(String namespace, String id, int nativeMax, int start) {
        String path = "hex.enchantments.max-level-overrides." + namespace + "." + id;
        if (plugin.getConfig().isInt(path)) return Math.max(start, plugin.getConfig().getInt(path));
        String legacy = "hex.enchantments.max-level-overrides." + id;
        if ("minecraft".equals(namespace) && plugin.getConfig().isInt(legacy)) {
            return Math.max(start, plugin.getConfig().getInt(legacy));
        }
        return Math.max(start, nativeMax);
    }

    public double moneyCost(Enchantment enchantment, int level) {
        return moneyCost(enchantment.getKey().getNamespace(), enchantment.getKey().getKey(), level);
    }

    private double moneyCost(String namespace, String id, int level) {
        Double override = decimalOverride("hex.enchantments.cost-overrides", namespace, id, "money");
        if (override != null && override >= 0) return roundMoney(override * Math.max(1, level));
        double base = Math.max(0, plugin.getConfig().getDouble("hex.enchantments.base-money-cost", 500.0));
        double exponent = Math.max(0, plugin.getConfig().getDouble("hex.enchantments.money-level-exponent", 1.35));
        return roundMoney(base * Math.pow(Math.max(1, level), exponent));
    }

    public long xpCost(Enchantment enchantment, int level) {
        return xpCost(enchantment.getKey().getNamespace(), enchantment.getKey().getKey(), level);
    }

    private long xpCost(String namespace, String id, int level) {
        Double override = decimalOverride("hex.enchantments.cost-overrides", namespace, id, "xp");
        if (override != null && override >= 0) return Math.max(0L, Math.round(override * Math.max(1, level)));
        long base = Math.max(0L, plugin.getConfig().getLong("hex.enchantments.base-xp-cost", 25L));
        double exponent = Math.max(0, plugin.getConfig().getDouble("hex.enchantments.xp-level-exponent", 1.25));
        return Math.max(0L, Math.round(base * Math.pow(Math.max(1, level), exponent)));
    }

    private Double decimalOverride(String root, String namespace, String id, String field) {
        String path = root + "." + namespace + "." + id + "." + field;
        if (plugin.getConfig().isSet(path)) return plugin.getConfig().getDouble(path);
        String legacy = root + "." + id + "." + field;
        return "minecraft".equals(namespace) && plugin.getConfig().isSet(legacy)
                ? plugin.getConfig().getDouble(legacy) : null;
    }

    private static double roundMoney(double value) {
        return Math.round(Math.max(0, value) * 100.0) / 100.0;
    }

    public String displayName(Enchantment enchantment) {
        String excellentName = excellentEnchants.displayName(enchantment);
        if (excellentName != null && !excellentName.isBlank()) return excellentName;
        String pretty = Text.prettyEnum(enchantment.getKey().getKey().toUpperCase(Locale.ROOT));
        return "minecraft".equals(enchantment.getKey().getNamespace())
                ? pretty : pretty + " (" + enchantment.getKey().getNamespace() + ")";
    }

    public boolean pluginEnabled(String pluginName) {
        return pluginName != null && plugin.getServer().getPluginManager().isPluginEnabled(pluginName);
    }

    public boolean excellentEnchantsAvailable() {
        return excellentEnchants.available();
    }

    public boolean incogRpgAvailable() {
        return incogRpg.available();
    }

    public boolean reforgeAvailable() {
        return reforgeCommand() != null;
    }

    public String reforgeProviderName() {
        PluginCommand command = reforgeCommand();
        return command == null ? "" : command.getPlugin().getName();
    }

    public boolean openReforge(Player player) {
        PluginCommand command = reforgeCommand();
        if (command == null || player == null) return false;
        player.closeInventory();
        plugin.getServer().getScheduler().runTaskLater(plugin.host(), () -> {
            if (player.isOnline()) command.execute(player, "reforge", new String[0]);
        }, 1L);
        return true;
    }

    private PluginCommand reforgeCommand() {
        // IncogRPG is now the host module inside IncogUtils. Prefer the host's
        // command directly so a legacy plugin-name lookup cannot break Hex.
        PluginCommand unified = plugin.getServer().getPluginCommand("incogutils:reforge");
        if (ownedByEnabled(unified, "IncogUtils") && incogRpg.available()) return unified;
        PluginCommand incogNamespaced = plugin.getServer().getPluginCommand("incogrpg:reforge");
        if (ownedByEnabled(incogNamespaced, "IncogRPG") && incogRpg.available()) return incogNamespaced;
        PluginCommand direct = plugin.getServer().getPluginCommand("reforge");
        if (ownedByEnabled(direct, "IncogUtils") && incogRpg.available()) return direct;
        if (ownedByEnabled(direct, "IncogRPG") && incogRpg.available()) return direct;
        if (ownedByEnabled(direct, "Reforges")) return direct;
        PluginCommand legacyNamespaced = plugin.getServer().getPluginCommand("reforges:reforge");
        return ownedByEnabled(legacyNamespaced, "Reforges") ? legacyNamespaced : null;
    }

    private boolean ownedByEnabled(PluginCommand command, String pluginName) {
        return command != null && command.getPlugin().isEnabled()
                && command.getPlugin().getName().equalsIgnoreCase(pluginName);
    }

    public void logDetectedIntegrations() {
        if (excellentEnchants.available()) {
            plugin.getLogger().info("The Hex connected to ExcellentEnchants registered enchantments.");
        }
        if (incogRpg.available()) {
            plugin.getLogger().info("The Hex connected directly to the IncogUtils RPG module.");
        }
        if (reforgeAvailable()) {
            plugin.getLogger().info("The Hex reforge handoff is ready through " + reforgeProviderName() + ".");
        }
    }

    private static String bukkitId(Enchantment enchantment) {
        return BUKKIT_PREFIX + enchantment.getKey();
    }
}

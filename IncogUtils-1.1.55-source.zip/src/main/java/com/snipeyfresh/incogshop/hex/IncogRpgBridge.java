package com.snipeyfresh.incogshop.hex;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogrpg.model.EnchantDefinition;
import com.incogdev.incogrpg.service.EnchantService;
import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.util.Text;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Typed bridge between the unified RPG and Hex modules.
 *
 * <p>Both features now live in IncogUtils. A legacy plugin-name lookup for
 * "IncogRPG" would therefore disable Hex upgrades after the unified rename.
 * This bridge uses the host directly and keeps all RPG validation authoritative.</p>
 */
final class IncogRpgBridge {
    record Definition(String id, String displayName, int maxLevel) { }

    enum ApplyOutcome { SUCCESS, INCOMPATIBLE, CONFLICT, LIMIT, INVALID_LEVEL, ERROR }

    private final IncogRpgPlugin rpg;

    IncogRpgBridge(IncogShopPlugin plugin) {
        this.rpg = plugin.host();
    }

    boolean available() {
        return rpg.isEnabled() && rpg.configs() != null && rpg.enchants() != null;
    }

    List<Definition> definitions(ItemStack target) {
        if (!available() || target == null || target.getType().isAir()) return List.of();
        List<Definition> result = new ArrayList<>();
        for (EnchantDefinition definition : rpg.configs().get().enchants().values()) {
            if (!definition.enabled() || !definition.supports(target.getType())) continue;
            result.add(new Definition(definition.id(), Text.renderMiniMessage(definition.displayName()),
                    Math.max(1, definition.maxLevel())));
        }
        return List.copyOf(result);
    }

    Definition definition(String id) {
        EnchantDefinition definition = rawDefinition(id);
        return definition == null ? null : new Definition(definition.id(), Text.renderMiniMessage(definition.displayName()),
                Math.max(1, definition.maxLevel()));
    }

    boolean supports(String id, Material material) {
        EnchantDefinition definition = rawDefinition(id);
        return definition != null && material != null && definition.supports(material);
    }

    Map<String, Integer> enchants(ItemStack item) {
        if (!available() || item == null || item.getType().isAir()) return Map.of();
        return Map.copyOf(new LinkedHashMap<>(rpg.enchants().get(item)));
    }

    ApplyOutcome apply(ItemStack item, String id, int level, boolean unsafe) {
        EnchantDefinition definition = rawDefinition(id);
        if (definition == null) return ApplyOutcome.ERROR;
        EnchantService.ApplyResult result = rpg.enchants().apply(item, definition, level, unsafe);
        try {
            return ApplyOutcome.valueOf(result.name());
        } catch (IllegalArgumentException ignored) {
            return ApplyOutcome.ERROR;
        }
    }

    private EnchantDefinition rawDefinition(String id) {
        if (!available() || id == null || id.isBlank()) return null;
        EnchantDefinition definition = rpg.configs().get().enchants().get(id);
        return definition != null && definition.enabled() ? definition : null;
    }
}

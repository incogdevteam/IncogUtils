package com.snipeyfresh.incogshop.history;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.economy.WalletManager;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Staff-facing durable transaction audit trail for IncogShop money/item trades. */
public final class TransactionLogManager {
    public record Entry(Instant time, String type, UUID buyerUuid, String buyerName,
                        UUID sellerUuid, String sellerName, String item, int amount,
                        double unitPrice, double total, String source, String details) {
        public boolean involves(String player) {
            if (player == null || player.isBlank()) return true;
            String q = player.trim().toLowerCase(Locale.ROOT);
            return (buyerName != null && buyerName.toLowerCase(Locale.ROOT).equals(q))
                    || (sellerName != null && sellerName.toLowerCase(Locale.ROOT).equals(q))
                    || (buyerUuid != null && buyerUuid.toString().equalsIgnoreCase(q))
                    || (sellerUuid != null && sellerUuid.toString().equalsIgnoreCase(q));
        }
    }

    private final IncogShopPlugin plugin;
    private final File file;

    public TransactionLogManager(IncogShopPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(new File(plugin.getDataFolder(), "logs"), "transactions.tsv");
    }

    public void log(String type, UUID buyerUuid, String buyerName, UUID sellerUuid, String sellerName,
                    String item, int amount, double unitPrice, double total, String source, String details) {
        String line = Instant.now() + "\t" + clean(type) + "\t" + id(buyerUuid) + "\t" + clean(buyerName)
                + "\t" + id(sellerUuid) + "\t" + clean(sellerName) + "\t" + clean(item) + "\t" + amount
                + "\t" + WalletManager.round(unitPrice) + "\t" + WalletManager.round(total)
                + "\t" + clean(source) + "\t" + clean(details) + "\n";
        plugin.io().appendText(file.toPath(), line, "transactions.tsv");
    }

    public List<Entry> find(String player, int limit) {
        if (!file.exists()) return List.of();
        try {
            List<String> lines = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
            List<Entry> out = new ArrayList<>();
            for (int i = lines.size() - 1; i >= 0 && out.size() < Math.max(1, limit); i--) {
                Entry e = parse(lines.get(i));
                if (e != null && e.involves(player)) out.add(e);
            }
            return Collections.unmodifiableList(out);
        } catch (Exception ex) {
            plugin.getLogger().warning("Could not read transaction log: " + ex.getMessage());
            return List.of();
        }
    }

    private Entry parse(String line) {
        try {
            String[] p = line.split("\\t", -1);
            if (p.length < 12) return null;
            return new Entry(Instant.parse(p[0]), p[1], uuid(p[2]), value(p[3]), uuid(p[4]), value(p[5]),
                    p[6], Integer.parseInt(p[7]), Double.parseDouble(p[8]), Double.parseDouble(p[9]), p[10], p[11]);
        } catch (Exception ignored) { return null; }
    }

    private static String clean(String s) { return s == null || s.isBlank() ? "-" : s.replace('\t',' ').replace('\n',' '); }
    private static String id(UUID id) { return id == null ? "-" : id.toString(); }
    private static UUID uuid(String s) { try { return s == null || s.equals("-") ? null : UUID.fromString(s); } catch (Exception e) { return null; } }
    private static String value(String s) { return s == null || s.equals("-") ? null : s; }
}

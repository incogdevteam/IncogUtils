package com.snipeyfresh.incogshop.listener;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.gui.HexGui;
import com.snipeyfresh.incogshop.hex.HexManager.ApplyResult;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public final class HexListener implements Listener {
    private final IncogShopPlugin plugin;

    public HexListener(IncogShopPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Object holder = event.getView().getTopInventory().getHolder();
        if (!(holder instanceof HexGui.MainHolder)
                && !(holder instanceof HexGui.EnchantHolder)
                && !(holder instanceof HexGui.BookHolder)
                && !(holder instanceof HexGui.IntegrationHolder)
                && !(holder instanceof HexGui.UpgradeHolder)) return;

        // Cross-platform safety: Hex never depends on left/right/shift/middle/Q distinctions.
        // Every player action is a single visible GUI button, and all inventory movement is blocked.
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;

        int slot = event.getRawSlot();
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) return;

        if (holder instanceof HexGui.MainHolder) {
            switch (slot) {
                case 20 -> plugin.hexGui().openEnchantments(player, 0);
                case 22 -> plugin.hexGui().openBooks(player, 0);
                case 24 -> openReforges(player);
                case 29 -> plugin.hexGui().openItemUpgrades(player);
                case 31 -> plugin.hexGui().openIntegrations(player);
                case 33 -> {
                    if (plugin.hex().refresh(player)) {
                        player.sendMessage(plugin.prefix() + "§aHex target refreshed.");
                        plugin.hexGui().openMain(player);
                    } else {
                        player.closeInventory();
                        player.sendMessage(plugin.prefix() + "§cThe target item is no longer available. Reopen /hex.");
                    }
                }
                case 49 -> player.performCommand("menus");
                default -> { }
            }
            return;
        }

        if (holder instanceof HexGui.EnchantHolder enchantHolder) {
            if (slot == 45) { plugin.hexGui().openEnchantments(player, enchantHolder.page() - 1); return; }
            if (slot == 49) { plugin.hexGui().openMain(player); return; }
            if (slot == 53) { plugin.hexGui().openEnchantments(player, enchantHolder.page() + 1); return; }

            var meta = clicked.getItemMeta();
            if (meta == null) return;
            String raw = meta.getPersistentDataContainer().get(plugin.hexGui().enchantKey(), PersistentDataType.STRING);
            if (raw == null) return;
            ApplyResult result = plugin.hex().purchaseEnchant(player, raw);
            player.sendMessage(plugin.prefix() + (result.success() ? "§a" : "§c") + result.message());
            plugin.hexGui().openEnchantments(player, enchantHolder.page());
            return;
        }

        if (holder instanceof HexGui.BookHolder bookHolder) {
            if (slot == 45) { plugin.hexGui().openBooks(player, bookHolder.page() - 1); return; }
            if (slot == 49) { plugin.hexGui().openMain(player); return; }
            if (slot == 53) { plugin.hexGui().openBooks(player, bookHolder.page() + 1); return; }

            var meta = clicked.getItemMeta();
            if (meta == null) return;
            Integer inventorySlot = meta.getPersistentDataContainer().get(plugin.hexGui().bookSlotKey(), PersistentDataType.INTEGER);
            if (inventorySlot == null) return;
            ApplyResult result = plugin.hex().applyBook(player, inventorySlot);
            player.sendMessage(plugin.prefix() + (result.success() ? "§a" : "§c") + result.message());
            plugin.hexGui().openBooks(player, bookHolder.page());
            return;
        }

        if (holder instanceof HexGui.UpgradeHolder) {
            switch (slot) {
                case 20, 22 -> ecoArmorHandoff(player);
                case 24 -> openReforges(player);
                case 30 -> plugin.hexGui().openEnchantments(player, 0);
                case 49 -> plugin.hexGui().openMain(player);
                default -> { }
            }
            return;
        }

        if (holder instanceof HexGui.IntegrationHolder && slot == 49) {
            plugin.hexGui().openMain(player);
        }
    }


    private void ecoArmorHandoff(Player player) {
        if (!plugin.hex().pluginEnabled("EcoArmor")) {
            player.sendMessage(plugin.prefix() + "§7EcoArmor is not installed on this server.");
            return;
        }
        player.closeInventory();
        player.sendMessage(plugin.prefix() + "§aEcoArmor detected. §7Use its Upgrade Crystal or Advancement Shard on the item through your normal inventory, then reopen §f/hex§7. IncogEcon will not bypass EcoArmor's own validation or costs.");
    }

    private void openReforges(Player player) {
        if (plugin.hex().openReforge(player)) return;
        player.sendMessage(plugin.prefix() + "§7No supported reforge service is available. Install IncogRPG or the Reforges gameplay plugin.");
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        Object holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof HexGui.MainHolder
                || holder instanceof HexGui.EnchantHolder
                || holder instanceof HexGui.BookHolder
                || holder instanceof HexGui.IntegrationHolder
                || holder instanceof HexGui.UpgradeHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.hex().end(event.getPlayer());
    }
}

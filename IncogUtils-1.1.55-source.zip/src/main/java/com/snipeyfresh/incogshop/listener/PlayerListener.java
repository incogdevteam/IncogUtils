package com.snipeyfresh.incogshop.listener;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public final class PlayerListener implements Listener {
    private final IncogShopPlugin plugin;
    public PlayerListener(IncogShopPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.wallets().touch(player.getUniqueId(), player.getName());
        // Allocate on the next tick so the join event never competes with
        // world/player initialization or blocks the login thread.
        plugin.getServer().getScheduler().runTask(plugin.host(), () -> {
            if (plugin.ownerShopHolograms() != null) plugin.ownerShopHolograms().refreshViewer(player);
            if (plugin.shoppingDistrict() == null || !plugin.shoppingDistrict().enabled()) return;
            boolean hadPlot = !plugin.shoppingDistrict().plots(player.getUniqueId()).isEmpty();
            var result = plugin.shoppingDistrict().ensureStarterPlot(player);
            if (!result.success() || result.plot() == null) return;
            if (plugin.shoppingDistrict().settings().notifyFirstJoin()
                    && !hadPlot) {
                player.sendMessage(plugin.prefix() + "§aYour Shopping District plot is ready! Use §f/shopdistrict home§a to visit it.");
                player.sendMessage(plugin.prefix() + "§7Place a chest or barrel there, hold an item, and run §f/pshop create <price>§7 to start selling.");
            }
            if (plugin.shoppingDistrict().settings().teleportFirstJoin()
                    && !hadPlot) {
                plugin.shoppingDistrict().teleport(player, result.plot());
            }
        });
    }
}

package com.snipeyfresh.incogshop.listener;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.shopping.ShoppingDistrictManager;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Hanging;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockMultiPlaceEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.vehicle.VehicleDestroyEvent;
import org.bukkit.inventory.EquipmentSlot;

/**
 * Full protection layer for the district. Roads, unassigned plots, and other
 * players' plots are protected; the owner may build and stock their own plot.
 * Registered physical player-shop containers are deliberately skipped so the
 * existing ShopProtectionListener can open the public shop GUI.
 */
public final class ShoppingDistrictListener implements Listener {
    private final IncogShopPlugin plugin;

    public ShoppingDistrictListener(IncogShopPlugin plugin) {
        this.plugin = plugin;
    }

    private ShoppingDistrictManager district() {
        return plugin.shoppingDistrict();
    }

    /**
     * Rescue players only after they fall through the district void. Empty
     * space between lazy-generated islands is intentionally traversable, so
     * this must not send players back merely for flying or teleporting away
     * from the hub platform.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() == null || !district().inDistrict(event.getTo())) return;
        if (event.getTo().getY() > district().voidRescueY()) return;
        var spawn = district().spawn();
        if (spawn != null) {
            event.getPlayer().setFallDistance(0.0F);
            event.setTo(spawn);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onBreak(BlockBreakEvent event) {
        if (!district().inDistrict(event.getBlock().getLocation())) return;
        if (plugin.shops().at(event.getBlock()) != null) return;
        if (district().canBuild(event.getPlayer(), event.getBlock().getLocation())) return;
        event.setCancelled(true);
        deny(event.getPlayer(), "break blocks here");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onPlace(BlockPlaceEvent event) {
        if (!district().inDistrict(event.getBlockPlaced().getLocation())) return;
        if (district().canBuild(event.getPlayer(), event.getBlockPlaced().getLocation())) return;
        event.setCancelled(true);
        deny(event.getPlayer(), "place blocks here");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onMultiPlace(BlockMultiPlaceEvent event) {
        if (!district().inDistrict(event.getBlock().getLocation())) return;
        for (Block block : event.getReplacedBlockStates().stream().map(state -> state.getBlock()).toList()) {
            if (!district().canBuild(event.getPlayer(), block.getLocation())) {
                event.setCancelled(true);
                deny(event.getPlayer(), "place blocks here");
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || event.getClickedBlock() == null) return;
        if (!district().inDistrict(event.getClickedBlock().getLocation())) return;
        // The existing player-shop listener opens the customer GUI for these
        // exact containers; cancelling here would make public shops unusable.
        if (plugin.shops().at(event.getClickedBlock()) != null) return;
        if (district().canAccess(event.getPlayer(), event.getClickedBlock().getLocation())) return;
        event.setCancelled(true);
        deny(event.getPlayer(), "interact with blocks here");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (!district().inDistrict(event.getRightClicked().getLocation())) return;
        if (district().canAccess(event.getPlayer(), event.getRightClicked().getLocation())) return;
        event.setCancelled(true);
        deny(event.getPlayer(), "interact with entities here");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (!district().inDistrict(event.getInventory().getLocation())) return;
        if (district().canAccess(player, event.getInventory().getLocation())) return;
        event.setCancelled(true);
        deny(player, "open containers here");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!district().inDistrict(event.getView().getTopInventory().getLocation())) return;
        if (district().canAccess(player, event.getView().getTopInventory().getLocation())) return;
        event.setCancelled(true);
        deny(player, "take items from containers here");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!district().inDistrict(event.getView().getTopInventory().getLocation())) return;
        if (district().canAccess(player, event.getView().getTopInventory().getLocation())) return;
        event.setCancelled(true);
        deny(player, "move items in containers here");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInventoryMove(InventoryMoveItemEvent event) {
        if (inDistrict(event.getSource().getLocation()) || inDistrict(event.getDestination().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInventoryPickup(InventoryPickupItemEvent event) {
        if (inDistrict(event.getInventory().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onDrop(PlayerDropItemEvent event) {
        if (!district().inDistrict(event.getItemDrop().getLocation())) return;
        if (district().canBuild(event.getPlayer(), event.getItemDrop().getLocation())) return;
        event.setCancelled(true);
        deny(event.getPlayer(), "drop items outside your plot");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!district().inDistrict(event.getItem().getLocation())) return;
        if (district().canBuild(player, event.getItem().getLocation())) return;
        event.setCancelled(true);
        deny(player, "pick up items from another shop");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onDamage(EntityDamageEvent event) {
        if (!district().inDistrict(event.getEntity().getLocation())) return;
        if (event instanceof EntityDamageByEntityEvent damage && district().settings().allowPvp()
                && damage.getEntity() instanceof Player && damage.getDamager() instanceof Player) return;
        if (event instanceof EntityDamageByEntityEvent damage && damage.getDamager() instanceof Player player
                && !(damage.getEntity() instanceof Player)
                && district().canBuild(player, damage.getEntity().getLocation())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onExplode(EntityExplodeEvent event) {
        if (district().inDistrict(event.getLocation())) {
            event.blockList().clear();
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onBlockExplode(BlockExplodeEvent event) {
        if (district().inDistrict(event.getBlock().getLocation())) {
            event.blockList().clear();
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        if (district().inDistrict(event.getBlock().getLocation())
                || event.getBlocks().stream().anyMatch(block -> district().inDistrict(block.getLocation())
                || district().inDistrict(block.getRelative(event.getDirection()).getLocation()))) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        if (district().inDistrict(event.getBlock().getLocation())
                || event.getBlocks().stream().anyMatch(block -> district().inDistrict(block.getLocation())
                || district().inDistrict(block.getRelative(event.getDirection()).getLocation()))) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onFlow(BlockFromToEvent event) {
        if (district().inDistrict(event.getBlock().getLocation())
                || district().inDistrict(event.getToBlock().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onBurn(BlockBurnEvent event) {
        if (district().inDistrict(event.getBlock().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onIgnite(BlockIgniteEvent event) {
        if (district().inDistrict(event.getBlock().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onEntityChangeBlock(EntityChangeBlockEvent event) {
        if (district().inDistrict(event.getBlock().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onItemSpawn(ItemSpawnEvent event) {
        // Prevent accidental item piles on public roads, but allow an owner to
        // drop an item inside their own plot for normal building workflows.
        if (!district().inDistrict(event.getLocation())) return;
        if (district().plotAt(event.getLocation()).isEmpty()) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        if (!district().inDistrict(event.getBlock().getLocation())) return;
        if (district().canBuild(event.getPlayer(), event.getBlock().getLocation())) return;
        event.setCancelled(true);
        deny(event.getPlayer(), "use buckets outside your plot");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (!district().inDistrict(event.getBlock().getLocation())) return;
        if (district().canBuild(event.getPlayer(), event.getBlock().getLocation())) return;
        event.setCancelled(true);
        deny(event.getPlayer(), "use buckets outside your plot");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onSignChange(SignChangeEvent event) {
        if (!district().inDistrict(event.getBlock().getLocation())) return;
        if (district().canBuild(event.getPlayer(), event.getBlock().getLocation())) return;
        event.setCancelled(true);
        deny(event.getPlayer(), "edit signs outside your plot");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onHangingPlace(HangingPlaceEvent event) {
        if (!district().inDistrict(event.getEntity().getLocation())) return;
        if (district().canBuild(event.getPlayer(), event.getEntity().getLocation())) return;
        event.setCancelled(true);
        deny(event.getPlayer(), "place displays outside your plot");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onHangingBreak(HangingBreakEvent event) {
        if (!district().inDistrict(event.getEntity().getLocation())) return;
        if (event instanceof HangingBreakByEntityEvent byEntity && byEntity.getRemover() instanceof Player player
                && district().canBuild(player, event.getEntity().getLocation())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onVehicleDestroy(VehicleDestroyEvent event) {
        if (!(event.getAttacker() instanceof Player player)) return;
        if (!district().inDistrict(event.getVehicle().getLocation())) return;
        if (district().canBuild(player, event.getVehicle().getLocation())) return;
        event.setCancelled(true);
        deny(player, "break vehicles outside your plot");
    }

    private boolean inDistrict(org.bukkit.Location location) {
        return district().inDistrict(location);
    }

    private void deny(Player player, String action) {
        if (player == null || player.hasPermission("incogshop.shoppingdistrict.bypass")) return;
        player.sendMessage(plugin.prefix() + "§cYou cannot " + action + " in the Shopping District.");
    }
}

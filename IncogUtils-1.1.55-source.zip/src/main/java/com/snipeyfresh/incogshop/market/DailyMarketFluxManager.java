package com.snipeyfresh.incogshop.market;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Applies independently rolled buy and sell price modifiers for one Minecraft
 * day. The active draw is persisted so restarts never reroll the same day.
 */
public final class DailyMarketFluxManager {
    public record Modifiers(double buyMultiplier, double sellMultiplier) {
        public boolean hasBuyModifier() { return Math.abs(buyMultiplier - 1.0D) > 0.0001D; }
        public boolean hasSellModifier() { return Math.abs(sellMultiplier - 1.0D) > 0.0001D; }
    }

    private record Settings(boolean enabled, String worldName, int minimumItems, int maximumItems,
                            double buyChance, double sellChance, double minimumMultiplier,
                            double maximumMultiplier, double step, Set<Material> excluded) { }

    private static final String PATH = "market.daily-flux";
    private final IncogShopPlugin plugin;
    private final File stateFile;
    private Settings settings;
    private long activeDay = Long.MIN_VALUE;
    private String activeWorldId = "";
    private Map<Material, Modifiers> modifiers = Map.of();

    public DailyMarketFluxManager(IncogShopPlugin plugin) {
        this.plugin = plugin;
        this.stateFile = new File(plugin.getDataFolder(), "daily-market-flux.yml");
        this.settings = readSettings();
    }

    public void load() {
        settings = readSettings();
        activeDay = Long.MIN_VALUE;
        activeWorldId = "";
        EnumMap<Material, Modifiers> loaded = new EnumMap<>(Material.class);
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(stateFile);
        activeDay = yaml.getLong("day", Long.MIN_VALUE);
        activeWorldId = yaml.getString("world-id", "");
        var modifierSection = yaml.getConfigurationSection("modifiers");
        if (modifierSection != null) {
            for (String raw : modifierSection.getKeys(false)) {
                Material material = Material.matchMaterial(raw);
                if (material == null) continue;
                double buy = sanitizeMultiplier(yaml.getDouble("modifiers." + raw + ".buy", 1.0D));
                double sell = sanitizeMultiplier(yaml.getDouble("modifiers." + raw + ".sell", 1.0D));
                if (Math.abs(buy - 1.0D) > 0.0001D || Math.abs(sell - 1.0D) > 0.0001D) {
                    loaded.put(material, new Modifiers(buy, sell));
                }
            }
        }
        modifiers = Map.copyOf(loaded);
        refresh();
    }

    public void reload() { load(); }
    public void tick() { refresh(); }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("day", activeDay);
        yaml.set("world-id", activeWorldId);
        for (var entry : modifiers.entrySet()) {
            String key = "modifiers." + entry.getKey().name();
            yaml.set(key + ".buy", entry.getValue().buyMultiplier());
            yaml.set(key + ".sell", entry.getValue().sellMultiplier());
        }
        plugin.io().writeTextAtomic(stateFile.toPath(), yaml.saveToString(), "daily-market-flux.yml");
    }

    public boolean enabled() { return settings.enabled(); }
    public double buyMultiplier(Material material) { return modifier(material).buyMultiplier(); }
    public double sellMultiplier(Material material) { return modifier(material).sellMultiplier(); }
    public Modifiers modifier(Material material) { return modifiers.getOrDefault(material, new Modifiers(1.0D, 1.0D)); }
    public Map<Material, Modifiers> activeModifiers() { return modifiers; }

    private void refresh() {
        if (!settings.enabled()) {
            if (!modifiers.isEmpty()) {
                modifiers = Map.of();
                save();
            }
            return;
        }
        World world = resolveWorld();
        if (world == null) return;
        long day = Math.floorDiv(Math.max(0L, world.getFullTime()), 24_000L);
        String worldId = world.getUID().toString();
        if (day == activeDay && worldId.equals(activeWorldId)) return;
        roll(world, day);
    }

    private void roll(World world, long day) {
        List<Material> candidates = new ArrayList<>(plugin.market().tradableMaterials().stream()
                .filter(material -> !settings.excluded().contains(material))
                .filter(material -> plugin.market().isBuyAllowed(material) || plugin.market().isSellAllowed(material))
                .toList());
        Collections.shuffle(candidates, ThreadLocalRandom.current());

        int maximum = Math.min(settings.maximumItems(), candidates.size());
        int minimum = Math.min(settings.minimumItems(), maximum);
        int amount = maximum <= 0 ? 0 : ThreadLocalRandom.current().nextInt(minimum, maximum + 1);
        EnumMap<Material, Modifiers> next = new EnumMap<>(Material.class);
        for (Material material : candidates.subList(0, amount)) {
            boolean buyAllowed = plugin.market().isBuyAllowed(material);
            boolean sellAllowed = plugin.market().isSellAllowed(material);
            boolean buy = buyAllowed && rollChance(settings.buyChance());
            boolean sell = sellAllowed && rollChance(settings.sellChance());
            if (!buy && !sell) {
                if (buyAllowed && sellAllowed) buy = ThreadLocalRandom.current().nextBoolean();
                else buy = buyAllowed;
                sell = !buy && sellAllowed;
            }
            next.put(material, new Modifiers(buy ? randomMultiplier() : 1.0D, sell ? randomMultiplier() : 1.0D));
        }

        activeDay = day;
        activeWorldId = world.getUID().toString();
        modifiers = Map.copyOf(next);
        save();
        plugin.getLogger().info("Daily Market Flux rolled " + modifiers.size() + " item modifier(s) for Minecraft day "
                + day + " in " + world.getName() + ".");
    }

    private boolean rollChance(double percent) {
        return ThreadLocalRandom.current().nextDouble(100.0D) < percent;
    }

    private double randomMultiplier() {
        double raw = ThreadLocalRandom.current().nextDouble(settings.minimumMultiplier(), settings.maximumMultiplier() + settings.step());
        double rounded = Math.round(raw / settings.step()) * settings.step();
        return Math.max(settings.minimumMultiplier(), Math.min(settings.maximumMultiplier(), rounded));
    }

    private World resolveWorld() {
        if (!settings.worldName().isBlank()) return Bukkit.getWorld(settings.worldName());
        return Bukkit.getWorlds().stream().filter(world -> world.getEnvironment() == World.Environment.NORMAL).findFirst().orElse(null);
    }

    private Settings readSettings() {
        boolean enabled = plugin.getConfig().getBoolean(PATH + ".enabled", true);
        String worldName = plugin.getConfig().getString(PATH + ".world", "").trim();
        int minimum = clampInt(plugin.getConfig().getInt(PATH + ".minimum-items", 4), 0, 512);
        int maximum = clampInt(plugin.getConfig().getInt(PATH + ".maximum-items", 12), minimum, 512);
        double buyChance = clamp(plugin.getConfig().getDouble(PATH + ".buy-chance-percent", 50.0D), 0.0D, 100.0D);
        double sellChance = clamp(plugin.getConfig().getDouble(PATH + ".sell-chance-percent", 50.0D), 0.0D, 100.0D);
        double minimumMultiplier = clamp(plugin.getConfig().getDouble(PATH + ".minimum-multiplier", 0.80D), 0.01D, 100.0D);
        double maximumMultiplier = clamp(plugin.getConfig().getDouble(PATH + ".maximum-multiplier", 1.75D), minimumMultiplier, 100.0D);
        double step = clamp(plugin.getConfig().getDouble(PATH + ".multiplier-step", 0.01D), 0.001D, 1.0D);
        Set<Material> excluded = EnumSet.noneOf(Material.class);
        for (String raw : plugin.getConfig().getStringList(PATH + ".excluded-materials")) {
            Material material = Material.matchMaterial(raw == null ? "" : raw.toUpperCase(Locale.ROOT));
            if (material != null) excluded.add(material);
        }
        return new Settings(enabled, worldName, minimum, maximum, buyChance, sellChance,
                minimumMultiplier, maximumMultiplier, step, Set.copyOf(excluded));
    }

    private double sanitizeMultiplier(double multiplier) {
        return Double.isFinite(multiplier) && multiplier > 0.0D ? multiplier : 1.0D;
    }

    private static int clampInt(int value, int minimum, int maximum) { return Math.max(minimum, Math.min(maximum, value)); }
    private static double clamp(double value, double minimum, double maximum) { return Math.max(minimum, Math.min(maximum, value)); }
}

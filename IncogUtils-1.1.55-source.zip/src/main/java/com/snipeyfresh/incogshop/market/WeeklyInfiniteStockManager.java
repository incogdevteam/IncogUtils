package com.snipeyfresh.incogshop.market;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Runs the rank-limited weekly market event. A single three-item draw is made
 * shortly before the configured start: Cryptic can use the first item, Incog
 * the first two, and Incog+ all three by default. Administrators may fully
 * change the permissions and item counts in economy/config.yml.
 */
public final class WeeklyInfiniteStockManager {
    private static final String PATH = "market.weekly-infinite-stock";

    public record EventStatus(
            boolean enabled,
            boolean active,
            boolean selectionsRevealed,
            Instant eventStart,
            Instant eventEnd,
            Instant selectionAt,
            List<Material> playerItems,
            int itemLimit
    ) { }

    private record RankTier(String id, String permission, int itemCount, Set<String> luckPermsGroups) { }

    private record CachedGroups(long checkedAtMillis, Set<String> groups) { }

    private record Settings(
            boolean enabled,
            boolean displayEnabled,
            ZoneId zone,
            DayOfWeek day,
            LocalTime startTime,
            Duration duration,
            Duration selectionLead,
            List<RankTier> tiers,
            Set<Material> excludedMaterials
    ) {
        int maximumItemCount() {
            return tiers.stream().mapToInt(RankTier::itemCount).max().orElse(0);
        }
    }

    private record Window(
            Instant currentStart,
            Instant currentEnd,
            Instant nextStart,
            Instant nextSelectionAt,
            boolean active
    ) { }

    private final IncogShopPlugin plugin;
    private final File stateFile;
    private Settings settings;
    private long selectedForStartEpochMillis;
    private List<Material> selectedMaterials = List.of();
    private final Map<UUID, CachedGroups> groupCache = new HashMap<>();

    public WeeklyInfiniteStockManager(IncogShopPlugin plugin) {
        this.plugin = plugin;
        this.stateFile = new File(plugin.getDataFolder(), "weekly-infinite-stock.yml");
        this.settings = readSettings();
    }

    /** Loads both the configurable schedule and the persisted draw state. */
    public void load() {
        settings = readSettings();
        selectedForStartEpochMillis = 0L;
        selectedMaterials = List.of();

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(stateFile);
        selectedForStartEpochMillis = Math.max(0L, yml.getLong("selected-for-start-epoch-ms", 0L));
        List<Material> loaded = new ArrayList<>();
        for (String raw : yml.getStringList("selected-materials")) {
            Material material = Material.matchMaterial(raw);
            if (material != null && material.isItem()) loaded.add(material);
        }
        selectedMaterials = List.copyOf(loaded);
        refresh(Instant.now());
    }

    /** Re-reads the schedule after /reload without replacing a valid active draw. */
    public void reload() {
        load();
    }

    /** Called once per second on the server thread. */
    public void tick() {
        refresh(Instant.now());
    }

    /** Persists the selected set so a restart cannot reroll an active event. */
    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("selected-for-start-epoch-ms", selectedForStartEpochMillis);
        yml.set("selected-materials", selectedMaterials.stream().map(Material::name).toList());
        plugin.io().writeTextAtomic(stateFile.toPath(), yml.saveToString(), "weekly-infinite-stock.yml");
    }

    /** True only when this player is entitled to the selected material right now. */
    public boolean hasInfiniteStock(Player player, Material material) {
        if (player == null || material == null) return false;
        Instant now = Instant.now();
        refresh(now);
        if (!settings.enabled()) return false;

        Window window = window(now);
        if (!window.active() || selectedForStartEpochMillis != window.currentStart().toEpochMilli()) return false;

        int limit = itemLimit(player);
        return limit > 0 && selectedMaterials.subList(0, Math.min(limit, selectedMaterials.size())).contains(material);
    }

    /** Whether the player should receive the private event-status card in market GUIs. */
    public boolean shouldDisplayTo(Player player) {
        return player != null && settings.enabled() && settings.displayEnabled() && itemLimit(player) > 0;
    }

    /** Returns the number of event materials currently unlocked by permissions or configured LuckPerms groups. */
    public int itemLimitFor(Player player) {
        return itemLimit(player);
    }

    /** A rank-scoped display model used by every normal market menu. */
    public EventStatus statusFor(Player player) {
        Instant now = Instant.now();
        refresh(now);
        Window window = window(now);
        int limit = itemLimit(player);

        if (!settings.enabled()) {
            return new EventStatus(false, false, false, window.nextStart(),
                    window.nextStart().plus(settings.duration()), window.nextSelectionAt(), List.of(), limit);
        }

        Instant displayedStart = window.active() ? window.currentStart() : window.nextStart();
        Instant displayedEnd = displayedStart.plus(settings.duration());
        boolean revealed = selectedForStartEpochMillis == displayedStart.toEpochMilli();
        List<Material> entitled = !revealed || limit <= 0
                ? List.of()
                : List.copyOf(selectedMaterials.subList(0, Math.min(limit, selectedMaterials.size())));
        Instant selectionAt = window.active()
                ? window.nextStart().minus(settings.selectionLead())
                : window.nextSelectionAt();
        return new EventStatus(true, window.active(), revealed, displayedStart, displayedEnd,
                selectionAt, entitled, limit);
    }

    private void refresh(Instant now) {
        if (!settings.enabled()) {
            clearSelection();
            return;
        }

        Window window = window(now);
        if (window.active()) {
            if (selectedForStartEpochMillis != window.currentStart().toEpochMilli()) {
                selectFor(window.currentStart());
            }
            return;
        }

        if (!now.isBefore(window.nextSelectionAt())) {
            if (selectedForStartEpochMillis != window.nextStart().toEpochMilli()) {
                selectFor(window.nextStart());
            }
        } else if (selectedForStartEpochMillis != 0L) {
            // The prior event has ended and the suspense window has not yet begun.
            clearSelection();
        }
    }

    private void selectFor(Instant eventStart) {
        int count = settings.maximumItemCount();
        List<Material> candidates = new ArrayList<>(plugin.market().tradableMaterials().stream()
                .filter(plugin.market()::isBuyAllowed)
                .filter(material -> !settings.excludedMaterials().contains(material))
                .toList());
        Collections.shuffle(candidates, ThreadLocalRandom.current());

        selectedForStartEpochMillis = eventStart.toEpochMilli();
        selectedMaterials = List.copyOf(candidates.subList(0, Math.min(Math.max(0, count), candidates.size())));
        save();

        String selected = selectedMaterials.isEmpty()
                ? "no eligible materials"
                : String.join(", ", selectedMaterials.stream().map(Material::name).toList());
        plugin.market().audit("WEEKLY_INFINITE_STOCK_SELECT", null, "SYSTEM", "GLOBAL", selectedMaterials.size(), 0.0,
                "event-start=" + eventStart + ";items=" + selected);
        plugin.getLogger().info("Weekly Infinite Stock draw selected " + selectedMaterials.size()
                + " item(s) for " + eventStart + ": " + selected + ".");
    }

    private void clearSelection() {
        if (selectedForStartEpochMillis == 0L && selectedMaterials.isEmpty()) return;
        selectedForStartEpochMillis = 0L;
        selectedMaterials = List.of();
        save();
    }

    private Window window(Instant now) {
        ZonedDateTime localNow = now.atZone(settings.zone());
        LocalDate latestDate = localNow.toLocalDate().with(TemporalAdjusters.previousOrSame(settings.day()));
        ZonedDateTime latestStart = ZonedDateTime.of(latestDate, settings.startTime(), settings.zone());
        if (latestStart.toInstant().isAfter(now)) latestStart = latestStart.minusWeeks(1);

        Instant currentStart = latestStart.toInstant();
        Instant currentEnd = currentStart.plus(settings.duration());
        Instant nextStart = latestStart.plusWeeks(1).toInstant();
        Instant nextSelection = nextStart.minus(settings.selectionLead());
        boolean active = !now.isBefore(currentStart) && now.isBefore(currentEnd);
        return new Window(currentStart, currentEnd, nextStart, nextSelection, active);
    }

    private int itemLimit(Player player) {
        if (player == null) return 0;
        int limit = 0;
        for (RankTier tier : settings.tiers()) {
            if (matchesTier(player, tier)) limit = Math.max(limit, tier.itemCount());
        }
        return limit;
    }

    /**
     * Supports both the documented permission nodes and actual LuckPerms group
     * names. This prevents an eligible rank holder being excluded merely
     * because their group has not been given a duplicate permission node.
     */
    private boolean matchesTier(Player player, RankTier tier) {
        if (player.hasPermission(tier.permission())) return true;
        if (tier.luckPermsGroups().isEmpty() || !Bukkit.getPluginManager().isPluginEnabled("LuckPerms")) return false;
        Set<String> groups = luckPermsGroups(player);
        return tier.luckPermsGroups().stream().anyMatch(groups::contains);
    }

    private Set<String> luckPermsGroups(Player player) {
        long now = System.currentTimeMillis();
        CachedGroups cached = groupCache.get(player.getUniqueId());
        if (cached != null && now - cached.checkedAtMillis() < 5_000L) return cached.groups();

        Set<String> groups = new java.util.HashSet<>();
        try {
            User user = LuckPermsProvider.get().getPlayerAdapter(Player.class).getUser(player);
            for (InheritanceNode node : user.getNodes(NodeType.INHERITANCE)) {
                groups.add(node.getGroupName().toLowerCase(Locale.ROOT));
            }
        } catch (RuntimeException ignored) {
            // LuckPerms can be reloading while a menu is opened. Permission
            // checks above still work, and the next cache refresh retries.
        }
        Set<String> resolved = Set.copyOf(groups);
        groupCache.put(player.getUniqueId(), new CachedGroups(now, resolved));
        return resolved;
    }

    private Settings readSettings() {
        boolean enabled = plugin.getConfig().getBoolean(PATH + ".enabled", true);
        boolean displayEnabled = plugin.getConfig().getBoolean(PATH + ".display.enabled", true);
        ZoneId zone = parseZone(plugin.getConfig().getString(PATH + ".schedule.zone-id", "America/New_York"));
        DayOfWeek day = parseDay(plugin.getConfig().getString(PATH + ".schedule.day-of-week", "SUNDAY"));
        LocalTime start = parseTime(plugin.getConfig().getString(PATH + ".schedule.start-time", "20:00"));
        long minutes = clamp(plugin.getConfig().getLong(PATH + ".duration-minutes", 90L), 1L, 10_080L);
        long seconds = clamp(plugin.getConfig().getLong(PATH + ".selection-lead-seconds", 10L), 0L, 3_600L);

        List<RankTier> tiers = new ArrayList<>();
        ConfigurationSection rankSection = plugin.getConfig().getConfigurationSection(PATH + ".ranks");
        if (rankSection != null) {
            for (String id : rankSection.getKeys(false)) {
                String permission = rankSection.getString(id + ".permission", "").trim().toLowerCase(Locale.ROOT);
                int itemCount = (int) clamp(rankSection.getLong(id + ".item-count", 0L), 0L, 54L);
                Set<String> groups = new java.util.HashSet<>();
                for (String group : rankSection.getStringList(id + ".luckperms-groups")) {
                    if (group != null && !group.isBlank()) groups.add(group.trim().toLowerCase(Locale.ROOT));
                }
                if (!permission.isBlank() && itemCount > 0) tiers.add(new RankTier(id, permission, itemCount, Set.copyOf(groups)));
            }
        }
        if (tiers.isEmpty()) {
            // Older economy/config.yml files can contain an absent, empty, or
            // incomplete nested ranks section. Bukkit defaults do not reliably
            // materialize a usable ConfigurationSection in that case, so keep
            // the documented tiers available rather than silently treating
            // every rank as locked.
            tiers.add(new RankTier("cryptic", "incogshop.discount.cryptic", 1, Set.of("cryptic")));
            tiers.add(new RankTier("incog", "incogshop.discount.incog", 2, Set.of("incog")));
            tiers.add(new RankTier("incogplus", "incogshop.discount.incogplus", 3, Set.of("incogplus", "incog+")));
            plugin.getLogger().info("Weekly Infinite Stock is using the built-in rank defaults because market.weekly-infinite-stock.ranks has no usable tiers in economy/config.yml.");
        }
        tiers.sort((left, right) -> Integer.compare(right.itemCount(), left.itemCount()));

        Set<Material> excluded = EnumSet.noneOf(Material.class);
        for (String raw : plugin.getConfig().getStringList(PATH + ".excluded-materials")) {
            Material material = Material.matchMaterial(raw);
            if (material != null) excluded.add(material);
        }

        return new Settings(enabled, displayEnabled, zone, day, start, Duration.ofMinutes(minutes),
                Duration.ofSeconds(seconds), List.copyOf(tiers), Set.copyOf(excluded));
    }

    private ZoneId parseZone(String raw) {
        try {
            return ZoneId.of(raw == null || raw.isBlank() ? "America/New_York" : raw.trim());
        } catch (RuntimeException ignored) {
            getLoggerWarning("Invalid " + PATH + ".schedule.zone-id; using America/New_York.");
            return ZoneId.of("America/New_York");
        }
    }

    private DayOfWeek parseDay(String raw) {
        try {
            return DayOfWeek.valueOf(raw == null ? "SUNDAY" : raw.trim().toUpperCase(Locale.ROOT));
        } catch (RuntimeException ignored) {
            getLoggerWarning("Invalid " + PATH + ".schedule.day-of-week; using SUNDAY.");
            return DayOfWeek.SUNDAY;
        }
    }

    private LocalTime parseTime(String raw) {
        try {
            return LocalTime.parse(raw == null || raw.isBlank() ? "20:00" : raw.trim());
        } catch (RuntimeException ignored) {
            getLoggerWarning("Invalid " + PATH + ".schedule.start-time; using 20:00.");
            return LocalTime.of(20, 0);
        }
    }

    private void getLoggerWarning(String message) {
        plugin.getLogger().warning(message);
    }

    private static long clamp(long value, long minimum, long maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}

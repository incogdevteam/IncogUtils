package com.snipeyfresh.incogshop.platform;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Optional Bedrock-native text input bridge. Geyser/Floodgate classes are loaded only when
 * their APIs exist on the same backend, so IncogEcon still runs normally on Java-only servers.
 */
public final class BedrockInputManager {
    private final IncogShopPlugin plugin;
    private final List<BedrockInputProvider> providers = new ArrayList<>();

    public BedrockInputManager(IncogShopPlugin plugin) {
        this.plugin = plugin;
        tryLoad("org.geysermc.geyser.api.GeyserApi",
                "com.snipeyfresh.incogshop.platform.GeyserBedrockInputProvider");
        tryLoad("org.geysermc.floodgate.api.FloodgateApi",
                "com.snipeyfresh.incogshop.platform.FloodgateBedrockInputProvider");
    }

    private void tryLoad(String apiClass, String providerClass) {
        try {
            Class.forName(apiClass, false, getClass().getClassLoader());
            Object instance = Class.forName(providerClass, true, getClass().getClassLoader())
                    .getDeclaredConstructor().newInstance();
            providers.add((BedrockInputProvider) instance);
        } catch (Throwable ignored) {
            // This provider is optional. Another provider may still be usable.
        }
    }

    public boolean available() { return !providers.isEmpty(); }

    public String status() {
        if (providers.isEmpty()) return "unavailable";
        return providers.stream().map(BedrockInputProvider::name).distinct().reduce((a, b) -> a + ", " + b).orElse("available");
    }

    public boolean isBedrock(Player player) {
        if (player == null) return false;
        for (BedrockInputProvider provider : providers) {
            try {
                if (provider.isBedrock(player.getUniqueId())) return true;
            } catch (Throwable ignored) { }
        }
        return false;
    }

    /**
     * Opens a native Bedrock CustomForm for Bedrock players. Returns false for Java players,
     * allowing the caller to use its normal Java chat/sign fallback.
     */
    public boolean prompt(Player player, String title, String label, String placeholder, String defaultValue,
                          Consumer<String> onSubmit, Runnable onCancel) {
        if (player == null || !player.isOnline()) return false;

        BedrockInputProvider selected = null;
        for (BedrockInputProvider provider : providers) {
            try {
                if (provider.isBedrock(player.getUniqueId())) {
                    selected = provider;
                    break;
                }
            } catch (Throwable ignored) { }
        }
        if (selected == null) return false;

        BedrockInputProvider provider = selected;
        player.closeInventory();

        Consumer<String> mainSubmit = value -> plugin.getServer().getScheduler().runTaskLater(plugin.host(), () -> {
            if (player.isOnline()) onSubmit.accept(value == null ? "" : value);
        }, 1L);
        Runnable mainCancel = () -> plugin.getServer().getScheduler().runTaskLater(plugin.host(), () -> {
            if (player.isOnline()) onCancel.run();
        }, 1L);

        // Give Geyser a moment to finish translating the Java inventory close before the form opens.
        plugin.getServer().getScheduler().runTaskLater(plugin.host(), () -> {
            if (!player.isOnline()) return;
            boolean sent = provider.showTextInput(player.getUniqueId(), title, label, placeholder, defaultValue,
                    mainSubmit, mainCancel);
            if (!sent) {
                player.sendMessage(plugin.prefix() + "§cCould not open the Bedrock input form. Returning to the previous menu.");
                mainCancel.run();
            }
        }, 2L);
        return true;
    }
}

package com.snipeyfresh.incogshop.platform;

import java.util.UUID;
import java.util.function.Consumer;

interface BedrockInputProvider {
    String name();
    boolean isBedrock(UUID uuid);
    boolean showTextInput(UUID uuid, String title, String label, String placeholder, String defaultValue,
                          Consumer<String> onSubmit, Runnable onCancel);
}

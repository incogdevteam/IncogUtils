package com.snipeyfresh.incogshop.platform;

import org.geysermc.cumulus.form.CustomForm;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.UUID;
import java.util.function.Consumer;

final class FloodgateBedrockInputProvider implements BedrockInputProvider {
    @Override
    public String name() { return "Floodgate API"; }

    @Override
    public boolean isBedrock(UUID uuid) {
        try {
            FloodgateApi api = FloodgateApi.getInstance();
            return api != null && api.isFloodgatePlayer(uuid);
        } catch (Throwable ignored) {
            return false;
        }
    }

    @Override
    public boolean showTextInput(UUID uuid, String title, String label, String placeholder, String defaultValue,
                                 Consumer<String> onSubmit, Runnable onCancel) {
        try {
            FloodgateApi api = FloodgateApi.getInstance();
            if (api == null || !api.isFloodgatePlayer(uuid)) return false;

            var form = CustomForm.builder()
                    .title(title)
                    .input(label, placeholder, defaultValue == null ? "" : defaultValue)
                    .closedOrInvalidResultHandler(onCancel)
                    .validResultHandler(response -> {
                        Object value = response.next();
                        onSubmit.accept(value == null ? "" : String.valueOf(value));
                    });
            api.sendForm(uuid, form);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }
}

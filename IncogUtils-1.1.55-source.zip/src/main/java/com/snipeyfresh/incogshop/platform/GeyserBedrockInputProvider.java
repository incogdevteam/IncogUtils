package com.snipeyfresh.incogshop.platform;

import org.geysermc.cumulus.form.CustomForm;
import org.geysermc.geyser.api.GeyserApi;

import java.util.UUID;
import java.util.function.Consumer;

final class GeyserBedrockInputProvider implements BedrockInputProvider {
    @Override
    public String name() { return "Geyser API"; }

    @Override
    public boolean isBedrock(UUID uuid) {
        try {
            GeyserApi api = GeyserApi.api();
            return api != null && api.isBedrockPlayer(uuid);
        } catch (Throwable ignored) {
            return false;
        }
    }

    @Override
    public boolean showTextInput(UUID uuid, String title, String label, String placeholder, String defaultValue,
                                 Consumer<String> onSubmit, Runnable onCancel) {
        try {
            GeyserApi api = GeyserApi.api();
            if (api == null || !api.isBedrockPlayer(uuid)) return false;

            var form = CustomForm.builder()
                    .title(title)
                    .input(label, placeholder, defaultValue == null ? "" : defaultValue)
                    .closedOrInvalidResultHandler(onCancel)
                    .validResultHandler(response -> {
                        Object value = response.next();
                        onSubmit.accept(value == null ? "" : String.valueOf(value));
                    });
            api.sendForm(uuid, form);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }
}

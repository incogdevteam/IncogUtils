package com.snipeyfresh.incogshop.shop;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Non-interactive labels for player shops in the Shopping District. Bukkit's
 * entity-visibility API keeps each label entirely client-side for everyone
 * except the owner; this is intentionally not a shared/public hologram.
 */
public final class OwnerShopHologramManager {
    private final IncogShopPlugin plugin;
    private final NamespacedKey markerKey;
    private final Map<UUID, ArmorStand> labels = new HashMap<>();

    public OwnerShopHologramManager(IncogShopPlugin plugin) {
        this.plugin = plugin;
        this.markerKey = new NamespacedKey(plugin.host(), "owner_shop_hologram");
    }

    /** Rebuilds transient labels after startup or a configuration reload. */
    public void refresh() {
        clear();
        if (!enabled() || plugin.shops() == null) return;
        for (PlayerShop shop : plugin.shops().all()) create(shop);
    }

    public void create(PlayerShop shop) {
        if (!enabled() || shop == null || !eligible(shop)) return;
        remove(shop.id());
        Location location = shop.location().clone().add(0.5, yOffset(), 0.5);
        if (location.getWorld() == null) return;
        ArmorStand label = location.getWorld().spawn(location, ArmorStand.class, stand -> {
            stand.setInvisible(true);
            stand.setMarker(true);
            stand.setSmall(true);
            stand.setGravity(false);
            stand.setInvulnerable(true);
            stand.setSilent(true);
            stand.setCollidable(false);
            // The label must survive a Shopping District chunk unload. Stale
            // labels are tagged and cleared safely on module startup/reload.
            stand.setPersistent(true);
            stand.setCustomName(text());
            stand.setCustomNameVisible(true);
            stand.getPersistentDataContainer().set(markerKey, PersistentDataType.STRING, shop.id().toString());
        });
        labels.put(shop.id(), label);
        applyVisibility(label, shop.owner());
    }

    public void remove(UUID shopId) {
        ArmorStand label = labels.remove(shopId);
        if (label != null && label.isValid()) label.remove();
    }

    /** Applies the private visibility rule to a player after they join. */
    public void refreshViewer(Player player) {
        if (player == null) return;
        for (Map.Entry<UUID, ArmorStand> entry : labels.entrySet()) {
            ArmorStand label = entry.getValue();
            PlayerShop shop = plugin.shops() == null ? null : plugin.shops().byId(entry.getKey());
            if (label == null || !label.isValid() || shop == null) continue;
            if (shop.owner().equals(player.getUniqueId())) player.showEntity(plugin.host(), label);
            else player.hideEntity(plugin.host(), label);
        }
    }

    /** Removes all labels created by this manager, including remnants of a prior crash. */
    public void clear() {
        labels.values().forEach(label -> { if (label != null && label.isValid()) label.remove(); });
        labels.clear();
        Bukkit.getWorlds().forEach(world -> world.getEntitiesByClass(ArmorStand.class).forEach(stand -> {
            if (stand.getPersistentDataContainer().has(markerKey, PersistentDataType.STRING)) stand.remove();
        }));
    }

    private boolean eligible(PlayerShop shop) {
        return plugin.shoppingDistrict() != null
                && plugin.shoppingDistrict().plotAt(shop.location())
                .map(plot -> plot.owner().equals(shop.owner()))
                .orElse(false);
    }

    private void applyVisibility(ArmorStand label, UUID owner) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (owner.equals(viewer.getUniqueId())) viewer.showEntity(plugin.host(), label);
            else viewer.hideEntity(plugin.host(), label);
        }
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("shopping-district.owner-shop-holograms.enabled", true);
    }

    private double yOffset() {
        return Math.max(0.0, Math.min(16.0,
                plugin.getConfig().getDouble("shopping-district.owner-shop-holograms.y-offset", 1.55)));
    }

    private String text() {
        String configured = plugin.getConfig().getString("shopping-district.owner-shop-holograms.text", "&aYour Shop");
        return ChatColor.translateAlternateColorCodes('&', configured == null ? "Your Shop" : configured);
    }
}

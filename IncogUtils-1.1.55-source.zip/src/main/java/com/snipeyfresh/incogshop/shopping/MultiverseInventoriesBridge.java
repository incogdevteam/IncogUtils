package com.snipeyfresh.incogshop.shopping;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Safely joins the Shopping District to an existing Multiverse-Inventories group. */
public final class MultiverseInventoriesBridge {
    private static final String PLUGIN_NAME = "Multiverse-Inventories";
    private final IncogShopPlugin plugin;

    public MultiverseInventoriesBridge(IncogShopPlugin plugin) {
        this.plugin = plugin;
    }

    public void scheduleSync() {
        if (!plugin.getConfig().getBoolean("shopping-district.inventory-sharing.enabled", true)) return;
        long delay = Math.max(1L, Math.min(1200L,
                plugin.getConfig().getLong("shopping-district.inventory-sharing.setup-delay-ticks", 20L)));
        Bukkit.getScheduler().runTaskLater(plugin.host(), this::sync, delay);
    }

    public void sync() {
        if (plugin.shoppingDistrict() == null || !plugin.shoppingDistrict().enabled()) return;
        if (!plugin.getConfig().getBoolean("shopping-district.inventory-sharing.enabled", true)) return;

        Plugin inventories = Bukkit.getPluginManager().getPlugin(PLUGIN_NAME);
        if (inventories == null || !inventories.isEnabled()) {
            plugin.getLogger().warning("Shopping District inventory sharing is enabled, but Multiverse-Inventories is not loaded.");
            return;
        }

        String sourceWorld = safeToken(plugin.getConfig().getString(
                "shopping-district.inventory-sharing.source-world", "world"));
        String districtWorld = safeToken(plugin.shoppingDistrict().settings().worldName());
        String configuredGroup = plugin.getConfig().getString(
                "shopping-district.inventory-sharing.group", "auto");
        if (sourceWorld == null || districtWorld == null) {
            plugin.getLogger().warning("Shopping District inventory sharing has an invalid source or district world name.");
            return;
        }

        File groupsFile = new File(inventories.getDataFolder(), "groups.yml");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(groupsFile);
        ConfigurationSection groups = yaml.getConfigurationSection("groups");
        String group = resolveGroup(groups, configuredGroup, sourceWorld);
        if (group == null) {
            maybeCreateGroup(configuredGroup, sourceWorld, districtWorld);
            return;
        }

        ConfigurationSection selectedGroup = sectionFor(groups, group);
        if (selectedGroup == null) {
            plugin.getLogger().warning("Multiverse-Inventories group '" + group + "' disappeared before it could be updated.");
            return;
        }
        List<String> worlds = selectedGroup.getStringList("worlds");
        if (!containsIgnoreCase(worlds, sourceWorld)) {
            plugin.getLogger().warning("Multiverse-Inventories group '" + group + "' does not contain source world '"
                    + sourceWorld + "'. No group was changed; select the group that already owns the Overworld.");
            return;
        }

        boolean changed = false;
        if (!containsIgnoreCase(worlds, districtWorld)) {
            changed |= dispatch("mvinv add-worlds " + group + " " + districtWorld);
        }

        List<String> requestedShares = requestedShares();
        List<String> existingShares = selectedGroup.getStringList("shares");
        if (!containsIgnoreCase(existingShares, "all") && !containsIgnoreCase(existingShares, "*")) {
            List<String> missing = requestedShares.stream()
                    .filter(share -> !containsIgnoreCase(existingShares, share))
                    .toList();
            if (!missing.isEmpty()) changed |= dispatch("mvinv add-shares " + group + " " + String.join(",", missing));
        }

        if (changed) {
            plugin.getLogger().info("Added Shopping District world '" + districtWorld
                    + "' to Multiverse-Inventories group '" + group + "' with shares " + requestedShares + ".");
        } else {
            plugin.getLogger().info("Shopping District already shares Overworld inventories through Multiverse-Inventories group '"
                    + group + "'.");
        }
    }

    private String resolveGroup(ConfigurationSection groups, String configured, String sourceWorld) {
        if (groups == null) return null;
        String requested = configured == null ? "auto" : configured.trim();
        if (!requested.equalsIgnoreCase("auto")) {
            return groups.getKeys(false).stream().filter(key -> key.equalsIgnoreCase(requested)).findFirst().orElse(null);
        }

        List<String> candidates = groups.getKeys(false).stream()
                .filter(group -> containsIgnoreCase(values(groups, group, "worlds"), sourceWorld))
                .toList();
        if (candidates.size() == 1) return candidates.get(0);
        List<String> inventoryCandidates = candidates.stream()
                .filter(group -> sharesInventory(values(groups, group, "shares")))
                .toList();
        if (inventoryCandidates.size() == 1) return inventoryCandidates.get(0);
        if (candidates.size() > 1) {
            plugin.getLogger().warning("More than one Multiverse-Inventories group contains source world '" + sourceWorld
                    + "': " + candidates + ". Set shopping-district.inventory-sharing.group explicitly.");
        }
        return null;
    }

    private void maybeCreateGroup(String configured, String sourceWorld, String districtWorld) {
        if (!plugin.getConfig().getBoolean("shopping-district.inventory-sharing.create-group-if-missing", false)) {
            plugin.getLogger().warning("No unambiguous Multiverse-Inventories group contains source world '" + sourceWorld
                    + "'. Set shopping-district.inventory-sharing.group to its existing group. IncogUtils did not create "
                    + "a new group because doing so can replace established player inventory data.");
            return;
        }
        String requested = configured == null || configured.equalsIgnoreCase("auto") ? "incog_survival" : configured;
        String group = safeToken(requested);
        if (group == null) {
            plugin.getLogger().warning("Cannot create the configured Multiverse-Inventories group because its name is invalid.");
            return;
        }
        if (dispatch("mvinv create-group " + group + " " + sourceWorld + "," + districtWorld
                + " " + String.join(",", requestedShares()))) {
            plugin.getLogger().warning("Created Multiverse-Inventories group '" + group + "'. If '" + sourceWorld
                    + "' previously stored ungrouped inventory data, follow MVI's profile migration procedure before players enter the district.");
        }
    }

    private List<String> requestedShares() {
        Set<String> shares = new LinkedHashSet<>();
        for (String raw : plugin.getConfig().getStringList("shopping-district.inventory-sharing.shares")) {
            String share = safeShare(raw);
            if (share != null) shares.add(share);
        }
        if (shares.isEmpty()) shares.add("inventory");
        return new ArrayList<>(shares);
    }

    private boolean dispatch(String command) {
        boolean accepted = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
        if (!accepted) plugin.getLogger().warning("Multiverse-Inventories rejected command: /" + command);
        return accepted;
    }

    private static boolean sharesInventory(List<String> shares) {
        return containsIgnoreCase(shares, "all") || containsIgnoreCase(shares, "*")
                || containsIgnoreCase(shares, "inventory") || containsIgnoreCase(shares, "inv")
                || (containsIgnoreCase(shares, "inventory_contents")
                && containsIgnoreCase(shares, "armor_contents")
                && containsIgnoreCase(shares, "off_hand"));
    }

    private static boolean containsIgnoreCase(List<String> values, String expected) {
        return values.stream().anyMatch(value -> value.equalsIgnoreCase(expected));
    }

    private static List<String> values(ConfigurationSection groups, String group, String key) {
        ConfigurationSection section = sectionFor(groups, group);
        return section == null ? List.of() : section.getStringList(key);
    }

    /**
     * Reads an immediate child without interpreting dots inside an MVI group
     * name as Bukkit configuration-path separators.
     */
    private static ConfigurationSection sectionFor(ConfigurationSection parent, String key) {
        if (parent == null) return null;
        Object value = parent.getValues(false).get(key);
        return value instanceof ConfigurationSection section ? section : null;
    }

    private static String safeToken(String raw) {
        if (raw == null) return null;
        String value = raw.trim();
        return value.matches("[A-Za-z0-9_.+-]+") ? value : null;
    }

    private static String safeShare(String raw) {
        if (raw == null) return null;
        String value = raw.trim().toLowerCase(Locale.ROOT);
        return value.matches("[a-z0-9_-]+") ? value : null;
    }
}

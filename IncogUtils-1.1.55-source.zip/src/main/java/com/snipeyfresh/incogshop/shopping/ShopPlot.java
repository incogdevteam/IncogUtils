package com.snipeyfresh.incogshop.shopping;

import java.util.UUID;

/** Persistent owner and geometry information for one district plot. */
public final class ShopPlot {
    private final UUID id;
    private final UUID owner;
    private String ownerName;
    private final int gridX;
    private final int gridZ;
    private int size;
    private int expansions;
    private String layout;
    private String displayName;
    private final long createdAt;

    public ShopPlot(UUID id, UUID owner, String ownerName, int gridX, int gridZ,
                    int size, int expansions, long createdAt) {
        this(id, owner, ownerName, gridX, gridZ, size, expansions, createdAt, "flat", null);
    }
    public ShopPlot(UUID id, UUID owner, String ownerName, int gridX, int gridZ,
                    int size, int expansions, long createdAt, String layout) {
        this(id, owner, ownerName, gridX, gridZ, size, expansions, createdAt, layout, null);
    }
    public ShopPlot(UUID id, UUID owner, String ownerName, int gridX, int gridZ,
                    int size, int expansions, long createdAt, String layout, String displayName) {
        this.id = id;
        this.owner = owner;
        this.ownerName = ownerName == null || ownerName.isBlank() ? "Unknown" : ownerName;
        this.gridX = gridX;
        this.gridZ = gridZ;
        this.size = size;
        this.expansions = Math.max(0, expansions);
        this.createdAt = createdAt;
        this.layout = layout == null || layout.isBlank() ? "flat" : layout.toLowerCase();
        this.displayName = displayName == null || displayName.isBlank()
                ? "Plot " + gridX + ", " + gridZ : displayName.trim();
    }

    public UUID id() { return id; }
    public UUID owner() { return owner; }
    public String ownerName() { return ownerName; }
    public void ownerName(String value) { if (value != null && !value.isBlank()) ownerName = value; }
    public int gridX() { return gridX; }
    public int gridZ() { return gridZ; }
    public int size() { return size; }
    public void size(int value) { size = value; }
    public int expansions() { return expansions; }
    public void expansions(int value) { expansions = Math.max(0, value); }
    public long createdAt() { return createdAt; }
    public String layout() { return layout; }
    public void layout(String value) { if (value != null && !value.isBlank()) layout = value.toLowerCase(); }
    public String displayName() { return displayName; }
    public void displayName(String value) { if (value != null && !value.isBlank()) displayName = value.trim(); }
}

package com.snipeyfresh.incogshop.shopping;

import org.bukkit.World;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

import java.util.Random;

/**
 * Keeps the district world empty. The manager materializes only the public hub
 * and plots that have actually been allocated, avoiding an ever-growing road
 * grid of generated chunks on disk.
 */
public final class ShoppingDistrictGenerator extends ChunkGenerator {
    private final ShoppingDistrictSettings settings;

    public ShoppingDistrictGenerator(ShoppingDistrictSettings settings) {
        this.settings = settings;
    }

    @Override
    public ChunkData generateChunkData(World world, Random random, int chunkX, int chunkZ, BiomeGrid biome) {
        return createChunkData(world);
    }

    @Override
    public boolean shouldGenerateNoise() {
        return false;
    }

    @Override
    public boolean shouldGenerateSurface() {
        return false;
    }

    @Override
    public boolean shouldGenerateCaves() {
        return false;
    }

    @Override
    public boolean shouldGenerateDecorations() {
        return false;
    }

    @Override
    public boolean shouldGenerateMobs() {
        return false;
    }

    @Override
    public boolean shouldGenerateStructures() {
        return false;
    }

    @Override
    public BiomeProvider getDefaultBiomeProvider(WorldInfo worldInfo) {
        return null;
    }

    static int nearestGrid(int coordinate, int cellSize) {
        return (int) Math.floor((coordinate + cellSize / 2.0) / cellSize);
    }
}

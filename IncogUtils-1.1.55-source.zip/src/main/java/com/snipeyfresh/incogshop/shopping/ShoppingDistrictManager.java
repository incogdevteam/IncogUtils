package com.snipeyfresh.incogshop.shopping;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import com.snipeyfresh.incogshop.economy.WalletManager;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.Locale;

/**
 * Owns the separate shopping-district world, persistent plot allocation, plot
 * expansion and plot-purchase economy. Physical storefronts continue to use
 * the existing /pshop container system and are protected by the district
 * listener when placed inside an owned plot.
 */
public final class ShoppingDistrictManager {
    public record PlotResult(boolean success, String message, ShopPlot plot, double cost) {}
    public record GridKey(int x, int z) {}
    private record ArrivalColumn(int x, int z) {}
    private record SurfaceBounds(int minX, int maxX, int minZ, int maxZ) {
        boolean contains(int x, int z) {
            return x >= minX && x <= maxX && z >= minZ && z <= maxZ;
        }
    }

    private final IncogShopPlugin plugin;
    private final File file;
    private final Map<UUID, List<ShopPlot>> byOwner = new LinkedHashMap<>();
    private final Map<GridKey, ShopPlot> byGrid = new HashMap<>();
    private final Map<UUID, Long> teleportCooldowns = new HashMap<>();
    private World world;
    private ShoppingDistrictSettings settings;
    private boolean active;
    private boolean outerBorderInitialized;
    private SurfaceBounds materializedSurfaceBounds;

    public ShoppingDistrictManager(IncogShopPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shopping-district.yml");
    }

    public void enable() {
        settings = ShoppingDistrictSettings.from(plugin);
        load();
        active = settings.enabled();
        if (!active) {
            plugin.getLogger().info("Shopping District is disabled in the economy configuration.");
            return;
        }
        ensureWorld();
        plugin.getLogger().info("Shopping District ready in world " + settings.worldName()
                + " with " + byGrid.size() + " allocated plot(s).");
    }

    public void disable() {
        save();
        if (settings != null && settings.unloadWorldOnDisable() && world != null
                && Bukkit.getWorld(world.getUID()) != null) {
            Bukkit.unloadWorld(world, true);
        }
        world = null;
        active = false;
        outerBorderInitialized = false;
    }

    public void reload() {
        save();
        settings = ShoppingDistrictSettings.from(plugin);
        load();
        active = settings.enabled();
        if (active) ensureWorld();
    }

    public boolean enabled() { return active && settings != null && world != null; }
    public World world() { return world; }
    public ShoppingDistrictSettings settings() { return settings; }

    /**
     * The height at which a player who has fallen through the district void is
     * returned to the hub. This deliberately does not restrict normal flight
     * or teleporting between the hub and lazy-generated shop islands.
     */
    public int voidRescueY() {
        return settings == null ? Integer.MIN_VALUE : settings.floorY() - settings.voidRescueBelowFloor();
    }

    public Collection<ShopPlot> all() {
        List<ShopPlot> result = new ArrayList<>();
        byOwner.values().forEach(result::addAll);
        return List.copyOf(result);
    }

    public List<ShopPlot> plots(UUID owner) {
        return byOwner.getOrDefault(owner, List.of()).stream()
                .sorted(Comparator.comparingLong(ShopPlot::createdAt))
                .toList();
    }

    /** Resolves a player's plot by its 1-based list number or its saved display name. */
    public Optional<ShopPlot> resolveOwnedPlot(UUID owner, String selector) {
        List<ShopPlot> owned = plots(owner);
        if (owned.isEmpty()) return Optional.empty();
        String value = selector == null ? "" : selector.trim();
        if (value.isBlank()) return Optional.of(owned.get(0));
        try {
            int index = Integer.parseInt(value);
            if (index >= 1 && index <= owned.size()) return Optional.of(owned.get(index - 1));
        } catch (NumberFormatException ignored) {
            // A non-number is a plot name.
        }
        return owned.stream().filter(plot -> plot.displayName().equalsIgnoreCase(value)).findFirst();
    }

    public Optional<ShopPlot> primary(UUID owner) {
        return plots(owner).stream().findFirst();
    }

    /** Renames an owned plot. Names are deliberately plain text to keep command lookup unambiguous. */
    public PlotResult renamePlot(Player player, ShopPlot plot, String requestedName) {
        if (player == null || plot == null) return new PlotResult(false, "That plot does not exist.", plot, 0);
        if (!plot.owner().equals(player.getUniqueId())) return new PlotResult(false, "You do not own that plot.", plot, 0);
        String name = normalizePlotName(requestedName);
        if (name == null) {
            return new PlotResult(false, "Plot names must be 1-32 letters, numbers, spaces, apostrophes, underscores, or hyphens, and cannot be only a number.", plot, 0);
        }
        boolean duplicate = plots(plot.owner()).stream()
                .anyMatch(other -> !other.id().equals(plot.id()) && other.displayName().equalsIgnoreCase(name));
        if (duplicate) return new PlotResult(false, "You already have a plot named '" + name + "'.", plot, 0);
        plot.displayName(name);
        save();
        plugin.market().audit("SHOPPING_DISTRICT_PLOT_RENAME", player.getUniqueId(), player.getName(), plot.id().toString(),
                0, 0, "name=" + name);
        return new PlotResult(true, "Renamed plot " + shortId(plot) + " to '" + name + "'.", plot, 0);
    }

    public Optional<ShopPlot> find(UUID id) {
        return byGrid.values().stream().filter(plot -> plot.id().equals(id)).findFirst();
    }

    /** Ensures a first plot exists for a player, normally called on join. */
    public PlotResult ensureStarterPlot(Player player) {
        if (!enabled()) return new PlotResult(false, "The Shopping District is disabled.", null, 0);
        List<ShopPlot> owned = byOwner.computeIfAbsent(player.getUniqueId(), ignored -> new ArrayList<>());
        owned.forEach(plot -> plot.ownerName(player.getName()));
        if (!owned.isEmpty()) {
            saveIfNameChanged(owned);
            return new PlotResult(true, "Your Shopping District plot is ready.", owned.get(0), 0);
        }
        if (!settings.autoAssignOnFirstJoin()) {
            return new PlotResult(false, "New-player plot assignment is disabled. Use /shopdistrict buy.", null, 0);
        }
        PlotResult result = allocate(player, false, settings.firstTemplate());
        if (result.success()) save();
        return result;
    }

    /** Purchases an additional plot at the next escalating price tier. */
    public PlotResult buyPlot(Player player, String requestedLayout) {
        if (!enabled()) return new PlotResult(false, "The Shopping District is disabled.", null, 0);
        List<ShopPlot> owned = byOwner.computeIfAbsent(player.getUniqueId(), ignored -> new ArrayList<>());
        if (owned.size() >= settings.maxPlotsPerPlayer()
                && !player.hasPermission("incogshop.shoppingdistrict.bypass")) {
            return new PlotResult(false, "You have reached the maximum of " + settings.maxPlotsPerPlayer() + " plots.", null, 0);
        }
        GridKey grid = findFreeGrid();
        if (grid == null) return new PlotResult(false, "No free district plots are available right now.", null, 0);
        double cost = plotPrice(owned.size());
        if (!free(player) && !plugin.wallets().withdraw(player.getUniqueId(), cost)) {
            return new PlotResult(false, "You need " + plugin.money(cost) + " to buy your next plot.", null, cost);
        }
        String layout = settings.template(requestedLayout).id();
        ShopPlot plot = new ShopPlot(UUID.randomUUID(), player.getUniqueId(), player.getName(), grid.x(), grid.z(),
                settings.starterPlotSize(), 0, System.currentTimeMillis(), layout, "Plot " + (owned.size() + 1));
        register(plot);
        materializePlotIsland(plot, 0);
        materializeConnectedRoads();
        buildTemplate(plot);
        save();
        plugin.market().audit("SHOPPING_DISTRICT_PLOT_BUY", player.getUniqueId(), player.getName(), plot.id().toString(),
                0, cost, "grid=" + grid.x() + "," + grid.z());
        return new PlotResult(true, "Purchased plot " + shortId(plot) + " for " + plugin.money(cost) + ".", plot, cost);
    }
    public PlotResult buyPlot(Player player) { return buyPlot(player, "flat"); }

    public PlotResult sellPlot(Player actor, ShopPlot plot, boolean force) {
        if (!enabled() || plot == null) return new PlotResult(false, "That plot does not exist.", null, 0);
        if (!force && !plot.owner().equals(actor.getUniqueId())) return new PlotResult(false, "You do not own that plot.", plot, 0);
        double original = plotPrice(1) + expansionPrice(0, plot.expansions());
        double refund = WalletManager.round(original * settings.plotSaleRefundPercent() / 100.0);
        // Do not release the cell or pay the refund unless resetting succeeds.
        // This prevents a half-reset plot from being immediately allocated to a
        // new owner if the world reports an unexpected block-edit failure.
        if (settings.resetOnSale()) {
            try {
                resetPlotToFlat(plot);
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Could not reset sold Shopping District plot " + shortId(plot)
                        + "; sale was cancelled: " + ex.getClass().getSimpleName() + ": " + ex.getMessage());
                return new PlotResult(false, "The plot could not be reset safely; it was not sold.", plot, 0);
            }
        }
        List<ShopPlot> owned = byOwner.get(plot.owner());
        if (owned != null) { owned.remove(plot); if (owned.isEmpty()) byOwner.remove(plot.owner()); }
        byGrid.remove(new GridKey(plot.gridX(), plot.gridZ()));
        materializeConnectedRoads();
        updateOuterWorldBorder(false);
        // The reset removes the old shop container and any attached label.
        // Re-evaluate labels after ownership is released so no old owner can
        // retain a private marker in a plot they no longer own.
        if (plugin.ownerShopHolograms() != null) plugin.ownerShopHolograms().refresh();
        plugin.wallets().deposit(plot.owner(), refund);
        save();
        plugin.market().audit("SHOPPING_DISTRICT_PLOT_SELL", actor.getUniqueId(), actor.getName(), plot.id().toString(), 0, refund,
                "owner=" + plot.owner() + ",forced=" + force);
        return new PlotResult(true, "Sold plot " + shortId(plot) + " for " + plugin.money(refund) + ".", plot, refund);
    }

    /** Clears a sold island back to void so unallocated grid cells need no terrain. */
    private void resetPlotToFlat(ShopPlot plot) {
        if (world == null) return;
        int centerX = plot.gridX() * settings.cellSize(), centerZ = plot.gridZ() * settings.cellSize();
        int half = plot.size() / 2;
        int minX = centerX - half - 1, minZ = centerZ - half - 1;
        int maxX = minX + plot.size() + 2, maxZ = minZ + plot.size() + 2;
        int floorY = settings.floorY();
        int ceilingY = settings.saleResetHeight() <= 0 ? world.getMaxHeight() - 1
                : (int) Math.min(world.getMaxHeight() - 1L, (long) floorY + settings.saleResetHeight());

        BoundingBox bounds = new BoundingBox(minX, world.getMinHeight(), minZ, maxX, world.getMaxHeight(), maxZ);
        for (Entity entity : world.getNearbyEntities(bounds)) if (!(entity instanceof Player)) entity.remove();

        // Clear the complete vertical column, including the invisible safety
        // wall. A subsequent allocation creates a fresh floor and barrier.
        for (int x = minX; x < maxX; x++) for (int z = minZ; z < maxZ; z++) {
            for (int y = world.getMinHeight(); y <= ceilingY; y++) {
                org.bukkit.block.Block block = world.getBlockAt(x, y, z);
                if (!block.getType().isAir()) block.setType(org.bukkit.Material.AIR, false);
            }
        }
    }

    /** Expands the selected plot by the configured step or to an explicit size. */
    public PlotResult expand(Player player, Integer requestedSize) {
        if (!enabled()) return new PlotResult(false, "The Shopping District is disabled.", null, 0);
        return expand(player, plotForAction(player).orElse(null), requestedSize);
    }

    /** Expands one explicitly selected owned plot. */
    public PlotResult expand(Player player, ShopPlot plot, Integer requestedSize) {
        if (!enabled()) return new PlotResult(false, "The Shopping District is disabled.", null, 0);
        if (plot == null) return new PlotResult(false, "You do not have a Shopping District plot yet. Use /shopdistrict buy.", null, 0);
        if (player == null || !plot.owner().equals(player.getUniqueId())) return new PlotResult(false, "You do not own that plot.", plot, 0);
        int current = plot.size();
        int target = requestedSize == null ? current + settings.expansionStep() : requestedSize;
        if (target <= current) return new PlotResult(false, "The new size must be larger than " + current + "x" + current + ".", plot, 0);
        int purchaseLimit = purchasableMaxSize(player);
        if (target > purchaseLimit) {
            if (purchaseLimit < settings.maxPlotSize()) {
                return new PlotResult(false, "Your rank currently allows paid expansions up to " + purchaseLimit + "x" + purchaseLimit
                        + ". A higher Shopping District rank tier is required for " + target + "x" + target + ".", plot, 0);
            }
            return new PlotResult(false, "Plots can be expanded only up to " + settings.maxPlotSize() + "x" + settings.maxPlotSize() + ".", plot, 0);
        }

        int steps = (int) Math.ceil((target - current) / (double) settings.expansionStep());
        double cost = expansionPrice(plot.expansions(), steps);
        if (!free(player) && !plugin.wallets().withdraw(player.getUniqueId(), cost)) {
            return new PlotResult(false, "You need " + plugin.money(cost) + " to expand this plot.", plot, cost);
        }
        materializePlotIsland(plot, current, target);
        plot.size(target);
        plot.expansions(plot.expansions() + steps);
        materializeConnectedRoads();
        save();
        plugin.market().audit("SHOPPING_DISTRICT_PLOT_EXPAND", player.getUniqueId(), player.getName(), plot.id().toString(),
                steps, cost, "size=" + target);
        return new PlotResult(true, "Expanded plot " + shortId(plot) + " to " + target + "x" + target
                + " for " + plugin.money(cost) + ".", plot, cost);
    }

    /** Returns the largest plot size this player may purchase; it never grants a free expansion. */
    public int purchasableMaxSize(Player player) {
        if (player != null && player.hasPermission("incogshop.shoppingdistrict.bypass")) return settings.maxPlotSize();
        int limit = settings.baseMaxPlotSize();
        for (ShoppingDistrictSettings.ExpansionTier tier : settings.rankExpansionTiers()) {
            if (matchesExpansionTier(player, tier)) limit = Math.max(limit, tier.maximumSize());
        }
        return Math.min(limit, settings.maxPlotSize());
    }

    private boolean matchesExpansionTier(Player player, ShoppingDistrictSettings.ExpansionTier tier) {
        if (player == null || tier == null) return false;
        if (!tier.permission().isBlank() && player.hasPermission(tier.permission())) return true;
        if (tier.luckPermsGroups().isEmpty() || !Bukkit.getPluginManager().isPluginEnabled("LuckPerms")) return false;
        try {
            User user = LuckPermsProvider.get().getPlayerAdapter(Player.class).getUser(player);
            for (InheritanceNode node : user.getNodes(NodeType.INHERITANCE)) {
                if (tier.luckPermsGroups().contains(node.getGroupName().toLowerCase(Locale.ROOT))) return true;
            }
        } catch (RuntimeException ignored) {
            // LuckPerms may be reloading. The normal Bukkit permission check
            // above remains available, and the next purchase attempt retries.
        }
        return false;
    }

    /** Creates an allocated plot surface; connected roads are generated separately. */
    private void materializePlotIsland(ShopPlot plot, int previousSize) {
        materializePlotIsland(plot, previousSize, plot.size());
    }

    private void materializePlotIsland(ShopPlot plot, int previousSize, int targetSize) {
        if (world == null || plot == null || targetSize <= 0) return;
        if (previousSize > 0) clearLegacyPlotBarrier(plot, previousSize);
        int centerX = plot.gridX() * settings.cellSize();
        int centerZ = plot.gridZ() * settings.cellSize();
        int half = targetSize / 2;
        int minX = centerX - half;
        int minZ = centerZ - half;
        int floorY = settings.floorY();
        for (int x = minX; x < minX + targetSize; x++) for (int z = minZ; z < minZ + targetSize; z++) {
            if (previousSize > 0 && insideSquare(x, z, centerX, centerZ, previousSize)) continue;
            world.getBlockAt(x, floorY - 2, z).setType(settings.foundationMaterial(), false);
            world.getBlockAt(x, floorY - 1, z).setType(settings.foundationMaterial(), false);
            world.getBlockAt(x, floorY, z).setType(settings.plotFloorMaterial(), false);
            clearOuterSafetyBarrierAt(x, z);
        }
        clearLegacyPlotBarrier(plot, targetSize);
    }

    /** Reinstates missing terrain for an existing plot without overwriting its build or template. */
    private void preserveExistingPlotIsland(ShopPlot plot) {
        if (world == null || plot == null) return;
        int centerX = plot.gridX() * settings.cellSize();
        int centerZ = plot.gridZ() * settings.cellSize();
        int size = plot.size();
        int half = size / 2;
        int minX = centerX - half;
        int minZ = centerZ - half;
        int floorY = settings.floorY();
        for (int x = minX; x < minX + size; x++) for (int z = minZ; z < minZ + size; z++) {
            Block lowestFoundation = world.getBlockAt(x, floorY - 2, z);
            Block upperFoundation = world.getBlockAt(x, floorY - 1, z);
            Block floor = world.getBlockAt(x, floorY, z);
            if (lowestFoundation.getType().isAir()) lowestFoundation.setType(settings.foundationMaterial(), false);
            if (upperFoundation.getType().isAir()) upperFoundation.setType(settings.foundationMaterial(), false);
            if (floor.getType().isAir()) floor.setType(settings.plotFloorMaterial(), false);
            clearOuterSafetyBarrierAt(x, z);
        }
        clearLegacyPlotBarrier(plot, size);
    }

    /** Removes the per-plot barriers from the previous layout migration. */
    private void clearLegacyPlotBarrier(ShopPlot plot, int size) {
        if (world == null || size <= 0) return;
        int centerX = plot.gridX() * settings.cellSize();
        int centerZ = plot.gridZ() * settings.cellSize();
        int half = size / 2;
        int minX = centerX - half - 1;
        int minZ = centerZ - half - 1;
        int maxX = minX + size + 1;
        int maxZ = minZ + size + 1;
        int bottom = settings.floorY() + 1;
        int top = bottom + settings.barrierHeight() - 1;
        for (int y = bottom; y <= top; y++) {
            for (int x = minX; x <= maxX; x++) {
                world.getBlockAt(x, y, minZ).setType(Material.AIR, false);
                world.getBlockAt(x, y, maxZ).setType(Material.AIR, false);
            }
            for (int z = minZ + 1; z < maxZ; z++) {
                world.getBlockAt(minX, y, z).setType(Material.AIR, false);
                world.getBlockAt(maxX, y, z).setType(Material.AIR, false);
            }
        }
    }

    private static boolean insideSquare(int x, int z, int centerX, int centerZ, int size) {
        int half = size / 2;
        return x >= centerX - half && x < centerX - half + size
                && z >= centerZ - half && z < centerZ - half + size;
    }

    public Optional<ShopPlot> plotAt(Location location) {
        if (!inDistrict(location)) return Optional.empty();
        GridKey key = gridAt(location);
        ShopPlot plot = byGrid.get(key);
        if (plot == null || !inside(location, plot.size())) return Optional.empty();
        return Optional.of(plot);
    }

    /** Returns an allocated plot even when a player is standing in its road gap. */
    public Optional<ShopPlot> plotCellAt(Location location) {
        if (!inDistrict(location)) return Optional.empty();
        return Optional.ofNullable(byGrid.get(gridAt(location)));
    }

    public boolean inDistrict(Location location) {
        return enabled() && location != null && location.getWorld() != null
                && world.getUID().equals(location.getWorld().getUID());
    }

    /** True for an allocated plot or the public hub, never for void cells. */
    public boolean onGeneratedIsland(Location location) {
        if (!inDistrict(location)) return false;
        if (plotAt(location).isPresent()) return true;
        int x = location.getBlockX();
        int z = location.getBlockZ();
        return x >= -5 && x <= 5 && z >= -5 && z <= 5;
    }

    public boolean isOwner(Player player, Location location) {
        if (player == null) return false;
        return plotAt(location).map(plot -> plot.owner().equals(player.getUniqueId())).orElse(false);
    }

    public boolean canBuild(Player player, Location location) {
        if (!inDistrict(location)) return true;
        if (player != null && player.hasPermission("incogshop.shoppingdistrict.bypass")) return true;
        Optional<ShopPlot> plot = plotAt(location);
        if (plot.isEmpty()) return false;
        return settings.allowVisitorsToBuild() || plot.get().owner().equals(player == null ? null : player.getUniqueId());
    }

    public boolean canAccess(Player player, Location location) {
        if (!inDistrict(location)) return true;
        if (player != null && player.hasPermission("incogshop.shoppingdistrict.bypass")) return true;
        Optional<ShopPlot> plot = plotAt(location);
        if (plot.isEmpty()) return false;
        return settings.allowVisitorsToBuild() || plot.get().owner().equals(player == null ? null : player.getUniqueId());
    }

    public Location home(ShopPlot plot) {
        if (world == null || plot == null) return null;
        int centerX = plot.gridX() * settings.cellSize();
        int centerZ = plot.gridZ() * settings.cellSize();
        return new Location(world, centerX + 0.5, settings.floorY() + 1.0, centerZ + 0.5);
    }

    public Location spawn() {
        if (world == null) return null;
        // The public hub platform occupies floor-y + 1, so an arriving player
        // must stand one block higher instead of spawning inside that platform.
        return new Location(world, 0.5, settings.floorY() + 2.0, 0.5);
    }

    public boolean teleport(Player player, ShopPlot plot) {
        if (!enabled() || player == null || plot == null) return false;
        long now = System.currentTimeMillis();
        long last = teleportCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (settings.teleportCooldownMillis() > 0 && now - last < settings.teleportCooldownMillis()
                && !player.hasPermission("incogshop.shoppingdistrict.bypass")) {
            long remaining = settings.teleportCooldownMillis() - (now - last);
            player.sendMessage(plugin.prefix() + "§cPlease wait " + Math.max(1, (remaining + 999) / 1000) + "s before teleporting again.");
            return false;
        }
        Location target = safeArrival(plot);
        if (target == null) return false;
        target.setYaw(player.getLocation().getYaw());
        target.setPitch(0);
        boolean teleported = player.teleport(target);
        if (teleported) teleportCooldowns.put(player.getUniqueId(), now);
        return teleported;
    }

    /**
     * Finds the nearest safe two-block-tall arrival space in the owned plot.
     * Templates are commonly centered, so using the raw grid centre could put
     * an owner directly inside a wall, counter, or staircase after /shopdistrict
     * buy. The scan begins at the normal ground level and works upward, making
     * an open interior preferred over a roof or an arbitrary high platform.
     */
    private Location safeArrival(ShopPlot plot) {
        if (world == null || settings == null || plot == null) return null;
        int centerX = plot.gridX() * settings.cellSize();
        int centerZ = plot.gridZ() * settings.cellSize();
        int half = plot.size() / 2;
        int minX = centerX - half;
        int minZ = centerZ - half;
        int maxX = minX + plot.size() - 1;
        int maxZ = minZ + plot.size() - 1;

        List<ArrivalColumn> columns = new ArrayList<>(plot.size() * plot.size());
        for (int x = minX; x <= maxX; x++) for (int z = minZ; z <= maxZ; z++) {
            columns.add(new ArrivalColumn(x, z));
        }
        columns.sort(Comparator
                .comparingInt((ArrivalColumn column) -> squaredDistance(column.x(), column.z(), centerX, centerZ))
                .thenComparingInt(ArrivalColumn::x)
                .thenComparingInt(ArrivalColumn::z));

        int minimumY = Math.max(world.getMinHeight() + 1, settings.floorY() + 1);
        int maximumY = world.getMaxHeight() - 2;
        if (minimumY > maximumY) return null;
        for (int y = minimumY; y <= maximumY; y++) {
            for (ArrivalColumn column : columns) {
                if (safeStandingSpace(column.x(), y, column.z())) {
                    return new Location(world, column.x() + 0.5, y, column.z() + 0.5);
                }
            }
        }
        return null;
    }

    private boolean safeStandingSpace(int x, int feetY, int z) {
        Block floor = world.getBlockAt(x, feetY - 1, z);
        Material floorType = floor.getType();
        if (!floorType.isSolid() || unsafeArrivalFloor(floorType)) return false;
        return world.getBlockAt(x, feetY, z).isPassable()
                && world.getBlockAt(x, feetY + 1, z).isPassable();
    }

    private static boolean unsafeArrivalFloor(Material material) {
        return material == Material.MAGMA_BLOCK
                || material == Material.CAMPFIRE
                || material == Material.SOUL_CAMPFIRE
                || material == Material.CACTUS;
    }

    private static int squaredDistance(int x, int z, int centerX, int centerZ) {
        int xDistance = x - centerX;
        int zDistance = z - centerZ;
        return xDistance * xDistance + zDistance * zDistance;
    }

    public double plotPrice(int existingPlotCount) {
        return WalletManager.round(settings.newPlotBaseCost()
                * Math.pow(settings.newPlotCostMultiplier(), Math.max(0, existingPlotCount - 1)));
    }

    public double expansionPrice(int previousExpansions, int steps) {
        double total = 0;
        for (int i = 0; i < Math.max(0, steps); i++) {
            total += settings.expansionBaseCost()
                    * Math.pow(settings.expansionCostMultiplier(), Math.max(0, previousExpansions + i));
        }
        return WalletManager.round(total);
    }

    public String describe(ShopPlot plot) {
        if (plot == null) return "No plot";
        Location location = home(plot);
        if (location == null) return "§f" + plot.displayName() + " §8(" + shortId(plot) + ") §7owned by §f" + plot.ownerName();
        String worldName = location.getWorld() == null ? settings.worldName() : location.getWorld().getName();
        return "§f" + plot.displayName() + " §8(" + shortId(plot) + ") §7owned by §f" + plot.ownerName()
                + " §7| §f" + plot.size() + "x" + plot.size()
                + " §7| §f" + worldName + " §7at §f" + location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ();
    }

    private Optional<ShopPlot> plotForAction(Player player) {
        return plotAt(player.getLocation()).filter(plot -> plot.owner().equals(player.getUniqueId()))
                .or(() -> primary(player.getUniqueId()));
    }

    private PlotResult allocate(Player player, boolean purchased, String requestedLayout) {
        List<ShopPlot> owned = byOwner.computeIfAbsent(player.getUniqueId(), ignored -> new ArrayList<>());
        if (owned.size() >= settings.maxPlotsPerPlayer()) {
            return new PlotResult(false, "You have reached the maximum of " + settings.maxPlotsPerPlayer() + " plots.", null, 0);
        }
        GridKey grid = findFreeGrid();
        if (grid == null) return new PlotResult(false, "No free district plots are available right now.", null, 0);
        double cost = purchased ? plotPrice(owned.size()) : 0;
        if (cost > 0 && !free(player) && !plugin.wallets().withdraw(player.getUniqueId(), cost)) {
            return new PlotResult(false, "You need " + plugin.money(cost) + " to buy your next plot.", null, cost);
        }
        String layout = settings.template(requestedLayout).id();
        String name = purchased ? "Plot " + (owned.size() + 1) : "Starter Plot";
        ShopPlot plot = new ShopPlot(UUID.randomUUID(), player.getUniqueId(), player.getName(), grid.x(), grid.z(),
                settings.starterPlotSize(), 0, System.currentTimeMillis(), layout, name);
        register(plot);
        materializePlotIsland(plot, 0);
        buildTemplate(plot);
        return new PlotResult(true, purchased ? "Purchased a new plot." : "Your starter plot is ready.", plot, cost);
    }

    private void register(ShopPlot plot) {
        byGrid.put(new GridKey(plot.gridX(), plot.gridZ()), plot);
        byOwner.computeIfAbsent(plot.owner(), ignored -> new ArrayList<>()).add(plot);
        updateOuterWorldBorder(false);
    }

    private GridKey findFreeGrid() {
        // Keep (0,0) as a public spawn/hub cell. Search in expanding rings so
        // early plots stay near spawn and later plots remain deterministic.
        for (int radius = 1; radius < 10000; radius++) {
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    if (Math.abs(x) != radius && Math.abs(z) != radius) continue;
                    GridKey key = new GridKey(x, z);
                    if (!byGrid.containsKey(key)) return key;
                }
            }
        }
        return null;
    }

    private GridKey gridAt(Location location) {
        return new GridKey(
                ShoppingDistrictGenerator.nearestGrid(location.getBlockX(), settings.cellSize()),
                ShoppingDistrictGenerator.nearestGrid(location.getBlockZ(), settings.cellSize()));
    }

    private boolean inside(Location location, int size) {
        GridKey key = gridAt(location);
        int centerX = key.x() * settings.cellSize();
        int centerZ = key.z() * settings.cellSize();
        int half = size / 2;
        int relativeX = location.getBlockX() - centerX;
        int relativeZ = location.getBlockZ() - centerZ;
        return relativeX >= -half && relativeX < -half + size
                && relativeZ >= -half && relativeZ < -half + size;
    }

    private boolean free(Player player) {
        return player.hasPermission("incogshop.shoppingdistrict.free")
                || player.hasPermission("incogshop.shoppingdistrict.bypass");
    }

    private void ensureWorld() {
        if (settings == null || !settings.enabled()) return;
        if (world != null && world.getName().equals(settings.worldName())) {
            configureWorld(world);
            buildHub();
            materializeRegisteredPlots();
            materializeConnectedRoads();
            updateOuterWorldBorder(true);
            return;
        }
        World existing = Bukkit.getWorld(settings.worldName());
        if (existing != null) {
            world = existing;
            configureWorld(existing);
            buildHub();
            materializeRegisteredPlots();
            materializeConnectedRoads();
            updateOuterWorldBorder(true);
            return;
        }
        WorldCreator creator = new WorldCreator(settings.worldName())
                .environment(settings.environment())
                .type(WorldType.NORMAL)
                .generateStructures(false)
                .generator(new ShoppingDistrictGenerator(settings));
        if (settings.seedEnabled()) creator.seed(settings.seed());
        world = Bukkit.createWorld(creator);
        if (world != null) {
            configureWorld(world);
            buildHub();
            materializeRegisteredPlots();
            materializeConnectedRoads();
            updateOuterWorldBorder(true);
        }
    }

    private void configureWorld(World target) {
        target.setPVP(settings.allowPvp());
        target.setSpawnFlags(settings.allowMobSpawns(), settings.allowMobSpawns());
        target.setDifficulty(settings.difficulty());
        target.setStorm(false);
        target.setThundering(false);
        target.setTime(6000L);
        target.setSpawnLocation(0, settings.floorY() + 2, 0);
        try {
            target.setGameRule(GameRule.DO_MOB_SPAWNING, settings.allowMobSpawns());
            target.setGameRule(GameRule.DO_FIRE_TICK, false);
            target.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
            target.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            target.setGameRule(GameRule.DO_TILE_DROPS, false);
        } catch (IllegalArgumentException ignored) {
            // A future server may remove or rename a gamerule; protection is
            // still enforced by the event listener in that case.
        }
    }

    /** Builds the only public island in the otherwise void Shopping District. */
    private void buildHub() {
        if (world == null || settings == null) return;
        int floorY = settings.floorY();
        int y = floorY + 1;
        for (int x = -5; x <= 5; x++) for (int z = -5; z <= 5; z++) {
            world.getBlockAt(x, floorY - 2, z).setType(settings.foundationMaterial(), false);
            world.getBlockAt(x, floorY - 1, z).setType(settings.foundationMaterial(), false);
            world.getBlockAt(x, floorY, z).setType(settings.roadMaterial(), false);
            boolean edge = Math.abs(x) == 5 || Math.abs(z) == 5;
            world.getBlockAt(x, y, z).setType(edge ? org.bukkit.Material.SMOOTH_STONE : org.bukkit.Material.POLISHED_ANDESITE, false);
        }
        clearLegacyHubBarrier(y);
        world.setSpawnLocation(0, y + 1, 0);
    }

    private void materializeRegisteredPlots() {
        for (ShopPlot plot : byGrid.values()) preserveExistingPlotIsland(plot);
    }

    /**
     * Creates one continuous paved district surface from the hub through every
     * allocated plot. Only space outside that surface remains void, so players
     * can walk between shops without encountering internal safety barriers.
     */
    private void materializeConnectedRoads() {
        if (world == null || settings == null) return;
        SurfaceBounds bounds = districtSurfaceBounds();
        clearRetiredDistrictSurface(bounds);
        for (int x = bounds.minX(); x <= bounds.maxX(); x++) {
            for (int z = bounds.minZ(); z <= bounds.maxZ(); z++) materializeRoadSurface(x, z);
        }
        refreshDistrictBoundary(bounds);
        materializedSurfaceBounds = bounds;
    }

    private SurfaceBounds districtSurfaceBounds() {
        int minX = -5, maxX = 5, minZ = -5, maxZ = 5;
        for (ShopPlot plot : byGrid.values()) {
            int half = plot.size() / 2;
            int plotMinX = plot.gridX() * settings.cellSize() - half;
            int plotMinZ = plot.gridZ() * settings.cellSize() - half;
            minX = Math.min(minX, plotMinX);
            maxX = Math.max(maxX, plotMinX + plot.size() - 1);
            minZ = Math.min(minZ, plotMinZ);
            maxZ = Math.max(maxZ, plotMinZ + plot.size() - 1);
        }
        return new SurfaceBounds(minX, maxX, minZ, maxZ);
    }

    /** Removes road-only cells that became outside the district after an outer plot sale. */
    private void clearRetiredDistrictSurface(SurfaceBounds desired) {
        if (materializedSurfaceBounds == null) return;
        int minimumY = settings.floorY() - 2;
        int maximumY = Math.min(world.getMaxHeight() - 1,
                settings.floorY() + Math.max(settings.outerSafetyBarrierHeight(), 1));
        for (int x = materializedSurfaceBounds.minX(); x <= materializedSurfaceBounds.maxX(); x++) {
            for (int z = materializedSurfaceBounds.minZ(); z <= materializedSurfaceBounds.maxZ(); z++) {
                if (desired.contains(x, z)) continue;
                for (int y = minimumY; y <= maximumY; y++) world.getBlockAt(x, y, z).setType(Material.AIR, false);
            }
        }
    }

    private void materializeRoadSurface(int x, int z) {
        int floorY = settings.floorY();
        Block floor = world.getBlockAt(x, floorY, z);
        if (floor.getType().isAir()) {
            Block lowestFoundation = world.getBlockAt(x, floorY - 2, z);
            Block upperFoundation = world.getBlockAt(x, floorY - 1, z);
            if (lowestFoundation.getType().isAir()) lowestFoundation.setType(settings.foundationMaterial(), false);
            if (upperFoundation.getType().isAir()) upperFoundation.setType(settings.foundationMaterial(), false);
            floor.setType(settings.roadMaterial(), false);
        }
        clearOuterSafetyBarrierAt(x, z);
    }

    private void refreshDistrictBoundary(SurfaceBounds bounds) {
        for (int x = bounds.minX(); x <= bounds.maxX(); x++) {
            refreshOuterSafetyBarrierAt(x, bounds.minZ());
            refreshOuterSafetyBarrierAt(x, bounds.maxZ());
        }
        for (int z = bounds.minZ() + 1; z < bounds.maxZ(); z++) {
            refreshOuterSafetyBarrierAt(bounds.minX(), z);
            refreshOuterSafetyBarrierAt(bounds.maxX(), z);
        }
    }

    /** Places protection only beside exposed terrain, never between connected roads or plots. */
    private void refreshOuterSafetyBarrierAt(int x, int z) {
        if (world == null || settings == null || !hasDistrictSurface(x, z)) return;
        int[][] directions = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] direction : directions) {
            int nextX = x + direction[0];
            int nextZ = z + direction[1];
            if (hasDistrictSurface(nextX, nextZ)) {
                clearOuterSafetyBarrierAt(nextX, nextZ);
                continue;
            }
            if (settings.outerSafetyBarriersEnabled()) placeOuterSafetyBarrierAt(nextX, nextZ);
        }
    }

    private boolean hasDistrictSurface(int x, int z) {
        return world != null && !world.getBlockAt(x, settings.floorY(), z).getType().isAir();
    }

    private void placeOuterSafetyBarrierAt(int x, int z) {
        int minimumY = settings.floorY() + 1;
        int maximumY = Math.min(world.getMaxHeight() - 1, minimumY + settings.outerSafetyBarrierHeight() - 1);
        for (int y = minimumY; y <= maximumY; y++) {
            Block block = world.getBlockAt(x, y, z);
            if (block.getType().isAir()) block.setType(settings.outerSafetyBarrierMaterial(), false);
        }
    }

    private void clearOuterSafetyBarrierAt(int x, int z) {
        if (world == null || settings == null) return;
        int minimumY = settings.floorY() + 1;
        int maximumY = Math.min(world.getMaxHeight() - 1, minimumY + settings.outerSafetyBarrierHeight() - 1);
        for (int y = minimumY; y <= maximumY; y++) {
            Block block = world.getBlockAt(x, y, z);
            if (block.getType() == settings.outerSafetyBarrierMaterial()) block.setType(Material.AIR, false);
        }
    }

    private void clearLegacyHubBarrier(int hubPlatformY) {
        if (world == null) return;
        for (int y = hubPlatformY + 1; y <= hubPlatformY + settings.barrierHeight(); y++) {
            for (int x = -6; x <= 6; x++) {
                world.getBlockAt(x, y, -6).setType(Material.AIR, false);
                world.getBlockAt(x, y, 6).setType(Material.AIR, false);
            }
            for (int z = -5; z <= 5; z++) {
                world.getBlockAt(-6, y, z).setType(Material.AIR, false);
                world.getBlockAt(6, y, z).setType(Material.AIR, false);
            }
        }
    }

    /** Uses one expandable world border around the district rather than walls around every plot. */
    private void updateOuterWorldBorder(boolean allowShrink) {
        if (world == null || settings == null || !settings.outerWorldBorderEnabled()) return;
        int furthestGrid = 0;
        for (ShopPlot plot : byGrid.values()) {
            furthestGrid = Math.max(furthestGrid, Math.max(Math.abs(plot.gridX()), Math.abs(plot.gridZ())));
        }
        double radius = furthestGrid * (double) settings.cellSize()
                + settings.maxPlotSize() / 2.0D + settings.outerWorldBorderPadding();
        double desiredSize = Math.max(32.0D, radius * 2.0D + 1.0D);
        WorldBorder border = world.getWorldBorder();
        border.setCenter(0.5D, 0.5D);
        if (!outerBorderInitialized || allowShrink || border.getSize() < desiredSize) {
            border.setSize(desiredSize);
        }
        outerBorderInitialized = true;
    }

    private void load() {
        byOwner.clear();
        byGrid.clear();
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yaml.getConfigurationSection("plots");
        if (root == null) return;
        Set<GridKey> seen = new HashSet<>();
        for (String idString : root.getKeys(false)) {
            try {
                UUID id = UUID.fromString(idString);
                UUID owner = UUID.fromString(root.getString(idString + ".owner"));
                int gridX = root.getInt(idString + ".grid-x");
                int gridZ = root.getInt(idString + ".grid-z");
                GridKey key = new GridKey(gridX, gridZ);
                if (!seen.add(key) || (gridX == 0 && gridZ == 0)) continue;
                int size = Math.max(5, root.getInt(idString + ".size", settings == null ? 25 : settings.starterPlotSize()));
                if (settings != null) size = Math.min(size, settings.maxPlotSize());
                String ownerName = root.getString(idString + ".owner-name", "Unknown");
                String defaultName = "Plot " + gridX + ", " + gridZ;
                ShopPlot plot = new ShopPlot(id, owner, ownerName, gridX, gridZ,
                        size, Math.max(0, root.getInt(idString + ".expansions", 0)),
                        root.getLong(idString + ".created-at", System.currentTimeMillis()), root.getString(idString + ".layout", "flat"),
                        root.getString(idString + ".name", defaultName));
                byGrid.put(key, plot);
                byOwner.computeIfAbsent(owner, ignored -> new ArrayList<>()).add(plot);
            } catch (Exception ex) {
                plugin.getLogger().warning("Skipping invalid Shopping District plot " + idString + ": " + ex.getMessage());
            }
        }
    }

    public void save() {
        if (file == null) return;
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("version", 1);
        for (ShopPlot plot : byGrid.values()) {
            String root = "plots." + plot.id();
            yaml.set(root + ".owner", plot.owner().toString());
            yaml.set(root + ".owner-name", plot.ownerName());
            yaml.set(root + ".grid-x", plot.gridX());
            yaml.set(root + ".grid-z", plot.gridZ());
            yaml.set(root + ".size", plot.size());
            yaml.set(root + ".expansions", plot.expansions());
            yaml.set(root + ".created-at", plot.createdAt());
            yaml.set(root + ".layout", plot.layout());
            yaml.set(root + ".name", plot.displayName());
        }
        if (plugin.io() != null) plugin.io().writeTextAtomic(file.toPath(), yaml.saveToString(), "shopping-district.yml");
    }

    private void buildTemplate(ShopPlot plot) {
        ShoppingDistrictSettings.Template template = settings.template(plot.layout());
        if (template.flat() || world == null) return;
        if (pasteSchematic(plot)) return;
        if (!template.fallbackBuiltIn()) return;
        Location base = home(plot);
        int x = base.getBlockX() - 4, z = base.getBlockZ() - 4, y = settings.floorY() + 1;
        for (int dx = 0; dx < 9; dx++) for (int dz = 0; dz < 9; dz++)
            if (dx == 0 || dx == 8 || dz == 0 || dz == 8) world.getBlockAt(x + dx, y, z + dz).setType(org.bukkit.Material.OAK_PLANKS, false);
        for (int dx = 0; dx < 9; dx++) for (int dz = 0; dz < 9; dz++)
            world.getBlockAt(x + dx, y + 4, z + dz).setType(org.bukkit.Material.SPRUCE_SLAB, false);
        for (int dx = 1; dx < 8; dx++) for (int dz = 1; dz < 8; dz++)
            world.getBlockAt(x + dx, y + 1, z + dz).setType(org.bukkit.Material.OAK_PLANKS, false);
    }

    /** Loads a WorldEdit/Sponge schematic without making WorldEdit a hard dependency. */
    private boolean pasteSchematic(ShopPlot plot) {
        try {
            ShoppingDistrictSettings.Template template = settings.template(plot.layout());
            ShoppingDistrictSettings.TemplatePlacement placement = template.placement();
            String schematicPath = template.schematicFile();
            if (schematicPath == null || schematicPath.isBlank()) return false;
            File schematic = new File(plugin.getDataFolder(), schematicPath);
            if (!schematic.isFile()) return false;
            Class<?> formats = Class.forName("com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats");
            Object format = formats.getMethod("findByFile", File.class).invoke(null, schematic);
            if (format == null) return false;
            Object reader;
            try (FileInputStream input = new FileInputStream(schematic)) {
                Class<?> formatApi = Class.forName("com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat");
                reader = formatApi.getMethod("getReader", java.io.InputStream.class).invoke(format, input);
                Class<?> readerApi = Class.forName("com.sk89q.worldedit.extent.clipboard.io.ClipboardReader");
                Object clipboard = readerApi.getMethod("read").invoke(reader);
                Object worldEditWorld = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter")
                        .getMethod("adapt", World.class).invoke(null, world);
                Class<?> clipboardApi = Class.forName("com.sk89q.worldedit.extent.clipboard.Clipboard");
                Class<?> vectorApi = Class.forName("com.sk89q.worldedit.math.BlockVector3");
                SchematicBounds bounds = schematicBounds(clipboard, clipboardApi, vectorApi, placement);
                int plotCenterX = plot.gridX() * settings.cellSize();
                int plotCenterZ = plot.gridZ() * settings.cellSize();
                int desiredMinX = (placement.center() ? plotCenterX - bounds.width() / 2 : plotCenterX) + placement.xOffset();
                int desiredMinZ = (placement.center() ? plotCenterZ - bounds.length() / 2 : plotCenterZ) + placement.zOffset();
                // Shift every schematic one block lower than the original
                // district behavior. The configured y-offset remains additive,
                // so old behavior can be restored per template with y-offset: 1.
                int desiredMinY = (placement.alignLowestBlockToGround() ? settings.floorY() + 1 : bounds.minY())
                        + placement.yOffset() - 1;

                // ForwardExtentCopy maps its selected region's lower corner to
                // the target position, so each slice starts at the calculated
                // content minimum rather than the schematic's saved origin.
                queueSchematicLayers(plot, clipboard, worldEditWorld, bounds, desiredMinX, desiredMinY, desiredMinZ,
                        placement.ignoreAirBlocks());
                return true;
            }
        } catch (ReflectiveOperationException | java.io.IOException | RuntimeException ex) {
            plugin.getLogger().warning("Could not paste Shopping District schematic for template '"
                    + (plot == null ? "unknown" : plot.layout()) + "'; using fallback shack: "
                    + ex.getClass().getSimpleName() + ": " + ex.getMessage());
            return false;
        }
    }

    /**
     * Copies one horizontal WorldEdit region per tick. A typical shop therefore
     * takes several ticks to appear, but never asks WorldEdit to rewrite the
     * entire schematic in one server tick. This stays reflection-only so
     * WorldEdit/FAWE remains an optional dependency.
     */
    private void queueSchematicLayers(ShopPlot plot, Object clipboard, Object worldEditWorld,
                                      SchematicBounds bounds, int targetX, int targetY, int targetZ,
                                      boolean ignoreAir) throws ReflectiveOperationException {
        int layersPerTick = settings.schematicLayersPerTick();
        final int[] nextY = {bounds.minY()};
        final org.bukkit.scheduler.BukkitTask[] task = new org.bukkit.scheduler.BukkitTask[1];
        Runnable pasteNextLayers = () -> {
            try {
                for (int copied = 0; copied < layersPerTick && nextY[0] <= bounds.maxY(); copied++, nextY[0]++) {
                    pasteSchematicLayer(clipboard, worldEditWorld, bounds, nextY[0],
                            targetX, targetY + (nextY[0] - bounds.minY()), targetZ, ignoreAir);
                }
                if (nextY[0] > bounds.maxY()) task[0].cancel();
            } catch (ReflectiveOperationException | RuntimeException ex) {
                task[0].cancel();
                plugin.getLogger().warning("Stopped layered schematic paste for template '" + plot.layout()
                        + "' at Y=" + nextY[0] + ": " + ex.getClass().getSimpleName() + ": " + ex.getMessage());
            }
        };
        task[0] = Bukkit.getScheduler().runTaskTimer(plugin.host(), pasteNextLayers, 1L, 1L);
    }

    /** Executes a single WorldEdit horizontal clipboard slice. */
    private void pasteSchematicLayer(Object clipboard, Object worldEditWorld, SchematicBounds bounds, int sourceY,
                                     int targetX, int targetY, int targetZ, boolean ignoreAir)
            throws ReflectiveOperationException {
        Object editSession = null;
        try {
            Class<?> vectorApi = Class.forName("com.sk89q.worldedit.math.BlockVector3");
            Object sourceMin = vectorApi.getMethod("at", int.class, int.class, int.class)
                    .invoke(null, bounds.minX(), sourceY, bounds.minZ());
            Object sourceMax = vectorApi.getMethod("at", int.class, int.class, int.class)
                    .invoke(null, bounds.maxX(), sourceY, bounds.maxZ());
            Object target = vectorApi.getMethod("at", int.class, int.class, int.class)
                    .invoke(null, targetX, targetY, targetZ);

            Class<?> regionApi = Class.forName("com.sk89q.worldedit.regions.CuboidRegion");
            Object region = findCompatibleConstructor(regionApi, worldEditWorld, sourceMin, sourceMax)
                    .newInstance(worldEditWorld, sourceMin, sourceMax);
            Object worldEdit = Class.forName("com.sk89q.worldedit.WorldEdit").getMethod("getInstance").invoke(null);
            Class<?> worldEditApi = Class.forName("com.sk89q.worldedit.WorldEdit");
            editSession = worldEditApi.getMethod("newEditSession", Class.forName("com.sk89q.worldedit.world.World"))
                    .invoke(worldEdit, worldEditWorld);

            Class<?> copyApi = Class.forName("com.sk89q.worldedit.function.operation.ForwardExtentCopy");
            Object copy = findCompatibleConstructor(copyApi, clipboard, region, editSession, target)
                    .newInstance(clipboard, region, editSession, target);
            try {
                copyApi.getMethod("setCopyingEntities", boolean.class).invoke(copy, false);
            } catch (NoSuchMethodException ignored) {
                // Schematics normally contain no entities; older WorldEdit APIs
                // without this setting retain their standard behavior.
            }
            if (ignoreAir) {
                Class<?> maskApi = Class.forName("com.sk89q.worldedit.function.mask.ExistingBlockMask");
                Object mask = findCompatibleConstructor(maskApi, clipboard).newInstance(clipboard);
                findCompatibleMethod(copyApi, "setSourceMask", mask).invoke(copy, mask);
            }
            Class.forName("com.sk89q.worldedit.function.operation.Operations")
                    .getMethod("complete", Class.forName("com.sk89q.worldedit.function.operation.Operation"))
                    .invoke(null, copy);
        } finally {
            if (editSession != null) {
                try {
                    Class.forName("com.sk89q.worldedit.EditSession").getMethod("close").invoke(editSession);
                } catch (ReflectiveOperationException ignored) {
                    // Closing is best-effort on older WorldEdit versions.
                }
            }
        }
    }

    /** Finds a public one-argument method whose parameter accepts the value. */
    private static java.lang.reflect.Method findCompatibleMethod(Class<?> api, String name, Object value)
            throws NoSuchMethodException {
        Class<?> valueType = value == null ? null : value.getClass();
        for (java.lang.reflect.Method method : api.getMethods()) {
            if (!method.getName().equals(name) || method.getParameterCount() != 1) continue;
            Class<?> parameterType = method.getParameterTypes()[0];
            if (valueType == null ? !parameterType.isPrimitive() : parameterType.isAssignableFrom(valueType)) {
                return method;
            }
        }
        throw new NoSuchMethodException(api.getName() + "." + name + "(" +
                (valueType == null ? "null" : valueType.getName()) + ")");
    }

    private static java.lang.reflect.Constructor<?> findCompatibleConstructor(Class<?> api, Object... values)
            throws NoSuchMethodException {
        for (java.lang.reflect.Constructor<?> constructor : api.getConstructors()) {
            Class<?>[] parameters = constructor.getParameterTypes();
            if (parameters.length != values.length) continue;
            boolean compatible = true;
            for (int i = 0; i < parameters.length; i++) {
                if (values[i] != null && !parameters[i].isAssignableFrom(values[i].getClass())) {
                    compatible = false;
                    break;
                }
            }
            if (compatible) return constructor;
        }
        throw new NoSuchMethodException("No compatible constructor for " + api.getName());
    }

    /** Bounds are inclusive because WorldEdit regions include both min and max points. */
    private record SchematicBounds(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        int width() { return maxX - minX + 1; }
        int length() { return maxZ - minZ + 1; }
    }

    /**
     * Uses actual non-air blocks when possible, so accidental empty padding in
     * a WorldEdit selection never makes a shop float or look off-center.
     */
    private static SchematicBounds schematicBounds(Object clipboard, Class<?> clipboardApi, Class<?> vectorApi,
                                                    ShoppingDistrictSettings.TemplatePlacement placement)
            throws ReflectiveOperationException {
        Object region = clipboardApi.getMethod("getRegion").invoke(clipboard);
        Class<?> regionApi = Class.forName("com.sk89q.worldedit.regions.Region");
        Object min = regionApi.getMethod("getMinimumPoint").invoke(region);
        Object max = regionApi.getMethod("getMaximumPoint").invoke(region);
        SchematicBounds selection = new SchematicBounds(
                vectorCoordinate(vectorApi, min, "x"), vectorCoordinate(vectorApi, min, "y"), vectorCoordinate(vectorApi, min, "z"),
                vectorCoordinate(vectorApi, max, "x"), vectorCoordinate(vectorApi, max, "y"), vectorCoordinate(vectorApi, max, "z"));
        if (!placement.useContentBounds() || !(clipboard instanceof Iterable<?> positions)) return selection;

        java.lang.reflect.Method getBlock = clipboardApi.getMethod("getBlock", vectorApi);
        Class<?> stateApi = Class.forName("com.sk89q.worldedit.world.block.BlockState");
        java.lang.reflect.Method isAir = stateApi.getMethod("isAir");
        int scanned = 0;
        boolean found = false;
        int minX = 0, minY = 0, minZ = 0, maxX = 0, maxY = 0, maxZ = 0;
        for (Object point : positions) {
            if (++scanned > placement.contentBoundsScanLimit()) return selection;
            Object state = getBlock.invoke(clipboard, point);
            if (Boolean.TRUE.equals(isAir.invoke(state))) continue;
            int x = vectorCoordinate(vectorApi, point, "x");
            int y = vectorCoordinate(vectorApi, point, "y");
            int z = vectorCoordinate(vectorApi, point, "z");
            if (!found) {
                found = true;
                minX = maxX = x;
                minY = maxY = y;
                minZ = maxZ = z;
            } else {
                minX = Math.min(minX, x); minY = Math.min(minY, y); minZ = Math.min(minZ, z);
                maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); maxZ = Math.max(maxZ, z);
            }
        }
        return found ? new SchematicBounds(minX, minY, minZ, maxX, maxY, maxZ) : selection;
    }

    /** Supports WorldEdit's modern x()/y()/z() vector API and older getters. */
    private static int vectorCoordinate(Class<?> vectorApi, Object vector, String axis) throws ReflectiveOperationException {
        try {
            return ((Number) vectorApi.getMethod(axis).invoke(vector)).intValue();
        } catch (NoSuchMethodException ignored) {
            String legacy = switch (axis) {
                case "x" -> "getBlockX";
                case "y" -> "getBlockY";
                case "z" -> "getBlockZ";
                default -> throw new NoSuchMethodException(axis);
            };
            return ((Number) vectorApi.getMethod(legacy).invoke(vector)).intValue();
        }
    }

    private static String normalizePlotName(String raw) {
        if (raw == null) return null;
        String name = raw.trim().replaceAll("\\s+", " ");
        return name.matches("[\\p{L}\\p{N}][\\p{L}\\p{N} _'\\-]{0,31}") && !name.matches("\\d+") ? name : null;
    }

    private void saveIfNameChanged(List<ShopPlot> plots) {
        // Persist the refreshed owner name so offline visit/list lookups stay
        // useful after a player changes their display name.
        if (!plots.isEmpty()) save();
    }

    private static String shortId(ShopPlot plot) {
        return plot.id().toString().substring(0, 8);
    }
}

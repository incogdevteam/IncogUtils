package com.snipeyfresh.incogshop.shopping;

import com.snipeyfresh.incogshop.IncogShopPlugin;
import org.bukkit.Difficulty;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Locale;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Immutable, validated settings for the procedurally generated shopping
 * district. Keeping the values in one object makes the generator and the
 * protection manager use exactly the same plot geometry.
 */
public record ShoppingDistrictSettings(
        boolean enabled,
        String worldName,
        World.Environment environment,
        boolean seedEnabled,
        long seed,
        Difficulty difficulty,
        int floorY,
        int maxPlotSize,
        int baseMaxPlotSize,
        int starterPlotSize,
        int roadWidth,
        Material plotFloorMaterial,
        Material roadMaterial,
        Material foundationMaterial,
        int maxPlotsPerPlayer,
        boolean autoAssignOnFirstJoin,
        boolean teleportFirstJoin,
        boolean notifyFirstJoin,
        int expansionStep,
        double newPlotBaseCost,
        double newPlotCostMultiplier,
        double expansionBaseCost,
        double expansionCostMultiplier,
        boolean allowVisitorsToBuild,
        boolean allowPvp,
        boolean allowMobSpawns,
        boolean unloadWorldOnDisable,
        long teleportCooldownMillis,
        String firstTemplate,
        Map<String, Template> templates,
        int schematicLayersPerTick,
        double plotSaleRefundPercent,
        boolean resetOnSale,
        int saleResetHeight,
        int barrierHeight,
        List<ExpansionTier> rankExpansionTiers,
        boolean outerWorldBorderEnabled,
        int outerWorldBorderPadding,
        int voidRescueBelowFloor,
        boolean outerSafetyBarriersEnabled,
        int outerSafetyBarrierHeight,
        Material outerSafetyBarrierMaterial
) {
    /** A paid plot-size ceiling unlocked by either a Bukkit permission or LP group. */
    public record ExpansionTier(String id, int maximumSize, String permission, Set<String> luckPermsGroups) {}
    /** Per-template paste behavior. Offsets are applied after centering/grounding. */
    public record TemplatePlacement(
            boolean center,
            boolean useContentBounds,
            boolean alignLowestBlockToGround,
            int xOffset,
            int yOffset,
            int zOffset,
            boolean ignoreAirBlocks,
            int contentBoundsScanLimit
    ) {}

    public record Template(String id, String name, String schematicFile, boolean flat,
                           boolean fallbackBuiltIn, TemplatePlacement placement) {
        public Template {
            if (placement == null) placement = new TemplatePlacement(true, true, true, 0, 0, 0, true, 250_000);
        }
    }

    public static ShoppingDistrictSettings from(IncogShopPlugin plugin) {
        var config = plugin.getConfig();
        String worldName = config.getString("shopping-district.world-name", "incog_shopping_district");
        if (worldName == null || worldName.isBlank()) worldName = "incog_shopping_district";

        String environmentName = config.getString("shopping-district.environment", "NORMAL");
        World.Environment environment;
        try {
            environment = World.Environment.valueOf(environmentName == null
                    ? "NORMAL" : environmentName.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            environment = World.Environment.NORMAL;
        }

        String difficultyName = config.getString("shopping-district.world.difficulty", "PEACEFUL");
        Difficulty difficulty;
        try {
            difficulty = Difficulty.valueOf(difficultyName == null
                    ? "PEACEFUL" : difficultyName.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            difficulty = Difficulty.PEACEFUL;
        }

        int maxSize = clamp(config.getInt("shopping-district.plots.max-size", 100), 5, 256);
        int starterSize = clamp(config.getInt("shopping-district.plots.starter-size", 40), 5, maxSize);
        int baseMaxSize = clamp(config.getInt("shopping-district.plots.base-max-size", 50), starterSize, maxSize);
        int roadWidth = clamp(config.getInt("shopping-district.generation.road-width", 6), 2, 64);
        int floorY = config.getInt("shopping-district.generation.floor-y", 64);
        // The generator places two foundation layers below the visible floor;
        // keep those layers inside the vanilla world height even if an admin
        // enters an unusually low custom floor value.
        floorY = Math.max(-62, Math.min(300, floorY));

        Map<String, Template> templates = new LinkedHashMap<>();
        var templateSection = config.getConfigurationSection("shopping-district.template.templates");
        if (templateSection != null) for (String rawId : templateSection.getKeys(false)) {
            String id = rawId.toLowerCase(Locale.ROOT);
            String path = "shopping-district.template.templates." + rawId;
            String type = config.getString(path + ".type", "schematic");
            templates.put(id, new Template(id, config.getString(path + ".name", id),
                    config.getString(path + ".schematic-file", ""), "flat".equalsIgnoreCase(type),
                    config.getBoolean(path + ".fallback-built-in", false), placement(config, path + ".placement")));
        }
        if (!templates.containsKey("flat")) templates.put("flat", new Template("flat", "Flat Land", "", true, false,
                placement(config, "shopping-district.template.placement")));
        if (!templates.containsKey("shack")) templates.put("shack", new Template("shack", "Starter Shack",
                config.getString("shopping-district.template.schematic-file", "templates/shopping-shack.schem"), false,
                config.getBoolean("shopping-district.template.fallback-built-in", true),
                placement(config, "shopping-district.template.placement")));
        String first = config.getString("shopping-district.template.first-template", "shack");
        if (!templates.containsKey(first.toLowerCase(Locale.ROOT))) first = "shack";

        List<ExpansionTier> rankExpansionTiers = new ArrayList<>();
        var rankExpansionSection = config.getConfigurationSection("shopping-district.plots.rank-expansions");
        if (rankExpansionSection != null) for (String rawId : rankExpansionSection.getKeys(false)) {
            String path = "shopping-district.plots.rank-expansions." + rawId;
            int maximumSize = clamp(config.getInt(path + ".maximum-size", baseMaxSize), baseMaxSize, maxSize);
            String permission = config.getString(path + ".permission", "");
            Set<String> groups = new LinkedHashSet<>();
            for (String group : config.getStringList(path + ".luckperms-groups")) {
                if (group != null && !group.isBlank()) groups.add(group.trim().toLowerCase(Locale.ROOT));
            }
            rankExpansionTiers.add(new ExpansionTier(rawId.toLowerCase(Locale.ROOT), maximumSize,
                    permission == null ? "" : permission.trim().toLowerCase(Locale.ROOT), Set.copyOf(groups)));
        }

        return new ShoppingDistrictSettings(
                config.getBoolean("shopping-district.enabled", true),
                worldName,
                environment,
                config.getBoolean("shopping-district.generation.seed-enabled", false),
                config.getLong("shopping-district.generation.seed", 0L),
                difficulty,
                floorY,
                maxSize,
                baseMaxSize,
                starterSize,
                roadWidth,
                material(config.getString("shopping-district.generation.plot-floor-material", "GRASS_BLOCK"), Material.GRASS_BLOCK),
                material(config.getString("shopping-district.generation.road-material", "SMOOTH_STONE"), Material.SMOOTH_STONE),
                material(config.getString("shopping-district.generation.foundation-material", "STONE"), Material.STONE),
                clamp(config.getInt("shopping-district.plots.max-per-player", 8), 1, 1000),
                config.getBoolean("shopping-district.plots.auto-assign-on-first-join", true),
                config.getBoolean("shopping-district.plots.teleport-first-join", false),
                config.getBoolean("shopping-district.plots.notify-first-join", true),
                clamp(config.getInt("shopping-district.plots.expansion-step", 5), 1, maxSize),
                Math.max(0, config.getDouble("shopping-district.pricing.new-plot-base-cost", 2500.0)),
                Math.max(1.0, config.getDouble("shopping-district.pricing.new-plot-cost-multiplier", 1.65)),
                Math.max(0, config.getDouble("shopping-district.pricing.expansion-base-cost", 500.0)),
                Math.max(1.0, config.getDouble("shopping-district.pricing.expansion-cost-multiplier", 1.35)),
                config.getBoolean("shopping-district.protection.allow-visitors-to-build", false),
                config.getBoolean("shopping-district.protection.allow-pvp", false),
                config.getBoolean("shopping-district.protection.allow-mob-spawns", false),
                config.getBoolean("shopping-district.world.unload-on-disable", false),
                Math.max(0, config.getLong("shopping-district.teleport.cooldown-seconds", 3L)) * 1000L,
                first.toLowerCase(Locale.ROOT),
                Map.copyOf(templates),
                clamp(config.getInt("shopping-district.template.schematic-layers-per-tick", 1), 1, 8),
                Math.max(0, Math.min(100, config.getDouble("shopping-district.pricing.plot-sale-refund-percent", 70.0))),
                config.getBoolean("shopping-district.plots.reset-on-sale", true),
                Math.max(0, config.getInt("shopping-district.plots.sale-reset-height", 0)),
                clamp(config.getInt("shopping-district.generation.barrier-height", 4), 2, 32),
                List.copyOf(rankExpansionTiers),
                config.getBoolean("shopping-district.generation.outer-world-border.enabled", true),
                clamp(config.getInt("shopping-district.generation.outer-world-border.padding", 16), 1, 512),
                clamp(config.getInt("shopping-district.generation.void-rescue-below-floor", 4), 1, 64),
                config.getBoolean("shopping-district.generation.outer-safety-barriers.enabled", true),
                clamp(config.getInt("shopping-district.generation.outer-safety-barriers.height", 4), 1, 32),
                material(config.getString("shopping-district.generation.outer-safety-barriers.material", "BARRIER"), Material.BARRIER)
        );
    }

    public int cellSize() {
        return maxPlotSize + roadWidth;
    }

    public Template template(String id) { return templates.getOrDefault(id == null ? "flat" : id.toLowerCase(Locale.ROOT), templates.get("flat")); }

    private static TemplatePlacement placement(FileConfiguration config, String path) {
        return new TemplatePlacement(
                config.getBoolean(path + ".center", true),
                config.getBoolean(path + ".use-content-bounds", true),
                config.getBoolean(path + ".align-lowest-block-to-ground", true),
                clamp(config.getInt(path + ".x-offset", 0), -512, 512),
                clamp(config.getInt(path + ".y-offset", 0), -128, 320),
                clamp(config.getInt(path + ".z-offset", 0), -512, 512),
                config.getBoolean(path + ".ignore-air-blocks", true),
                clamp(config.getInt(path + ".content-bounds-scan-limit", 250_000), 1_000, 1_000_000)
        );
    }

    private static int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static Material material(String raw, Material fallback) {
        Material material = raw == null ? null : Material.matchMaterial(raw.trim());
        return material == null || material.isAir() ? fallback : material;
    }
}

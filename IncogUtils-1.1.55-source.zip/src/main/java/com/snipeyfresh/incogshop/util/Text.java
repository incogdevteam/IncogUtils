package com.snipeyfresh.incogshop.util;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;

public final class Text {
    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer LEGACY_HEX = LegacyComponentSerializer.builder()
            .character(LegacyComponentSerializer.SECTION_CHAR)
            .hexColors()
            .useUnusualXRepeatedCharacterHexFormat()
            .build();

    private Text() {}

    public static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    /**
     * Renders provider-supplied MiniMessage into the legacy string format used
     * by this plugin's inventory GUI. Hex colors use Minecraft's repeated
     * section-sign format so gradients remain colored instead of appearing as
     * literal tags such as {@code <gradient:...>}.
     */
    public static String renderMiniMessage(String text) {
        if (text == null || text.isBlank() || !text.contains("<")) return text == null ? "" : text;
        try {
            return LEGACY_HEX.serialize(MINI_MESSAGE.deserialize(text));
        } catch (RuntimeException ignored) {
            try { return MINI_MESSAGE.stripTags(text); }
            catch (RuntimeException ignoredAgain) { return text.replaceAll("<[^>]*>", ""); }
        }
    }

    public static String prettyEnum(String name) {
        String[] parts = name.toLowerCase().split("_");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (!out.isEmpty()) out.append(' ');
            out.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return out.toString();
    }
}

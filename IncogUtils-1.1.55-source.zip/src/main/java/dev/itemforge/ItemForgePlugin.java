package dev.itemforge;

import com.incogdev.incogrpg.IncogRpgPlugin;
import com.incogdev.incogutils.module.ModuleContext;
import com.incogdev.incogutils.branding.Branding;
import dev.itemforge.ability.AbilityListener;
import dev.itemforge.ability.AbilityRegistry;
import dev.itemforge.command.ItemForgeCommand;
import dev.itemforge.gui.MenuService;
import dev.itemforge.item.ItemRegistry;
import dev.itemforge.loot.LootListener;
import dev.itemforge.prompt.ChatPromptManager;
import dev.itemforge.recipe.CustomRecipeManager;
import dev.itemforge.util.Texts;
import dev.itemforge.util.ProblemReporter;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

import java.util.Objects;

public final class ItemForgePlugin extends ModuleContext {
    private ItemRegistry items;
    private CustomRecipeManager recipes;
    private ChatPromptManager prompts;
    private MenuService menus;
    private AbilityListener abilityListener;
    private AbilityRegistry abilityRegistry;
    private ProblemReporter problems;

    public ItemForgePlugin(IncogRpgPlugin host) {
        super(host, "itemforge", "ItemForge");
    }

    public void enable() {
        saveDefaultConfig();
        problems = new ProblemReporter(this);
        abilityRegistry = new AbilityRegistry(this);
        abilityRegistry.load();
        items = new ItemRegistry(this);
        items.load();
        recipes = new CustomRecipeManager(this, items);
        recipes.registerAll();
        prompts = new ChatPromptManager(this);
        menus = new MenuService(this);
        abilityListener = new AbilityListener(this);
        Bukkit.getPluginManager().registerEvents(prompts, host());
        Bukkit.getPluginManager().registerEvents(menus, host());
        Bukkit.getPluginManager().registerEvents(abilityListener, host());
        Bukkit.getPluginManager().registerEvents(new LootListener(this), host());
        ItemForgeCommand command = new ItemForgeCommand(this, menus);
        Objects.requireNonNull(getCommand("itemforge"), "itemforge command missing from plugin.yml").setExecutor(command);
        Objects.requireNonNull(getCommand("itemforge")).setTabCompleter(command);
        abilityListener.start();
        getLogger().info("Loaded " + items.all().size() + " custom items and " + abilityRegistry.all().size() + " abilities.");
    }

    public void disable() {
        if (prompts != null) prompts.clear();
        if (abilityListener != null) abilityListener.stop();
        if (recipes != null) recipes.unregisterAll();
        if (items != null) items.save();
        if (problems != null) problems.clear();
    }

    public void reloadEverything() {
        reloadConfig();
        problems.clear();
        abilityRegistry.load();
        items.load();
        recipes.registerAll();
        abilityListener.start();
    }

    public void message(CommandSender sender, String message) {
        String prefix = Branding.miniConfigured(getConfig().getString("messages.prefix", ""), "ItemForge");
        sender.sendMessage(Texts.mini(prefix + message));
    }

    public ItemRegistry items() {
        return items;
    }

    public CustomRecipeManager recipes() {
        return recipes;
    }

    public ChatPromptManager prompts() {
        return prompts;
    }

    public ProblemReporter problems() {
        return problems;
    }

    public AbilityRegistry abilityRegistry() {
        return abilityRegistry;
    }
}

package dev.itemforge.ability;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public record AbilityAction(AbilityActionType type, Map<String, Object> settings) {
    public AbilityAction {
        if (type == null) throw new IllegalArgumentException("Action type is required");
        settings = Map.copyOf(settings == null ? Map.of() : settings);
    }

    public static AbilityAction fromMap(Map<?, ?> input) {
        Object rawType = input.get("type");
        if (rawType == null) throw new IllegalArgumentException("Action type is missing");
        AbilityActionType type = AbilityActionType.valueOf(String.valueOf(rawType).toUpperCase(Locale.ROOT));
        Map<String, Object> settings = new LinkedHashMap<>();
        input.forEach((key, value) -> {
            if (key != null && !String.valueOf(key).equalsIgnoreCase("type")) settings.put(String.valueOf(key), value);
        });
        return new AbilityAction(type, settings);
    }

    public String string(String key, String fallback) {
        Object value = settings.get(key);
        return value == null ? fallback : String.valueOf(value);
    }

    public boolean bool(String key, boolean fallback) {
        Object value = settings.get(key);
        if (value instanceof Boolean bool) return bool;
        return value == null ? fallback : Boolean.parseBoolean(String.valueOf(value));
    }
}

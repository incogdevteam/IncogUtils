package dev.itemforge.ability;

public enum AbilityActionType {
    VELOCITY,
    PROJECTILE,
    HEAL,
    DAMAGE,
    POTION,
    LIGHTNING,
    COMMAND,
    MESSAGE,
    ACTION_BAR,
    SOUND,
    PARTICLE,
    FIRE,
    EXPLOSION
}

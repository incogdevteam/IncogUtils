package dev.itemforge.ability;

import dev.itemforge.ItemForgePlugin;
import dev.itemforge.model.AbilityDefinition;
import dev.itemforge.model.CustomItemDefinition;
import dev.itemforge.util.Expressions;
import dev.itemforge.util.Texts;
import io.papermc.paper.registry.RegistryAccess;
import io.papermc.paper.registry.RegistryKey;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Egg;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.SmallFireball;
import org.bukkit.entity.Snowball;
import org.bukkit.entity.Trident;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Executes the data-driven abilities loaded from the plugin's abilities folder. */
public final class AbilityListener implements Listener {
    private final ItemForgePlugin plugin;
    private final NamespacedKey projectileDamageKey;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    private BukkitTask passiveTask;

    public AbilityListener(ItemForgePlugin plugin) {
        this.plugin = plugin;
        this.projectileDamageKey = new NamespacedKey(plugin.host(), "ability_projectile_damage");
    }

    public void start() {
        stop();
        long period = Math.max(5L, plugin.getConfig().getLong("passive-scan-ticks", 20L));
        passiveTask = Bukkit.getScheduler().runTaskTimer(plugin.host(), () -> scanPassives((int) period), period, period);
    }

    public void stop() {
        if (passiveTask != null) {
            passiveTask.cancel();
            passiveTask = null;
        }
        cooldowns.clear();
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() == null || !event.getPlayer().hasPermission("itemforge.use")) return;
        AbilityTrigger trigger = switch (event.getAction()) {
            case RIGHT_CLICK_AIR, RIGHT_CLICK_BLOCK -> AbilityTrigger.RIGHT_CLICK;
            case LEFT_CLICK_AIR, LEFT_CLICK_BLOCK -> AbilityTrigger.LEFT_CLICK;
            default -> null;
        };
        if (trigger == null) return;
        ItemStack stack = event.getHand() == EquipmentSlot.HAND
            ? event.getPlayer().getInventory().getItemInMainHand()
            : event.getPlayer().getInventory().getItemInOffHand();
        executeItem(event.getPlayer(), stack, trigger, null, event, 0.0, true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Projectile projectile) {
            Double damage = projectile.getPersistentDataContainer().get(projectileDamageKey, PersistentDataType.DOUBLE);
            if (damage != null) event.setDamage(Math.max(0.0, damage));
        }

        if (event.getDamager() instanceof Player attacker && event.getEntity() instanceof LivingEntity target) {
            executeItem(attacker, attacker.getInventory().getItemInMainHand(), AbilityTrigger.MELEE_HIT, target, event, event.getDamage(), false);
        }
        if (event.getEntity() instanceof Player victim) {
            LivingEntity attacker = resolveAttacker(event.getDamager());
            executeEquipped(victim, AbilityTrigger.DAMAGED, attacker, event, event.getDamage());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer != null) executeItem(killer, killer.getInventory().getItemInMainHand(), AbilityTrigger.KILL, event.getEntity(), event, 0.0, false);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSneak(PlayerToggleSneakEvent event) {
        if (event.isSneaking()) executeEquipped(event.getPlayer(), AbilityTrigger.SNEAK, null, event, 0.0);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        cooldowns.remove(event.getPlayer().getUniqueId());
    }

    private void scanPassives(int period) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            executeEquipped(player, AbilityTrigger.PASSIVE, null, null, period);
        }
    }

    private void executeEquipped(Player player, AbilityTrigger trigger, LivingEntity target, Event event, double value) {
        if (!player.hasPermission("itemforge.use")) return;
        List<ItemStack> equipped = new ArrayList<>();
        equipped.add(player.getInventory().getItemInMainHand());
        equipped.add(player.getInventory().getItemInOffHand());
        for (ItemStack armor : player.getInventory().getArmorContents()) equipped.add(armor);

        Set<String> seenItemIds = new HashSet<>();
        for (ItemStack stack : equipped) {
            String itemId = plugin.items().identify(stack).orElse(null);
            if (itemId != null && seenItemIds.add(itemId)) {
                executeItem(player, stack, trigger, target, event, value, false);
            }
        }
    }

    private boolean executeItem(
        Player player,
        ItemStack stack,
        AbilityTrigger trigger,
        LivingEntity target,
        Event event,
        double value,
        boolean notifyCooldown
    ) {
        if (!player.hasPermission("itemforge.use")) return false;
        String itemId = plugin.items().identify(stack).orElse(null);
        if (itemId == null) return false;
        CustomItemDefinition item = plugin.items().get(itemId).orElse(null);
        if (item == null) return false;

        boolean used = false;
        for (AbilityDefinition attached : item.abilities()) {
            ConfiguredAbility ability = plugin.abilityRegistry().get(attached.abilityId()).orElse(null);
            if (ability == null || ability.trigger() != trigger) continue;
            // Some command-based staff abilities must never run against mobs. Check this
            // before the cooldown/actions so a mob hit is indistinguishable from a normal hit.
            if (ability.requirePlayerTarget() && !(target instanceof Player)) continue;
            if (!ability.permission().isBlank() && !player.hasPermission(ability.permission())) continue;
            if (!ready(player, itemId, attached, ability, notifyCooldown)) continue;

            AbilityContext context = new AbilityContext(player, target, item, attached, ability, event, value);
            boolean succeeded = false;
            for (int index = 0; index < ability.actions().size(); index++) {
                AbilityAction action = ability.actions().get(index);
                try {
                    double chance = number(action, "chance-percent", context, 100.0);
                    if (chance < 100.0 && Math.random() * 100.0 >= Math.max(0.0, chance)) continue;
                    executeAction(action, context);
                    succeeded = true;
                } catch (RuntimeException exception) {
                    plugin.problems().error(
                        "ability.runtime." + ability.id() + "." + index,
                        "Ability '" + ability.id() + "' action " + (index + 1) + " failed",
                        exception
                    );
                }
            }
            if (!succeeded) continue;
            markUsed(player, itemId, attached);
            used = true;
            if (ability.cancelTrigger() && event instanceof Cancellable cancellable) cancellable.setCancelled(true);
        }
        return used;
    }

    private void executeAction(AbilityAction action, AbilityContext context) {
        switch (action.type()) {
            case VELOCITY -> velocity(action, context);
            case PROJECTILE -> projectile(action, context);
            case HEAL -> heal(action, context);
            case DAMAGE -> damage(action, context);
            case POTION -> potion(action, context);
            case LIGHTNING -> lightning(action, context);
            case COMMAND -> command(action, context);
            case MESSAGE -> message(action, context, false);
            case ACTION_BAR -> message(action, context, true);
            case SOUND -> sound(action, context);
            case PARTICLE -> particle(action, context);
            case FIRE -> fire(action, context);
            case EXPLOSION -> explosion(action, context);
        }
    }

    private void velocity(AbilityAction action, AbilityContext context) {
        LivingEntity target = target(action, context);
        if (target == null) return;
        double multiplier = Math.max(0.0, number(action, "multiplier", context, 1.0));
        Vector direction = context.player().getLocation().getDirection().normalize().multiply(multiplier);
        if (action.settings().containsKey("vertical")) direction.setY(number(action, "vertical", context, direction.getY()));
        if (action.bool("add", false)) direction.add(target.getVelocity());
        target.setVelocity(direction);
    }

    private void projectile(AbilityAction action, AbilityContext context) {
        String kind = action.string("projectile", "SNOWBALL").toUpperCase(Locale.ROOT);
        Projectile projectile = switch (kind) {
            case "SMALL_FIREBALL" -> context.player().launchProjectile(SmallFireball.class);
            case "FIREBALL" -> context.player().launchProjectile(Fireball.class);
            case "ARROW" -> context.player().launchProjectile(Arrow.class);
            case "EGG" -> context.player().launchProjectile(Egg.class);
            case "ENDER_PEARL" -> context.player().launchProjectile(EnderPearl.class);
            case "TRIDENT" -> context.player().launchProjectile(Trident.class);
            default -> context.player().launchProjectile(Snowball.class);
        };
        double speed = Math.max(0.0, number(action, "speed", context, 1.0));
        projectile.setVelocity(context.player().getEyeLocation().getDirection().normalize().multiply(speed));
        projectile.setGravity(action.bool("gravity", true));
        if (projectile instanceof Fireball fireball) fireball.setIsIncendiary(action.bool("incendiary", false));
        if (projectile instanceof AbstractArrow arrow) arrow.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
        if (action.settings().containsKey("damage")) {
            projectile.getPersistentDataContainer().set(
                projectileDamageKey,
                PersistentDataType.DOUBLE,
                Math.max(0.0, number(action, "damage", context, 1.0))
            );
        }
    }

    private void heal(AbilityAction action, AbilityContext context) {
        LivingEntity target = target(action, context);
        if (target == null) return;
        double amount = Math.max(0.0, number(action, "amount", context, context.attached().power()));
        AttributeInstance attribute = target.getAttribute(Attribute.MAX_HEALTH);
        double maximum = attribute == null ? 20.0 : attribute.getValue();
        target.setHealth(Math.min(maximum, target.getHealth() + amount));
    }

    private void damage(AbilityAction action, AbilityContext context) {
        LivingEntity target = target(action, context);
        if (target == null) return;
        double amount = Math.max(0.0, number(action, "amount", context, context.attached().power()));
        String mode = action.string("mode", "DIRECT").toUpperCase(Locale.ROOT);
        if (context.event() instanceof EntityDamageByEntityEvent damageEvent && target.equals(damageEvent.getEntity())) {
            if (mode.equals("ADD")) damageEvent.setDamage(damageEvent.getDamage() + amount);
            else if (mode.equals("SET")) damageEvent.setDamage(amount);
            else target.damage(amount, context.player());
        } else {
            target.damage(amount, context.player());
        }
    }

    private void potion(AbilityAction action, AbilityContext context) {
        LivingEntity target = target(action, context);
        if (target == null) return;
        NamespacedKey key = NamespacedKey.fromString(action.string("effect", "minecraft:speed").toLowerCase(Locale.ROOT));
        PotionEffectType effect = key == null ? null : RegistryAccess.registryAccess().getRegistry(RegistryKey.MOB_EFFECT).get(key);
        if (effect == null) throw new IllegalArgumentException("Unknown potion effect");
        int duration = Math.max(1, integer(action, "duration-ticks", context, 100));
        int amplifier = Math.max(0, integer(action, "amplifier", context, 0));
        target.addPotionEffect(new PotionEffect(
            effect,
            duration,
            amplifier,
            action.bool("ambient", true),
            action.bool("particles", false),
            action.bool("icon", true)
        ));
    }

    private void lightning(AbilityAction action, AbilityContext context) {
        Location location = targetLocation(action, context);
        if (location == null) return;
        if (action.bool("real", false)) location.getWorld().strikeLightning(location);
        else location.getWorld().strikeLightningEffect(location);
    }

    private void command(AbilityAction action, AbilityContext context) {
        String command = placeholders(action.string("command", ""), context).strip();
        if (command.startsWith("/")) command = command.substring(1);
        if (command.isBlank()) return;
        if (action.bool("as-player", false)) context.player().performCommand(command);
        else Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
    }

    private void message(AbilityAction action, AbilityContext context, boolean actionBar) {
        String text = placeholders(action.string("text", ""), context);
        if (actionBar) context.player().sendActionBar(Texts.mini(text));
        else context.player().sendMessage(Texts.mini(text));
    }

    private void sound(AbilityAction action, AbilityContext context) {
        NamespacedKey key = NamespacedKey.fromString(action.string("sound", "minecraft:block.note_block.pling").toLowerCase(Locale.ROOT));
        Sound sound = key == null ? null : RegistryAccess.registryAccess().getRegistry(RegistryKey.SOUND_EVENT).get(key);
        if (sound == null) throw new IllegalArgumentException("Unknown sound");
        Location location = targetLocation(action, context);
        if (location != null) location.getWorld().playSound(
            location,
            sound,
            (float) Math.max(0.0, number(action, "volume", context, 1.0)),
            (float) Math.max(0.01, number(action, "pitch", context, 1.0))
        );
    }

    private void particle(AbilityAction action, AbilityContext context) {
        String name = action.string("particle", "HAPPY_VILLAGER").toUpperCase(Locale.ROOT);
        Particle particle;
        try {
            particle = Particle.valueOf(name);
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException("Unknown particle '" + name + "'");
        }
        Location location = targetLocation(action, context);
        if (location == null) return;
        location.add(0.0, number(action, "offset-location-y", context, 1.0), 0.0);
        location.getWorld().spawnParticle(
            particle,
            location,
            Math.max(1, integer(action, "count", context, 1)),
            Math.max(0.0, number(action, "offset-x", context, 0.0)),
            Math.max(0.0, number(action, "offset-y", context, 0.0)),
            Math.max(0.0, number(action, "offset-z", context, 0.0)),
            Math.max(0.0, number(action, "extra", context, 0.0))
        );
    }

    private void fire(AbilityAction action, AbilityContext context) {
        LivingEntity target = target(action, context);
        if (target != null) target.setFireTicks(Math.max(target.getFireTicks(), integer(action, "ticks", context, 60)));
    }

    private void explosion(AbilityAction action, AbilityContext context) {
        Location location = targetLocation(action, context);
        if (location == null) return;
        float power = (float) Math.max(0.0, number(action, "power", context, context.attached().power()));
        location.getWorld().createExplosion(location, power, action.bool("set-fire", false), action.bool("break-blocks", false), context.player());
    }

    private LivingEntity target(AbilityAction action, AbilityContext context) {
        if (action.string("target", "SELF").equalsIgnoreCase("SELF")) return context.player();
        if (context.target() != null) return context.target();
        RayTraceResult result = context.player().getWorld().rayTraceEntities(
            context.player().getEyeLocation(),
            context.player().getEyeLocation().getDirection(),
            Math.max(1.0, number(action, "range", context, 12.0)),
            0.35,
            entity -> entity instanceof LivingEntity && !entity.equals(context.player())
        );
        return result != null && result.getHitEntity() instanceof LivingEntity living ? living : null;
    }

    private Location targetLocation(AbilityAction action, AbilityContext context) {
        LivingEntity entity = target(action, context);
        if (entity != null) return entity.getLocation().clone();
        double range = Math.max(1.0, number(action, "range", context, 12.0));
        RayTraceResult result = context.player().rayTraceBlocks(range);
        return result == null ? null : result.getHitPosition().toLocation(context.player().getWorld());
    }

    private double number(AbilityAction action, String key, AbilityContext context, double fallback) {
        return Expressions.evaluate(action.settings().get(key), variables(context), fallback);
    }

    private int integer(AbilityAction action, String key, AbilityContext context, int fallback) {
        return (int) Math.round(number(action, key, context, fallback));
    }

    private Map<String, Double> variables(AbilityContext context) {
        return Map.of(
            "power", context.attached().power(),
            "damage", context.value(),
            "health", context.player().getHealth(),
            "max_health", maxHealth(context.player()),
            "period", context.ability().trigger() == AbilityTrigger.PASSIVE ? context.value() : 0.0
        );
    }

    private String placeholders(String input, AbilityContext context) {
        String target = context.target() == null ? "" : context.target().getName();
        return input
            .replace("{player}", context.player().getName())
            .replace("{target}", target)
            .replace("{item_id}", context.item().id())
            .replace("{ability_id}", context.ability().id())
            .replace("{power}", String.valueOf(context.attached().power()))
            .replace("{damage}", String.valueOf(context.value()));
    }

    private LivingEntity resolveAttacker(Entity damager) {
        if (damager instanceof LivingEntity living) return living;
        return damager instanceof Projectile projectile && projectile.getShooter() instanceof LivingEntity living ? living : null;
    }

    private boolean ready(Player player, String itemId, AbilityDefinition attached, ConfiguredAbility ability, boolean notify) {
        String key = itemId + ':' + ability.id();
        long now = System.currentTimeMillis();
        long until = cooldowns.getOrDefault(player.getUniqueId(), Map.of()).getOrDefault(key, 0L);
        if (until <= now) return true;
        if (notify) {
            double seconds = Math.ceil((until - now) / 100.0) / 10.0;
            player.sendActionBar(Texts.mini("<red>" + ability.displayName() + " cooldown: " + seconds + "s</red>"));
        }
        return false;
    }

    private void markUsed(Player player, String itemId, AbilityDefinition attached) {
        if (attached.cooldownTicks() <= 0) return;
        String key = itemId + ':' + attached.abilityId();
        long until = System.currentTimeMillis() + attached.cooldownTicks() * 50L;
        cooldowns.computeIfAbsent(player.getUniqueId(), ignored -> new HashMap<>()).put(key, until);
    }

    private double maxHealth(LivingEntity living) {
        AttributeInstance attribute = living.getAttribute(Attribute.MAX_HEALTH);
        return attribute == null ? 20.0 : attribute.getValue();
    }

    private record AbilityContext(
        Player player,
        LivingEntity target,
        CustomItemDefinition item,
        AbilityDefinition attached,
        ConfiguredAbility ability,
        Event event,
        double value
    ) {
    }
}

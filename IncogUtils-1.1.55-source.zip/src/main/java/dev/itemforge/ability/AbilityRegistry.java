package dev.itemforge.ability;

import dev.itemforge.ItemForgePlugin;
import dev.itemforge.util.Ids;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

public final class AbilityRegistry {
    private static final List<String> DEFAULT_RESOURCES = List.of(
        "abilities/README.md",
        "abilities/dash.yml",
        "abilities/fireball.yml",
        "abilities/heal.yml",
        "abilities/lightning.yml",
        "abilities/lifesteal.yml",
        "abilities/speed.yml",
        "abilities/strength.yml",
        "abilities/resistance.yml",
        "abilities/jump_boost.yml",
        "abilities/example_frost_burst.yml"
    );

    private final ItemForgePlugin plugin;
    private final File folder;
    private final Map<String, ConfiguredAbility> abilities = new LinkedHashMap<>();
    private int failedFiles;

    public AbilityRegistry(ItemForgePlugin plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "abilities");
    }

    public void load() {
        ensureDefaults();
        Map<String, ConfiguredAbility> loaded = new LinkedHashMap<>();
        failedFiles = 0;
        try (Stream<java.nio.file.Path> paths = Files.walk(folder.toPath())) {
            paths.filter(Files::isRegularFile)
                .filter(path -> {
                    String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
                    return name.endsWith(".yml") || name.endsWith(".yaml");
                })
                .sorted()
                .forEach(path -> loadFile(path.toFile(), loaded));
        } catch (IOException exception) {
            plugin.problems().error("abilities.scan", "Could not scan the abilities folder", exception);
        }
        abilities.clear();
        loaded.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(entry -> abilities.put(entry.getKey(), entry.getValue()));
    }

    private void ensureDefaults() {
        if (!folder.exists() && !folder.mkdirs()) {
            plugin.problems().warning("abilities.folder", "Could not create the abilities folder");
            return;
        }
        for (String resource : DEFAULT_RESOURCES) {
            File target = new File(plugin.getDataFolder(), resource);
            if (!target.exists()) plugin.saveResource(resource, false);
        }
    }

    private void loadFile(File file, Map<String, ConfiguredAbility> loaded) {
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        if (!yaml.getBoolean("enabled", true)) return;
        String filename = file.getName().replaceFirst("\\.(?i:ya?ml)$", "");
        String id = Ids.normalize(yaml.getString("id", filename));
        try {
            if (!Ids.isValid(id)) throw new IllegalArgumentException("Use a 2-48 character lowercase id");
            if (loaded.containsKey(id)) throw new IllegalArgumentException("Duplicate ability id '" + id + "'");
            String displayName = yaml.getString("display-name", "<gold>" + id + "</gold>");
            List<String> description = new ArrayList<>(yaml.getStringList("description"));
            if (description.isEmpty() && yaml.isString("description")) description.add(yaml.getString("description", ""));
            Material icon = Material.matchMaterial(yaml.getString("icon", "BLAZE_POWDER"));
            if (icon == null || !icon.isItem()) throw new IllegalArgumentException("Invalid icon material");
            AbilityTrigger trigger = AbilityTrigger.valueOf(yaml.getString("trigger", "RIGHT_CLICK").toUpperCase(Locale.ROOT));
            double defaultPower = yaml.getDouble("default-power", 1.0);
            int defaultCooldown = yaml.getInt("default-cooldown-ticks", 0);
            if (!Double.isFinite(defaultPower) || defaultPower < 0.0) throw new IllegalArgumentException("default-power must be zero or greater");
            if (defaultCooldown < 0) throw new IllegalArgumentException("default-cooldown-ticks cannot be negative");

            List<AbilityAction> actions = new ArrayList<>();
            for (Map<?, ?> action : yaml.getMapList("actions")) actions.add(AbilityAction.fromMap(action));
            if (actions.isEmpty()) throw new IllegalArgumentException("At least one action is required");

            loaded.put(id, new ConfiguredAbility(
                id, displayName, description, icon, trigger, yaml.getBoolean("require-player-target", false), defaultPower, defaultCooldown,
                yaml.getBoolean("cancel-trigger", false), yaml.getString("permission", ""), actions
            ));
        } catch (RuntimeException exception) {
            failedFiles++;
            plugin.problems().error("abilities.file." + file.getName(), "Could not load ability file '" + file.getName() + "'", exception);
        }
    }

    public Optional<ConfiguredAbility> get(String id) {
        return Optional.ofNullable(abilities.get(Ids.normalize(id)));
    }

    public Collection<ConfiguredAbility> all() {
        return List.copyOf(abilities.values());
    }

    public List<String> ids() {
        return abilities.keySet().stream().sorted().toList();
    }

    public int failedFiles() {
        return failedFiles;
    }

    public File folder() {
        return folder;
    }
}

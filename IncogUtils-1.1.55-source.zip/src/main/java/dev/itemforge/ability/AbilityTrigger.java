package dev.itemforge.ability;

public enum AbilityTrigger {
    RIGHT_CLICK,
    LEFT_CLICK,
    MELEE_HIT,
    DAMAGED,
    KILL,
    SNEAK,
    PASSIVE
}

package dev.itemforge.ability;

import org.bukkit.Material;

import java.util.List;

public record ConfiguredAbility(
    String id,
    String displayName,
    List<String> description,
    Material icon,
    AbilityTrigger trigger,
    boolean requirePlayerTarget,
    double defaultPower,
    int defaultCooldownTicks,
    boolean cancelTrigger,
    String permission,
    List<AbilityAction> actions
) {
    public ConfiguredAbility {
        description = List.copyOf(description == null ? List.of() : description);
        actions = List.copyOf(actions == null ? List.of() : actions);
        permission = permission == null ? "" : permission.trim();
    }
}

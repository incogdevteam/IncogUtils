package dev.itemforge.command;

import dev.itemforge.ItemForgePlugin;
import dev.itemforge.gui.MenuService;
import dev.itemforge.model.CustomItemDefinition;
import dev.itemforge.util.Ids;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ItemForgeCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUBCOMMANDS = List.of("catalog", "create", "edit", "recipe", "give", "duplicate", "delete", "list", "abilities", "inspect", "logging", "reload", "help");
    private final ItemForgePlugin plugin;
    private final MenuService menus;

    public ItemForgeCommand(ItemForgePlugin plugin, MenuService menus) {
        this.plugin = plugin;
        this.menus = menus;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("catalog")) {
            if (!(sender instanceof Player player)) {
                plugin.message(sender, "<red>The custom-item catalog must be opened in-game.</red>");
                return true;
            }
            if (!player.hasPermission("itemforge.catalog")) {
                plugin.message(player, "<red>You do not have permission to open the custom-item catalog.</red>");
                return true;
            }
            menus.openCatalog(player);
            return true;
        }
        if (!sender.hasPermission("itemforge.admin")) {
            plugin.message(sender, "<red>You do not have permission to manage custom items.</red>");
            return true;
        }
        if (args.length == 0) {
            if (sender instanceof Player player) menus.openDashboard(player);
            else help(sender, label);
            return true;
        }
        try {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "create" -> create(sender, label, args);
                case "edit" -> edit(sender, label, args);
                case "recipe" -> recipe(sender, label, args);
                case "give" -> give(sender, label, args);
                case "duplicate", "copy" -> duplicate(sender, label, args);
                case "delete" -> delete(sender, label, args);
                case "list" -> list(sender);
                case "abilities" -> abilities(sender, label, args);
                case "inspect" -> inspect(sender);
                case "logging", "logs" -> logging(sender, label, args);
                case "reload" -> {
                    plugin.reloadEverything();
                    plugin.message(sender, "<green>Reloaded config, items, recipes, and abilities.</green>");
                }
                case "help" -> help(sender, label);
                default -> help(sender, label);
            }
        } catch (IllegalArgumentException exception) {
            plugin.message(sender, "<red>" + exception.getMessage() + ".</red>");
        }
        return true;
    }

    private void create(CommandSender sender, String label, String[] args) {
        if (args.length < 2) throw new IllegalArgumentException("Usage: /" + label + " create <id> [material]");
        Material material = args.length >= 3 ? Material.matchMaterial(args[2]) : Material.STONE;
        CustomItemDefinition item = plugin.items().create(args[1], material);
        plugin.message(sender, "<green>Created <white>" + item.id() + "</white>.</green>");
        if (sender instanceof Player player) menus.openEditor(player, item.id());
    }

    private void edit(CommandSender sender, String label, String[] args) {
        Player player = requirePlayer(sender);
        if (args.length < 2) throw new IllegalArgumentException("Usage: /" + label + " edit <id>");
        if (plugin.items().get(args[1]).isEmpty()) throw new IllegalArgumentException("Unknown item id");
        menus.openEditor(player, args[1]);
    }

    private void recipe(CommandSender sender, String label, String[] args) {
        Player player = requirePlayer(sender);
        if (args.length < 2) throw new IllegalArgumentException("Usage: /" + label + " recipe <id>");
        if (plugin.items().get(args[1]).isEmpty()) throw new IllegalArgumentException("Unknown item id");
        menus.openRecipe(player, args[1]);
    }

    private void give(CommandSender sender, String label, String[] args) {
        if (args.length < 3) throw new IllegalArgumentException("Usage: /" + label + " give <player> <id> [amount]");
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) throw new IllegalArgumentException("That player is not online");
        int amount = args.length >= 4 ? Integer.parseInt(args[3]) : 1;
        if (amount < 1) throw new IllegalArgumentException("Amount must be at least 1");
        ItemStack stack = plugin.items().build(args[2], amount);
        if (stack == null) throw new IllegalArgumentException("Unknown item id");
        target.getInventory().addItem(stack).values().forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
        plugin.message(sender, "<green>Gave <white>" + target.getName() + "</white> " + stack.getAmount() + "× <white>" + Ids.normalize(args[2]) + "</white>.</green>");
    }

    private void duplicate(CommandSender sender, String label, String[] args) {
        if (args.length < 3) throw new IllegalArgumentException("Usage: /" + label + " duplicate <source> <new-id>");
        CustomItemDefinition copy = plugin.items().duplicate(args[1], args[2]);
        plugin.recipes().registerAll();
        plugin.message(sender, "<green>Duplicated as <white>" + copy.id() + "</white>.</green>");
        if (sender instanceof Player player) menus.openEditor(player, copy.id());
    }

    private void delete(CommandSender sender, String label, String[] args) {
        if (args.length < 3 || !args[2].equalsIgnoreCase("confirm")) {
            throw new IllegalArgumentException("To delete permanently: /" + label + " delete <id> confirm");
        }
        if (!plugin.items().delete(args[1])) throw new IllegalArgumentException("Unknown item id");
        plugin.recipes().registerAll();
        plugin.message(sender, "<yellow>Deleted <white>" + Ids.normalize(args[1]) + "</white>.</yellow>");
    }

    private void list(CommandSender sender) {
        List<String> ids = plugin.items().ids();
        plugin.message(sender, ids.isEmpty()
            ? "<yellow>No custom items yet. Use /itemforge to create one.</yellow>"
            : "<gold>Items (" + ids.size() + "):</gold> <white>" + String.join("<gray>,</gray> ", ids) + "</white>");
    }

    private void inspect(CommandSender sender) {
        Player player = requirePlayer(sender);
        plugin.items().identify(player.getInventory().getItemInMainHand()).ifPresentOrElse(
            id -> plugin.message(player, "<green>This is ItemForge item <white>" + id + "</white>.</green>"),
            () -> plugin.message(player, "<yellow>The item in your hand is not an ItemForge item.</yellow>"));
    }

    private void abilities(CommandSender sender, String label, String[] args) {
        if (args.length >= 2) {
            if (!args[1].equalsIgnoreCase("reload")) {
                throw new IllegalArgumentException("Use /" + label + " abilities [reload]");
            }
            plugin.reloadEverything();
            int failed = plugin.abilityRegistry().failedFiles();
            plugin.message(sender, "<green>Loaded <white>" + plugin.abilityRegistry().all().size() + "</white> abilities.</green>"
                + (failed == 0 ? "" : " <yellow>" + failed + " file(s) had problems; check the quiet-mode summary.</yellow>"));
            return;
        }
        List<String> ids = plugin.abilityRegistry().ids();
        plugin.message(sender, ids.isEmpty()
            ? "<yellow>No abilities are loaded. Add YAML files under plugins/ItemForge/abilities.</yellow>"
            : "<gold>Abilities (" + ids.size() + "):</gold> <white>" + String.join("<gray>,</gray> ", ids) + "</white>"
                + "<newline><gray>Edit YAML under plugins/ItemForge/abilities, then run /" + label + " abilities reload.</gray>");
    }

    private void logging(CommandSender sender, String label, String[] args) {
        if (args.length < 2) {
            plugin.message(sender, "<gold>Logging mode:</gold> <white>" + (plugin.problems().quiet() ? "quiet" : "normal") + "</white>. "
                + "<gray>Use /" + label + " logging quiet|normal</gray>");
            return;
        }
        if (args[1].equalsIgnoreCase("quiet")) plugin.problems().setQuiet(true);
        else if (args[1].equalsIgnoreCase("normal")) plugin.problems().setQuiet(false);
        else throw new IllegalArgumentException("Use /" + label + " logging quiet|normal");
        plugin.message(sender, plugin.problems().quiet()
            ? "<green>Quiet logging enabled. Repeated problems will be rate-limited.</green>"
            : "<yellow>Normal logging enabled. Every problem will be logged.</yellow>");
    }

    private void help(CommandSender sender, String label) {
        sender.sendMessage(Component.text(" "));
        plugin.message(sender, "<gradient:#ff9d2e:#ff4d6d><bold>ItemForge commands</bold></gradient>");
        sender.sendMessage(Component.text("/" + label + " — open the item browser"));
        sender.sendMessage(Component.text("/" + label + " catalog — browse and take custom items without editor access"));
        sender.sendMessage(Component.text("/" + label + " create <id> [material]"));
        sender.sendMessage(Component.text("/" + label + " edit <id>"));
        sender.sendMessage(Component.text("/" + label + " recipe <id>"));
        sender.sendMessage(Component.text("/" + label + " give <player> <id> [amount]"));
        sender.sendMessage(Component.text("/" + label + " duplicate <source> <new-id>"));
        sender.sendMessage(Component.text("/" + label + " delete <id> confirm"));
        sender.sendMessage(Component.text("/" + label + " list | inspect | reload"));
        sender.sendMessage(Component.text("/" + label + " abilities [reload]"));
        sender.sendMessage(Component.text("/" + label + " logging quiet|normal"));
    }

    private Player requirePlayer(CommandSender sender) {
        if (sender instanceof Player player) return player;
        throw new IllegalArgumentException("This command requires an in-game player");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("itemforge.admin")) return List.of();
        List<String> candidates = new ArrayList<>();
        if (args.length == 1) candidates.addAll(SUBCOMMANDS);
        else if (args.length == 2 && List.of("edit", "recipe", "duplicate", "delete").contains(args[0].toLowerCase(Locale.ROOT))) candidates.addAll(plugin.items().ids());
        else if (args.length == 2 && args[0].equalsIgnoreCase("give")) Bukkit.getOnlinePlayers().forEach(player -> candidates.add(player.getName()));
        else if (args.length == 3 && args[0].equalsIgnoreCase("give")) candidates.addAll(plugin.items().ids());
        else if (args.length == 3 && args[0].equalsIgnoreCase("delete")) candidates.add("confirm");
        else if (args.length == 2 && args[0].equalsIgnoreCase("logging")) candidates.addAll(List.of("quiet", "normal"));
        else if (args.length == 2 && args[0].equalsIgnoreCase("abilities")) candidates.add("reload");
        String typed = args[args.length - 1].toLowerCase(Locale.ROOT);
        return candidates.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(typed)).sorted().toList();
    }
}

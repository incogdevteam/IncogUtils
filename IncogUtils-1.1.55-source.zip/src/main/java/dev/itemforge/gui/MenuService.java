package dev.itemforge.gui;

import dev.itemforge.ItemForgePlugin;
import dev.itemforge.ability.ConfiguredAbility;
import dev.itemforge.model.AbilityDefinition;
import dev.itemforge.model.AttributeDefinition;
import dev.itemforge.model.AttributeSlot;
import dev.itemforge.model.AttributeType;
import dev.itemforge.model.CustomItemDefinition;
import dev.itemforge.model.DropRule;
import dev.itemforge.model.DropType;
import dev.itemforge.model.RecipeDefinition;
import dev.itemforge.util.Ids;
import dev.itemforge.util.Texts;
import com.incog.vaults.ItemFactory;
import com.incog.vaults.VaultType;
import com.incogdev.incogclaims.listeners.EnchantListener;
import io.papermc.paper.registry.RegistryAccess;
import io.papermc.paper.registry.RegistryKey;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemRarity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Comparator;
import java.util.function.Consumer;
import java.util.function.Supplier;

public final class MenuService implements Listener {
    private static final int[] RECIPE_GRID = {10, 11, 12, 19, 20, 21, 28, 29, 30};
    private final ItemForgePlugin plugin;

    public MenuService(ItemForgePlugin plugin) {
        this.plugin = plugin;
    }

    public void openDashboard(Player player) {
        openDashboard(player, 0);
    }

    /** Read-only creative-builder catalog. Unlike the admin dashboard it never exposes editor actions. */
    public void openCatalog(Player player) {
        openCatalog(player, 0);
    }

    private void openCatalog(Player player, int requestedPage) {
        List<CatalogEntry> all = catalogEntries();
        int pages = Math.max(1, (all.size() + 44) / 45);
        int page = Math.max(0, Math.min(requestedPage, pages - 1));
        CatalogHolder holder = new CatalogHolder(page);
        Inventory inventory = holder.create(54, "<gradient:#60A5FA:#A78BFA>Custom Item Catalog</gradient> <gray>• " + (page + 1) + "/" + pages);
        paint(inventory);
        int from = page * 45;
        int to = Math.min(all.size(), from + 45);
        for (int index = from; index < to; index++) {
            CatalogEntry entry = all.get(index);
            int slot = index - from;
            ItemStack preview = entry.create();
            if (preview == null || preview.isEmpty()) continue;
            appendLore(preview, "<dark_gray>────────────</dark_gray>",
                "<gray>Source: <white>" + entry.source() + "</white></gray>",
                "<gray>ID: <white>" + entry.id() + "</white></gray>",
                "<green>Click to take one</green>");
            inventory.setItem(slot, preview);
            holder.entries.put(slot, entry);
        }
        inventory.setItem(45, page > 0
                ? button(Material.ARROW, "<yellow>Previous page</yellow>")
                : button(Material.ARROW, "<yellow><bold>Back to Menus</bold></yellow>",
                        "<gray>Return to the IncogUtils menu hub.</gray>"));
        inventory.setItem(49, button(Material.CHEST_MINECART, "<green>Unified Creative Catalog</green>",
            "<gray>" + all.size() + " custom items • Click an item to take one</gray>"));
        if (page + 1 < pages) inventory.setItem(53, button(Material.ARROW, "<yellow>Next page</yellow>"));
        player.openInventory(inventory);
    }

    /** Builds every real, giveable custom item owned by the bundled IncogUtils modules. */
    private List<CatalogEntry> catalogEntries() {
        List<CatalogEntry> entries = new ArrayList<>();
        for (CustomItemDefinition definition : plugin.items().all()) {
            entries.add(new CatalogEntry("ItemForge", definition.id(), () -> plugin.items().build(definition, 1)));
        }

        var host = plugin.host();
        host.configs().get().items().values().stream()
                .filter(com.incogdev.incogrpg.model.CustomItemDefinition::enabled)
                .forEach(definition -> entries.add(new CatalogEntry("IncogRPG", definition.id(),
                        () -> host.customItems().create(definition, 1))));
        host.configs().get().enchants().values().forEach(definition -> entries.add(new CatalogEntry(
                "IncogRPG Enchant", definition.id() + " " + definition.maxLevel(),
                () -> host.enchants().book(definition, definition.maxLevel()))));

        if (host.claimsModule() != null) {
            entries.add(new CatalogEntry("Claims", "claim_core", () -> host.claimsModule().createClaimCore(false)));
            entries.add(new CatalogEntry("Claims", "additional_claim_core", () -> host.claimsModule().createClaimCore(true)));
            entries.add(new CatalogEntry("Claims", "claim_breaker", () -> EnchantListener.buildClaimBreakerPickaxe(host.claimsModule())));
        }
        if (host.vaultsModule() != null) {
            entries.add(new CatalogEntry("Vaults", "vault_regen_key", () -> ItemFactory.createRegenKey(host, VaultType.NORMAL)));
            entries.add(new CatalogEntry("Vaults", "ominous_vault_regen_key", () -> ItemFactory.createRegenKey(host, VaultType.OMINOUS)));
        }
        if (host.economyModuleAvailable() && host.economyModule().sellWands() != null) {
            entries.add(new CatalogEntry("Market", "sell_wand", () -> host.economyModule().sellWands().createWand()));
        }
        entries.sort(Comparator.comparing(CatalogEntry::source).thenComparing(CatalogEntry::id));
        return entries;
    }

    private void openDashboard(Player player, int requestedPage) {
        List<CustomItemDefinition> all = new ArrayList<>(plugin.items().all());
        int pages = Math.max(1, (all.size() + 44) / 45);
        int page = Math.max(0, Math.min(requestedPage, pages - 1));
        DashboardHolder holder = new DashboardHolder(page);
        Inventory inventory = holder.create(54, "<gradient:#ff9d2e:#ff4d6d>ItemForge</gradient> <gray>• " + (page + 1) + "/" + pages);
        paint(inventory);
        int from = page * 45;
        int to = Math.min(all.size(), from + 45);
        for (int index = from; index < to; index++) {
            CustomItemDefinition definition = all.get(index);
            int slot = index - from;
            ItemStack preview = plugin.items().build(definition, 1);
            appendLore(preview,
                "<dark_gray>────────────</dark_gray>",
                "<gray>ID: <white>" + definition.id() + "</white></gray>",
                "<yellow>Click to edit</yellow>");
            inventory.setItem(slot, preview);
            holder.ids.put(slot, definition.id());
        }
        inventory.setItem(45, page > 0
                ? button(Material.ARROW, "<yellow>Previous page</yellow>")
                : button(Material.ARROW, "<yellow><bold>Back to Menus</bold></yellow>",
                        "<gray>Return to the IncogUtils menu hub.</gray>"));
        inventory.setItem(49, button(Material.LIME_DYE, "<green><bold>Create item</bold></green>",
            "<gray>A two-step guided setup</gray>"));
        if (page + 1 < pages) inventory.setItem(53, button(Material.ARROW, "<yellow>Next page</yellow>"));
        player.openInventory(inventory);
    }

    public void openEditor(Player player, String id) {
        CustomItemDefinition item = plugin.items().get(id).orElse(null);
        if (item == null) {
            plugin.message(player, "<red>That item no longer exists.</red>");
            openDashboard(player);
            return;
        }
        EditorHolder holder = new EditorHolder(item.id());
        Inventory inventory = holder.create(54, "<gold>Edit:</gold> <white>" + item.id() + "</white>");
        paint(inventory);
        ItemStack preview = plugin.items().build(item, 1);
        appendLore(preview, "<dark_gray>────────────</dark_gray>", "<gray>Live preview</gray>");
        inventory.setItem(4, preview);
        inventory.setItem(10, button(item.material(), "<aqua>Material</aqua>",
            "<white>" + item.material().name() + "</white>", "<yellow>Click, then type a material</yellow>"));
        inventory.setItem(11, button(Material.NAME_TAG, "<aqua>Display name</aqua>",
            item.name(), "<yellow>Click to edit with MiniMessage</yellow>"));
        inventory.setItem(12, button(Material.WRITABLE_BOOK, "<aqua>Lore</aqua>",
            "<white>" + item.lore().size() + " line(s)</white>", "<yellow>Click to edit; separate lines with |</yellow>"));
        inventory.setItem(13, button(Material.ENCHANTED_BOOK, "<light_purple>Enchantments</light_purple>",
            "<white>" + item.enchantments().size() + " configured</white>", "<yellow>Click to manage</yellow>"));
        inventory.setItem(14, button(Material.BLAZE_POWDER, "<red>Abilities</red>",
            "<white>" + item.abilities().size() + " active/passive</white>", "<yellow>Click to manage</yellow>"));
        inventory.setItem(15, button(Material.CRAFTING_TABLE, "<gold>Custom recipe</gold>",
            state(item.recipe().enabled()) + " <gray>•</gray> <white>" + (item.recipe().shapeless() ? "Shapeless" : "Shaped") + "</white>",
            "<yellow>Click to edit the 3×3 recipe</yellow>"));
        inventory.setItem(16, button(Material.CHEST, "<gold>Loot & drops</gold>",
            "<white>" + item.dropRules().size() + " drop rule(s)</white>", "<yellow>Click to manage</yellow>"));

        inventory.setItem(19, button(Material.ITEM_FRAME, "<aqua>Resource-pack model</aqua>",
            "<gray>Item model: <white>" + value(item.itemModel()) + "</white></gray>",
            "<gray>Custom model data: <white>" + value(item.customModelData()) + "</white></gray>",
            "<yellow>Left: item model • Right: model data</yellow>"));
        inventory.setItem(20, button(Material.LEATHER_CHESTPLATE, "<aqua>Leather color</aqua>",
            "<white>" + value(item.leatherColor()) + "</white>", "<gray>Use #RRGGBB; applies to leather armor</gray>"));
        inventory.setItem(21, toggle(Material.OBSIDIAN, "Unbreakable", item.unbreakable()));
        inventory.setItem(22, toggle(Material.GLOW_INK_SAC, "Forced enchant glint", item.glint()));
        inventory.setItem(23, toggle(Material.PAPER, "Hide entire tooltip", item.hideTooltip()));
        inventory.setItem(24, button(Material.SLIME_BALL, "<aqua>Max stack size</aqua>",
            "<white>" + value(item.maxStackSize()) + "</white>",
            item.maxDurability() == null ? "<yellow>Click to set 1-99, or none</yellow>" : "<red>Locked to 1 while custom durability is set</red>"));
        inventory.setItem(25, button(Material.SPYGLASS, "<aqua>Tooltip details</aqua>",
            "<gray>Enchantments: " + onOff(!item.hideEnchantments()) + "</gray>",
            "<gray>Attributes: " + onOff(!item.hideAttributes()) + "</gray>",
            "<yellow>Left: enchants • Right: attributes</yellow>"));
        inventory.setItem(26, button(Material.NETHER_STAR, "<aqua>Item rarity</aqua>",
            "<white>" + item.rarity().name() + "</white>", "<yellow>Click to cycle</yellow>"));
        inventory.setItem(27, button(Material.DIAMOND_PICKAXE, "<aqua>Maximum durability</aqua>",
            "<white>" + value(item.maxDurability()) + "</white>",
            "<gray>Custom vanilla durability; items stack to one</gray>",
            "<yellow>Click to set a positive value, or none</yellow>"));
        inventory.setItem(31, button(Material.ANVIL, "<aqua>Attribute modifiers</aqua>",
            "<white>" + item.attributes().size() + " configured</white>",
            "<gray>Damage, speed, armor, health, and more</gray>", "<yellow>Click to manage</yellow>"));

        inventory.setItem(40, button(Material.CHEST_MINECART, "<green>Give yourself one</green>"));
        inventory.setItem(45, button(Material.ARROW, "<yellow>Back to item list</yellow>"));
        inventory.setItem(53, button(Material.LIME_DYE, "<green><bold>Done</bold></green>", "<gray>Changes save immediately</gray>"));
        player.openInventory(inventory);
    }

    private void openEnchantments(Player player, String id) {
        CustomItemDefinition item = requireItem(player, id);
        if (item == null) return;
        EnchantmentHolder holder = new EnchantmentHolder(id);
        Inventory inventory = holder.create(54, "<light_purple>Enchantments:</light_purple> <white>" + id);
        paint(inventory);
        int slot = 0;
        for (Map.Entry<String, Integer> enchantment : item.enchantments().entrySet()) {
            if (slot >= 45) break;
            inventory.setItem(slot, button(Material.ENCHANTED_BOOK, "<light_purple>" + enchantment.getKey() + "</light_purple>",
                "<gray>Level: <white>" + enchantment.getValue() + "</white></gray>",
                "<yellow>Left: edit level • Right: remove</yellow>"));
            holder.keys.put(slot, enchantment.getKey());
            slot++;
        }
        inventory.setItem(45, button(Material.ARROW, "<yellow>Back</yellow>"));
        inventory.setItem(49, button(Material.LIME_DYE, "<green>Add enchantment</green>",
            "<gray>Example: sharpness 5</gray>"));
        player.openInventory(inventory);
    }

    private void openAbilities(Player player, String id) {
        openAbilities(player, id, 0);
    }

    private void openAbilities(Player player, String id, int requestedPage) {
        CustomItemDefinition item = requireItem(player, id);
        if (item == null) return;
        List<ConfiguredAbility> configured = new ArrayList<>(plugin.abilityRegistry().all());
        int pages = Math.max(1, (configured.size() + 26) / 27);
        int page = Math.max(0, Math.min(requestedPage, pages - 1));
        AbilityHolder holder = new AbilityHolder(id, page);
        Inventory inventory = holder.create(54, "<red>Abilities:</red> <white>" + id + "</white> <gray>• " + (page + 1) + "/" + pages);
        paint(inventory);
        int from = page * 27;
        int to = Math.min(configured.size(), from + 27);
        for (int index = from; index < to; index++) {
            ConfiguredAbility ability = configured.get(index);
            int slot = index - from;
            List<String> lore = new ArrayList<>(ability.description());
            lore.add("<dark_gray>Trigger: " + ability.trigger().name().replace('_', ' ') + "</dark_gray>");
            lore.add("<dark_gray>Power " + ability.defaultPower() + " • " + seconds(ability.defaultCooldownTicks()) + "s cooldown</dark_gray>");
            lore.add("<yellow>Click to add</yellow>");
            inventory.setItem(slot, button(ability.icon(), "<gold>Add</gold> " + ability.displayName(), lore.toArray(String[]::new)));
            holder.presets.put(slot, ability.id());
        }
        for (int index = 0; index < item.abilities().size() && index < 18; index++) {
            AbilityDefinition attached = item.abilities().get(index);
            ConfiguredAbility ability = plugin.abilityRegistry().get(attached.abilityId()).orElse(null);
            int slot = 27 + index;
            Material icon = ability == null ? Material.BARRIER : ability.icon();
            String name = ability == null ? "<red>Missing: " + attached.abilityId() + "</red>" : "<green>" + ability.displayName() + "</green>";
            inventory.setItem(slot, button(icon, name,
                "<gray>ID: <white>" + attached.abilityId() + "</white></gray>",
                "<gray>Power: <white>" + attached.power() + "</white></gray>",
                "<gray>Cooldown: <white>" + seconds(attached.cooldownTicks()) + "s</white></gray>",
                ability == null ? "<red>Add its YAML file to activate it</red>" : "<yellow>Left: tune • Right: remove</yellow>"));
            holder.abilities.put(slot, index);
        }
        if (page > 0) inventory.setItem(45, button(Material.ARROW, "<yellow>Previous ability page</yellow>"));
        inventory.setItem(46, button(Material.OAK_DOOR, "<yellow>Back to item</yellow>"));
        inventory.setItem(49, button(Material.NAME_TAG, "<green>Add ability by ID</green>",
            "<gray>Useful after adding a new YAML file</gray>"));
        if (page + 1 < pages) inventory.setItem(53, button(Material.ARROW, "<yellow>Next ability page</yellow>"));
        player.openInventory(inventory);
    }

    private void openDrops(Player player, String id) {
        CustomItemDefinition item = requireItem(player, id);
        if (item == null) return;
        DropHolder holder = new DropHolder(id);
        Inventory inventory = holder.create(54, "<gold>Loot & drops:</gold> <white>" + id);
        paint(inventory);
        inventory.setItem(10, button(Material.ZOMBIE_HEAD, "<green>Add mob drop</green>",
            "<gray>Example: zombie 5 1 2</gray>", "<dark_gray>source • chance% • min • max</dark_gray>"));
        inventory.setItem(12, button(Material.DIAMOND_ORE, "<green>Add block drop</green>",
            "<gray>Example: diamond_ore 2.5 1 1</gray>"));
        inventory.setItem(14, button(Material.CHEST, "<green>Add loot-table drop</green>",
            "<gray>Example: minecraft:chests/simple_dungeon 8 1 1</gray>"));
        for (int index = 0; index < item.dropRules().size() && index < 18; index++) {
            DropRule rule = item.dropRules().get(index);
            int slot = 27 + index;
            inventory.setItem(slot, button(dropIcon(rule.type()), "<gold>" + rule.type().name().replace('_', ' ') + "</gold>",
                "<gray>Source: <white>" + rule.source() + "</white></gray>",
                "<gray>Chance: <white>" + rule.chancePercent() + "%</white></gray>",
                "<gray>Amount: <white>" + rule.minAmount() + "-" + rule.maxAmount() + "</white></gray>",
                "<yellow>Left: tune • Right: remove</yellow>"));
            holder.rules.put(slot, index);
        }
        inventory.setItem(45, button(Material.ARROW, "<yellow>Back</yellow>"));
        player.openInventory(inventory);
    }

    private void openAttributes(Player player, String id) {
        CustomItemDefinition item = requireItem(player, id);
        if (item == null) return;
        AttributeHolder holder = new AttributeHolder(id);
        Inventory inventory = holder.create(54, "<aqua>Attributes:</aqua> <white>" + id);
        paint(inventory);
        AttributeType[] types = AttributeType.values();
        for (int index = 0; index < types.length; index++) {
            AttributeType type = types[index];
            int slot = 9 + index;
            inventory.setItem(slot, button(type.icon(), "<gold>Add " + type.displayName() + "</gold>",
                "<gray>Amount: <white>" + type.defaultAmount() + "</white></gray>",
                "<gray>Slot: <white>" + type.defaultSlot().name() + "</white></gray>"));
            holder.presets.put(slot, type);
        }
        for (int index = 0; index < item.attributes().size() && index < 18; index++) {
            AttributeDefinition attribute = item.attributes().get(index);
            int slot = 27 + index;
            inventory.setItem(slot, button(attribute.type().icon(), "<green>" + attribute.type().displayName() + "</green>",
                "<gray>Amount: <white>" + attribute.amount() + "</white></gray>",
                "<gray>Operation: <white>" + attribute.operation().name() + "</white></gray>",
                "<gray>Slot: <white>" + attribute.slot().name() + "</white></gray>",
                "<yellow>Left: tune • Right: remove</yellow>"));
            holder.attributes.put(slot, index);
        }
        inventory.setItem(45, button(Material.ARROW, "<yellow>Back</yellow>"));
        player.openInventory(inventory);
    }

    public void openRecipe(Player player, String id) {
        CustomItemDefinition item = requireItem(player, id);
        if (item == null) return;
        RecipeHolder holder = new RecipeHolder(id, item.recipe().shapeless());
        Inventory inventory = holder.create(54, "<gold>Recipe:</gold> <white>" + id);
        paint(inventory);
        for (int slot : RECIPE_GRID) inventory.clear(slot);
        RecipeDefinition recipe = item.recipe();
        for (int gridIndex = 0; gridIndex < 9; gridIndex++) {
            char key = recipe.shape().get(gridIndex / 3).charAt(gridIndex % 3);
            if (key == ' ') continue;
            ItemStack ingredient = ingredientStack(recipe.ingredients().get(key));
            if (ingredient != null) inventory.setItem(RECIPE_GRID[gridIndex], ingredient);
        }
        inventory.setItem(16, recipeTypeButton(holder.shapeless));
        ItemStack result = plugin.items().build(item, 1);
        appendLore(result, "<dark_gray>────────────</dark_gray>", "<gray>Crafting result</gray>");
        inventory.setItem(24, result);
        inventory.setItem(45, button(Material.ARROW, "<yellow>Cancel and go back</yellow>"));
        inventory.setItem(49, button(Material.LIME_DYE, "<green><bold>Save recipe</bold></green>",
            "<gray>An empty grid disables crafting</gray>"));
        inventory.setItem(53, button(Material.BARRIER, "<red>Clear grid</red>"));
        player.openInventory(inventory);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        InventoryHolder rawHolder = event.getView().getTopInventory().getHolder();
        if (!(rawHolder instanceof BaseHolder holder)) return;

        if (holder instanceof RecipeHolder recipe) {
            handleRecipeClick(event, player, recipe);
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;
        int slot = event.getRawSlot();

        if (holder instanceof DashboardHolder dashboard) {
            String id = dashboard.ids.get(slot);
            if (id != null) openEditor(player, id);
            else if (slot == 45) {
                if (dashboard.page > 0) openDashboard(player, dashboard.page - 1);
                else player.performCommand("menus");
            }
            else if (slot == 49) beginCreate(player);
            else if (slot == 53) openDashboard(player, dashboard.page + 1);
        } else if (holder instanceof CatalogHolder catalog) {
            CatalogEntry entry = catalog.entries.get(slot);
            if (entry != null) {
                ItemStack item = entry.create();
                if (item == null) {
                    plugin.message(player, "<red>That item no longer exists.</red>");
                    openCatalog(player, catalog.page);
                    return;
                }
                player.getInventory().addItem(item).values().forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
                plugin.message(player, "<green>Added <white>" + entry.id() + "</white> to your inventory.</green>");
            } else if (slot == 45) {
                if (catalog.page > 0) openCatalog(player, catalog.page - 1);
                else player.performCommand("menus");
            }
            else if (slot == 53) openCatalog(player, catalog.page + 1);
        } else if (holder instanceof EditorHolder editor) {
            handleEditorClick(player, editor.id, slot, event.isRightClick());
        } else if (holder instanceof EnchantmentHolder enchantments) {
            handleEnchantmentClick(player, enchantments, slot, event.isRightClick());
        } else if (holder instanceof AbilityHolder abilities) {
            handleAbilityClick(player, abilities, slot, event.isRightClick());
        } else if (holder instanceof DropHolder drops) {
            handleDropClick(player, drops, slot, event.isRightClick());
        } else if (holder instanceof AttributeHolder attributes) {
            handleAttributeClick(player, attributes, slot, event.isRightClick());
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof RecipeHolder) {
            int topSize = event.getView().getTopInventory().getSize();
            if (event.getRawSlots().stream().anyMatch(slot -> slot < topSize)) event.setCancelled(true);
        }
    }

    private void beginCreate(Player player) {
        plugin.prompts().ask(player,
            Texts.mini("<gold><bold>New item ID</bold></gold><newline><gray>Example: <white>ember_blade</white></gray>"),
            input -> {
                String id = Ids.normalize(input);
                if (!Ids.isValid(id) || plugin.items().get(id).isPresent()) {
                    plugin.message(player, "<red>Use a unique 2-48 character ID with letters, numbers, _ or -.</red>");
                    openDashboard(player);
                    return;
                }
                plugin.prompts().ask(player,
                    Texts.mini("<gold><bold>Starting material</bold></gold><newline><gray>Example: <white>diamond_sword</white></gray>"),
                    materialInput -> {
                        Material material = Material.matchMaterial(materialInput);
                        if (material == null || material.isAir() || !material.isItem()) {
                            plugin.message(player, "<red>That is not a valid item material.</red>");
                            openDashboard(player);
                            return;
                        }
                        plugin.items().create(id, material);
                        plugin.message(player, "<green>Created <white>" + id + "</white>.</green>");
                        openEditor(player, id);
                    }, () -> openDashboard(player));
            }, () -> openDashboard(player));
    }

    private void handleEditorClick(Player player, String id, int slot, boolean rightClick) {
        CustomItemDefinition item = requireItem(player, id);
        if (item == null) return;
        switch (slot) {
            case 10 -> askEditor(player, id,
                "<gold>Type a material</gold><newline><gray>Example: diamond_sword</gray>", input -> {
                    Material material = Material.matchMaterial(input);
                    if (material == null || material.isAir() || !material.isItem()) throw new IllegalArgumentException("Invalid item material");
                    item.setMaterial(material);
                });
            case 11 -> askEditor(player, id,
                "<gold>Type the display name</gold><newline><gray>MiniMessage works: &lt;gradient:red:gold&gt;Sunblade&lt;/gradient&gt;</gray>", item::setName);
            case 12 -> askEditor(player, id,
                "<gold>Type lore lines separated by |</gold><newline><gray>Use none to clear. MiniMessage works.</gray>", input ->
                    item.setLore(input.equalsIgnoreCase("none") ? List.of() : List.of(input.split("\\|", -1))));
            case 13 -> openEnchantments(player, id);
            case 14 -> openAbilities(player, id);
            case 15 -> openRecipe(player, id);
            case 16 -> openDrops(player, id);
            case 19 -> {
                if (rightClick) {
                    askEditor(player, id, "<gold>Custom model data</gold><newline><gray>Type a non-negative number, or none.</gray>", input -> {
                        if (input.equalsIgnoreCase("none")) item.setCustomModelData(null);
                        else {
                            int value = Integer.parseInt(input);
                            if (value < 0) throw new IllegalArgumentException("Model data must be non-negative");
                            item.setCustomModelData(value);
                        }
                    });
                } else {
                    askEditor(player, id, "<gold>Item model key</gold><newline><gray>Example: mypack:ember_blade, or none.</gray>", input -> {
                        if (!input.equalsIgnoreCase("none") && NamespacedKey.fromString(input) == null) throw new IllegalArgumentException("Use namespace:model_name");
                        item.setItemModel(input.equalsIgnoreCase("none") ? "" : input.toLowerCase(Locale.ROOT));
                    });
                }
            }
            case 20 -> askEditor(player, id, "<gold>Leather color</gold><newline><gray>Type #RRGGBB, or none.</gray>", input -> {
                if (!input.equalsIgnoreCase("none") && !input.matches("#?[0-9a-fA-F]{6}")) throw new IllegalArgumentException("Use a six-digit hex color");
                item.setLeatherColor(input.equalsIgnoreCase("none") ? "" : (input.startsWith("#") ? input : "#" + input));
            });
            case 21 -> changeAndRefresh(player, item, () -> item.setUnbreakable(!item.unbreakable()));
            case 22 -> changeAndRefresh(player, item, () -> item.setGlint(!item.glint()));
            case 23 -> changeAndRefresh(player, item, () -> item.setHideTooltip(!item.hideTooltip()));
            case 24 -> askEditor(player, id, "<gold>Max stack size</gold><newline><gray>Type 1-99, or none.</gray>", input -> {
                if (input.equalsIgnoreCase("none")) item.setMaxStackSize(null);
                else {
                    int size = Integer.parseInt(input);
                    if (size < 1 || size > 99) throw new IllegalArgumentException("Stack size must be 1-99");
                    if (item.maxDurability() != null && size != 1) throw new IllegalArgumentException("Items with custom durability must stack to one");
                    item.setMaxStackSize(size);
                }
            });
            case 25 -> changeAndRefresh(player, item, () -> {
                if (rightClick) item.setHideAttributes(!item.hideAttributes());
                else item.setHideEnchantments(!item.hideEnchantments());
            });
            case 26 -> changeAndRefresh(player, item, () -> item.setRarity(nextRarity(item.rarity())));
            case 27 -> askEditor(player, id, "<gold>Maximum durability</gold><newline><gray>Type a positive whole number, or none. Durable items always stack to one.</gray>", input -> {
                if (input.equalsIgnoreCase("none")) {
                    item.setMaxDurability(null);
                } else {
                    int durability = Integer.parseInt(input);
                    if (durability < 1) throw new IllegalArgumentException("Durability must be at least 1");
                    item.setMaxDurability(durability);
                    item.setMaxStackSize(1);
                }
            });
            case 31 -> openAttributes(player, id);
            case 40 -> {
                ItemStack stack = plugin.items().build(item, 1);
                player.getInventory().addItem(stack).values().forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
                plugin.message(player, "<green>Added one to your inventory.</green>");
            }
            case 45 -> openDashboard(player);
            case 53 -> player.closeInventory();
            default -> { }
        }
    }

    private void handleEnchantmentClick(Player player, EnchantmentHolder holder, int slot, boolean rightClick) {
        CustomItemDefinition item = requireItem(player, holder.id);
        if (item == null) return;
        String key = holder.keys.get(slot);
        if (key != null) {
            if (rightClick) {
                item.enchantments().remove(key);
                saveRefresh(() -> openEnchantments(player, holder.id));
            } else {
                plugin.prompts().ask(player, Texts.mini("<gold>New level for " + key + "</gold>"), input -> {
                    try {
                        int level = Integer.parseInt(input);
                        if (level < 1 || level > 255) throw new IllegalArgumentException("Use a level from 1-255");
                        item.enchantments().put(key, level);
                        saveRefresh(() -> openEnchantments(player, holder.id));
                    } catch (RuntimeException exception) {
                        inputError(player, exception, () -> openEnchantments(player, holder.id));
                    }
                }, () -> openEnchantments(player, holder.id));
            }
        } else if (slot == 45) {
            openEditor(player, holder.id);
        } else if (slot == 49) {
            plugin.prompts().ask(player, Texts.mini("<gold>Add an enchantment</gold><newline><gray>Example: sharpness 5</gray>"), input -> {
                try {
                    String[] parts = input.trim().split("\\s+");
                    if (parts.length != 2) throw new IllegalArgumentException("Use: enchantment level");
                    NamespacedKey enchantKey = NamespacedKey.fromString(parts[0].contains(":") ? parts[0] : "minecraft:" + parts[0]);
                    Enchantment enchantment = enchantKey == null ? null : RegistryAccess.registryAccess().getRegistry(RegistryKey.ENCHANTMENT).get(enchantKey);
                    int level = Integer.parseInt(parts[1]);
                    if (enchantment == null) throw new IllegalArgumentException("Unknown enchantment");
                    if (level < 1 || level > 255) throw new IllegalArgumentException("Use a level from 1-255");
                    item.enchantments().put(enchantKey.toString(), level);
                    saveRefresh(() -> openEnchantments(player, holder.id));
                } catch (RuntimeException exception) {
                    inputError(player, exception, () -> openEnchantments(player, holder.id));
                }
            }, () -> openEnchantments(player, holder.id));
        }
    }

    private void handleAbilityClick(Player player, AbilityHolder holder, int slot, boolean rightClick) {
        CustomItemDefinition item = requireItem(player, holder.id);
        if (item == null) return;
        String preset = holder.presets.get(slot);
        Integer index = holder.abilities.get(slot);
        if (preset != null) {
            ConfiguredAbility configured = plugin.abilityRegistry().get(preset).orElse(null);
            if (configured == null) {
                plugin.message(player, "<red>That ability is no longer loaded.</red>");
                openAbilities(player, holder.id, holder.page);
                return;
            }
            if (item.abilities().stream().anyMatch(ability -> ability.abilityId().equals(preset))) {
                plugin.message(player, "<yellow>That ability is already on this item.</yellow>");
                return;
            }
            item.abilities().add(AbilityDefinition.preset(configured.id(), configured.defaultPower(), configured.defaultCooldownTicks()));
            saveRefresh(() -> openAbilities(player, holder.id, holder.page));
        } else if (index != null && index < item.abilities().size()) {
            if (rightClick) {
                item.abilities().remove((int) index);
                saveRefresh(() -> openAbilities(player, holder.id, holder.page));
            } else {
                AbilityDefinition current = item.abilities().get(index);
                String displayName = plugin.abilityRegistry().get(current.abilityId())
                    .map(ConfiguredAbility::displayName).orElse(current.abilityId());
                plugin.prompts().ask(player, Texts.mini("<gold>Tune " + displayName + "</gold><newline><gray>Type: power cooldown-seconds</gray>"), input -> {
                    try {
                        String[] parts = input.trim().split("\\s+");
                        if (parts.length != 2) throw new IllegalArgumentException("Use: power cooldown-seconds");
                        double power = Double.parseDouble(parts[0]);
                        double cooldownSeconds = Double.parseDouble(parts[1]);
                        item.abilities().set(index, new AbilityDefinition(current.abilityId(), power, (int) Math.round(cooldownSeconds * 20.0)));
                        saveRefresh(() -> openAbilities(player, holder.id, holder.page));
                    } catch (RuntimeException exception) {
                        inputError(player, exception, () -> openAbilities(player, holder.id, holder.page));
                    }
                }, () -> openAbilities(player, holder.id, holder.page));
            }
        } else if (slot == 45) {
            openAbilities(player, holder.id, holder.page - 1);
        } else if (slot == 46) {
            openEditor(player, holder.id);
        } else if (slot == 49) {
            plugin.prompts().ask(player, Texts.mini("<gold>Add an ability by ID</gold><newline><gray>Use /itemforge abilities to see loaded IDs</gray>"), input -> {
                String abilityId = Ids.normalize(input);
                ConfiguredAbility configured = plugin.abilityRegistry().get(abilityId).orElse(null);
                if (configured == null) {
                    plugin.message(player, "<red>No loaded ability has that ID.</red>");
                    openAbilities(player, holder.id, holder.page);
                    return;
                }
                if (item.abilities().stream().anyMatch(ability -> ability.abilityId().equals(abilityId))) {
                    plugin.message(player, "<yellow>That ability is already on this item.</yellow>");
                    openAbilities(player, holder.id, holder.page);
                    return;
                }
                item.abilities().add(AbilityDefinition.preset(configured.id(), configured.defaultPower(), configured.defaultCooldownTicks()));
                saveRefresh(() -> openAbilities(player, holder.id, holder.page));
            }, () -> openAbilities(player, holder.id, holder.page));
        } else if (slot == 53) {
            openAbilities(player, holder.id, holder.page + 1);
        }
    }

    private void handleDropClick(Player player, DropHolder holder, int slot, boolean rightClick) {
        CustomItemDefinition item = requireItem(player, holder.id);
        if (item == null) return;
        Integer index = holder.rules.get(slot);
        if (index != null && index < item.dropRules().size()) {
            if (rightClick) {
                item.dropRules().remove((int) index);
                saveRefresh(() -> openDrops(player, holder.id));
            } else {
                DropRule current = item.dropRules().get(index);
                plugin.prompts().ask(player, Texts.mini("<gold>Tune this rule</gold><newline><gray>Type: chance% min max</gray>"), input -> {
                    try {
                        String[] parts = input.trim().split("\\s+");
                        if (parts.length != 3) throw new IllegalArgumentException("Use: chance% min max");
                        item.dropRules().set(index, new DropRule(current.type(), current.source(),
                            Double.parseDouble(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2])));
                        saveRefresh(() -> openDrops(player, holder.id));
                    } catch (RuntimeException exception) {
                        inputError(player, exception, () -> openDrops(player, holder.id));
                    }
                }, () -> openDrops(player, holder.id));
            }
            return;
        }
        if (slot == 45) {
            openEditor(player, holder.id);
        } else if (slot == 10) {
            askDrop(player, item, DropType.MOB, "<gold>Add a mob drop</gold><newline><gray>Type: mob chance% min max</gray>");
        } else if (slot == 12) {
            askDrop(player, item, DropType.BLOCK, "<gold>Add a block drop</gold><newline><gray>Type: block chance% min max</gray>");
        } else if (slot == 14) {
            askDrop(player, item, DropType.LOOT_TABLE, "<gold>Add a loot-table drop</gold><newline><gray>Type: loot-table-key chance% min max</gray>");
        }
    }

    private void askDrop(Player player, CustomItemDefinition item, DropType type, String prompt) {
        plugin.prompts().ask(player, Texts.mini(prompt), input -> {
            try {
                String[] parts = input.trim().split("\\s+");
                if (parts.length != 4) throw new IllegalArgumentException("Use: source chance% min max");
                validateDropSource(type, parts[0]);
                item.dropRules().add(new DropRule(type, parts[0], Double.parseDouble(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
                saveRefresh(() -> openDrops(player, item.id()));
            } catch (RuntimeException exception) {
                inputError(player, exception, () -> openDrops(player, item.id()));
            }
        }, () -> openDrops(player, item.id()));
    }

    private void handleAttributeClick(Player player, AttributeHolder holder, int slot, boolean rightClick) {
        CustomItemDefinition item = requireItem(player, holder.id);
        if (item == null) return;
        AttributeType preset = holder.presets.get(slot);
        Integer index = holder.attributes.get(slot);
        if (preset != null) {
            item.attributes().add(AttributeDefinition.preset(preset));
            saveRefresh(() -> openAttributes(player, holder.id));
        } else if (index != null && index < item.attributes().size()) {
            if (rightClick) {
                item.attributes().remove((int) index);
                saveRefresh(() -> openAttributes(player, holder.id));
            } else {
                AttributeDefinition current = item.attributes().get(index);
                plugin.prompts().ask(player, Texts.mini("<gold>Tune " + current.type().displayName() + "</gold><newline>"
                    + "<gray>Type: amount slot operation</gray><newline>"
                    + "<dark_gray>Slots: MAINHAND, OFFHAND, HEAD, CHEST, LEGS, FEET, ARMOR, ANY</dark_gray><newline>"
                    + "<dark_gray>Operations: ADD_NUMBER, ADD_SCALAR, MULTIPLY_SCALAR_1</dark_gray>"), input -> {
                    try {
                        String[] parts = input.trim().split("\\s+");
                        if (parts.length != 3) throw new IllegalArgumentException("Use: amount slot operation");
                        AttributeDefinition changed = new AttributeDefinition(current.type(), Double.parseDouble(parts[0]),
                            AttributeModifier.Operation.valueOf(parts[2].toUpperCase(Locale.ROOT)),
                            AttributeSlot.valueOf(parts[1].toUpperCase(Locale.ROOT)));
                        item.attributes().set(index, changed);
                        saveRefresh(() -> openAttributes(player, holder.id));
                    } catch (RuntimeException exception) {
                        inputError(player, exception, () -> openAttributes(player, holder.id));
                    }
                }, () -> openAttributes(player, holder.id));
            }
        } else if (slot == 45) {
            openEditor(player, holder.id);
        }
    }

    private void validateDropSource(DropType type, String source) {
        switch (type) {
            case MOB -> EntityType.valueOf(source.toUpperCase(Locale.ROOT));
            case BLOCK -> {
                Material material = Material.matchMaterial(source);
                if (material == null || !material.isBlock()) throw new IllegalArgumentException("Unknown block material");
            }
            case LOOT_TABLE -> {
                if (NamespacedKey.fromString(source) == null) throw new IllegalArgumentException("Use namespace:path");
            }
        }
    }

    private void handleRecipeClick(InventoryClickEvent event, Player player, RecipeHolder holder) {
        int rawSlot = event.getRawSlot();
        Inventory top = event.getView().getTopInventory();
        if (rawSlot >= top.getSize()) {
            if (event.isShiftClick()) event.setCancelled(true);
            return;
        }
        event.setCancelled(true);
        if (isRecipeGrid(rawSlot)) {
            ItemStack cursor = event.getCursor();
            if (cursor.isEmpty()) {
                top.clear(rawSlot);
            } else {
                ItemStack copy = cursor.clone();
                copy.setAmount(1);
                top.setItem(rawSlot, copy);
            }
        } else if (rawSlot == 16) {
            holder.shapeless = !holder.shapeless;
            top.setItem(16, recipeTypeButton(holder.shapeless));
        } else if (rawSlot == 45) {
            openEditor(player, holder.id);
        } else if (rawSlot == 49) {
            saveRecipe(player, holder, top);
        } else if (rawSlot == 53) {
            for (int slot : RECIPE_GRID) top.clear(slot);
        }
    }

    private void saveRecipe(Player player, RecipeHolder holder, Inventory inventory) {
        CustomItemDefinition item = requireItem(player, holder.id);
        if (item == null) return;
        Map<String, Character> assigned = new LinkedHashMap<>();
        Map<Character, String> ingredients = new LinkedHashMap<>();
        List<String> shape = new ArrayList<>(3);
        for (int row = 0; row < 3; row++) {
            StringBuilder line = new StringBuilder(3);
            for (int column = 0; column < 3; column++) {
                ItemStack stack = inventory.getItem(RECIPE_GRID[row * 3 + column]);
                if (stack == null || stack.isEmpty()) {
                    line.append(' ');
                    continue;
                }
                String descriptor = descriptor(stack);
                char key = assigned.computeIfAbsent(descriptor, ignored -> (char) ('A' + assigned.size()));
                ingredients.putIfAbsent(key, descriptor);
                line.append(key);
            }
            shape.add(line.toString());
        }
        RecipeDefinition recipe = item.recipe();
        recipe.setShape(shape);
        recipe.setIngredients(ingredients);
        recipe.setShapeless(holder.shapeless);
        recipe.setEnabled(!ingredients.isEmpty());
        plugin.items().save();
        plugin.recipes().registerAll();
        plugin.message(player, ingredients.isEmpty()
            ? "<yellow>Recipe disabled because the grid is empty.</yellow>"
            : "<green>Saved and registered the custom recipe.</green>");
        openEditor(player, holder.id);
    }

    private String descriptor(ItemStack stack) {
        return plugin.items().identify(stack).map(id -> "item:" + id).orElse("material:" + stack.getType().name());
    }

    private ItemStack ingredientStack(String descriptor) {
        if (descriptor == null) return null;
        if (descriptor.startsWith("item:")) return plugin.items().build(descriptor.substring(5), 1);
        if (descriptor.startsWith("material:")) {
            Material material = Material.matchMaterial(descriptor.substring(9));
            return material == null || !material.isItem() ? null : new ItemStack(material);
        }
        return null;
    }

    private void askEditor(Player player, String id, String prompt, Consumer<String> change) {
        plugin.prompts().ask(player, Texts.mini(prompt), input -> {
            try {
                change.accept(input);
                saveRefresh(() -> openEditor(player, id));
            } catch (RuntimeException exception) {
                inputError(player, exception, () -> openEditor(player, id));
            }
        }, () -> openEditor(player, id));
    }

    private void changeAndRefresh(Player player, CustomItemDefinition item, Runnable change) {
        change.run();
        saveRefresh(() -> openEditor(player, item.id()));
    }

    private void saveRefresh(Runnable reopen) {
        plugin.items().save();
        plugin.recipes().registerAll();
        reopen.run();
    }

    private void inputError(Player player, RuntimeException exception, Runnable reopen) {
        String message = exception.getMessage() == null ? "Invalid value" : exception.getMessage();
        plugin.message(player, "<red>" + message + ".</red>");
        reopen.run();
    }

    private CustomItemDefinition requireItem(Player player, String id) {
        CustomItemDefinition item = plugin.items().get(id).orElse(null);
        if (item == null) {
            plugin.message(player, "<red>That item no longer exists.</red>");
            openDashboard(player);
        }
        return item;
    }

    private static boolean isRecipeGrid(int slot) {
        for (int gridSlot : RECIPE_GRID) if (slot == gridSlot) return true;
        return false;
    }

    private static void paint(Inventory inventory) {
        ItemStack filler = button(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int slot = 0; slot < inventory.getSize(); slot++) inventory.setItem(slot, filler);
    }

    private static ItemStack button(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Texts.mini(name));
        meta.lore(lore.length == 0 ? null : List.of(lore).stream().map(Texts::mini).toList());
        meta.setHideTooltip(false);
        stack.setItemMeta(meta);
        return stack;
    }

    private static ItemStack toggle(Material material, String label, boolean enabled) {
        return button(material, "<aqua>" + label + "</aqua>", state(enabled), "<yellow>Click to toggle</yellow>");
    }

    private static ItemStack recipeTypeButton(boolean shapeless) {
        return button(shapeless ? Material.GUNPOWDER : Material.CRAFTING_TABLE,
            "<aqua>Recipe type</aqua>", "<white>" + (shapeless ? "Shapeless" : "Shaped") + "</white>", "<yellow>Click to toggle</yellow>");
    }

    private static void appendLore(ItemStack stack, String... lines) {
        ItemMeta meta = stack.getItemMeta();
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        for (String line : lines) lore.add(Texts.mini(line));
        meta.lore(lore);
        stack.setItemMeta(meta);
    }

    private static Material dropIcon(DropType type) {
        return switch (type) {
            case MOB -> Material.ZOMBIE_HEAD;
            case BLOCK -> Material.DIAMOND_ORE;
            case LOOT_TABLE -> Material.CHEST;
        };
    }

    private static String value(Object value) {
        return value == null || value.toString().isBlank() ? "Not set" : value.toString();
    }

    private static String state(boolean enabled) {
        return enabled ? "<green>Enabled</green>" : "<red>Disabled</red>";
    }

    private static String onOff(boolean enabled) {
        return enabled ? "<green>Shown</green>" : "<red>Hidden</red>";
    }

    private static double seconds(int ticks) {
        return Math.round(ticks / 2.0) / 10.0;
    }

    private static ItemRarity nextRarity(ItemRarity rarity) {
        ItemRarity[] values = ItemRarity.values();
        return values[(rarity.ordinal() + 1) % values.length];
    }

    private abstract static class BaseHolder implements InventoryHolder {
        private Inventory inventory;

        Inventory create(int size, String title) {
            inventory = Bukkit.createInventory(this, size, Texts.mini(title));
            return inventory;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class DashboardHolder extends BaseHolder {
        private final int page;
        private final Map<Integer, String> ids = new HashMap<>();
        private DashboardHolder(int page) { this.page = page; }
    }

    private static final class CatalogHolder extends BaseHolder {
        private final int page;
        private final Map<Integer, CatalogEntry> entries = new HashMap<>();
        private CatalogHolder(int page) { this.page = page; }
    }

    private record CatalogEntry(String source, String id, Supplier<ItemStack> factory) {
        ItemStack create() { return factory.get(); }
    }

    private static final class EditorHolder extends BaseHolder {
        private final String id;
        private EditorHolder(String id) { this.id = id; }
    }

    private static final class EnchantmentHolder extends BaseHolder {
        private final String id;
        private final Map<Integer, String> keys = new HashMap<>();
        private EnchantmentHolder(String id) { this.id = id; }
    }

    private static final class AbilityHolder extends BaseHolder {
        private final String id;
        private final int page;
        private final Map<Integer, String> presets = new HashMap<>();
        private final Map<Integer, Integer> abilities = new HashMap<>();
        private AbilityHolder(String id, int page) {
            this.id = id;
            this.page = page;
        }
    }

    private static final class DropHolder extends BaseHolder {
        private final String id;
        private final Map<Integer, Integer> rules = new HashMap<>();
        private DropHolder(String id) { this.id = id; }
    }

    private static final class AttributeHolder extends BaseHolder {
        private final String id;
        private final Map<Integer, AttributeType> presets = new HashMap<>();
        private final Map<Integer, Integer> attributes = new HashMap<>();
        private AttributeHolder(String id) { this.id = id; }
    }

    private static final class RecipeHolder extends BaseHolder {
        private final String id;
        private boolean shapeless;
        private RecipeHolder(String id, boolean shapeless) {
            this.id = id;
            this.shapeless = shapeless;
        }
    }
}

package dev.itemforge.item;

import dev.itemforge.ItemForgePlugin;
import dev.itemforge.ability.ConfiguredAbility;
import dev.itemforge.model.AbilityDefinition;
import dev.itemforge.model.AttributeDefinition;
import dev.itemforge.model.CustomItemDefinition;
import dev.itemforge.model.DropRule;
import dev.itemforge.model.RecipeDefinition;
import dev.itemforge.util.Ids;
import dev.itemforge.util.Texts;
import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.registry.RegistryAccess;
import io.papermc.paper.registry.RegistryKey;
import net.kyori.adventure.text.Component;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemRarity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class ItemRegistry {
    private final ItemForgePlugin plugin;
    private final File file;
    private final NamespacedKey identityKey;
    private final Map<String, CustomItemDefinition> definitions = new LinkedHashMap<>();

    public ItemRegistry(ItemForgePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "items.yml");
        this.identityKey = new NamespacedKey(plugin.host(), "item_id");
    }

    public void load() {
        if (!file.exists()) {
            plugin.saveResource("items.yml", false);
        }
        definitions.clear();
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection items = yaml.getConfigurationSection("items");
        if (items == null) return;

        for (String rawId : items.getKeys(false)) {
            String id = Ids.normalize(rawId);
            ConfigurationSection section = items.getConfigurationSection(rawId);
            if (!Ids.isValid(id) || section == null) {
                plugin.problems().warning("load.invalid-id." + rawId, "Skipped invalid custom item id: " + rawId);
                continue;
            }
            try {
                CustomItemDefinition definition = loadDefinition(id, section);
                definitions.put(id, definition);
            } catch (RuntimeException exception) {
                plugin.problems().error("load.item." + id, "Could not load item '" + id + "'", exception);
            }
        }
    }

    private CustomItemDefinition loadDefinition(String id, ConfigurationSection section) {
        Material material = Material.matchMaterial(section.getString("material", "STONE"));
        if (material == null || material.isAir() || !material.isItem()) {
            throw new IllegalArgumentException("Invalid item material");
        }
        CustomItemDefinition item = new CustomItemDefinition(id, material);
        item.setName(section.getString("name", item.name()));
        item.setLore(section.getStringList("lore"));
        item.setUnbreakable(section.getBoolean("unbreakable", false));
        item.setGlint(section.getBoolean("glint", false));
        item.setHideTooltip(section.getBoolean("hide-tooltip", false));
        item.setHideEnchantments(section.getBoolean("hide-enchantments", false));
        item.setHideAttributes(section.getBoolean("hide-attributes", false));
        item.setItemModel(section.getString("item-model", ""));
        item.setLeatherColor(section.getString("leather-color", ""));
        item.setCustomModelData(section.contains("custom-model-data") ? section.getInt("custom-model-data") : null);
        item.setMaxStackSize(section.contains("max-stack-size") ? section.getInt("max-stack-size") : null);
        item.setMaxDurability(section.get("max-durability") == null ? null : section.getInt("max-durability"));
        try {
            item.setRarity(ItemRarity.valueOf(section.getString("rarity", "COMMON").toUpperCase(java.util.Locale.ROOT)));
        } catch (IllegalArgumentException ignored) {
            item.setRarity(ItemRarity.COMMON);
        }

        ConfigurationSection enchants = section.getConfigurationSection("enchantments");
        Map<String, Integer> enchantments = new LinkedHashMap<>();
        if (enchants != null) {
            for (String key : enchants.getKeys(false)) {
                enchantments.put(key, Math.max(1, enchants.getInt(key, 1)));
            }
        }
        item.setEnchantments(enchantments);

        List<AbilityDefinition> abilities = new ArrayList<>();
        for (Map<?, ?> map : section.getMapList("abilities")) {
            try {
                Object raw = map.containsKey("id") ? map.get("id") : map.get("type");
                String abilityId = Ids.normalize(raw == null ? "" : String.valueOf(raw));
                ConfiguredAbility configured = plugin.abilityRegistry().get(abilityId).orElse(null);
                double defaultPower = configured == null ? 1.0 : configured.defaultPower();
                int defaultCooldown = configured == null ? 0 : configured.defaultCooldownTicks();
                abilities.add(AbilityDefinition.fromMap(map, defaultPower, defaultCooldown));
                if (configured == null) {
                    plugin.problems().warning(
                        "load.ability-missing." + abilityId,
                        "Item '" + id + "' references missing ability '" + abilityId + "'; it will activate when that ability file is added"
                    );
                }
            } catch (RuntimeException exception) {
                plugin.problems().warning("load.ability." + id, "Skipped invalid ability on item '" + id + "': " + exception.getMessage());
            }
        }
        item.setAbilities(abilities);

        List<AttributeDefinition> attributes = new ArrayList<>();
        for (Map<?, ?> map : section.getMapList("attributes")) {
            try {
                attributes.add(AttributeDefinition.fromMap(map));
            } catch (RuntimeException exception) {
                plugin.problems().warning("load.attribute." + id, "Skipped invalid attribute on item '" + id + "': " + exception.getMessage());
            }
        }
        item.setAttributes(attributes);

        List<DropRule> rules = new ArrayList<>();
        for (Map<?, ?> map : section.getMapList("drops")) {
            try {
                rules.add(DropRule.fromMap(map));
            } catch (RuntimeException exception) {
                plugin.problems().warning("load.drop." + id, "Skipped invalid drop rule on item '" + id + "': " + exception.getMessage());
            }
        }
        item.setDropRules(rules);

        ConfigurationSection recipeSection = section.getConfigurationSection("recipe");
        if (recipeSection != null) {
            RecipeDefinition recipe = new RecipeDefinition();
            recipe.setEnabled(recipeSection.getBoolean("enabled", false));
            recipe.setShapeless(recipeSection.getBoolean("shapeless", false));
            List<String> shape = recipeSection.getStringList("shape");
            if (shape.size() == 3) recipe.setShape(shape);
            Map<Character, String> ingredients = new LinkedHashMap<>();
            ConfigurationSection ingredientSection = recipeSection.getConfigurationSection("ingredients");
            if (ingredientSection != null) {
                for (String key : ingredientSection.getKeys(false)) {
                    if (key.length() == 1) ingredients.put(key.charAt(0), ingredientSection.getString(key, ""));
                }
            }
            recipe.setIngredients(ingredients);
            item.setRecipe(recipe);
        }
        return item;
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (CustomItemDefinition item : definitions.values()) {
            ConfigurationSection section = yaml.createSection("items." + item.id());
            section.set("material", item.material().name());
            section.set("name", item.name());
            section.set("lore", item.lore());
            section.set("unbreakable", item.unbreakable());
            section.set("glint", item.glint());
            section.set("hide-tooltip", item.hideTooltip());
            section.set("hide-enchantments", item.hideEnchantments());
            section.set("hide-attributes", item.hideAttributes());
            section.set("item-model", blankToNull(item.itemModel()));
            section.set("custom-model-data", item.customModelData());
            section.set("leather-color", blankToNull(item.leatherColor()));
            section.set("max-stack-size", item.maxStackSize());
            section.set("max-durability", item.maxDurability());
            section.set("rarity", item.rarity().name());

            ConfigurationSection enchantments = section.createSection("enchantments");
            item.enchantments().forEach(enchantments::set);
            section.set("abilities", item.abilities().stream().map(AbilityDefinition::toMap).toList());
            section.set("attributes", item.attributes().stream().map(AttributeDefinition::toMap).toList());
            section.set("drops", item.dropRules().stream().map(DropRule::toMap).toList());

            RecipeDefinition recipe = item.recipe();
            ConfigurationSection recipeSection = section.createSection("recipe");
            recipeSection.set("enabled", recipe.enabled());
            recipeSection.set("shapeless", recipe.shapeless());
            recipeSection.set("shape", recipe.shape());
            ConfigurationSection ingredients = recipeSection.createSection("ingredients");
            recipe.ingredients().forEach((key, value) -> ingredients.set(String.valueOf(key), value));
        }
        try {
            yaml.save(file);
        } catch (IOException exception) {
            plugin.problems().error("save.items", "Could not save items.yml", exception);
        }
    }

    public CustomItemDefinition create(String input, Material material) {
        String id = Ids.normalize(input);
        if (!Ids.isValid(id)) throw new IllegalArgumentException("Use 2-48 lowercase letters, numbers, _ or -");
        if (definitions.containsKey(id)) throw new IllegalArgumentException("That item id already exists");
        if (material == null || material.isAir() || !material.isItem()) throw new IllegalArgumentException("Choose a valid item material");
        CustomItemDefinition item = new CustomItemDefinition(id, material);
        definitions.put(id, item);
        save();
        return item;
    }

    public CustomItemDefinition duplicate(String existingId, String newInput) {
        CustomItemDefinition source = get(existingId).orElseThrow(() -> new IllegalArgumentException("Unknown source item"));
        String id = Ids.normalize(newInput);
        if (!Ids.isValid(id)) throw new IllegalArgumentException("Use 2-48 lowercase letters, numbers, _ or -");
        if (definitions.containsKey(id)) throw new IllegalArgumentException("That item id already exists");
        CustomItemDefinition copy = source.copyAs(id);
        definitions.put(id, copy);
        save();
        return copy;
    }

    public boolean delete(String id) {
        boolean removed = definitions.remove(Ids.normalize(id)) != null;
        if (removed) save();
        return removed;
    }

    public Optional<CustomItemDefinition> get(String id) {
        return Optional.ofNullable(definitions.get(Ids.normalize(id)));
    }

    public Collection<CustomItemDefinition> all() {
        return definitions.values().stream().sorted(Comparator.comparing(CustomItemDefinition::id)).toList();
    }

    public List<String> ids() {
        return definitions.keySet().stream().sorted().toList();
    }

    public ItemStack build(String id, int requestedAmount) {
        return get(id).map(item -> build(item, requestedAmount)).orElse(null);
    }

    public ItemStack build(CustomItemDefinition definition, int requestedAmount) {
        // Minecraft's MAX_DAMAGE component cannot coexist with a stack size above one.
        int stackMaximum = definition.maxDurability() != null ? 1
                : (definition.maxStackSize() == null ? definition.material().getMaxStackSize() : definition.maxStackSize());
        int amount = Math.max(1, Math.min(requestedAmount, Math.max(1, stackMaximum)));
        ItemStack stack = new ItemStack(definition.material(), amount);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Texts.mini(definition.name()));
        List<Component> lore = definition.lore().stream().map(Texts::mini).toList();
        meta.lore(lore.isEmpty() ? null : lore);
        meta.setUnbreakable(definition.unbreakable());
        meta.setRarity(definition.rarity());
        if (definition.glint()) meta.setEnchantmentGlintOverride(true);
        meta.setHideTooltip(definition.hideTooltip());
        if (definition.hideEnchantments()) meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        if (definition.hideAttributes()) meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        if (definition.maxDurability() != null) {
            meta.setMaxStackSize(1);
        } else if (definition.maxStackSize() != null) {
            try {
                meta.setMaxStackSize(Math.max(1, Math.min(99, definition.maxStackSize())));
            } catch (IllegalArgumentException exception) {
                plugin.problems().warning("render.stack-size." + definition.id(), "Invalid max stack size on item '" + definition.id() + "': " + exception.getMessage());
            }
        }
        if (definition.customModelData() != null) {
            var modelData = meta.getCustomModelDataComponent();
            modelData.setFloats(List.of(definition.customModelData().floatValue()));
            meta.setCustomModelDataComponent(modelData);
        }
        if (!definition.itemModel().isBlank()) {
            NamespacedKey model = NamespacedKey.fromString(definition.itemModel());
            if (model != null) meta.setItemModel(model);
        }
        if (meta instanceof LeatherArmorMeta leather && !definition.leatherColor().isBlank()) {
            Integer rgb = parseColor(definition.leatherColor());
            if (rgb != null) leather.setColor(Color.fromRGB(rgb));
        }
        for (Map.Entry<String, Integer> entry : definition.enchantments().entrySet()) {
            NamespacedKey key = NamespacedKey.fromString(entry.getKey());
            Enchantment enchantment = key == null ? null : RegistryAccess.registryAccess().getRegistry(RegistryKey.ENCHANTMENT).get(key);
            if (enchantment != null) meta.addEnchant(enchantment, entry.getValue(), true);
        }
        for (int index = 0; index < definition.attributes().size(); index++) {
            AttributeDefinition attribute = definition.attributes().get(index);
            NamespacedKey modifierKey = new NamespacedKey(plugin.host(), "attr_" + definition.id() + "_" + index);
            AttributeModifier modifier = new AttributeModifier(modifierKey, attribute.amount(), attribute.operation(), attribute.slot().group());
            meta.addAttributeModifier(attribute.type().attribute(), modifier);
        }
        meta.getPersistentDataContainer().set(identityKey, PersistentDataType.STRING, definition.id());
        stack.setItemMeta(meta);
        if (definition.maxDurability() != null) {
            // ItemMeta has no custom max-damage setter, so use Paper's native
            // data component API. Every newly created item starts undamaged.
            stack.setData(DataComponentTypes.MAX_STACK_SIZE, 1);
            stack.setData(DataComponentTypes.MAX_DAMAGE, definition.maxDurability());
            stack.setData(DataComponentTypes.DAMAGE, 0);
        }
        return stack;
    }

    public Optional<String> identify(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return Optional.empty();
        String id = stack.getPersistentDataContainer().get(identityKey, PersistentDataType.STRING);
        return id == null || !definitions.containsKey(id) ? Optional.empty() : Optional.of(id);
    }

    public NamespacedKey identityKey() {
        return identityKey;
    }

    private static Integer parseColor(String input) {
        try {
            String normalized = input.trim().replace("#", "");
            return normalized.length() == 6 ? Integer.parseInt(normalized, 16) : null;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }
}

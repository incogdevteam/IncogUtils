package dev.itemforge.loot;

import dev.itemforge.ItemForgePlugin;
import dev.itemforge.model.CustomItemDefinition;
import dev.itemforge.model.DropRule;
import dev.itemforge.model.DropType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public final class LootListener implements Listener {
    private final ItemForgePlugin plugin;

    public LootListener(ItemForgePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onMobDeath(EntityDeathEvent event) {
        String source = event.getEntityType().name().toLowerCase(Locale.ROOT);
        forEachMatch(DropType.MOB, source, (item, amount) -> event.getDrops().add(plugin.items().build(item, amount)));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        String source = event.getBlock().getType().name().toLowerCase(Locale.ROOT);
        forEachMatch(DropType.BLOCK, source, (item, amount) -> {
            ItemStack drop = plugin.items().build(item, amount);
            if (plugin.getConfig().getBoolean("drop-items-naturally", true)) {
                event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), drop);
            } else {
                event.getBlock().getWorld().dropItem(event.getBlock().getLocation(), drop);
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    public void onLootGenerate(LootGenerateEvent event) {
        String source = event.getLootTable().getKey().toString().toLowerCase(Locale.ROOT);
        forEachMatch(DropType.LOOT_TABLE, source, (item, amount) -> event.getLoot().add(plugin.items().build(item, amount)));
    }

    private void forEachMatch(DropType type, String source, DropConsumer consumer) {
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (CustomItemDefinition item : plugin.items().all()) {
            for (DropRule rule : item.dropRules()) {
                if (rule.type() != type || !rule.source().equalsIgnoreCase(source)) continue;
                if (random.nextDouble(100.0) >= rule.chancePercent()) continue;
                int amount = rule.minAmount() == rule.maxAmount()
                    ? rule.minAmount()
                    : random.nextInt(rule.minAmount(), rule.maxAmount() + 1);
                consumer.drop(item, amount);
            }
        }
    }

    @FunctionalInterface
    private interface DropConsumer {
        void drop(CustomItemDefinition item, int amount);
    }
}

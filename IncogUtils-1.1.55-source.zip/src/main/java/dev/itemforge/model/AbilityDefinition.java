package dev.itemforge.model;

import dev.itemforge.util.Ids;

import java.util.LinkedHashMap;
import java.util.Map;

public record AbilityDefinition(String abilityId, double power, int cooldownTicks) {
    public AbilityDefinition {
        abilityId = Ids.normalize(abilityId);
        if (!Ids.isValid(abilityId)) {
            throw new IllegalArgumentException("Ability id is invalid");
        }
        if (!Double.isFinite(power) || power < 0.0) {
            throw new IllegalArgumentException("Ability power must be zero or greater");
        }
        if (cooldownTicks < 0) {
            throw new IllegalArgumentException("Ability cooldown cannot be negative");
        }
    }

    public static AbilityDefinition preset(String abilityId, double defaultPower, int defaultCooldownTicks) {
        return new AbilityDefinition(abilityId, defaultPower, defaultCooldownTicks);
    }

    /** Compatibility bridge for integrations compiled against ItemForge 1.0. */
    @Deprecated(forRemoval = false)
    public AbilityDefinition(AbilityType type, double power, int cooldownTicks) {
        this(type.name(), power, cooldownTicks);
    }

    /** Compatibility bridge for integrations compiled against ItemForge 1.0. */
    @Deprecated(forRemoval = false)
    public static AbilityDefinition preset(AbilityType type) {
        return preset(type.name(), type.defaultPower(), type.defaultCooldownTicks());
    }

    /** Compatibility bridge; returns null for YAML-only ability IDs. */
    @Deprecated(forRemoval = false)
    public AbilityType type() {
        try {
            return AbilityType.valueOf(abilityId.toUpperCase(java.util.Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    public static AbilityDefinition fromMap(Map<?, ?> map, double defaultPower, int defaultCooldownTicks) {
        Object raw = map.containsKey("id") ? map.get("id") : map.get("type");
        if (raw == null) throw new IllegalArgumentException("Ability id is missing");
        double power = number(map.get("power"), defaultPower).doubleValue();
        int cooldown = number(map.get("cooldown-ticks"), defaultCooldownTicks).intValue();
        return new AbilityDefinition(String.valueOf(raw), power, cooldown);
    }

    /** Compatibility bridge using neutral defaults when no registry is available. */
    @Deprecated(forRemoval = false)
    public static AbilityDefinition fromMap(Map<?, ?> map) {
        return fromMap(map, 1.0, 0);
    }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", abilityId);
        map.put("power", power);
        map.put("cooldown-ticks", cooldownTicks);
        return map;
    }

    private static Number number(Object value, Number fallback) {
        return value instanceof Number number ? number : fallback;
    }
}

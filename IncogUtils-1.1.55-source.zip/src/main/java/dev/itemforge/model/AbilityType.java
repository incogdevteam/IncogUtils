package dev.itemforge.model;

/**
 * Built-in ability IDs kept for binary/configuration compatibility with ItemForge 1.0.
 * New abilities are discovered from YAML and do not need an enum entry.
 */
@Deprecated(forRemoval = false)
public enum AbilityType {
    DASH("Dash", false, 1.35, 60, "Right-click to surge forward"),
    FIREBALL("Fireball", false, 1.5, 80, "Right-click to launch a fireball"),
    HEAL("Heal", false, 4.0, 100, "Right-click to restore health"),
    LIGHTNING("Lightning", false, 4.0, 80, "Strike enemies you hit"),
    LIFESTEAL("Lifesteal", false, 0.25, 20, "Heal for a fraction of melee damage"),
    SPEED("Speed", true, 1.0, 0, "Speed while held or equipped"),
    STRENGTH("Strength", true, 1.0, 0, "Strength while held or equipped"),
    RESISTANCE("Resistance", true, 1.0, 0, "Resistance while held or equipped"),
    JUMP_BOOST("Jump Boost", true, 1.0, 0, "Jump boost while held or equipped");

    private final String displayName;
    private final boolean passive;
    private final double defaultPower;
    private final int defaultCooldownTicks;
    private final String description;

    AbilityType(String displayName, boolean passive, double defaultPower, int defaultCooldownTicks, String description) {
        this.displayName = displayName;
        this.passive = passive;
        this.defaultPower = defaultPower;
        this.defaultCooldownTicks = defaultCooldownTicks;
        this.description = description;
    }

    public String displayName() { return displayName; }
    public boolean passive() { return passive; }
    public double defaultPower() { return defaultPower; }
    public int defaultCooldownTicks() { return defaultCooldownTicks; }
    public String description() { return description; }
}

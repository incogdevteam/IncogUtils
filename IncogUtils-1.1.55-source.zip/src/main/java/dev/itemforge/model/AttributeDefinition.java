package dev.itemforge.model;

import org.bukkit.attribute.AttributeModifier;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public record AttributeDefinition(AttributeType type, double amount, AttributeModifier.Operation operation, AttributeSlot slot) {
    public AttributeDefinition {
        if (type == null || operation == null || slot == null) throw new IllegalArgumentException("Attribute fields are required");
        if (!Double.isFinite(amount)) throw new IllegalArgumentException("Attribute amount must be a number");
    }

    public static AttributeDefinition preset(AttributeType type) {
        return new AttributeDefinition(type, type.defaultAmount(), AttributeModifier.Operation.ADD_NUMBER, type.defaultSlot());
    }

    public static AttributeDefinition fromMap(Map<?, ?> map) {
        AttributeType type = AttributeType.valueOf(String.valueOf(map.get("type")).toUpperCase(Locale.ROOT));
        double amount = map.get("amount") instanceof Number number ? number.doubleValue() : type.defaultAmount();
        Object rawOperation = map.containsKey("operation") ? map.get("operation") : "ADD_NUMBER";
        Object rawSlot = map.containsKey("slot") ? map.get("slot") : type.defaultSlot().name();
        return new AttributeDefinition(type, amount,
            AttributeModifier.Operation.valueOf(String.valueOf(rawOperation).toUpperCase(Locale.ROOT)),
            AttributeSlot.valueOf(String.valueOf(rawSlot).toUpperCase(Locale.ROOT)));
    }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("type", type.name());
        map.put("amount", amount);
        map.put("operation", operation.name());
        map.put("slot", slot.name());
        return map;
    }
}

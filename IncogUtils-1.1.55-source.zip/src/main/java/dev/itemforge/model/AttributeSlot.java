package dev.itemforge.model;

import org.bukkit.inventory.EquipmentSlotGroup;

public enum AttributeSlot {
    MAINHAND(EquipmentSlotGroup.MAINHAND),
    OFFHAND(EquipmentSlotGroup.OFFHAND),
    HAND(EquipmentSlotGroup.HAND),
    HEAD(EquipmentSlotGroup.HEAD),
    CHEST(EquipmentSlotGroup.CHEST),
    LEGS(EquipmentSlotGroup.LEGS),
    FEET(EquipmentSlotGroup.FEET),
    ARMOR(EquipmentSlotGroup.ARMOR),
    ANY(EquipmentSlotGroup.ANY);

    private final EquipmentSlotGroup group;

    AttributeSlot(EquipmentSlotGroup group) {
        this.group = group;
    }

    public EquipmentSlotGroup group() {
        return group;
    }
}

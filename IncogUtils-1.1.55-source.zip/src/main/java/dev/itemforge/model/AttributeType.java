package dev.itemforge.model;

import org.bukkit.Material;
import org.bukkit.attribute.Attribute;

public enum AttributeType {
    ATTACK_DAMAGE("Attack damage", Attribute.ATTACK_DAMAGE, 5.0, AttributeSlot.MAINHAND, Material.IRON_SWORD),
    ATTACK_SPEED("Attack speed", Attribute.ATTACK_SPEED, 0.2, AttributeSlot.MAINHAND, Material.GOLDEN_SWORD),
    ARMOR("Armor", Attribute.ARMOR, 3.0, AttributeSlot.ARMOR, Material.IRON_CHESTPLATE),
    ARMOR_TOUGHNESS("Armor toughness", Attribute.ARMOR_TOUGHNESS, 2.0, AttributeSlot.ARMOR, Material.DIAMOND_CHESTPLATE),
    MAX_HEALTH("Max health", Attribute.MAX_HEALTH, 4.0, AttributeSlot.ANY, Material.GOLDEN_APPLE),
    MOVEMENT_SPEED("Movement speed", Attribute.MOVEMENT_SPEED, 0.05, AttributeSlot.FEET, Material.LEATHER_BOOTS),
    KNOCKBACK_RESISTANCE("Knockback resistance", Attribute.KNOCKBACK_RESISTANCE, 0.1, AttributeSlot.ARMOR, Material.SHIELD),
    ATTACK_KNOCKBACK("Attack knockback", Attribute.ATTACK_KNOCKBACK, 0.5, AttributeSlot.MAINHAND, Material.PISTON);

    private final String displayName;
    private final Attribute attribute;
    private final double defaultAmount;
    private final AttributeSlot defaultSlot;
    private final Material icon;

    AttributeType(String displayName, Attribute attribute, double defaultAmount, AttributeSlot defaultSlot, Material icon) {
        this.displayName = displayName;
        this.attribute = attribute;
        this.defaultAmount = defaultAmount;
        this.defaultSlot = defaultSlot;
        this.icon = icon;
    }

    public String displayName() { return displayName; }
    public Attribute attribute() { return attribute; }
    public double defaultAmount() { return defaultAmount; }
    public AttributeSlot defaultSlot() { return defaultSlot; }
    public Material icon() { return icon; }
}

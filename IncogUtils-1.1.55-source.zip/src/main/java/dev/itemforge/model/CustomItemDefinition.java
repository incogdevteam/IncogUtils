package dev.itemforge.model;

import org.bukkit.Material;
import org.bukkit.inventory.ItemRarity;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class CustomItemDefinition {
    private final String id;
    private Material material;
    private String name;
    private List<String> lore = new ArrayList<>();
    private Map<String, Integer> enchantments = new LinkedHashMap<>();
    private List<AbilityDefinition> abilities = new ArrayList<>();
    private List<DropRule> dropRules = new ArrayList<>();
    private List<AttributeDefinition> attributes = new ArrayList<>();
    private RecipeDefinition recipe = new RecipeDefinition();
    private String itemModel = "";
    private Integer customModelData;
    private String leatherColor = "";
    private boolean unbreakable;
    private boolean glint;
    private boolean hideTooltip;
    private boolean hideEnchantments;
    private boolean hideAttributes;
    private Integer maxStackSize;
    private Integer maxDurability;
    private ItemRarity rarity = ItemRarity.COMMON;

    public CustomItemDefinition(String id, Material material) {
        this.id = id;
        this.material = material;
        this.name = "<white>" + friendlyName(id) + "</white>";
    }

    public String id() { return id; }
    public Material material() { return material; }
    public void setMaterial(Material material) { this.material = material; }
    public String name() { return name; }
    public void setName(String name) { this.name = name; }
    public List<String> lore() { return lore; }
    public void setLore(List<String> lore) { this.lore = new ArrayList<>(lore); }
    public Map<String, Integer> enchantments() { return enchantments; }
    public void setEnchantments(Map<String, Integer> enchantments) { this.enchantments = new LinkedHashMap<>(enchantments); }
    public List<AbilityDefinition> abilities() { return abilities; }
    public void setAbilities(List<AbilityDefinition> abilities) { this.abilities = new ArrayList<>(abilities); }
    public List<DropRule> dropRules() { return dropRules; }
    public void setDropRules(List<DropRule> dropRules) { this.dropRules = new ArrayList<>(dropRules); }
    public List<AttributeDefinition> attributes() { return attributes; }
    public void setAttributes(List<AttributeDefinition> attributes) { this.attributes = new ArrayList<>(attributes); }
    public RecipeDefinition recipe() { return recipe; }
    public void setRecipe(RecipeDefinition recipe) { this.recipe = recipe; }
    public String itemModel() { return itemModel; }
    public void setItemModel(String itemModel) { this.itemModel = itemModel == null ? "" : itemModel.trim(); }
    public Integer customModelData() { return customModelData; }
    public void setCustomModelData(Integer customModelData) { this.customModelData = customModelData; }
    public String leatherColor() { return leatherColor; }
    public void setLeatherColor(String leatherColor) { this.leatherColor = leatherColor == null ? "" : leatherColor.trim(); }
    public boolean unbreakable() { return unbreakable; }
    public void setUnbreakable(boolean unbreakable) { this.unbreakable = unbreakable; }
    public boolean glint() { return glint; }
    public void setGlint(boolean glint) { this.glint = glint; }
    public boolean hideTooltip() { return hideTooltip; }
    public void setHideTooltip(boolean hideTooltip) { this.hideTooltip = hideTooltip; }
    public boolean hideEnchantments() { return hideEnchantments; }
    public void setHideEnchantments(boolean hideEnchantments) { this.hideEnchantments = hideEnchantments; }
    public boolean hideAttributes() { return hideAttributes; }
    public void setHideAttributes(boolean hideAttributes) { this.hideAttributes = hideAttributes; }
    public Integer maxStackSize() { return maxStackSize; }
    public void setMaxStackSize(Integer maxStackSize) { this.maxStackSize = maxStackSize; }
    /** Null keeps the material's normal durability behavior. A value is a custom vanilla max damage. */
    public Integer maxDurability() { return maxDurability; }
    public void setMaxDurability(Integer maxDurability) {
        if (maxDurability != null && maxDurability < 1) throw new IllegalArgumentException("Max durability must be at least 1");
        this.maxDurability = maxDurability;
    }
    public ItemRarity rarity() { return rarity; }
    public void setRarity(ItemRarity rarity) { this.rarity = rarity == null ? ItemRarity.COMMON : rarity; }

    public CustomItemDefinition copyAs(String newId) {
        CustomItemDefinition copy = new CustomItemDefinition(newId, material);
        copy.name = name;
        copy.lore = new ArrayList<>(lore);
        copy.enchantments = new LinkedHashMap<>(enchantments);
        copy.abilities = new ArrayList<>(abilities);
        copy.dropRules = new ArrayList<>(dropRules);
        copy.attributes = new ArrayList<>(attributes);
        copy.recipe = recipe.copy();
        copy.itemModel = itemModel;
        copy.customModelData = customModelData;
        copy.leatherColor = leatherColor;
        copy.unbreakable = unbreakable;
        copy.glint = glint;
        copy.hideTooltip = hideTooltip;
        copy.hideEnchantments = hideEnchantments;
        copy.hideAttributes = hideAttributes;
        copy.maxStackSize = maxStackSize;
        copy.maxDurability = maxDurability;
        copy.rarity = rarity;
        return copy;
    }

    private static String friendlyName(String id) {
        String[] words = id.replace('-', '_').split("_");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (word.isBlank()) continue;
            if (!result.isEmpty()) result.append(' ');
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }
}

package dev.itemforge.model;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public record DropRule(DropType type, String source, double chancePercent, int minAmount, int maxAmount) {
    public DropRule {
        if (type == null) {
            throw new IllegalArgumentException("Drop type is required");
        }
        source = source == null ? "" : source.trim().toLowerCase(Locale.ROOT);
        if (source.isBlank()) {
            throw new IllegalArgumentException("Drop source is required");
        }
        if (!Double.isFinite(chancePercent) || chancePercent < 0.0 || chancePercent > 100.0) {
            throw new IllegalArgumentException("Chance must be between 0 and 100");
        }
        if (minAmount < 1 || maxAmount < minAmount) {
            throw new IllegalArgumentException("Amounts must be at least 1 and max must be >= min");
        }
    }

    public static DropRule fromMap(Map<?, ?> map) {
        Object rawType = map.containsKey("type") ? map.get("type") : "MOB";
        Object rawSource = map.containsKey("source") ? map.get("source") : "zombie";
        DropType type = DropType.valueOf(String.valueOf(rawType).toUpperCase(Locale.ROOT));
        String source = String.valueOf(rawSource);
        double chance = number(map.get("chance-percent"), 5.0).doubleValue();
        int min = number(map.get("min-amount"), 1).intValue();
        int max = number(map.get("max-amount"), min).intValue();
        return new DropRule(type, source, chance, min, max);
    }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("type", type.name());
        map.put("source", source);
        map.put("chance-percent", chancePercent);
        map.put("min-amount", minAmount);
        map.put("max-amount", maxAmount);
        return map;
    }

    private static Number number(Object value, Number fallback) {
        return value instanceof Number number ? number : fallback;
    }
}

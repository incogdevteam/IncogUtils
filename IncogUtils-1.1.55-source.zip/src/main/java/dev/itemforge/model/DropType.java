package dev.itemforge.model;

public enum DropType {
    MOB,
    BLOCK,
    LOOT_TABLE
}

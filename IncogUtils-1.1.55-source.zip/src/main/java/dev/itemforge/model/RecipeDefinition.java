package dev.itemforge.model;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class RecipeDefinition {
    private boolean enabled;
    private boolean shapeless;
    private List<String> shape = List.of("   ", "   ", "   ");
    private Map<Character, String> ingredients = new LinkedHashMap<>();

    public boolean enabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean shapeless() {
        return shapeless;
    }

    public void setShapeless(boolean shapeless) {
        this.shapeless = shapeless;
    }

    public List<String> shape() {
        return shape;
    }

    public void setShape(List<String> shape) {
        if (shape == null || shape.size() != 3 || shape.stream().anyMatch(line -> line == null || line.length() != 3)) {
            throw new IllegalArgumentException("Recipe shape must contain three rows of three characters");
        }
        this.shape = List.copyOf(shape);
    }

    public Map<Character, String> ingredients() {
        return ingredients;
    }

    public void setIngredients(Map<Character, String> ingredients) {
        this.ingredients = new LinkedHashMap<>(ingredients);
    }

    public RecipeDefinition copy() {
        RecipeDefinition copy = new RecipeDefinition();
        copy.enabled = enabled;
        copy.shapeless = shapeless;
        copy.shape = List.copyOf(shape);
        copy.ingredients = new LinkedHashMap<>(ingredients);
        return copy;
    }
}

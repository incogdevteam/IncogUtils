package dev.itemforge.prompt;

import dev.itemforge.ItemForgePlugin;
import dev.itemforge.util.Texts;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class ChatPromptManager implements Listener {
    private final ItemForgePlugin plugin;
    private final Map<UUID, Prompt> prompts = new ConcurrentHashMap<>();

    public ChatPromptManager(ItemForgePlugin plugin) {
        this.plugin = plugin;
    }

    public void ask(Player player, Component instruction, Consumer<String> answer, Runnable cancelled) {
        prompts.put(player.getUniqueId(), new Prompt(answer, cancelled));
        player.closeInventory();
        player.sendMessage(Component.empty());
        player.sendMessage(instruction);
        player.sendMessage(Texts.mini("<gray>Type your answer in chat, or type <yellow>cancel</yellow>.</gray>"));
    }

    public boolean isPrompted(Player player) {
        return prompts.containsKey(player.getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncChatEvent event) {
        Prompt prompt = prompts.remove(event.getPlayer().getUniqueId());
        if (prompt == null) return;
        event.setCancelled(true);
        String answer = Texts.plain(event.message()).trim();
        Bukkit.getScheduler().runTask(plugin.host(), () -> {
            if (answer.equalsIgnoreCase("cancel")) {
                prompt.cancelled().run();
            } else {
                prompt.answer().accept(answer);
            }
        });
    }

    public void clear() {
        prompts.clear();
    }

    private record Prompt(Consumer<String> answer, Runnable cancelled) {
    }
}

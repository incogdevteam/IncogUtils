package dev.itemforge.recipe;

import dev.itemforge.ItemForgePlugin;
import dev.itemforge.item.ItemRegistry;
import dev.itemforge.model.CustomItemDefinition;
import dev.itemforge.model.RecipeDefinition;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class CustomRecipeManager {
    private final ItemForgePlugin plugin;
    private final ItemRegistry items;
    private final Set<NamespacedKey> registered = new HashSet<>();

    public CustomRecipeManager(ItemForgePlugin plugin, ItemRegistry items) {
        this.plugin = plugin;
        this.items = items;
    }

    public void registerAll() {
        unregisterAll();
        for (CustomItemDefinition item : items.all()) {
            RecipeDefinition recipe = item.recipe();
            if (!recipe.enabled() || recipe.ingredients().isEmpty()) continue;
            try {
                register(item);
            } catch (RuntimeException exception) {
                plugin.problems().error("recipe.register." + item.id(), "Could not register recipe for '" + item.id() + "'", exception);
            }
        }
    }

    private void register(CustomItemDefinition item) {
        NamespacedKey key = new NamespacedKey(plugin.host(), "craft_" + item.id());
        RecipeDefinition definition = item.recipe();
        ItemStack result = items.build(item, 1);
        if (definition.shapeless()) {
            ShapelessRecipe recipe = new ShapelessRecipe(key, result);
            recipe.setGroup("itemforge");
            for (String row : definition.shape()) {
                for (char ingredientKey : row.toCharArray()) {
                    if (ingredientKey == ' ') continue;
                    String descriptor = definition.ingredients().get(ingredientKey);
                    if (descriptor != null) recipe.addIngredient(toChoice(descriptor));
                }
            }
            Bukkit.addRecipe(recipe);
        } else {
            ShapedRecipe recipe = new ShapedRecipe(key, result);
            recipe.shape(definition.shape().toArray(String[]::new));
            recipe.setGroup("itemforge");
            for (Map.Entry<Character, String> ingredient : definition.ingredients().entrySet()) {
                recipe.setIngredient(ingredient.getKey(), toChoice(ingredient.getValue()));
            }
            Bukkit.addRecipe(recipe);
        }
        registered.add(key);
    }

    private RecipeChoice toChoice(String descriptor) {
        if (descriptor.startsWith("item:")) {
            String id = descriptor.substring("item:".length());
            ItemStack exact = items.build(id, 1);
            if (exact == null) throw new IllegalArgumentException("Unknown custom ingredient: " + id);
            return new RecipeChoice.ExactChoice(exact);
        }
        if (descriptor.startsWith("material:")) {
            Material material = Material.matchMaterial(descriptor.substring("material:".length()));
            if (material == null || !material.isItem()) throw new IllegalArgumentException("Unknown material ingredient: " + descriptor);
            return new RecipeChoice.MaterialChoice(material);
        }
        throw new IllegalArgumentException("Unknown ingredient descriptor: " + descriptor);
    }

    public void unregisterAll() {
        registered.forEach(Bukkit::removeRecipe);
        registered.clear();
    }
}

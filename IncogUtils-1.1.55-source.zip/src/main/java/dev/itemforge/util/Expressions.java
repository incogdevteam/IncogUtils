package dev.itemforge.util;

import java.util.Locale;
import java.util.Map;

public final class Expressions {
    private Expressions() {
    }

    public static double evaluate(Object input, Map<String, Double> variables, double fallback) {
        if (input instanceof Number number) return number.doubleValue();
        if (input == null) return fallback;
        String expression = String.valueOf(input).trim();
        if (expression.isEmpty()) return fallback;
        try {
            return new Parser(expression, variables).parse();
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static final class Parser {
        private final String input;
        private final Map<String, Double> variables;
        private int position;

        private Parser(String input, Map<String, Double> variables) {
            this.input = input.replace("{", "").replace("}", "");
            this.variables = variables;
        }

        double parse() {
            double value = expression();
            whitespace();
            if (position != input.length() || !Double.isFinite(value)) throw new IllegalArgumentException("Invalid expression");
            return value;
        }

        private double expression() {
            double value = term();
            while (true) {
                whitespace();
                if (take('+')) value += term();
                else if (take('-')) value -= term();
                else return value;
            }
        }

        private double term() {
            double value = factor();
            while (true) {
                whitespace();
                if (take('*')) value *= factor();
                else if (take('/')) value /= factor();
                else return value;
            }
        }

        private double factor() {
            whitespace();
            if (take('+')) return factor();
            if (take('-')) return -factor();
            if (take('(')) {
                double value = expression();
                whitespace();
                if (!take(')')) throw new IllegalArgumentException("Missing parenthesis");
                return value;
            }
            if (position < input.length() && (Character.isLetter(input.charAt(position)) || input.charAt(position) == '_')) {
                int start = position++;
                while (position < input.length() && (Character.isLetterOrDigit(input.charAt(position)) || input.charAt(position) == '_')) position++;
                String name = input.substring(start, position).toLowerCase(Locale.ROOT);
                Double value = variables.get(name);
                if (value == null) throw new IllegalArgumentException("Unknown variable");
                return value;
            }
            int start = position;
            while (position < input.length()) {
                char current = input.charAt(position);
                if (Character.isDigit(current) || current == '.') position++;
                else break;
            }
            if (start == position) throw new IllegalArgumentException("Expected value");
            return Double.parseDouble(input.substring(start, position));
        }

        private void whitespace() {
            while (position < input.length() && Character.isWhitespace(input.charAt(position))) position++;
        }

        private boolean take(char expected) {
            if (position < input.length() && input.charAt(position) == expected) {
                position++;
                return true;
            }
            return false;
        }
    }
}

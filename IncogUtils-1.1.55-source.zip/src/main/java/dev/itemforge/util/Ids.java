package dev.itemforge.util;

import java.util.Locale;
import java.util.regex.Pattern;

public final class Ids {
    private static final Pattern VALID = Pattern.compile("[a-z0-9][a-z0-9_-]{1,47}");

    private Ids() {
    }

    public static String normalize(String input) {
        return input == null ? "" : input.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
    }

    public static boolean isValid(String input) {
        return input != null && VALID.matcher(input).matches();
    }
}

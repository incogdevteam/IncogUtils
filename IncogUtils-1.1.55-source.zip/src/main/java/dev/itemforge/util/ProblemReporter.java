package dev.itemforge.util;

import dev.itemforge.ItemForgePlugin;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public final class ProblemReporter {
    private final ItemForgePlugin plugin;
    private final Map<String, Entry> entries = new ConcurrentHashMap<>();

    public ProblemReporter(ItemForgePlugin plugin) {
        this.plugin = plugin;
    }

    public void warning(String key, String message) {
        report(Level.WARNING, key, message, null);
    }

    public void error(String key, String message, Throwable throwable) {
        report(Level.SEVERE, key, message, throwable);
    }

    public void report(Level level, String key, String message, Throwable throwable) {
        if (!quiet()) {
            log(level, message, throwable, true);
            return;
        }
        long now = System.currentTimeMillis();
        long window = Math.max(10L, plugin.getConfig().getLong("logging.repeat-window-seconds", 300L)) * 1000L;
        Entry current = entries.computeIfAbsent(key, ignored -> new Entry());
        synchronized (current) {
            if (now - current.lastLogged < window) {
                current.suppressed++;
                return;
            }
            String suffix = current.suppressed == 0 ? "" : " (suppressed " + current.suppressed + " repeat(s))";
            current.lastLogged = now;
            current.suppressed = 0;
            boolean includeTrace = plugin.getConfig().getBoolean("logging.include-stack-traces-in-quiet-mode", false);
            log(level, message + suffix + " [quiet mode]", throwable, includeTrace);
        }
    }

    public boolean quiet() {
        return plugin.getConfig().getString("logging.mode", "quiet").equalsIgnoreCase("quiet");
    }

    public void setQuiet(boolean quiet) {
        plugin.getConfig().set("logging.mode", quiet ? "quiet" : "normal");
        plugin.saveConfig();
        entries.clear();
    }

    public void clear() {
        entries.clear();
    }

    private void log(Level level, String message, Throwable throwable, boolean includeTrace) {
        if (throwable != null && includeTrace) plugin.getLogger().log(level, message, throwable);
        else plugin.getLogger().log(level, message + (throwable == null ? "" : ": " + throwable.getMessage()));
    }

    private static final class Entry {
        private long lastLogged;
        private int suppressed;
    }
}

package dev.itemforge.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

public final class Texts {
    private static final MiniMessage MINI = MiniMessage.miniMessage();
    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();

    private Texts() {
    }

    public static Component mini(String value) {
        try {
            return MINI.deserialize(value == null ? "" : value);
        } catch (RuntimeException ignored) {
            return Component.text(value == null ? "" : value, NamedTextColor.WHITE);
        }
    }

    public static String plain(Component value) {
        return PLAIN.serialize(value);
    }
}

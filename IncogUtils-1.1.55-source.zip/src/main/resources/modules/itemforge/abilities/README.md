# ItemForge custom abilities

Each `.yml` or `.yaml` file in this folder defines one ability. Files may also be
placed in subfolders. ItemForge loads them on startup and whenever an admin runs:

    /itemforge abilities reload

Copy `example_frost_burst.yml` for a safe starting point. Give the copy a unique
lowercase `id`, set `enabled: true`, and edit its actions. The in-game ability
menu automatically shows every successfully loaded definition.

## Definition fields

```yaml
enabled: true
id: example_ability
display-name: "<aqua>Example Ability"
description:
  - "<gray>Shown in the item editor</gray>"
icon: AMETHYST_SHARD
trigger: RIGHT_CLICK
require-player-target: false # Only activate when the event target is a player
default-power: 2.0
default-cooldown-ticks: 60
cancel-trigger: true
permission: "" # Optional extra permission required to use this ability
actions:
  - type: ACTION_BAR
    text: "<aqua>Activated with power {power}!</aqua>"
```

Supported triggers are `RIGHT_CLICK`, `LEFT_CLICK`, `MELEE_HIT`, `DAMAGED`,
`KILL`, `SNEAK`, and `PASSIVE`. Passive abilities are checked at the interval
configured by `passive-scan-ticks` in the main `config.yml`.

Set `require-player-target: true` on a target-based ability to prevent it from
activating on mobs. This is especially useful for staff command abilities such
as ban, kick, or moderation wands.

## Common action settings

Most actions accept `target: SELF` or `target: TARGET`. When no event target is
available, `TARGET` performs a short ray trace; set `range` to change the default
12-block range. Add `chance-percent: 25` to any action for a 25% activation chance.

Numeric fields can contain simple expressions using `+`, `-`, `*`, `/`, and
parentheses. Available variables are `{power}`, `{damage}`, `{health}`,
`{max_health}`, and `{period}`. `{period}` is the passive scan interval in ticks.

Text and commands support `{player}`, `{target}`, `{item_id}`, `{ability_id}`,
`{power}`, and `{damage}` placeholders. Display names, descriptions, messages,
and action bars support MiniMessage formatting.

## Action reference

- `VELOCITY`: `target`, `multiplier`, `vertical`, `add`
- `PROJECTILE`: `projectile`, `speed`, `damage`, `gravity`, `incendiary`
  - Projectiles: `SMALL_FIREBALL`, `FIREBALL`, `ARROW`, `SNOWBALL`, `EGG`,
    `ENDER_PEARL`, or `TRIDENT`
- `HEAL`: `target`, `amount`
- `DAMAGE`: `target`, `amount`, `mode`
  - Modes: `DIRECT`, `ADD`, or `SET`. `ADD` and `SET` modify an existing hit.
- `POTION`: `target`, `effect`, `duration-ticks`, `amplifier`, `ambient`,
  `particles`, `icon`
- `LIGHTNING`: `target`, `real`
- `COMMAND`: `command`, `as-player`
  - Commands run as console by default. Never install untrusted ability files.
- `MESSAGE`: `text`
- `ACTION_BAR`: `text`
- `SOUND`: `target`, `sound`, `volume`, `pitch`
- `PARTICLE`: `target`, `particle`, `count`, `offset-location-y`, `offset-x`,
  `offset-y`, `offset-z`, `extra`
- `FIRE`: `target`, `ticks`
- `EXPLOSION`: `target`, `power`, `set-fire`, `break-blocks`

Minecraft registry keys such as `minecraft:speed` are recommended for potion
effects and sounds. Bukkit/Purpur enum names such as `SNOWFLAKE` are used for
particles and projectiles.

## Troubleshooting

One broken file does not stop the other abilities from loading. ItemForge reports
the filename and continues. Quiet logging mode rate-limits repeated runtime errors:

    /itemforge logging quiet

Temporarily use `/itemforge logging normal` while authoring a file if you want a
full error for every failed activation.

package com.incogdev.incogclaims.integrations;

import com.incogdev.incogclaims.data.ClaimType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TabListIntegrationTest {
    @Test
    void markerUsesConfiguredIconAndExpectedColor() {
        assertEquals(" &a[P]&r", TabListIntegration.marker(ClaimType.PEACEFUL, "[P]", "[A]"));
        assertEquals(" &c⚔&r", TabListIntegration.marker(ClaimType.PVP, "☮", "⚔"));
        assertEquals("", TabListIntegration.marker(null, "[P]", "[A]"));
    }

    @Test
    void stripsOnlyTrailingPlaystyleMarkerAndPreservesRankSuffix() {
        assertEquals("&7VIP", TabListIntegration.stripPlaystyleSuffix("&7VIP &a[P]&r", "[P]", "[A]"));
        assertEquals("§6Admin", TabListIntegration.stripPlaystyleSuffix("§6Admin §c§l[A]§r", "[P]", "[A]"));
        assertEquals("&7[P] Builder", TabListIntegration.stripPlaystyleSuffix("&7[P] Builder", "[P]", "[A]"));
    }

    @Test
    void stripsDuplicatesAndCustomIconsAcrossFormattingStyles() {
        assertEquals("&bRank", TabListIntegration.stripPlaystyleSuffix("&bRank &a☮&r §a☮§r", "☮", "⚔"));
        assertEquals("", TabListIntegration.stripPlaystyleSuffix(" &c[A]&r", "☮", "⚔"));
    }
}

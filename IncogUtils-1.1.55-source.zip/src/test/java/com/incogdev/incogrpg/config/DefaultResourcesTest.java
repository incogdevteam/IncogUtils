package com.incogdev.incogrpg.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class DefaultResourcesTest {
    @Test void allYamlFilesParseAndCatalogsAreLarge() throws Exception {
        for (String file : new String[]{"config.yml", "messages.yml", "skills.yml", "enchants.yml", "reforges.yml", "items.yml", "relics.yml", "pets.yml", "achievements.yml", "plugin.yml"}) {
            YamlConfiguration yaml = new YamlConfiguration();
            yaml.load(new File("src/main/resources", file));
            assertFalse(yaml.getKeys(false).isEmpty(), file + " should not be empty");
        }
        YamlConfiguration skills = YamlConfiguration.loadConfiguration(new File("src/main/resources/skills.yml"));
        YamlConfiguration enchants = YamlConfiguration.loadConfiguration(new File("src/main/resources/enchants.yml"));
        YamlConfiguration reforges = YamlConfiguration.loadConfiguration(new File("src/main/resources/reforges.yml"));
        YamlConfiguration items = YamlConfiguration.loadConfiguration(new File("src/main/resources/items.yml"));
        YamlConfiguration relics = YamlConfiguration.loadConfiguration(new File("src/main/resources/relics.yml"));
        YamlConfiguration pets = YamlConfiguration.loadConfiguration(new File("src/main/resources/pets.yml"));
        YamlConfiguration achievements = YamlConfiguration.loadConfiguration(new File("src/main/resources/achievements.yml"));
        assertEquals(17, skills.getConfigurationSection("skills").getKeys(false).size());
        assertEquals(100, enchants.getConfigurationSection("enchants").getKeys(false).size());
        assertEquals(52, reforges.getConfigurationSection("reforges").getKeys(false).size());
        assertEquals(26, items.getConfigurationSection("items").getKeys(false).size());
        assertEquals(51, relics.getConfigurationSection("items").getKeys(false).size());
        assertEquals(175, pets.getConfigurationSection("skill-pools").getKeys(false).stream()
                .mapToInt(skill -> pets.getMapList("skill-pools." + skill + ".pets").size()).sum());
        assertFalse(pets.getBoolean("settings.enabled"), "pets must remain opt-in by default");
        assertEquals(34, achievements.getConfigurationSection("achievements").getKeys(false).size());
        YamlConfiguration core = YamlConfiguration.loadConfiguration(new File("src/main/resources/config.yml"));
        assertTrue(core.getBoolean("hud.health.limit-vanilla-hearts"));
        assertEquals(10.0, core.getDouble("hud.health.visible-hearts"));
        assertEquals(3, core.getInt("accessory-bag.slots"));
        assertTrue(core.getBoolean("accessory-bag.include-milestone-rewards"));
        assertTrue(core.getBoolean("freeze.enabled"));
        assertTrue(core.getBoolean("freeze.persist-across-restarts"));
        YamlConfiguration plugin = YamlConfiguration.loadConfiguration(new File("src/main/resources/plugin.yml"));
        assertEquals("IncogUtils", plugin.getString("name"));
        assertTrue(plugin.getConfigurationSection("commands").contains("menus"));
        assertEquals("incogutils.menus", plugin.getString("commands.menus.permission"));
        assertTrue(plugin.getConfigurationSection("commands").contains("freeze"));
        assertEquals("incogutils.freeze", plugin.getString("commands.freeze.permission"));
        assertTrue(plugin.getConfigurationSection("commands").contains("reload"));
        assertEquals("incogrpg.admin.reload", plugin.getString("commands.reload.permission"));
        assertTrue(plugin.getConfigurationSection("commands").contains("shopdistrict"));
        assertEquals("incogshop.shoppingdistrict", plugin.getString("commands.shopdistrict.permission"));
        assertTrue(plugin.getConfigurationSection("commands").contains("globalrestock"));
        assertEquals("incogshop.admin.globalrestock", plugin.getString("commands.globalrestock.permission"));
        assertTrue(plugin.getConfigurationSection("commands").contains("weeklystock"));
        assertEquals("incogshop.weeklystock", plugin.getString("commands.weeklystock.permission"));
        assertTrue(plugin.getConfigurationSection("commands").contains("regenkey"));
        assertEquals("incogvaults.admin.keys", plugin.getString("commands.regenkey.permission"));
        YamlConfiguration economy = YamlConfiguration.loadConfiguration(new File("src/main/resources/modules/economy/config.yml"));
        assertTrue(economy.getBoolean("market.daily-flux.enabled"));
        assertEquals(4, economy.getInt("market.daily-flux.minimum-items"));
        assertEquals(12, economy.getInt("market.daily-flux.maximum-items"));
        assertEquals(0.80, economy.getDouble("market.daily-flux.minimum-multiplier"));
        assertEquals(1.75, economy.getDouble("market.daily-flux.maximum-multiplier"));
        assertTrue(economy.getBoolean("market.weekly-infinite-stock.enabled"));
        assertEquals(90, economy.getInt("market.weekly-infinite-stock.duration-minutes"));
        assertEquals(List.of("cryptic"), economy.getStringList("market.weekly-infinite-stock.ranks.cryptic.luckperms-groups"));
        assertEquals(1, economy.getInt("market.weekly-infinite-stock.ranks.cryptic.item-count"));
        assertEquals(2, economy.getInt("market.weekly-infinite-stock.ranks.incog.item-count"));
        assertEquals(3, economy.getInt("market.weekly-infinite-stock.ranks.incogplus.item-count"));
        assertTrue(economy.getBoolean("market.protected-item-namespaces.enabled"));
        assertEquals("STICK", economy.getString("sell-wands.material"));
        assertEquals(100, economy.getInt("shopping-district.plots.max-size"));
        assertEquals(40, economy.getInt("shopping-district.plots.starter-size"));
        assertEquals(50, economy.getInt("shopping-district.plots.base-max-size"));
        assertEquals(60, economy.getInt("shopping-district.plots.rank-expansions.secret.maximum-size"));
        assertEquals(100, economy.getInt("shopping-district.plots.rank-expansions.incogplus.maximum-size"));
        assertTrue(economy.getBoolean("shopping-district.generation.outer-world-border.enabled"));
        assertEquals(16, economy.getInt("shopping-district.generation.outer-world-border.padding"));
        assertEquals(4, economy.getInt("shopping-district.generation.void-rescue-below-floor"));
        assertTrue(economy.getBoolean("shopping-district.generation.outer-safety-barriers.enabled"));
        assertEquals(4, economy.getInt("shopping-district.generation.outer-safety-barriers.height"));
        assertEquals("BARRIER", economy.getString("shopping-district.generation.outer-safety-barriers.material"));
        assertEquals(1, economy.getInt("shopping-district.generation.lazy-islands-migration-version"));
        assertTrue(economy.getBoolean("shopping-district.plots.auto-assign-on-first-join"));
        assertTrue(economy.getBoolean("shopping-district.template.templates.shack.placement.use-content-bounds"));
        assertEquals(0, economy.getInt("shopping-district.template.templates.shack.placement.y-offset"));
        assertEquals(1, economy.getInt("shopping-district.template.schematic-layers-per-tick"));
        assertTrue(economy.getBoolean("shopping-district.owner-shop-holograms.enabled"));
        assertEquals("&aYour Shop", economy.getString("shopping-district.owner-shop-holograms.text"));
        assertFalse(economy.getBoolean("shopping-district.protection.allow-pvp"));
        assertEquals(1, economy.getInt("shopping-district.protection.policy-migration-version"));
        assertTrue(economy.getBoolean("shopping-district.inventory-sharing.enabled"));
        assertEquals("world", economy.getString("shopping-district.inventory-sharing.source-world"));
        assertEquals("auto", economy.getString("shopping-district.inventory-sharing.group"));
        assertEquals(List.of("inventory"), economy.getStringList("shopping-district.inventory-sharing.shares"));
    }

    @Test void achievementTreeReferencesAndMetricsResolve() {
        YamlConfiguration achievements = YamlConfiguration.loadConfiguration(new File("src/main/resources/achievements.yml"));
        YamlConfiguration skills = YamlConfiguration.loadConfiguration(new File("src/main/resources/skills.yml"));
        YamlConfiguration items = YamlConfiguration.loadConfiguration(new File("src/main/resources/items.yml"));
        YamlConfiguration relics = YamlConfiguration.loadConfiguration(new File("src/main/resources/relics.yml"));
        var root = achievements.getConfigurationSection("achievements");
        Set<String> ids = root.getKeys(false);
        Set<String> skillIds = skills.getConfigurationSection("skills").getKeys(false);
        Set<String> itemIds = items.getConfigurationSection("items").getKeys(false);
        ids.forEach(id -> {
            String parent = root.getString(id + ".parent", "");
            if (!parent.isBlank()) assertTrue(ids.contains(parent), id + " references missing parent " + parent);
            root.getMapList(id + ".requirements").forEach(requirement -> {
                String metric = String.valueOf(requirement.get("metric"));
                assertTrue(com.incogdev.incogrpg.service.AchievementService.BUILT_IN_METRICS.contains(metric),
                        id + " uses unsupported built-in metric " + metric);
                assertTrue(((Number) requirement.get("amount")).doubleValue() > 0, id + " has a non-positive requirement");
            });
            var rewardItems = root.getConfigurationSection(id + ".rewards.items");
            if (rewardItems != null) rewardItems.getKeys(false).forEach(item -> assertTrue(itemIds.contains(item), id + " rewards missing item " + item));
            var rewardXp = root.getConfigurationSection(id + ".rewards.skill-xp");
            if (rewardXp != null) rewardXp.getKeys(false).forEach(skill -> assertTrue(skillIds.contains(skill), id + " rewards missing skill " + skill));
        });
        assertTrue(ids.stream().anyMatch(id -> root.getBoolean(id + ".hidden")), "tree should include hidden branches");
        assertTrue(ids.stream().filter(id -> root.getString(id + ".frame", "TASK").equals("CHALLENGE")).count() >= 10);
    }

    @Test void customItemAndMilestoneReferencesResolve() {
        YamlConfiguration skills = YamlConfiguration.loadConfiguration(new File("src/main/resources/skills.yml"));
        YamlConfiguration enchants = YamlConfiguration.loadConfiguration(new File("src/main/resources/enchants.yml"));
        YamlConfiguration reforges = YamlConfiguration.loadConfiguration(new File("src/main/resources/reforges.yml"));
        YamlConfiguration items = YamlConfiguration.loadConfiguration(new File("src/main/resources/items.yml"));
        YamlConfiguration relics = YamlConfiguration.loadConfiguration(new File("src/main/resources/relics.yml"));
        var itemRoot = items.getConfigurationSection("items");
        var relicRoot = relics.getConfigurationSection("items");
        Set<String> itemIds = new java.util.LinkedHashSet<>(itemRoot.getKeys(false));
        itemIds.addAll(relicRoot.getKeys(false));
        Set<String> enchantIds = enchants.getConfigurationSection("enchants").getKeys(false);
        Set<String> reforgeIds = reforges.getConfigurationSection("reforges").getKeys(false);
        itemIds.forEach(id -> {
            var catalog = itemRoot.contains(id) ? itemRoot : relicRoot;
            var enchantSection = catalog.getConfigurationSection(id + ".enchants");
            if (enchantSection != null) enchantSection.getKeys(false).forEach(enchant ->
                    assertTrue(enchantIds.contains(enchant), id + " references missing enchant " + enchant));
            String reforge = catalog.getString(id + ".reforge", "");
            if (!reforge.isBlank()) assertTrue(reforgeIds.contains(reforge), id + " references missing reforge " + reforge);
            String applies = catalog.getString(id + ".applies-reforge", "");
            if (!applies.isBlank()) assertTrue(reforgeIds.contains(applies), id + " applies missing reforge " + applies);
        });
        Set<String> milestoneItemIds = new java.util.LinkedHashSet<>();
        int[] itemRewards = {0};
        var skillRoot = skills.getConfigurationSection("skills");
        skillRoot.getKeys(false).forEach(skill -> {
            var milestones = skillRoot.getConfigurationSection(skill + ".milestones");
            if (milestones == null) return;
            milestones.getKeys(false).forEach(level -> {
                var rewards = milestones.getConfigurationSection(level + ".items");
                if (rewards == null) return;
                rewards.getKeys(false).forEach(item -> {
                    assertTrue(itemIds.contains(item), skill + " references missing item " + item);
                    milestoneItemIds.add(item);
                });
                itemRewards[0] += rewards.getKeys(false).size();
            });
        });
        assertEquals(68, itemRewards[0], "each default skill should have four milestone item rewards");
        assertEquals(68, milestoneItemIds.size(), "milestone relic IDs must be unique");
        milestoneItemIds.forEach(id -> {
            var catalog = itemRoot.contains(id) ? itemRoot : relicRoot;
            assertTrue(catalog.getBoolean(id + ".milestone-exclusive"), id + " must be source guarded");
            assertNull(catalog.getConfigurationSection(id + ".recipe"), id + " must not have a random recipe");
            assertNull(catalog.getConfigurationSection(id + ".drops"), id + " must not have random drops");
        });
        YamlConfiguration achievements = YamlConfiguration.loadConfiguration(new File("src/main/resources/achievements.yml"));
        achievements.getConfigurationSection("achievements").getKeys(false).forEach(achievement -> {
            var rewardItems = achievements.getConfigurationSection("achievements." + achievement + ".rewards.items");
            if (rewardItems != null) rewardItems.getKeys(false).forEach(id ->
                    assertFalse(milestoneItemIds.contains(id), achievement + " must not leak milestone-exclusive " + id));
        });
        long stoneOnly = reforgeIds.stream().filter(id -> !reforges.getBoolean("reforges." + id + ".roll-enabled", true))
                .filter(id -> reforges.getStringList("reforges." + id + ".natural-sources").isEmpty()).count();
        long naturalOnly = reforgeIds.stream().filter(id -> !reforges.getBoolean("reforges." + id + ".roll-enabled", true))
                .filter(id -> !reforges.getStringList("reforges." + id + ".natural-sources").isEmpty()).count();
        long stones = itemIds.stream().filter(id -> {
            var catalog = itemRoot.contains(id) ? itemRoot : relicRoot;
            return !catalog.getString(id + ".applies-reforge", "").isBlank();
        }).count();
        assertEquals(6, stoneOnly);
        assertEquals(10, naturalOnly);
        assertEquals(stoneOnly, stones, "every stone-only reforge should have a custom-item catalyst");
    }

    @Test void everyDefaultEnchantUsesAnImplementedEffect() {
        var supported = java.util.Set.of("AIRBORNE_DAMAGE", "AOE_ON_KILL", "ATTRIBUTE", "CHEAT_DEATH", "CLOSE_DAMAGE", "COMBO_DAMAGE", "CUSTOM_STAT",
                "DELAYED_ECHO", "DUPLICATE_RANDOM_DROP", "ELITE_SKILL_XP", "FIRST_ORE_CHUNK_DROPS", "FULL_HEALTH_DAMAGE",
                "FLAT_BONUS_DAMAGE", "GRAVITY_WELL", "HEALTH_GAP_DAMAGE", "HEAL_LOWEST_ALLY", "HEIGHT_ADVANTAGE_DAMAGE",
                "ISOLATED_DAMAGE", "ITEM_MAGNET", "KILL_ABSORPTION", "KILL_STREAK_DAMAGE", "LARGE_HIT_REDUCTION", "LIGHT_ARMOR_DAMAGE",
                "LOW_HEALTH_DAMAGE", "LOW_HEALTH_REGEN", "MARK_DAMAGE", "MISSING_HEALTH_DAMAGE", "MULTIKILL_HEAL", "NEARBY_ALLY_REDUCTION",
                "ORE_STREAK_DROPS", "PACIFIST_REDUCTION", "PROJECTILE_REDUCTION", "RADIAL_KNOCKBACK", "RARE_CATCH_XP",
                "REAR_DAMAGE", "RECENT_HURT_DAMAGE", "RETALIATE", "RICOCHET", "SECOND_WIND", "SKILL_SCALE_ATTRIBUTE",
                "SKILL_SCALE_DAMAGE", "SNEAK_REDUCTION", "SOURCE_XP_BURST", "SPRINT_DAMAGE", "STATIONARY_REDUCTION",
                "STATUS_COUNT_DAMAGE", "SURROUNDED_DAMAGE", "TARGET_MAX_HEALTH_DAMAGE", "VICTIM_HEALTH_HEAL", "WARD");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(new File("src/main/resources/enchants.yml"));
        var root = yaml.getConfigurationSection("enchants");
        root.getKeys(false).forEach(id -> root.getMapList(id + ".effects").forEach(effect ->
                assertTrue(supported.contains(String.valueOf(effect.get("type"))), id + " has unsupported effect " + effect.get("type"))));
    }

    @Test void enchantConflictsResolveAndIdsDoNotCollideWithExcellentEnchants() {
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(new File("src/main/resources/enchants.yml"));
        var root = yaml.getConfigurationSection("enchants");
        assertNotNull(root);
        Set<String> ids = root.getKeys(false);
        ids.forEach(id -> root.getStringList(id + ".conflicts").forEach(conflict ->
                assertTrue(ids.contains(conflict), id + " references missing conflict " + conflict)));
        Set<String> excellentIds = Set.of("cold_steel", "darkness_cloak", "dragon_heart", "elemental_protection",
                "fire_shield", "flame_walker", "hardened", "ice_shield", "jumping", "kamikadze", "lightweight",
                "night_vision", "rebound", "regrowth", "saturation", "speed", "stopping_force", "water_breathing",
                "bomber", "confusing_arrows", "darkness_arrows", "dragonfire_arrows", "electrified_arrows", "ender_bow",
                "explosive_arrows", "flare", "ghast", "hover", "lingering", "poisoned_arrows", "sniper",
                "vampiric_arrows", "withered_arrows", "blast_mining", "glass_breaker", "haste", "lucky_miner",
                "replanter", "silk_chest", "silk_spawner", "smelter", "telekinesis", "treefeller", "tunnel",
                "veinminer", "auto_reel", "curse_of_drowned", "double_catch", "river_master", "seasoned_angler",
                "survivalist", "bane_of_netherspawn", "blindness", "confusion", "cure", "curse_of_death", "cutter",
                "decapitator", "double_strike", "exhaust", "ice_aspect", "infernus", "nimble", "paralyze", "rage",
                "rocket", "swiper", "temper", "thrifty", "thunder", "vampire", "venom", "village_defender", "wisdom",
                "wither", "curse_of_breaking", "curse_of_fragility", "curse_of_mediocrity", "curse_of_misfortune",
                "restore", "soulbound");
        assertTrue(ids.stream().noneMatch(excellentIds::contains), "IncogRPG IDs must remain separate from ExcellentEnchants");
    }
}

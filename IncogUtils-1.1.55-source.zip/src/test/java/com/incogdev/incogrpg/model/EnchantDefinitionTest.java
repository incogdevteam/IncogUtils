package com.incogdev.incogrpg.model;

import org.bukkit.Material;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class EnchantDefinitionTest {
    @Test void chanceAndEffectScalingAreBounded() {
        EnchantDefinition enchant = new EnchantDefinition("test", "Test", List.of(), "MYTHIC", true, 5,
                Set.of("SWORDS"), Set.of(), "ATTACK", 10, 25, 0, List.of());
        assertEquals(10, enchant.procChance(1));
        assertEquals(100, enchant.procChance(5));
        assertTrue(enchant.supports(Material.DIAMOND_SWORD));
        assertFalse(enchant.supports(Material.BOW));
        var effect = new EnchantDefinition.EffectDefinition("DAMAGE", Map.of("percent", 5, "percent-per-level", 2.5));
        assertEquals(12.5, effect.scaled("percent", 4, 0), 0.0001);
    }
}

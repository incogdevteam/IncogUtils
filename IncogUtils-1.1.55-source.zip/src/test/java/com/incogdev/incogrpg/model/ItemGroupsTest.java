package com.incogdev.incogrpg.model;

import org.bukkit.Material;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ItemGroupsTest {
    @Test void itemForgeDurabilitySurvivesDefinitionCopies() {
        dev.itemforge.model.CustomItemDefinition definition = new dev.itemforge.model.CustomItemDefinition("durable_blade", Material.DIAMOND_SWORD);
        definition.setMaxDurability(2400);
        definition.setMaxStackSize(1);

        dev.itemforge.model.CustomItemDefinition copy = definition.copyAs("durable_blade_copy");

        assertEquals(2400, copy.maxDurability());
        assertEquals(1, copy.maxStackSize());
    }

    @Test void classifiesModernEquipment() {
        assertTrue(ItemGroups.matches("WEAPONS", Material.NETHERITE_SWORD));
        assertTrue(ItemGroups.matches("WEAPONS", Material.MACE));
        assertTrue(ItemGroups.matches("CHESTPLATES", Material.ELYTRA));
        assertTrue(ItemGroups.matches("TOOLS", Material.DIAMOND_HOE));
        assertFalse(ItemGroups.matches("BOWS", Material.TRIDENT));
        assertTrue(ItemGroups.matches("TRIDENTS", Material.TRIDENT));
    }
}

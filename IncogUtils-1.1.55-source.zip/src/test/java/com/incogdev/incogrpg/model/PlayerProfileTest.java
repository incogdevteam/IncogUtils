package com.incogdev.incogrpg.model;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class PlayerProfileTest {
    @Test void revisionTrackingDoesNotLoseConcurrentChanges() {
        PlayerProfile profile = new PlayerProfile(UUID.randomUUID(), "Tester");
        profile.markClean();
        profile.setProgress("mining", new SkillProgress(1, 2));
        long savingRevision = profile.revision();
        profile.setProgress("combat", new SkillProgress(2, 3));
        profile.markClean(savingRevision);
        assertTrue(profile.dirty(), "a change made after a save snapshot must remain dirty");
        profile.markClean();
        assertFalse(profile.dirty());
    }

    @Test void achievementMetricsAndUnlocksArePersistentSnapshots() {
        PlayerProfile profile = new PlayerProfile(UUID.randomUUID(), "Tester");
        assertEquals(5.0, profile.addAchievementProgress("BLOCKS_BROKEN:all", 5));
        profile.setAchievementProgress("SKILL_LEVEL:mining", 25);
        assertEquals(5.0, profile.achievementProgress("BLOCKS_BROKEN:all"));
        assertTrue(profile.completeAchievement("first_steps", 1234));
        assertFalse(profile.completeAchievement("first_steps", 5678), "an unlock must only be recorded once");
        assertTrue(profile.achievementCompleted("first_steps"));
        assertEquals(1234L, profile.completedAchievementsSnapshot().get("first_steps"));
        assertTrue(profile.revokeAchievement("first_steps"));
        assertFalse(profile.achievementCompleted("first_steps"));
        profile.resetAchievements();
        assertTrue(profile.achievementProgressSnapshot().isEmpty());
    }
}

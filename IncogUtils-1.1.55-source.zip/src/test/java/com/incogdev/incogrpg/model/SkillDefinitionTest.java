package com.incogdev.incogrpg.model;

import org.bukkit.Material;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import com.incogdev.incogrpg.service.SkillService;

class SkillDefinitionTest {
    @Test void curveIsPositiveAndIncreasing() {
        SkillDefinition skill = new SkillDefinition("mining", "Mining", List.of(), Material.DIAMOND_PICKAXE,
                true, 100, 75, 1, 1.62, List.of(), Map.of(), Map.of());
        assertEquals(75, skill.xpRequired(0), 0.0001);
        assertTrue(skill.xpRequired(50) > skill.xpRequired(10));
        assertThrows(IllegalArgumentException.class, () -> skill.xpRequired(-1));
    }

    @Test void sourceTargetModesWork() {
        assertTrue(new SkillDefinition.XpSourceDefinition("BLOCK_BREAK", 1, java.util.Set.of("_ORE"), "SUFFIX").matches("DIAMOND_ORE"));
        assertFalse(new SkillDefinition.XpSourceDefinition("BLOCK_BREAK", 1, java.util.Set.of("_LOG"), "SUFFIX").matches("STONE"));
    }

    @Test void totalXpRoundTripsAcrossLevelsAndCaps() {
        SkillDefinition skill = new SkillDefinition("mining", "Mining", List.of(), Material.DIAMOND_PICKAXE,
                true, 100, 75, 1, 1.62, List.of(), Map.of(), Map.of());
        SkillProgress original = new SkillProgress(37, 12.5);
        double total = SkillService.totalXp(skill, original);
        SkillProgress rebuilt = SkillService.progressForTotalXp(skill, total);
        assertEquals(original.level(), rebuilt.level());
        assertEquals(original.xp(), rebuilt.xp(), 0.0001);
        assertEquals(new SkillProgress(0, 0), SkillService.progressForTotalXp(skill, -500));
        assertEquals(100, SkillService.progressForTotalXp(skill, Double.MAX_VALUE).level());
        assertEquals(0, SkillService.progressForTotalXp(skill, Double.MAX_VALUE).xp());
    }
}
